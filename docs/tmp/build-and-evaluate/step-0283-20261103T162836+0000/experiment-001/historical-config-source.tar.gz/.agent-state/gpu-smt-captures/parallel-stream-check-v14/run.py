"""Native controls, then one finite Mathlib closure matrix."""
import os,json,time,sys,subprocess
from pathlib import Path
from native import run,SDK,ROOT,environment
R=Path('/workspaces/repository/research/parallel-stream-check')
ORAW=Path('/workspaces/.agent-state/gpu-smt-captures/decoupled-check-20261031')
def env():
 e=environment()
 p=json.loads(Path('/workspaces/.agent-state/gpu-smt-captures/profile-2026-10-31/startup-replay/repair-v3/preparation.json').read_text())
 e['LEAN_PATH']=str(ROOT/'fixtures')+':'+str(ORAW/'constructed/lib')+':'+p['lean_path']
 return e
def events(key):
 return [json.loads(x) for x in (ROOT/'runs'/key/'stdout').read_text().splitlines() if x.startswith('{')]
def controls():
 os.sched_setaffinity(0,set(range(8,16)))
 d=ROOT/'fixtures';d.mkdir(exist_ok=True);e=env();e['LEAN_PATH']=str(d)+':'+str(SDK/'lib/lean')
 cases={
 'DupA':'namespace Shared\ntheorem t : True := True.intro\nend Shared\n',
 'DupB':'namespace Shared\ntheorem t : True := True.intro\nend Shared\n',
 'ExtraA':'namespace Shared\ntheorem externalProof : True := True.intro\nend Shared\n',
 'ExtraB':'namespace LocalB\ntheorem result : True := True.intro\nend LocalB\n',
 'DupDeps':'namespace Shared\ntheorem helper : True := True.intro\ntheorem t : True := helper\nend Shared\n',
 'DefA':'namespace Shared\ndef f : Nat := 0\nend Shared\n',
 'DefB':'namespace Shared\ndef f : Nat := 1\nend Shared\n',
 'PrivateA':'private theorem helper : True := True.intro\ntheorem privateA : True := helper\n',
 'PrivateB':'private theorem helper : True := True.intro\ntheorem privateB : True := helper\n',
 'Waves':'def a : Nat := 7\ndef b : Nat := 8\ntheorem aa : Eq a a := Eq.refl a\ntheorem bb : Eq b b := Eq.refl b\ntheorem cc : Eq a a := aa\n'}
 for mod,text in cases.items():
  p=d/(mod+'.lean');p.write_text('prelude\nimport Init.Prelude\n'+text)
  r=run('fixture-'+mod,[SDK/'bin/lean','--root='+str(d),'-o',d/(mod+'.olean'),p],60,False,e)
  if r['returncode']:raise RuntimeError('compile fixture')
  # Deliberately cyclic raw proof data, never a successfully compiled proof.
 ee=e.copy();ee['PARALLEL_CONTROL_OUT']=str(d)
 rr=run('generate-raw-cycle',[SDK/'bin/lean','--run',ROOT/'source/RawControls.lean'],90,False,ee)
 if rr['returncode']:raise RuntimeError('raw control generator failed')
 os.sched_setaffinity(0,set(range(8)))
 # Preserve a red native result against the previously measured v4 binary.
 prior=Path('/workspaces/.agent-state/gpu-smt-captures/parallel-stream-check-v4/parallel-stream')
 if prior.exists():
  red=run('hidden-cycle-v4-red',[prior,'parallel','none','DupA','Cyclic'],90,False,e)
  if red['returncode']!=0:raise RuntimeError('expected prior hidden-cycle acceptance not reproduced')
 else:
  (ROOT/'historical-red-unavailable.json').write_text(json.dumps(dict(reason='historical v4 binary absent; current rejection controls still required')))
 isolated=run('hidden-cycle-native-oracle',[ROOT/'parallel-stream','one','none','Cyclic'],90,False,e)
 if isolated['returncode']!=1 or not any(x.get('event')=='reject'for x in events('hidden-cycle-native-oracle')):
  raise RuntimeError('isolated native rejection control did not qualify')
 controls=[
 ('ordinary','none',None,['DupA','DupB'],True,None),
 ('duplicate-local-deps','none',None,['DupA','DupDeps'],True,None),
 ('hidden-cycle','none',None,['DupA','Cyclic'],False,None),
 ('corrupt','bvar','DupB',['DupA','DupB'],False,None),
 ('sibling','sibling','ExtraB',['ExtraA','ExtraB'],False,None),
 ('definitions','none',None,['DefA','DefB'],True,None),
 ('private','none',None,['PrivateA','PrivateB'],True,None),
 ('waves','none',None,['Waves'],True,None),
 ('duplicate-token','none',None,['Waves'],False,'duplicate'),
 ('stale-token','none',None,['Waves'],False,'stale')]
 rows=[]
 for name,mutation,target,roots,expected,fault in controls:
  for workers in [1,8]:
   ee=e.copy();ee['PARALLEL_WORKERS']=str(workers)
   if target:ee['DECOUPLED_MUTATE_MODULE']=target
   if fault:ee['PARALLEL_FAULT']=fault
   key=name+'-'+str(workers)
   rr=run(key,[ROOT/'parallel-stream','parallel',mutation]+roots,180,False,ee)
   ev=events(key);reject=any(x.get('event')=='reject' for x in ev)
   ok=rr['returncode']==0 if expected else rr['returncode']==1 and reject
   rows.append(dict(key=key,expected_accept=expected,returncode=rr['returncode'],explicit_reject=reject,qualified=ok))
   (ROOT/'controls.json').write_text(json.dumps(rows,indent=2))
   if not ok:raise RuntimeError('control failed '+key)
 ce=e.copy();ce.update(PARALLEL_WORKERS='8',PARALLEL_CURVE_MODULES='Waves')
 cr=run('curve-clock-control',[ROOT/'parallel-stream','parallel','none','Waves'],90,False,ce)
 cells=[x for x in events('curve-clock-control')if x.get('event')=='curve_cell']
 if cr['returncode']or len(cells)!=5 or not all(int(x['cpu_ns'])>0 and int(x['elapsed_ns'])>0 for x in cells):
  raise RuntimeError('curve/UInt64 clock control failed')
 (ROOT/'curve-clock-qualified.json').write_text(json.dumps(dict(cells=5,not_a_performance_result=True)))
 (ROOT/'controls-qualified.json').write_text(json.dumps(dict(cases=len(rows),utc=time.strftime('%FT%TZ',time.gmtime()))))
def matrix():
 assert (ROOT/'controls-qualified.json').exists()
 os.sched_setaffinity(0,set(range(8)))
 e=env();records=[];deadline=time.monotonic()+1670
 modes=[('reference',ORAW/'stream-check','stream',1),('audited',ROOT/'parallel-stream','audit',1)]+[('parallel'+str(w),ROOT/'parallel-stream','parallel',w)for w in [1,2,4,8]]
 for repeat in range(3):
  for name,binary,mode,w in modes:
   if time.monotonic()>deadline-180:raise RuntimeError('finite-window-incomplete; retain cells')
   ee=e.copy();ee['PARALLEL_WORKERS']=str(w)
   key='math-'+name+'-'+str(repeat)
   rr=run(key,[binary,mode,'none','Mathlib.Data.Nat.Basic'],180,True,ee)
   ev=events(key);accepted=[x['module'] for x in ev if x.get('event')=='accept']
   rr['accepted']=accepted;rr['complete']=[x for x in ev if x.get('event')=='complete']
   records.append(rr);(ROOT/'matrix-results.json').write_text(json.dumps(records,indent=2))
   if rr['returncode'] or len(accepted)!=1330:raise RuntimeError('matrix incomplete '+key)
   if set(accepted)!=set(records[0]['accepted']):raise RuntimeError('accepted-set difference '+key)
 (ROOT/'matrix-complete.json').write_text(json.dumps(dict(cells=len(records),utc=time.strftime('%FT%TZ',time.gmtime()))))
if __name__=='__main__':
 try:
  if sys.argv[1]=='controls':controls()
  elif sys.argv[1]=='both':
   controls()
   matrix()
  elif sys.argv[1]=='matrix':matrix()
 finally:
  (ROOT/(sys.argv[1]+'-terminal.json')).write_text(json.dumps(dict(utc=time.strftime('%FT%TZ',time.gmtime()))))
