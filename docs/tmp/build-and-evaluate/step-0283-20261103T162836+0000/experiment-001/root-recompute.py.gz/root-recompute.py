from pathlib import Path
import os,json,time,resource,subprocess,gzip,datetime,tarfile,csv,statistics,collections
os.sched_setaffinity(0,{22,23});resource.setrlimit(resource.RLIMIT_AS,(3*1024**3,3*1024**3));start=time.monotonic()
r=Path('/workspaces/repository');b=Path('/workspaces/.agent-state/gpu-smt-captures/parallel-stream-wall-20261103')
assert subprocess.check_output(['git','symbolic-ref','--short','HEAD'],cwd=r,text=True).strip()=='main'
stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S+0000');s=r/'docs/tmp/build-and-evaluate'/('step-0283-'+stamp);e=s/'experiment-001';e.mkdir(parents=True)
Path('/workspaces/.agent-state/gpu-smt-math-persistent-root-step.txt').write_text(str(s)+'\n')
owned=['docs/paper/main.tex','docs/paper/main.pdf','docs/paper/references.bib','docs/research-status.md','docs/research-plan.md','research/README.md','docs/novelty-20261101.md','docs/evaluation.md','docs/cleanup-20261101.md']
for n in owned:
 data=(r/n).read_bytes();assert data==subprocess.check_output(['git','show','4cb0859e:'+n],cwd=r),(n,'root own uncommitted or new writer')
 (e/('before-'+n.replace('/','-')+'.gz')).write_bytes(gzip.compress(data))
(e/'entry-tracked-dirty.txt').write_text(subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=r,text=True))
def evs(p):
 with p.open()as f:
  for l in f:
   if l.startswith('{'):yield json.loads(l)
old=Path('/workspaces/.agent-state/gpu-smt-captures/parallel-stream-check-v14/runs/math-reference-0/stdout')
oldgraph={x['module']:(x['constants'],x['imports'])for x in evs(old)if x.get('event')=='accept'};assert len(oldgraph)==1330
freeze={old,b/'native.py',b/'matrix-v2.py',b/'build.py',b/'extended-build.json',b/'reboot-interruption.json',b/'controller-v2.log'}
freeze.update(p for p in(b/'source').iterdir()if p.is_file())
rows=[];ids=set();ordered=None;routes=None;control=[]
keys=['math-'+a+'-r'+str(i)for i in [1,2,3]for a in ['reference','parallel1','parallel8']]+['control-v2-P1','control-v2-P8','bad-v2-P1','bad-v2-P8']
for key in keys:
 p=b/'runs'/key;c=json.loads((p/'command.json').read_text());v=json.loads((p/'result.json').read_text());t=json.loads((b/(key+'-terminal.json')).read_text())
 assert all(t[k]==z for k,z in v.items()),key
 assert c['argv']==v['argv'] and c['affinity']==list(range(8))and c['wall_limit_s']==1100 and c['own_rss_sample_stop_gib']==c['cgroup_charged_memory_max_gib']==14
 assert not any(str(a).startswith('-M')for a in c['argv'])
 assert v['wait4_usage_complete']and v['native_retired']and v['cgroup_retired']and not v['stop_reasons']and not Path(v['cgroup']).exists()
 assert all(int(a.split()[1])==0 for a in v['memory_events'].splitlines()if a.split()[0]in ['oom','oom_kill','oom_group_kill'])
 ids.add((int(v['pid']),str(v['birth'])));peak=0
 for l in(p/'memory.jsonl').read_text().splitlines():
  a=json.loads(l);assert a['rss_bytes']==sum(z['rss']for z in a['processes']);peak=max(peak,a['rss_bytes']);ids.update((int(z['pid']),str(z['birth']))for z in a['processes'])
 assert peak==v['sampled_tree_peak_bytes']
 events=list(evs(p/'stdout'));counts=collections.Counter(x.get('event')for x in events)
 acc=[x for x in events if x.get('event')=='accept'];heads=[x for x in events if x.get('event')=='module_header'];complete=[x for x in events if x.get('event')=='complete'];reject=[x for x in events if x.get('event')=='reject']
 graph={x['module']:(x['constants'],x['imports'])for x in acc}
 if key.startswith('math-'):
  assert v['returncode']==0 and t['qualified']and not reject and not(p/'stderr').read_bytes()
  assert len(graph)==len(acc)==1330 and graph==oldgraph
  if ordered is None:ordered=[x['module']for x in acc]
  assert [x['module']for x in acc]==ordered==t['accepted_IDs']
  assert len(complete)==1 and complete[0]['constants']==132484 and complete[0]['modules']==1330 and complete[0]['skipped_unsafe_partial']==2269
  assert 'profile_module'not in counts and 'dependency_phase'not in counts
  if 'parallel'in key:
   assert len(heads)==1330 and {x['module']:(x['constants'],x['imports'])for x in heads}==graph
   assert complete[0]['module_local_fallbacks']==0
   work={x['module']:(x['path'],x['jobs'],x['waves'])for x in events if x.get('event')=='kernel_work'}
   assert len(work)==1330
   if routes is None:routes=work
   assert work==routes
   assert sum(x[1]for x in work.values())==55255 and sum(x[2]for x in work.values())==3616
  arm=key.split('-')[1];rep=int(key[-1])
  rows.append(dict(key=key,arm=arm,repeat=rep,wall_s=v['wall_s'],user_s=v['user_s'],system_s=v['system_s'],CPU_s=v['user_s']+v['system_s'],HWM_KiB=v['peak_rss_kib'],sampled_RSS_B=peak,charged_peak_B=v['charged_peak_bytes'],accepted=1330))
 else:
  if key.startswith('control'):
   assert v['returncode']==0 and len(acc)==2 and len(complete)==1 and not reject and not(p/'stderr').read_bytes()
  else:
   assert v['returncode']==1 and len(acc)==1 and len(reject)==1 and not complete
   assert reject[0]['module']=='Waves'and'loose bound variables'in reject[0]['error']
  control.append(dict(key=key,returncode=v['returncode'],accepted=len(acc),rejects=len(reject),complete=len(complete),wall_s=v['wall_s']))
 freeze.update(p/n for n in ['command.json','result.json','stdout','stderr','memory.jsonl']);freeze.add(b/(key+'-terminal.json'))
for pid,birth in ids:
 try:assert Path('/proc',str(pid),'stat').read_text().split(') ',1)[1].split()[19]!=birth,(pid,birth)
 except FileNotFoundError:pass
summary=[]
for arm in ['reference','parallel1','parallel8']:
 a=[v for v in rows if v['arm']==arm]
 summary.append(dict(arm=arm,repeats=3,wall_median=statistics.median(v['wall_s']for v in a),wall_min=min(v['wall_s']for v in a),wall_max=max(v['wall_s']for v in a),CPU_median=statistics.median(v['CPU_s']for v in a),CPU_min=min(v['CPU_s']for v in a),CPU_max=max(v['CPU_s']for v in a)))
base=summary[0];p8=summary[2];ratios=[next(z['wall_s']for z in rows if z['arm']=='reference'and z['repeat']==i)/next(z['wall_s']for z in rows if z['arm']=='parallel8'and z['repeat']==i)for i in[1,2,3]]
for name,data in [('nine-complete-math-processes.csv',rows),('three-arm-summary.csv',summary),('four-finite-controls.csv',control)]:
 with(e/name).open('w',newline='')as f:w=csv.DictWriter(f,fieldnames=list(data[0]),lineterminator='\n');w.writeheader();w.writerows(data)
for n in ['plan.md','corrected-math-results.md','math-corrected-stream-repeats.csv','math-corrected-stream-summary.csv','summarize.py','reboot-interruption.json']:
 p=r/'research/parallel-stream-check/wall-ceiling'/n
 if p.exists():freeze.add(p)
for n in ['step069.md','step069-audit.md','step070.md','step070-audit.md']:freeze.add(r/'research/parallel-stream-check'/n)
with tarfile.open(e/'qualified-math-raw-source.tar.gz','w:gz')as tar:
 for p in sorted(freeze):tar.add(p,arcname=str(p).removeprefix('/workspaces/'),recursive=False)
members=payload=0
with tarfile.open(e/'qualified-math-raw-source.tar.gz','r:gz')as tar:
 for m in tar:
  assert m.isfile();data=tar.extractfile(m).read();assert len(data)==m.size;members+=1;payload+=len(data)
with gzip.open(e/'qualified-math-raw-source.tar.gz','rb')as f:
 while f.read(1024*1024):pass
j=dict(UTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),boot_id=Path('/proc/sys/kernel/random/boot_id').read_text().strip(),summary=summary,ratio_of_medians=base['wall_median']/p8['wall_median'],wall_reduction_percent=100*(1-p8['wall_median']/base['wall_median']),CPU_increase_percent=100*(p8['CPU_median']/base['CPU_median']-1),same_repeat_wall_ratios=ratios,ordered_modules=1330,entries=132484,unsafe_partial_exclusions=2269,ordinary_jobs=55255,waves=3616,route_counts=dict(collections.Counter(v[0]for v in routes.values())),actual_PID_births_retired=len(ids),cgroups_absent=13,native_runs=0,archive_members=members,archive_payload_bytes=payload,archive_bytes=(e/'qualified-math-raw-source.tar.gz').stat().st_size,root_analysis_seconds=time.monotonic()-start,root_analysis_maxrss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
(e/'reanalysis.json').write_text(json.dumps(j,indent=2)+'\n')
print('STEP',s);print(json.dumps(j))
