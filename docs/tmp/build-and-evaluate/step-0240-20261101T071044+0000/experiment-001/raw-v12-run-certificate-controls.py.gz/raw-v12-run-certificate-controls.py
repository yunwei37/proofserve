from pathlib import Path
import os,json
from native import run,ROOT,environment
os.sched_setaffinity(0,set(range(8)))
assets=Path('/workspaces/.agent-state/gpu-smt-captures/parallel-stream-assets')
e=environment();e.update(LEAN_PATH=str(assets/'overlay-complete-v2'),PARALLEL_CHUNK_ASSETS=str(assets/'all-envelope'))
results=[]
for name,expected in [('good-all',0),('bad-input',1),('bad-chunk',1)]:
 ee=e.copy()
 if name=='bad-chunk':ee['PARALLEL_CHUNK_FAULT']='bvar'
 r=run('certificate-'+name,[ROOT/'certificate-controls',name],120,False,ee)
 ev=[json.loads(l)for l in(ROOT/'runs'/('certificate-'+name)/'stdout').read_text().splitlines()if l.startswith('{')]
 explicit=any(x.get('event')=='control_reject'and'kernel_reject' in x.get('error','')for x in ev)
 ok=r['returncode']==expected and(expected==0 or explicit)
 results.append(dict(scenario=name,returncode=r['returncode'],expected=expected,
  original_kernel_rejection=explicit,qualified=ok,events=ev))
 (ROOT/'certificate-control-results.json').write_text(json.dumps(results,indent=2))
 if not ok:raise RuntimeError('certificate control failed '+name)
(ROOT/'certificate-controls-qualified.json').write_text(json.dumps(dict(cases=len(results),scope='root dependencies imported through stock API; no whole-closure performance claim')))
