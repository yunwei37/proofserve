import ParallelCore
open Lean
/-- Read a prepared untrusted certificate payload without importing any proof.
Each helper/chunk is rechecked in the streaming frontier before use. -/
def pathParts (path : System.FilePath) : IO (Array (ModuleData × CompactedRegion)) := do
  let mut files := #[path]
  for level in [OLeanLevel.server,OLeanLevel.private] do
    let other := level.adjustFileName path
    if ← other.pathExists then files := files.push other
  readModuleDataParts files

def loadSingleBundle (root : System.FilePath) (k : Nat) : IO (Array ChunkBundle × Array CompactedRegion) := do
  unless [1,2,4,8].contains k do throw <| IO.userError "unsupported chunk k"
  let referenceParts ← pathParts (root / "reference.olean")
  let some (referenceData,_) := referenceParts[referenceParts.size-1]? | throw <| IO.userError "empty reference"
  let target := `OAI.AtomicTriangular.FiniteCertificate.envelopeExpB16_calc._proof_1_1
  let some reference := referenceData.constants.find? (·.name == target) |
    throw <| IO.userError "prepared target missing"
  let supportParts ← pathParts (root / "EnvelopeBase.olean")
  let some (supportData,_) := supportParts[supportParts.size-1]? | throw <| IO.userError "empty support"
  let mut support := {}
  for ci in supportData.constants do
    if ci.isUnsafe || ci.isPartial || ci.getUsedConstantsAsSet.contains `sorryAx then
      throw <| IO.userError "unsupported certificate support"
    if let .axiomInfo _ := ci then throw <| IO.userError "certificate adds an axiom"
    support := support.insert ci.name ci
  let mut regions := (referenceParts ++ supportParts).map (·.2)
  let mut children := #[]
  for i in [:k] do
    let parts ← pathParts (root / s!"EnvelopeK{k}Part{i}.olean")
    regions := regions ++ parts.map (·.2)
    let some (data,_) := parts[parts.size-1]? | throw <| IO.userError "empty child"
    let name := Name.str (Name.mkSimple s!"EnvelopeK{k}Part{i}") "proof"
    let some ci := data.constants.find? (·.name == name) |
      throw <| IO.userError "prepared child missing"
    if ci.getUsedConstantsAsSet.contains `sorryAx then throw <| IO.userError "sorry in chunk"
    let ci := if (← IO.getEnv "PARALLEL_CHUNK_FAULT") == some "bvar" && i==0 then
      match ci with | .thmInfo t => .thmInfo {t with value:=Expr.bvar 0} | _ => ci
      else ci
    children := children.push ci
  return (#[{reference,support,children,k,mergeName:=Name.str `MEnvelopeBase s!"merge_{k}"}],regions)

/-- Only transitive support actually read by this target/k is installed. -/
partial def supportClosure (available : Std.HashMap Name ConstantInfo) (todo : List Name)
    (seen : NameSet := {}) (selected : Std.HashMap Name ConstantInfo := {}) :
    Std.HashMap Name ConstantInfo :=
  match todo with
  | [] => selected
  | n::rest =>
    if seen.contains n then supportClosure available rest seen selected
    else match available[n]? with
    | none => supportClosure available rest (seen.insert n) selected
    | some ci => supportClosure available (ci.getUsedConstantsAsSet.toList ++ rest)
        (seen.insert n) (selected.insert n ci)

def loadBundle (root : System.FilePath) (k : Nat) : IO (Array ChunkBundle × Array CompactedRegion) := do
  unless [1,2,4,8].contains k do throw <| IO.userError "unsupported chunk k"
  unless ← (root / "schemas.json").pathExists do return ← loadSingleBundle root k
  let json ← match Json.parse (← IO.FS.readFile (root / "schemas.json")) with
    | .ok j => pure j
    | .error e => throw <| IO.userError e
  let .ok specs := json.getObjValAs? (Array Json) "specs" | throw <| IO.userError "missing schemas"
  let referenceParts ← pathParts (root / "reference.olean")
  let some (referenceData,_) := referenceParts[referenceParts.size-1]? | throw <| IO.userError "empty reference"
  let supportParts ← pathParts (root / "EnvelopeStreamBase.olean")
  let some (supportData,_) := supportParts[supportParts.size-1]? | throw <| IO.userError "empty support"
  let mut available := {}
  for ci in supportData.constants do
    if ci.isUnsafe || ci.isPartial || ci.getUsedConstantsAsSet.contains `sorryAx then
      throw <| IO.userError "unsupported certificate support"
    if let .axiomInfo _ := ci then throw <| IO.userError "certificate adds an axiom"
    available := available.insert ci.name ci
  let mut regions := (referenceParts ++ supportParts).map (·.2)
  let mut bundles := #[]
  for spec in specs do
    let .ok ident := spec.getObjValAs? String "id" | throw <| IO.userError "missing schema ID"
    let .ok target := spec.getObjValAs? String "original_name" | throw <| IO.userError "missing target name"
    let some reference := referenceData.constants.find? (·.name == target.toName) |
      throw <| IO.userError "profiled original missing"
    let childParts ← pathParts (root / s!"chunks_{ident}_{k}.olean")
    regions := regions ++ childParts.map (·.2)
    let some (childData,_) := childParts[childParts.size-1]? | throw <| IO.userError "empty chunks"
    let mut children := childData.constants
    unless children.size==k do throw <| IO.userError "wrong chunk count"
    for ci in children do
      if ci.getUsedConstantsAsSet.contains `sorryAx then throw <| IO.userError "sorry in chunk"
      unless ci matches .thmInfo _ do throw <| IO.userError "non-theorem chunk"
    if (← IO.getEnv "PARALLEL_CHUNK_FAULT") == some "bvar" then
      children := children.map fun ci => match ci with
        | .thmInfo t => .thmInfo {t with value:=Expr.bvar 0} | _ => ci
    let mergeName := Name.str `MEnvelopeStream s!"merge_{ident}_{k}"
    let seeds := mergeName :: (children.toList.flatMap (·.getUsedConstantsAsSet.toList))
    let support := supportClosure available seeds
    bundles := bundles.push {reference,support,children,mergeName,k}
  return (bundles,regions)

unsafe def main (args : List String) : IO UInt32 := do
  let scenario := args.headD "good-target"
  initSearchPath (← findSysroot)
  let some directory ← IO.getEnv "PARALLEL_CHUNK_ASSETS" |
    throw <| IO.userError "missing assets"
  let (bundles,retained) ← loadBundle directory 8
  let mod := `OAI.Analysis.Triangular.Envelope.EnvelopePsiB
  let parts ← pathParts (← findOLean mod)
  let some (first,_) := parts[0]? | throw <| IO.userError "missing input"
  let some (data,_) := parts[parts.size-1]? | throw <| IO.userError "missing input"
  for bundle in bundles do
    let some actual := data.constants.find? (·.name == bundle.reference.name) |
      throw <| IO.userError "source target absent"
    unless sameConstant actual bundle.reference do
      throw <| IO.userError "source CI differs from selector reference"
  let (_,state) ← importModulesCore first.imports |>.run
  let env ← finalizeImport state first.imports {} 0 false false (isModule := true)
  let mut blocked : NameSet := {}
  for bundle in bundles do blocked := blocked.insert bundle.reference.name
  let mut changed := true
  while changed do
    changed := false
    for ci in data.constants do
      unless blocked.contains ci.name do
        if ci.getUsedConstantsAsSet.toList.any blocked.contains then
          blocked := blocked.insert ci.name
          changed := true
  let mut ready : Std.HashMap Name ConstantInfo := {}
  for ci in data.constants do
    unless blocked.contains ci.name do ready := ready.insert ci.name ci
  -- Only short ready declarations, never the ten expensive facts or their users.
  let base ← env.toKernelEnv.replay ready
  let selected := if scenario == "good-all" then bundles else
    bundles.filter (fun b => b.reference.name.toString.endsWith "envelopeExpB16_calc._proof_1_1")
  unless !selected.isEmpty do throw <| IO.userError "target unavailable"
  let mut constants := #[]
  for bundle in selected do
    let ci := if scenario == "bad-input" then match bundle.reference with
      | .thmInfo t => ConstantInfo.thmInfo {t with value:=Expr.bvar 0}
      | other => other
      else bundle.reference
    constants := constants.push ci
  let testData := {data with constants,constNames:=constants.map (·.name)}
  let mut map : Std.HashMap Name ConstantInfo := {}
  for ci in constants do map := map.insert ci.name ci
  try
    let _ ← parallelReplay testData map base 8 "none" selected
    IO.println <| Json.compress <| Json.mkObj [
      ("event",toJson "control_accept"),("scenario",toJson scenario),
      ("retained_regions",toJson retained.size),("input_regions",toJson parts.size),("selected_targets",toJson selected.size)]
    return 0
  catch e =>
    IO.println <| Json.compress <| Json.mkObj [
      ("event",toJson "control_reject"),("scenario",toJson scenario),
      ("error",toJson e.toString),("retained_regions",toJson retained.size),
      ("input_regions",toJson parts.size)]
    return 1
