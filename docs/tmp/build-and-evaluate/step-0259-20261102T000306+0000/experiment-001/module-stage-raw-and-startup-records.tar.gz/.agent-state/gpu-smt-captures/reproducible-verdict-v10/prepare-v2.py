from pathlib import Path
import os,json
import native
P=Path(__file__).resolve().parent
os.sched_setaffinity(0,set(range(8,16)))
e=native.environment();e['LEAN_PATH']=json.loads((P/'runtime.json').read_text())['LEAN_PATH']
r=native.run('link-interpreter',[native.SDK/'bin/leanc','-rdynamic','-O2','-o',P/'module-probe',P/'ModuleProbe.c',P/'thread_cpu.o'],180,False,e)
items=[]
if r['returncode']==0:
 for x in json.loads((P/'modules.json').read_text()):
  short=x['module'].split('.')[-1]
  z=native.run('inventory-v2-'+short,[P/'module-probe','inventory',x['module'],x['source'],'1'],90,False,e)
  items.append(z)
  if z['returncode']:break
(P/'inventory-v2-terminal.json').write_text(json.dumps(dict(complete=len(items)==5 and all(x['returncode']==0 for x in items),link=r,cells=items),indent=2))
