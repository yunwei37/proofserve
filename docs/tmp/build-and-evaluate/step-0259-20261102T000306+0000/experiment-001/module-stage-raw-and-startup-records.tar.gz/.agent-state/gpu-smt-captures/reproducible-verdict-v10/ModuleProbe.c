// Lean compiler output
// Module: ModuleProbe
// Imports: public import Init public meta import Init public import Lean public import Lean.Util.CollectAxioms
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* l_Lean_JsonNumber_fromNat(lean_object*);
lean_object* lean_uint64_to_nat(uint64_t);
lean_object* l_Lean_bignumToJson(lean_object*);
lean_object* lean_mk_empty_array_with_capacity(lean_object*);
lean_object* l___private_Init_Data_List_Impl_0__List_flatMapTR_go___at___00Lean_Linter_CodeQuality_instToJsonEntry_toJson_spec__0(lean_object*, lean_object*);
lean_object* l_Lean_Json_mkObj(lean_object*);
uint8_t lean_nat_dec_lt(lean_object*, lean_object*);
lean_object* l_IO_Promise_result_x21___redArg(lean_object*);
lean_object* lean_io_wait(lean_object*);
lean_object* lean_nat_add(lean_object*, lean_object*);
lean_object* lean_nat_mod(lean_object*, lean_object*);
uint8_t lean_nat_dec_eq(lean_object*, lean_object*);
lean_object* l_Lean_Name_mkStr2(lean_object*, lean_object*);
lean_object* l_Lean_Name_mkStr1(lean_object*);
extern lean_object* l_Lean_Options_empty;
lean_object* l_Lean_Options_set___at___00Lean_Option_set___at___00__private_Lean_Shell_0__Lean_ShellOptions_process_spec__2_spec__3(lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Options_set___at___00Lean_Option_set___at___00__private_Lean_Shell_0__Lean_ShellOptions_process_spec__1_spec__1(lean_object*, lean_object*, uint8_t);
lean_object* l_Lean_Elab_Command_mkState(lean_object*, lean_object*, lean_object*);
lean_object* lean_st_mk_ref(lean_object*);
lean_object* l_Lean_Elab_Frontend_updateCmdPos___redArg(lean_object*);
lean_object* lean_st_ref_get(lean_object*);
extern lean_object* l_Lean_Elab_Command_instInhabitedScope_default;
lean_object* l_List_head_x21___redArg(lean_object*, lean_object*);
lean_object* l_Lean_Parser_parseCommand(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lean_st_ref_take(lean_object*);
lean_object* lean_array_push(lean_object*, lean_object*);
lean_object* lean_st_ref_set(lean_object*, lean_object*);
lean_object* l_Lean_Elab_Frontend_setParserState___redArg(lean_object*, lean_object*);
lean_object* l_Lean_Elab_Frontend_setMessages___redArg(lean_object*, lean_object*);
lean_object* lean_io_get_num_heartbeats();
lean_object* l_Lean_Elab_Frontend_elabCommandAtFrontend(lean_object*, lean_object*, lean_object*);
lean_object* lean_nat_sub(lean_object*, lean_object*);
uint64_t lean_uint64_sub(uint64_t, uint64_t);
lean_object* l_Lean_Syntax_getKind(lean_object*);
lean_object* l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(lean_object*, uint8_t);
lean_object* l_Lean_MessageLog_toArray(lean_object*);
lean_object* l_Array_append___redArg(lean_object*, lean_object*);
uint8_t l_Lean_Parser_isTerminalCommand(lean_object*);
lean_object* l_Lean_Array_toJson___at___00Lean_Server_Test_Runner_Client_instToJsonHyp_toJson_spec__1(lean_object*);
lean_object* l_Lean_Array_toJson___at___00Lean_Server_FileWorker_handlePreRequestSpecialCases_x3f_spec__6(lean_object*);
size_t lean_array_size(lean_object*);
size_t lean_usize_add(size_t, size_t);
uint8_t lean_usize_dec_lt(size_t, size_t);
lean_object* lean_array_uget_borrowed(lean_object*, size_t);
uint8_t l_Lean_instBEqMessageSeverity_beq(uint8_t, uint8_t);
lean_object* l_Lean_MessageData_toString(lean_object*);
lean_object* l_Lean_Environment_constants(lean_object*);
lean_object* l_Lean_PersistentHashMap_toList___at___00__private_Lean_Linter_TacticTypeCheck_0__Lean_Linter_tacticCheckInstances_spec__6___redArg(lean_object*);
extern lean_object* l___private_Lean_Util_CollectAxioms_0__Lean_instInhabitedExportedAxiomsState;
lean_object* l_Lean_Environment_setExporting(lean_object*, uint8_t);
extern lean_object* l___private_Lean_Util_CollectAxioms_0__Lean_exportedAxiomsExt;
lean_object* l_Lean_PersistentEnvExtension_getState___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l___private_Lean_Util_CollectAxioms_0__Lean_ExportedAxiomsState_find_x3f___boxed(lean_object*, lean_object*, lean_object*);
lean_object* l___private_Lean_Util_CollectAxioms_0__Lean_CollectAxioms_collectAndGet___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l___private_Lean_Util_CollectAxioms_0__Lean_CollectAxioms_runM___redArg(lean_object*, lean_object*);
uint8_t l_Array_contains___at___00__private_Lean_Linter_CheckUnivs_0__Lean_Linter_CheckUnivs_badParams_spec__0(lean_object*, lean_object*);
lean_object* l_Lean_Kernel_enableDiag(lean_object*, uint8_t);
uint8_t l_Lean_Environment_contains(lean_object*, lean_object*, uint8_t);
lean_object* l_Lean_PersistentHashMap_mkEmptyEntriesArray(lean_object*, lean_object*);
extern lean_object* l_Lean_inheritedTraceOptions;
lean_object* l_Lean_Core_getMaxHeartbeats(lean_object*);
extern lean_object* l_Lean_diagnostics;
uint8_t l_Lean_Option_get___at___00Lean_Elab_addMacroStack___at___00Lean_throwError___at___00Lean_throwErrorAt___at___00Lean_throwUnknownIdentifierAt___at___00Lean_throwUnknownConstantAt___at___00Lean_throwUnknownConstant___at___00Lean_getConstVal___at___00Lean_mkConstWithLevelParams___at___00Lean_Elab_addConstInfo___at___00Lean_Elab_PostprocessTraces_elabStoreTraceAs_spec__3_spec__5_spec__6_spec__9_spec__12_spec__14_spec__16_spec__18_spec__20_spec__21(lean_object*, lean_object*);
uint8_t l_Lean_Kernel_isDiagnosticsEnabled(lean_object*);
lean_object* l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00__private_Lean_Elab_DocString_Builtin_0__Lean_Doc_validateCat_spec__3___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
uint8_t lean_nat_dec_le(lean_object*, lean_object*);
uint64_t lean_io_get_tid();
lean_object* lean_array_get_size(lean_object*);
lean_object* lean_io_as_task(lean_object*, lean_object*);
extern lean_object* l_Lean_instInhabitedTheoremVal_default;
lean_object* lean_array_get_borrowed(lean_object*, lean_object*, lean_object*);
lean_object* lean_io_mono_nanos_now();
lean_object* l_Nat_reprFast(lean_object*);
lean_object* lean_string_append(lean_object*, lean_object*);
lean_object* l_Lean_Name_str___override(lean_object*, lean_object*);
lean_object* lean_add_decl(lean_object*, size_t, size_t, lean_object*, lean_object*);
lean_object* l_Lean_Kernel_Exception_toMessageData(lean_object*, lean_object*);
lean_object* lean_array_fswap(lean_object*, lean_object*, lean_object*);
lean_object* lean_array_fget_borrowed(lean_object*, lean_object*);
uint8_t lean_string_dec_lt(lean_object*, lean_object*);
lean_object* lean_array_fget(lean_object*, lean_object*);
lean_object* lean_nat_shiftr(lean_object*, lean_object*);
lean_object* l_Lean_Environment_getModuleIdxFor_x3f(lean_object*, lean_object*);
uint8_t lean_string_dec_eq(lean_object*, lean_object*);
lean_object* l_Lean_Expr_cleanupAnnotations(lean_object*);
lean_object* l_Lean_Expr_getAppFn(lean_object*);
uint8_t l_Lean_Expr_isConstOf(lean_object*, lean_object*);
uint8_t l_Lean_Expr_hasMVar(lean_object*);
uint8_t l_Lean_Expr_hasFVar(lean_object*);
uint8_t l_Lean_Expr_hasSorry(lean_object*);
lean_object* lean_nat_mul(lean_object*, lean_object*);
lean_object* lean_nat_div(lean_object*, lean_object*);
lean_object* lean_task_get_own(lean_object*);
lean_object* l_Lean_Json_compress(lean_object*);
lean_object* l_IO_println___at___00__private_Lean_Shell_0__Lean_ShellOptions_process_spec__3(lean_object*);
lean_object* lean_string_utf8_byte_size(lean_object*);
lean_object* l_String_Slice_toNat_x21(lean_object*);
uint8_t l_List_elem___at___00Lean_Meta_Grind_Arith_Cutsat_checkElimEqs_spec__0(lean_object*, lean_object*);
lean_object* lean_io_promise_new();
lean_object* lean_elab_environment_to_kernel_env(lean_object*);
lean_object* lean_io_promise_resolve(lean_object*, lean_object*);
lean_object* lean_array_uset(lean_object*, size_t, lean_object*);
lean_object* lean_array_set(lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_findSysroot(lean_object*);
lean_object* l_Lean_initSearchPath(lean_object*, lean_object*);
lean_object* lean_enable_initializer_execution();
lean_object* l_String_toName(lean_object*);
uint8_t lean_string_memcmp(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_importModules(lean_object*, lean_object*, uint32_t, lean_object*, uint8_t, uint8_t, uint8_t, lean_object*);
lean_object* l_Lean_Environment_getModuleIdx_x3f(lean_object*, lean_object*);
lean_object* l_Lean_SMap_toList___at___00__private_Lean_Elab_DocString_Builtin_0__Lean_Doc_getQualified_spec__1___redArg(lean_object*);
lean_object* l_IO_FS_readFile(lean_object*);
lean_object* l_Lean_Parser_mkInputContext___redArg(lean_object*, lean_object*, uint8_t, lean_object*);
lean_object* l_Lean_Parser_parseHeader(lean_object*);
lean_object* l_Lean_Elab_HeaderSyntax_imports(lean_object*, uint8_t);
lean_object* l_Lean_Environment_setMainModule(lean_object*, lean_object*);
lean_object* rv_thread_cpu_ns();
LEAN_EXPORT lean_object* l_threadCpuNs___boxed(lean_object*);
static const lean_string_object l_instToJsonUnitRow_toJson___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 7, .m_capacity = 7, .m_length = 6, .m_data = "target"};
static const lean_object* l_instToJsonUnitRow_toJson___closed__0 = (const lean_object*)&l_instToJsonUnitRow_toJson___closed__0_value;
static const lean_string_object l_instToJsonUnitRow_toJson___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 6, .m_capacity = 6, .m_length = 5, .m_data = "rawHB"};
static const lean_object* l_instToJsonUnitRow_toJson___closed__1 = (const lean_object*)&l_instToJsonUnitRow_toJson___closed__1_value;
static const lean_string_object l_instToJsonUnitRow_toJson___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 6, .m_capacity = 6, .m_length = 5, .m_data = "cpuNS"};
static const lean_object* l_instToJsonUnitRow_toJson___closed__2 = (const lean_object*)&l_instToJsonUnitRow_toJson___closed__2_value;
static const lean_string_object l_instToJsonUnitRow_toJson___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 7, .m_capacity = 7, .m_length = 6, .m_data = "wallNS"};
static const lean_object* l_instToJsonUnitRow_toJson___closed__3 = (const lean_object*)&l_instToJsonUnitRow_toJson___closed__3_value;
static const lean_string_object l_instToJsonUnitRow_toJson___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 8, .m_capacity = 8, .m_length = 7, .m_data = "verdict"};
static const lean_object* l_instToJsonUnitRow_toJson___closed__4 = (const lean_object*)&l_instToJsonUnitRow_toJson___closed__4_value;
static const lean_string_object l_instToJsonUnitRow_toJson___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 6, .m_capacity = 6, .m_length = 5, .m_data = "error"};
static const lean_object* l_instToJsonUnitRow_toJson___closed__5 = (const lean_object*)&l_instToJsonUnitRow_toJson___closed__5_value;
static const lean_string_object l_instToJsonUnitRow_toJson___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 4, .m_capacity = 4, .m_length = 3, .m_data = "tid"};
static const lean_object* l_instToJsonUnitRow_toJson___closed__6 = (const lean_object*)&l_instToJsonUnitRow_toJson___closed__6_value;
static const lean_array_object l_instToJsonUnitRow_toJson___closed__7_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_array_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 246}, .m_size = 0, .m_capacity = 0, .m_data = {}};
static const lean_object* l_instToJsonUnitRow_toJson___closed__7 = (const lean_object*)&l_instToJsonUnitRow_toJson___closed__7_value;
LEAN_EXPORT lean_object* l_instToJsonUnitRow_toJson(lean_object*);
static const lean_closure_object l_instToJsonUnitRow___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_instToJsonUnitRow_toJson, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* l_instToJsonUnitRow___closed__0 = (const lean_object*)&l_instToJsonUnitRow___closed__0_value;
LEAN_EXPORT const lean_object* l_instToJsonUnitRow = (const lean_object*)&l_instToJsonUnitRow___closed__0_value;
static const lean_ctor_object l_checked___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* l_checked___closed__0 = (const lean_object*)&l_checked___closed__0_value;
LEAN_EXPORT lean_object* l_checked(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_checked___boxed(lean_object*, lean_object*, lean_object*);
static const lean_string_object l_one___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 12, .m_capacity = 12, .m_length = 11, .m_data = "ReproKernel"};
static const lean_object* l_one___closed__0 = (const lean_object*)&l_one___closed__0_value;
static const lean_ctor_object l_one___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&l_one___closed__0_value),LEAN_SCALAR_PTR_LITERAL(66, 164, 223, 236, 0, 168, 114, 232)}};
static const lean_object* l_one___closed__1 = (const lean_object*)&l_one___closed__1_value;
static const lean_string_object l_one___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "unit"};
static const lean_object* l_one___closed__2 = (const lean_object*)&l_one___closed__2_value;
static const lean_string_object l_one___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 13, .m_capacity = 13, .m_length = 12, .m_data = "kernel_error"};
static const lean_object* l_one___closed__3 = (const lean_object*)&l_one___closed__3_value;
static const lean_string_object l_one___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 9, .m_capacity = 9, .m_length = 8, .m_data = "accepted"};
static const lean_object* l_one___closed__4 = (const lean_object*)&l_one___closed__4_value;
static const lean_string_object l_one___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 1, .m_capacity = 1, .m_length = 0, .m_data = ""};
static const lean_object* l_one___closed__5 = (const lean_object*)&l_one___closed__5_value;
LEAN_EXPORT lean_object* l_one(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_one___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static lean_once_cell_t l_commands___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_commands___closed__0;
static lean_once_cell_t l_commands___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_commands___closed__1;
static lean_once_cell_t l_commands___closed__2_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_commands___closed__2;
static const lean_string_object l_commands___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 6, .m_capacity = 6, .m_length = 5, .m_data = "start"};
static const lean_object* l_commands___closed__3 = (const lean_object*)&l_commands___closed__3_value;
static const lean_string_object l_commands___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 4, .m_capacity = 4, .m_length = 3, .m_data = "end"};
static const lean_object* l_commands___closed__4 = (const lean_object*)&l_commands___closed__4_value;
static const lean_string_object l_commands___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "kind"};
static const lean_object* l_commands___closed__5 = (const lean_object*)&l_commands___closed__5_value;
LEAN_EXPORT lean_object* l_commands(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_commands___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Lean_collectAxioms___at___00elaborateOne_spec__1___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Lean_collectAxioms___at___00elaborateOne_spec__1___redArg___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Lean_collectAxioms___at___00elaborateOne_spec__1(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Lean_collectAxioms___at___00elaborateOne_spec__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00elaborateOne_spec__0(lean_object*, size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00elaborateOne_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_string_object l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 8, .m_capacity = 8, .m_length = 7, .m_data = "sorryAx"};
static const lean_object* l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__0 = (const lean_object*)&l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__0_value;
static const lean_ctor_object l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__0_value),LEAN_SCALAR_PTR_LITERAL(196, 190, 164, 146, 38, 179, 69, 72)}};
static const lean_object* l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__1 = (const lean_object*)&l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__1_value;
static lean_once_cell_t l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__2_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__2;
static lean_once_cell_t l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__3_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__3;
static lean_once_cell_t l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__4_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__4;
static const lean_string_object l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 6, .m_capacity = 6, .m_length = 5, .m_data = "_uniq"};
static const lean_object* l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__5 = (const lean_object*)&l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__5_value;
static const lean_ctor_object l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__5_value),LEAN_SCALAR_PTR_LITERAL(237, 141, 162, 170, 202, 74, 55, 55)}};
static const lean_object* l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__6 = (const lean_object*)&l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__6_value;
static const lean_ctor_object l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__7_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)&l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__6_value),((lean_object*)(((size_t)(1) << 1) | 1))}};
static const lean_object* l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__7 = (const lean_object*)&l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__7_value;
static const lean_ctor_object l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__8_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*3 + 0, .m_other = 3, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)(((size_t)(1) << 1) | 1)),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__8 = (const lean_object*)&l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__8_value;
static lean_once_cell_t l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__9_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__9;
static lean_once_cell_t l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__10_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__10;
static const lean_array_object l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__11_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_array_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 246}, .m_size = 0, .m_capacity = 0, .m_data = {}};
static const lean_object* l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__11 = (const lean_object*)&l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__11_value;
static lean_once_cell_t l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__12_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__12;
static lean_once_cell_t l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__13_once = LEAN_ONCE_CELL_INITIALIZER;
static uint8_t l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__13;
LEAN_EXPORT lean_object* l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_string_object l_elaborateOne___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 14, .m_capacity = 14, .m_length = 13, .m_data = "maxHeartbeats"};
static const lean_object* l_elaborateOne___closed__0 = (const lean_object*)&l_elaborateOne___closed__0_value;
static const lean_ctor_object l_elaborateOne___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&l_elaborateOne___closed__0_value),LEAN_SCALAR_PTR_LITERAL(163, 202, 216, 251, 148, 187, 135, 206)}};
static const lean_object* l_elaborateOne___closed__1 = (const lean_object*)&l_elaborateOne___closed__1_value;
static lean_once_cell_t l_elaborateOne___closed__2_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_elaborateOne___closed__2;
static const lean_string_object l_elaborateOne___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 12, .m_capacity = 12, .m_length = 11, .m_data = "maxRecDepth"};
static const lean_object* l_elaborateOne___closed__3 = (const lean_object*)&l_elaborateOne___closed__3_value;
static const lean_ctor_object l_elaborateOne___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&l_elaborateOne___closed__3_value),LEAN_SCALAR_PTR_LITERAL(213, 238, 178, 82, 0, 139, 185, 177)}};
static const lean_object* l_elaborateOne___closed__4 = (const lean_object*)&l_elaborateOne___closed__4_value;
static lean_once_cell_t l_elaborateOne___closed__5_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_elaborateOne___closed__5;
static const lean_string_object l_elaborateOne___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "Elab"};
static const lean_object* l_elaborateOne___closed__6 = (const lean_object*)&l_elaborateOne___closed__6_value;
static const lean_string_object l_elaborateOne___closed__7_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 6, .m_capacity = 6, .m_length = 5, .m_data = "async"};
static const lean_object* l_elaborateOne___closed__7 = (const lean_object*)&l_elaborateOne___closed__7_value;
static const lean_ctor_object l_elaborateOne___closed__8_value_aux_0 = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&l_elaborateOne___closed__6_value),LEAN_SCALAR_PTR_LITERAL(13, 84, 199, 228, 250, 36, 60, 178)}};
static const lean_ctor_object l_elaborateOne___closed__8_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&l_elaborateOne___closed__8_value_aux_0),((lean_object*)&l_elaborateOne___closed__7_value),LEAN_SCALAR_PTR_LITERAL(6, 0, 36, 68, 138, 2, 151, 20)}};
static const lean_object* l_elaborateOne___closed__8 = (const lean_object*)&l_elaborateOne___closed__8_value;
static lean_once_cell_t l_elaborateOne___closed__9_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_elaborateOne___closed__9;
static const lean_array_object l_elaborateOne___closed__10_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_array_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 246}, .m_size = 0, .m_capacity = 0, .m_data = {}};
static const lean_object* l_elaborateOne___closed__10 = (const lean_object*)&l_elaborateOne___closed__10_value;
static const lean_string_object l_elaborateOne___closed__11_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 9, .m_capacity = 9, .m_length = 8, .m_data = "commands"};
static const lean_object* l_elaborateOne___closed__11 = (const lean_object*)&l_elaborateOne___closed__11_value;
static const lean_string_object l_elaborateOne___closed__12_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 6, .m_capacity = 6, .m_length = 5, .m_data = "scope"};
static const lean_object* l_elaborateOne___closed__12 = (const lean_object*)&l_elaborateOne___closed__12_value;
static const lean_string_object l_elaborateOne___closed__13_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 105, .m_capacity = 105, .m_length = 104, .m_data = "synchronous full-source elaboration; command CPU includes tactics and kernel; not stock async task total"};
static const lean_object* l_elaborateOne___closed__13 = (const lean_object*)&l_elaborateOne___closed__13_value;
static const lean_ctor_object l_elaborateOne___closed__14_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&l_elaborateOne___closed__13_value)}};
static const lean_object* l_elaborateOne___closed__14 = (const lean_object*)&l_elaborateOne___closed__14_value;
static const lean_ctor_object l_elaborateOne___closed__15_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)&l_elaborateOne___closed__12_value),((lean_object*)&l_elaborateOne___closed__14_value)}};
static const lean_object* l_elaborateOne___closed__15 = (const lean_object*)&l_elaborateOne___closed__15_value;
static const lean_ctor_object l_elaborateOne___closed__16_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&l_elaborateOne___closed__15_value),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* l_elaborateOne___closed__16 = (const lean_object*)&l_elaborateOne___closed__16_value;
static const lean_ctor_object l_elaborateOne___closed__17_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)&l_elaborateOne___closed__10_value),((lean_object*)&l_elaborateOne___closed__10_value)}};
static const lean_object* l_elaborateOne___closed__17 = (const lean_object*)&l_elaborateOne___closed__17_value;
static const lean_ctor_object l_elaborateOne___closed__18_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)&l_elaborateOne___closed__10_value),((lean_object*)&l_elaborateOne___closed__17_value)}};
static const lean_object* l_elaborateOne___closed__18 = (const lean_object*)&l_elaborateOne___closed__18_value;
static const lean_string_object l_elaborateOne___closed__19_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 7, .m_capacity = 7, .m_length = 6, .m_data = "module"};
static const lean_object* l_elaborateOne___closed__19 = (const lean_object*)&l_elaborateOne___closed__19_value;
static const lean_string_object l_elaborateOne___closed__20_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 8, .m_capacity = 8, .m_length = 7, .m_data = "workers"};
static const lean_object* l_elaborateOne___closed__20 = (const lean_object*)&l_elaborateOne___closed__20_value;
static const lean_string_object l_elaborateOne___closed__21_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 6, .m_capacity = 6, .m_length = 5, .m_data = "index"};
static const lean_object* l_elaborateOne___closed__21 = (const lean_object*)&l_elaborateOne___closed__21_value;
static const lean_string_object l_elaborateOne___closed__22_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 7, .m_capacity = 7, .m_length = 6, .m_data = "errors"};
static const lean_object* l_elaborateOne___closed__22 = (const lean_object*)&l_elaborateOne___closed__22_value;
static const lean_string_object l_elaborateOne___closed__23_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 6, .m_capacity = 6, .m_length = 5, .m_data = "sorry"};
static const lean_object* l_elaborateOne___closed__23 = (const lean_object*)&l_elaborateOne___closed__23_value;
static const lean_string_object l_elaborateOne___closed__24_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 11, .m_capacity = 11, .m_length = 10, .m_data = "new_axioms"};
static const lean_object* l_elaborateOne___closed__24 = (const lean_object*)&l_elaborateOne___closed__24_value;
static const lean_string_object l_elaborateOne___closed__25_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 9, .m_capacity = 9, .m_length = 8, .m_data = "theorems"};
static const lean_object* l_elaborateOne___closed__25 = (const lean_object*)&l_elaborateOne___closed__25_value;
static const lean_string_object l_elaborateOne___closed__26_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 11, .m_capacity = 11, .m_length = 10, .m_data = "incomplete"};
static const lean_object* l_elaborateOne___closed__26 = (const lean_object*)&l_elaborateOne___closed__26_value;
static const lean_string_object l_elaborateOne___closed__27_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 11, .m_capacity = 11, .m_length = 10, .m_data = "lean_error"};
static const lean_object* l_elaborateOne___closed__27 = (const lean_object*)&l_elaborateOne___closed__27_value;
LEAN_EXPORT lean_object* l_elaborateOne(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_elaborateOne___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_forIn_x27_loop___at___00elaborateOne_spec__2(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_forIn_x27_loop___at___00elaborateOne_spec__2___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t l_Option_instBEq_beq___at___00main_spec__1(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Option_instBEq_beq___at___00main_spec__1___boxed(lean_object*, lean_object*);
static const lean_string_object l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__3___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 27, .m_capacity = 27, .m_length = 26, .m_data = "not a closed checked input"};
static const lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__3___closed__0 = (const lean_object*)&l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__3___closed__0_value;
static const lean_ctor_object l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__3___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__3___closed__0_value)}};
static const lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__3___closed__1 = (const lean_object*)&l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__3___closed__1_value;
static const lean_string_object l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__3___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 6, .m_capacity = 6, .m_length = 5, .m_data = "front"};
static const lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__3___closed__2 = (const lean_object*)&l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__3___closed__2_value;
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__3(lean_object*, lean_object*, size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__3___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_string_object l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__15___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 7, .m_capacity = 7, .m_length = 6, .m_data = "FRONT "};
static const lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__15___closed__0 = (const lean_object*)&l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__15___closed__0_value;
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__15(lean_object*, size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__15___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__16(lean_object*, size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__16___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_QSort_Basic_0__Array_qpartition_loop___at___00__private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__8_spec__10___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_QSort_Basic_0__Array_qpartition_loop___at___00__private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__8_spec__10___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__8___redArg___lam__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__8___redArg___lam__0___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__8___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__8___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_string_object l_List_forIn_x27_loop___at___00List_forIn_x27_loop___at___00main_spec__2_spec__2___redArg___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 18, .m_capacity = 18, .m_length = 17, .m_data = "of_decide_eq_true"};
static const lean_object* l_List_forIn_x27_loop___at___00List_forIn_x27_loop___at___00main_spec__2_spec__2___redArg___closed__0 = (const lean_object*)&l_List_forIn_x27_loop___at___00List_forIn_x27_loop___at___00main_spec__2_spec__2___redArg___closed__0_value;
static const lean_ctor_object l_List_forIn_x27_loop___at___00List_forIn_x27_loop___at___00main_spec__2_spec__2___redArg___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&l_List_forIn_x27_loop___at___00List_forIn_x27_loop___at___00main_spec__2_spec__2___redArg___closed__0_value),LEAN_SCALAR_PTR_LITERAL(199, 143, 142, 104, 169, 34, 63, 25)}};
static const lean_object* l_List_forIn_x27_loop___at___00List_forIn_x27_loop___at___00main_spec__2_spec__2___redArg___closed__1 = (const lean_object*)&l_List_forIn_x27_loop___at___00List_forIn_x27_loop___at___00main_spec__2_spec__2___redArg___closed__1_value;
LEAN_EXPORT lean_object* l_List_forIn_x27_loop___at___00List_forIn_x27_loop___at___00main_spec__2_spec__2___redArg(lean_object*, lean_object*, uint8_t, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_forIn_x27_loop___at___00List_forIn_x27_loop___at___00main_spec__2_spec__2___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_forIn_x27_loop___at___00main_spec__2___redArg(lean_object*, lean_object*, uint8_t, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_forIn_x27_loop___at___00main_spec__2___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_string_object l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__7___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 8, .m_capacity = 8, .m_length = 7, .m_data = "KERNEL "};
static const lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__7___closed__0 = (const lean_object*)&l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__7___closed__0_value;
static const lean_string_object l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__7___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 9, .m_capacity = 9, .m_length = 8, .m_data = "eligible"};
static const lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__7___closed__1 = (const lean_object*)&l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__7___closed__1_value;
static const lean_string_object l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__7___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 9, .m_capacity = 9, .m_length = 8, .m_data = "selected"};
static const lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__7___closed__2 = (const lean_object*)&l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__7___closed__2_value;
static const lean_string_object l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__7___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 7, .m_capacity = 7, .m_length = 6, .m_data = "result"};
static const lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__7___closed__3 = (const lean_object*)&l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__7___closed__3_value;
static const lean_string_object l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__7___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 18, .m_capacity = 18, .m_length = 17, .m_data = "kernel_poll_count"};
static const lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__7___closed__4 = (const lean_object*)&l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__7___closed__4_value;
static const lean_ctor_object l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__7___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)&l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__7___closed__4_value),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__7___closed__5 = (const lean_object*)&l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__7___closed__5_value;
static const lean_ctor_object l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__7___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__7___closed__5_value),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__7___closed__6 = (const lean_object*)&l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__7___closed__6_value;
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__7(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__7___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_QSort_Basic_0__Array_qpartition_loop___at___00__private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__12_spec__15___redArg(uint8_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_QSort_Basic_0__Array_qpartition_loop___at___00__private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__12_spec__15___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__12___redArg___lam__0(uint8_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__12___redArg___lam__0___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__12___redArg(uint8_t, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__12___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00main_spec__9(uint8_t, size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00main_spec__9___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__4___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__4___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__5___redArg___lam__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__5___redArg___lam__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__5_spec__6___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__5_spec__6___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__5___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__5___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__10___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__10___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__6(lean_object*, size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__6___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__13___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__13___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__14___redArg___lam__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__14___redArg___lam__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__14_spec__18___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__14_spec__18___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__14___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__14___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_string_object l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__11___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 70, .m_capacity = 70, .m_length = 69, .m_data = "OAI.AtomicTriangular.FiniteCertificate.envelopeExpB16_calc._proof_1_1"};
static const lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__11___closed__0 = (const lean_object*)&l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__11___closed__0_value;
static const lean_ctor_object l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__11___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__11___closed__1 = (const lean_object*)&l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__11___closed__1_value;
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__11(uint8_t, lean_object*, size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__11___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t l_List_any___at___00main_spec__0(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_any___at___00main_spec__0___boxed(lean_object*, lean_object*, lean_object*);
static const lean_string_object l_main___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 56, .m_capacity = 56, .m_length = 55, .m_data = "usage: ModuleProbe (kernel|front) MODULE SOURCE WORKERS"};
static const lean_object* l_main___closed__0 = (const lean_object*)&l_main___closed__0_value;
static const lean_ctor_object l_main___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&l_main___closed__0_value)}};
static const lean_object* l_main___closed__1 = (const lean_object*)&l_main___closed__1_value;
static const lean_ctor_object l_main___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(8) << 1) | 1)),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* l_main___closed__2 = (const lean_object*)&l_main___closed__2_value;
static const lean_ctor_object l_main___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(4) << 1) | 1)),((lean_object*)&l_main___closed__2_value)}};
static const lean_object* l_main___closed__3 = (const lean_object*)&l_main___closed__3_value;
static const lean_ctor_object l_main___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(2) << 1) | 1)),((lean_object*)&l_main___closed__3_value)}};
static const lean_object* l_main___closed__4 = (const lean_object*)&l_main___closed__4_value;
static const lean_ctor_object l_main___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(1) << 1) | 1)),((lean_object*)&l_main___closed__4_value)}};
static const lean_object* l_main___closed__5 = (const lean_object*)&l_main___closed__5_value;
static const lean_string_object l_main___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 10, .m_capacity = 10, .m_length = 9, .m_data = "inventory"};
static const lean_object* l_main___closed__6 = (const lean_object*)&l_main___closed__6_value;
static const lean_array_object l_main___closed__7_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_array_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 246}, .m_size = 0, .m_capacity = 0, .m_data = {}};
static const lean_object* l_main___closed__7 = (const lean_object*)&l_main___closed__7_value;
static const lean_string_object l_main___closed__8_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 11, .m_capacity = 11, .m_length = 10, .m_data = "INVENTORY "};
static const lean_object* l_main___closed__8 = (const lean_object*)&l_main___closed__8_value;
static const lean_string_object l_main___closed__9_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 8, .m_capacity = 8, .m_length = 7, .m_data = "targets"};
static const lean_object* l_main___closed__9 = (const lean_object*)&l_main___closed__9_value;
static const lean_ctor_object l_main___closed__10_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&l_elaborateOne___closed__20_value)}};
static const lean_object* l_main___closed__10 = (const lean_object*)&l_main___closed__10_value;
static const lean_string_object l_main___closed__11_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "lean"};
static const lean_object* l_main___closed__11 = (const lean_object*)&l_main___closed__11_value;
static const lean_string_object l_main___closed__12_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 6, .m_capacity = 6, .m_length = 5, .m_data = "only "};
static const lean_object* l_main___closed__12 = (const lean_object*)&l_main___closed__12_value;
static const lean_string_object l_main___closed__13_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 19, .m_capacity = 19, .m_length = 18, .m_data = " eligible theorems"};
static const lean_object* l_main___closed__13 = (const lean_object*)&l_main___closed__13_value;
static const lean_string_object l_main___closed__14_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "mode"};
static const lean_object* l_main___closed__14 = (const lean_object*)&l_main___closed__14_value;
static const lean_ctor_object l_main___closed__15_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&l_main___closed__14_value)}};
static const lean_object* l_main___closed__15 = (const lean_object*)&l_main___closed__15_value;
static const lean_array_object l_main___closed__16_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_array_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 246}, .m_size = 0, .m_capacity = 0, .m_data = {}};
static const lean_object* l_main___closed__16 = (const lean_object*)&l_main___closed__16_value;
static const lean_string_object l_main___closed__17_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 10, .m_capacity = 10, .m_length = 9, .m_data = "UMoments9"};
static const lean_object* l_main___closed__17 = (const lean_object*)&l_main___closed__17_value;
static const lean_string_object l_main___closed__18_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 14, .m_capacity = 14, .m_length = 13, .m_data = "BarrierData41"};
static const lean_object* l_main___closed__18 = (const lean_object*)&l_main___closed__18_value;
static const lean_string_object l_main___closed__19_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 13, .m_capacity = 13, .m_length = 12, .m_data = "EnvelopePsiB"};
static const lean_object* l_main___closed__19 = (const lean_object*)&l_main___closed__19_value;
static const lean_string_object l_main___closed__20_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 14, .m_capacity = 14, .m_length = 13, .m_data = "module absent"};
static const lean_object* l_main___closed__20 = (const lean_object*)&l_main___closed__20_value;
static const lean_ctor_object l_main___closed__21_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&l_main___closed__20_value)}};
static const lean_object* l_main___closed__21 = (const lean_object*)&l_main___closed__21_value;
static const lean_string_object l_main___closed__22_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 7, .m_capacity = 7, .m_length = 6, .m_data = "kernel"};
static const lean_object* l_main___closed__22 = (const lean_object*)&l_main___closed__22_value;
LEAN_EXPORT lean_object* l_main___boxed__const__1;
LEAN_EXPORT lean_object* _lean_main(lean_object*);
LEAN_EXPORT lean_object* l_main___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_forIn_x27_loop___at___00main_spec__2(lean_object*, lean_object*, uint8_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_forIn_x27_loop___at___00main_spec__2___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__4(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__4___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__5(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__5___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__8(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__8___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__10(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__10___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__12(uint8_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__12___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__13(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__13___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__14(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__14___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_forIn_x27_loop___at___00List_forIn_x27_loop___at___00main_spec__2_spec__2(lean_object*, lean_object*, uint8_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_forIn_x27_loop___at___00List_forIn_x27_loop___at___00main_spec__2_spec__2___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__5_spec__6(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__5_spec__6___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_QSort_Basic_0__Array_qpartition_loop___at___00__private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__8_spec__10(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_QSort_Basic_0__Array_qpartition_loop___at___00__private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__8_spec__10___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_QSort_Basic_0__Array_qpartition_loop___at___00__private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__12_spec__15(uint8_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_QSort_Basic_0__Array_qpartition_loop___at___00__private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__12_spec__15___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__14_spec__18(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__14_spec__18___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_threadCpuNs___boxed(lean_object* v_a_00___x40___internal___hyg_2_){
_start:
{
lean_object* v_res_3_; 
v_res_3_ = rv_thread_cpu_ns();
return v_res_3_;
}
}
LEAN_EXPORT lean_object* l_instToJsonUnitRow_toJson(lean_object* v_x_13_){
_start:
{
lean_object* v_target_14_; lean_object* v_rawHB_15_; uint64_t v_cpuNS_16_; lean_object* v_wallNS_17_; lean_object* v_verdict_18_; lean_object* v_error_19_; uint64_t v_tid_20_; lean_object* v___x_21_; lean_object* v___x_22_; lean_object* v___x_23_; lean_object* v___x_24_; lean_object* v___x_25_; lean_object* v___x_26_; lean_object* v___x_27_; lean_object* v___x_28_; lean_object* v___x_29_; lean_object* v___x_30_; lean_object* v___x_31_; lean_object* v___x_32_; lean_object* v___x_33_; lean_object* v___x_34_; lean_object* v___x_35_; lean_object* v___x_36_; lean_object* v___x_37_; lean_object* v___x_38_; lean_object* v___x_39_; lean_object* v___x_40_; lean_object* v___x_41_; lean_object* v___x_42_; lean_object* v___x_43_; lean_object* v___x_44_; lean_object* v___x_45_; lean_object* v___x_46_; lean_object* v___x_47_; lean_object* v___x_48_; lean_object* v___x_49_; lean_object* v___x_50_; lean_object* v___x_51_; lean_object* v___x_52_; lean_object* v___x_53_; lean_object* v___x_54_; lean_object* v___x_55_; lean_object* v___x_56_; lean_object* v___x_57_; lean_object* v___x_58_; lean_object* v___x_59_; lean_object* v___x_60_; lean_object* v___x_61_; lean_object* v___x_62_; lean_object* v___x_63_; 
v_target_14_ = lean_ctor_get(v_x_13_, 0);
lean_inc_ref(v_target_14_);
v_rawHB_15_ = lean_ctor_get(v_x_13_, 1);
lean_inc(v_rawHB_15_);
v_cpuNS_16_ = lean_ctor_get_uint64(v_x_13_, sizeof(void*)*5);
v_wallNS_17_ = lean_ctor_get(v_x_13_, 2);
lean_inc(v_wallNS_17_);
v_verdict_18_ = lean_ctor_get(v_x_13_, 3);
lean_inc_ref(v_verdict_18_);
v_error_19_ = lean_ctor_get(v_x_13_, 4);
lean_inc_ref(v_error_19_);
v_tid_20_ = lean_ctor_get_uint64(v_x_13_, sizeof(void*)*5 + 8);
lean_dec_ref(v_x_13_);
v___x_21_ = ((lean_object*)(l_instToJsonUnitRow_toJson___closed__0));
v___x_22_ = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(v___x_22_, 0, v_target_14_);
v___x_23_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_23_, 0, v___x_21_);
lean_ctor_set(v___x_23_, 1, v___x_22_);
v___x_24_ = lean_box(0);
v___x_25_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_25_, 0, v___x_23_);
lean_ctor_set(v___x_25_, 1, v___x_24_);
v___x_26_ = ((lean_object*)(l_instToJsonUnitRow_toJson___closed__1));
v___x_27_ = l_Lean_JsonNumber_fromNat(v_rawHB_15_);
v___x_28_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_28_, 0, v___x_27_);
v___x_29_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_29_, 0, v___x_26_);
lean_ctor_set(v___x_29_, 1, v___x_28_);
v___x_30_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_30_, 0, v___x_29_);
lean_ctor_set(v___x_30_, 1, v___x_24_);
v___x_31_ = ((lean_object*)(l_instToJsonUnitRow_toJson___closed__2));
v___x_32_ = lean_uint64_to_nat(v_cpuNS_16_);
v___x_33_ = l_Lean_bignumToJson(v___x_32_);
v___x_34_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_34_, 0, v___x_31_);
lean_ctor_set(v___x_34_, 1, v___x_33_);
v___x_35_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_35_, 0, v___x_34_);
lean_ctor_set(v___x_35_, 1, v___x_24_);
v___x_36_ = ((lean_object*)(l_instToJsonUnitRow_toJson___closed__3));
v___x_37_ = l_Lean_JsonNumber_fromNat(v_wallNS_17_);
v___x_38_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_38_, 0, v___x_37_);
v___x_39_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_39_, 0, v___x_36_);
lean_ctor_set(v___x_39_, 1, v___x_38_);
v___x_40_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_40_, 0, v___x_39_);
lean_ctor_set(v___x_40_, 1, v___x_24_);
v___x_41_ = ((lean_object*)(l_instToJsonUnitRow_toJson___closed__4));
v___x_42_ = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(v___x_42_, 0, v_verdict_18_);
v___x_43_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_43_, 0, v___x_41_);
lean_ctor_set(v___x_43_, 1, v___x_42_);
v___x_44_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_44_, 0, v___x_43_);
lean_ctor_set(v___x_44_, 1, v___x_24_);
v___x_45_ = ((lean_object*)(l_instToJsonUnitRow_toJson___closed__5));
v___x_46_ = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(v___x_46_, 0, v_error_19_);
v___x_47_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_47_, 0, v___x_45_);
lean_ctor_set(v___x_47_, 1, v___x_46_);
v___x_48_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_48_, 0, v___x_47_);
lean_ctor_set(v___x_48_, 1, v___x_24_);
v___x_49_ = ((lean_object*)(l_instToJsonUnitRow_toJson___closed__6));
v___x_50_ = lean_uint64_to_nat(v_tid_20_);
v___x_51_ = l_Lean_bignumToJson(v___x_50_);
v___x_52_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_52_, 0, v___x_49_);
lean_ctor_set(v___x_52_, 1, v___x_51_);
v___x_53_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_53_, 0, v___x_52_);
lean_ctor_set(v___x_53_, 1, v___x_24_);
v___x_54_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_54_, 0, v___x_53_);
lean_ctor_set(v___x_54_, 1, v___x_24_);
v___x_55_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_55_, 0, v___x_48_);
lean_ctor_set(v___x_55_, 1, v___x_54_);
v___x_56_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_56_, 0, v___x_44_);
lean_ctor_set(v___x_56_, 1, v___x_55_);
v___x_57_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_57_, 0, v___x_40_);
lean_ctor_set(v___x_57_, 1, v___x_56_);
v___x_58_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_58_, 0, v___x_35_);
lean_ctor_set(v___x_58_, 1, v___x_57_);
v___x_59_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_59_, 0, v___x_30_);
lean_ctor_set(v___x_59_, 1, v___x_58_);
v___x_60_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_60_, 0, v___x_25_);
lean_ctor_set(v___x_60_, 1, v___x_59_);
v___x_61_ = ((lean_object*)(l_instToJsonUnitRow_toJson___closed__7));
v___x_62_ = l___private_Init_Data_List_Impl_0__List_flatMapTR_go___at___00Lean_Linter_CodeQuality_instToJsonEntry_toJson_spec__0(v___x_60_, v___x_61_);
v___x_63_ = l_Lean_Json_mkObj(v___x_62_);
lean_dec(v___x_62_);
return v___x_63_;
}
}
LEAN_EXPORT lean_object* l_checked(lean_object* v_base_68_, lean_object* v_decl_69_){
_start:
{
size_t v___x_71_; size_t v___x_72_; lean_object* v___x_73_; lean_object* v___x_74_; 
v___x_71_ = ((size_t)2000000000ULL);
v___x_72_ = ((size_t)20000ULL);
v___x_73_ = lean_box(0);
v___x_74_ = lean_add_decl(v_base_68_, v___x_71_, v___x_72_, v_decl_69_, v___x_73_);
if (lean_obj_tag(v___x_74_) == 0)
{
lean_object* v_a_75_; lean_object* v___x_77_; uint8_t v_isShared_78_; uint8_t v_isSharedCheck_83_; 
v_a_75_ = lean_ctor_get(v___x_74_, 0);
v_isSharedCheck_83_ = !lean_is_exclusive(v___x_74_);
if (v_isSharedCheck_83_ == 0)
{
v___x_77_ = v___x_74_;
v_isShared_78_ = v_isSharedCheck_83_;
goto v_resetjp_76_;
}
else
{
lean_inc(v_a_75_);
lean_dec(v___x_74_);
v___x_77_ = lean_box(0);
v_isShared_78_ = v_isSharedCheck_83_;
goto v_resetjp_76_;
}
v_resetjp_76_:
{
lean_object* v___x_80_; 
if (v_isShared_78_ == 0)
{
v___x_80_ = v___x_77_;
goto v_reusejp_79_;
}
else
{
lean_object* v_reuseFailAlloc_82_; 
v_reuseFailAlloc_82_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_82_, 0, v_a_75_);
v___x_80_ = v_reuseFailAlloc_82_;
goto v_reusejp_79_;
}
v_reusejp_79_:
{
lean_object* v___x_81_; 
v___x_81_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_81_, 0, v___x_80_);
return v___x_81_;
}
}
}
else
{
lean_object* v___x_84_; lean_object* v___x_85_; 
lean_dec_ref_known(v___x_74_, 1);
v___x_84_ = ((lean_object*)(l_checked___closed__0));
v___x_85_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_85_, 0, v___x_84_);
return v___x_85_;
}
}
}
LEAN_EXPORT lean_object* l_checked___boxed(lean_object* v_base_86_, lean_object* v_decl_87_, lean_object* v_a_88_){
_start:
{
lean_object* v_res_89_; 
v_res_89_ = l_checked(v_base_86_, v_decl_87_);
lean_dec(v_decl_87_);
return v_res_89_;
}
}
LEAN_EXPORT lean_object* l_one(lean_object* v_base_97_, lean_object* v_v_98_, lean_object* v_i_99_){
_start:
{
lean_object* v_toConstantVal_101_; lean_object* v_value_102_; lean_object* v___x_104_; uint8_t v_isShared_105_; uint8_t v_isSharedCheck_187_; 
v_toConstantVal_101_ = lean_ctor_get(v_v_98_, 0);
v_value_102_ = lean_ctor_get(v_v_98_, 1);
v_isSharedCheck_187_ = !lean_is_exclusive(v_v_98_);
if (v_isSharedCheck_187_ == 0)
{
lean_object* v_unused_188_; 
v_unused_188_ = lean_ctor_get(v_v_98_, 2);
lean_dec(v_unused_188_);
v___x_104_ = v_v_98_;
v_isShared_105_ = v_isSharedCheck_187_;
goto v_resetjp_103_;
}
else
{
lean_inc(v_value_102_);
lean_inc(v_toConstantVal_101_);
lean_dec(v_v_98_);
v___x_104_ = lean_box(0);
v_isShared_105_ = v_isSharedCheck_187_;
goto v_resetjp_103_;
}
v_resetjp_103_:
{
lean_object* v_name_106_; lean_object* v_levelParams_107_; lean_object* v_type_108_; lean_object* v___x_110_; uint8_t v_isShared_111_; uint8_t v_isSharedCheck_186_; 
v_name_106_ = lean_ctor_get(v_toConstantVal_101_, 0);
v_levelParams_107_ = lean_ctor_get(v_toConstantVal_101_, 1);
v_type_108_ = lean_ctor_get(v_toConstantVal_101_, 2);
v_isSharedCheck_186_ = !lean_is_exclusive(v_toConstantVal_101_);
if (v_isSharedCheck_186_ == 0)
{
v___x_110_ = v_toConstantVal_101_;
v_isShared_111_ = v_isSharedCheck_186_;
goto v_resetjp_109_;
}
else
{
lean_inc(v_type_108_);
lean_inc(v_levelParams_107_);
lean_inc(v_name_106_);
lean_dec(v_toConstantVal_101_);
v___x_110_ = lean_box(0);
v_isShared_111_ = v_isSharedCheck_186_;
goto v_resetjp_109_;
}
v_resetjp_109_:
{
uint64_t v___x_112_; lean_object* v___x_113_; lean_object* v___x_114_; 
v___x_112_ = lean_io_get_tid();
v___x_113_ = lean_io_mono_nanos_now();
v___x_114_ = rv_thread_cpu_ns();
if (lean_obj_tag(v___x_114_) == 0)
{
lean_object* v_a_115_; lean_object* v___x_116_; lean_object* v___x_117_; lean_object* v___x_118_; lean_object* v___x_119_; lean_object* v___x_120_; lean_object* v_n_121_; lean_object* v___x_123_; 
v_a_115_ = lean_ctor_get(v___x_114_, 0);
lean_inc(v_a_115_);
lean_dec_ref_known(v___x_114_, 1);
v___x_116_ = lean_io_get_num_heartbeats();
v___x_117_ = ((lean_object*)(l_one___closed__1));
v___x_118_ = ((lean_object*)(l_one___closed__2));
v___x_119_ = l_Nat_reprFast(v_i_99_);
v___x_120_ = lean_string_append(v___x_118_, v___x_119_);
lean_dec_ref(v___x_119_);
v_n_121_ = l_Lean_Name_str___override(v___x_117_, v___x_120_);
lean_inc(v_n_121_);
if (v_isShared_111_ == 0)
{
lean_ctor_set(v___x_110_, 0, v_n_121_);
v___x_123_ = v___x_110_;
goto v_reusejp_122_;
}
else
{
lean_object* v_reuseFailAlloc_177_; 
v_reuseFailAlloc_177_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v_reuseFailAlloc_177_, 0, v_n_121_);
lean_ctor_set(v_reuseFailAlloc_177_, 1, v_levelParams_107_);
lean_ctor_set(v_reuseFailAlloc_177_, 2, v_type_108_);
v___x_123_ = v_reuseFailAlloc_177_;
goto v_reusejp_122_;
}
v_reusejp_122_:
{
lean_object* v___x_124_; lean_object* v___x_125_; lean_object* v___x_127_; 
v___x_124_ = lean_box(0);
v___x_125_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_125_, 0, v_n_121_);
lean_ctor_set(v___x_125_, 1, v___x_124_);
if (v_isShared_105_ == 0)
{
lean_ctor_set(v___x_104_, 2, v___x_125_);
lean_ctor_set(v___x_104_, 0, v___x_123_);
v___x_127_ = v___x_104_;
goto v_reusejp_126_;
}
else
{
lean_object* v_reuseFailAlloc_176_; 
v_reuseFailAlloc_176_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v_reuseFailAlloc_176_, 0, v___x_123_);
lean_ctor_set(v_reuseFailAlloc_176_, 1, v_value_102_);
lean_ctor_set(v_reuseFailAlloc_176_, 2, v___x_125_);
v___x_127_ = v_reuseFailAlloc_176_;
goto v_reusejp_126_;
}
v_reusejp_126_:
{
lean_object* v_decl_128_; lean_object* v___x_129_; lean_object* v_a_130_; lean_object* v___x_131_; lean_object* v___x_132_; 
v_decl_128_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v_decl_128_, 0, v___x_127_);
v___x_129_ = l_checked(v_base_97_, v_decl_128_);
lean_dec_ref_known(v_decl_128_, 1);
v_a_130_ = lean_ctor_get(v___x_129_, 0);
lean_inc(v_a_130_);
lean_dec_ref(v___x_129_);
v___x_131_ = lean_io_get_num_heartbeats();
v___x_132_ = rv_thread_cpu_ns();
if (lean_obj_tag(v___x_132_) == 0)
{
lean_object* v_a_133_; lean_object* v___x_135_; uint8_t v_isShared_136_; uint8_t v_isSharedCheck_167_; 
v_a_133_ = lean_ctor_get(v___x_132_, 0);
v_isSharedCheck_167_ = !lean_is_exclusive(v___x_132_);
if (v_isSharedCheck_167_ == 0)
{
v___x_135_ = v___x_132_;
v_isShared_136_ = v_isSharedCheck_167_;
goto v_resetjp_134_;
}
else
{
lean_inc(v_a_133_);
lean_dec(v___x_132_);
v___x_135_ = lean_box(0);
v_isShared_136_ = v_isSharedCheck_167_;
goto v_resetjp_134_;
}
v_resetjp_134_:
{
lean_object* v___x_137_; 
v___x_137_ = lean_io_mono_nanos_now();
if (lean_obj_tag(v_a_130_) == 0)
{
lean_object* v_a_138_; lean_object* v___x_139_; lean_object* v___x_140_; lean_object* v___x_141_; uint8_t v___x_142_; lean_object* v___x_143_; lean_object* v___x_144_; uint64_t v___x_145_; uint64_t v___x_146_; uint64_t v___x_147_; lean_object* v___x_148_; lean_object* v___x_149_; lean_object* v___x_150_; lean_object* v___x_152_; 
v_a_138_ = lean_ctor_get(v_a_130_, 0);
lean_inc(v_a_138_);
lean_dec_ref_known(v_a_130_, 1);
v___x_139_ = l_Lean_Options_empty;
v___x_140_ = l_Lean_Kernel_Exception_toMessageData(v_a_138_, v___x_139_);
v___x_141_ = l_Lean_MessageData_toString(v___x_140_);
v___x_142_ = 1;
v___x_143_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v_name_106_, v___x_142_);
v___x_144_ = lean_nat_sub(v___x_131_, v___x_116_);
lean_dec(v___x_116_);
lean_dec(v___x_131_);
v___x_145_ = lean_unbox_uint64(v_a_133_);
lean_dec(v_a_133_);
v___x_146_ = lean_unbox_uint64(v_a_115_);
lean_dec(v_a_115_);
v___x_147_ = lean_uint64_sub(v___x_145_, v___x_146_);
v___x_148_ = lean_nat_sub(v___x_137_, v___x_113_);
lean_dec(v___x_113_);
lean_dec(v___x_137_);
v___x_149_ = ((lean_object*)(l_one___closed__3));
v___x_150_ = lean_alloc_ctor(0, 5, 16);
lean_ctor_set(v___x_150_, 0, v___x_143_);
lean_ctor_set(v___x_150_, 1, v___x_144_);
lean_ctor_set(v___x_150_, 2, v___x_148_);
lean_ctor_set(v___x_150_, 3, v___x_149_);
lean_ctor_set(v___x_150_, 4, v___x_141_);
lean_ctor_set_uint64(v___x_150_, sizeof(void*)*5, v___x_147_);
lean_ctor_set_uint64(v___x_150_, sizeof(void*)*5 + 8, v___x_112_);
if (v_isShared_136_ == 0)
{
lean_ctor_set(v___x_135_, 0, v___x_150_);
v___x_152_ = v___x_135_;
goto v_reusejp_151_;
}
else
{
lean_object* v_reuseFailAlloc_153_; 
v_reuseFailAlloc_153_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_153_, 0, v___x_150_);
v___x_152_ = v_reuseFailAlloc_153_;
goto v_reusejp_151_;
}
v_reusejp_151_:
{
return v___x_152_;
}
}
else
{
uint8_t v___x_154_; lean_object* v___x_155_; lean_object* v___x_156_; uint64_t v___x_157_; uint64_t v___x_158_; uint64_t v___x_159_; lean_object* v___x_160_; lean_object* v___x_161_; lean_object* v___x_162_; lean_object* v___x_163_; lean_object* v___x_165_; 
lean_dec_ref_known(v_a_130_, 1);
v___x_154_ = 1;
v___x_155_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v_name_106_, v___x_154_);
v___x_156_ = lean_nat_sub(v___x_131_, v___x_116_);
lean_dec(v___x_116_);
lean_dec(v___x_131_);
v___x_157_ = lean_unbox_uint64(v_a_133_);
lean_dec(v_a_133_);
v___x_158_ = lean_unbox_uint64(v_a_115_);
lean_dec(v_a_115_);
v___x_159_ = lean_uint64_sub(v___x_157_, v___x_158_);
v___x_160_ = lean_nat_sub(v___x_137_, v___x_113_);
lean_dec(v___x_113_);
lean_dec(v___x_137_);
v___x_161_ = ((lean_object*)(l_one___closed__4));
v___x_162_ = ((lean_object*)(l_one___closed__5));
v___x_163_ = lean_alloc_ctor(0, 5, 16);
lean_ctor_set(v___x_163_, 0, v___x_155_);
lean_ctor_set(v___x_163_, 1, v___x_156_);
lean_ctor_set(v___x_163_, 2, v___x_160_);
lean_ctor_set(v___x_163_, 3, v___x_161_);
lean_ctor_set(v___x_163_, 4, v___x_162_);
lean_ctor_set_uint64(v___x_163_, sizeof(void*)*5, v___x_159_);
lean_ctor_set_uint64(v___x_163_, sizeof(void*)*5 + 8, v___x_112_);
if (v_isShared_136_ == 0)
{
lean_ctor_set(v___x_135_, 0, v___x_163_);
v___x_165_ = v___x_135_;
goto v_reusejp_164_;
}
else
{
lean_object* v_reuseFailAlloc_166_; 
v_reuseFailAlloc_166_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_166_, 0, v___x_163_);
v___x_165_ = v_reuseFailAlloc_166_;
goto v_reusejp_164_;
}
v_reusejp_164_:
{
return v___x_165_;
}
}
}
}
else
{
lean_object* v_a_168_; lean_object* v___x_170_; uint8_t v_isShared_171_; uint8_t v_isSharedCheck_175_; 
lean_dec(v___x_131_);
lean_dec(v_a_130_);
lean_dec(v___x_116_);
lean_dec(v_a_115_);
lean_dec(v___x_113_);
lean_dec(v_name_106_);
v_a_168_ = lean_ctor_get(v___x_132_, 0);
v_isSharedCheck_175_ = !lean_is_exclusive(v___x_132_);
if (v_isSharedCheck_175_ == 0)
{
v___x_170_ = v___x_132_;
v_isShared_171_ = v_isSharedCheck_175_;
goto v_resetjp_169_;
}
else
{
lean_inc(v_a_168_);
lean_dec(v___x_132_);
v___x_170_ = lean_box(0);
v_isShared_171_ = v_isSharedCheck_175_;
goto v_resetjp_169_;
}
v_resetjp_169_:
{
lean_object* v___x_173_; 
if (v_isShared_171_ == 0)
{
v___x_173_ = v___x_170_;
goto v_reusejp_172_;
}
else
{
lean_object* v_reuseFailAlloc_174_; 
v_reuseFailAlloc_174_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_174_, 0, v_a_168_);
v___x_173_ = v_reuseFailAlloc_174_;
goto v_reusejp_172_;
}
v_reusejp_172_:
{
return v___x_173_;
}
}
}
}
}
}
else
{
lean_object* v_a_178_; lean_object* v___x_180_; uint8_t v_isShared_181_; uint8_t v_isSharedCheck_185_; 
lean_dec(v___x_113_);
lean_del_object(v___x_110_);
lean_dec_ref(v_type_108_);
lean_dec(v_levelParams_107_);
lean_dec(v_name_106_);
lean_del_object(v___x_104_);
lean_dec_ref(v_value_102_);
lean_dec(v_i_99_);
lean_dec_ref(v_base_97_);
v_a_178_ = lean_ctor_get(v___x_114_, 0);
v_isSharedCheck_185_ = !lean_is_exclusive(v___x_114_);
if (v_isSharedCheck_185_ == 0)
{
v___x_180_ = v___x_114_;
v_isShared_181_ = v_isSharedCheck_185_;
goto v_resetjp_179_;
}
else
{
lean_inc(v_a_178_);
lean_dec(v___x_114_);
v___x_180_ = lean_box(0);
v_isShared_181_ = v_isSharedCheck_185_;
goto v_resetjp_179_;
}
v_resetjp_179_:
{
lean_object* v___x_183_; 
if (v_isShared_181_ == 0)
{
v___x_183_ = v___x_180_;
goto v_reusejp_182_;
}
else
{
lean_object* v_reuseFailAlloc_184_; 
v_reuseFailAlloc_184_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_184_, 0, v_a_178_);
v___x_183_ = v_reuseFailAlloc_184_;
goto v_reusejp_182_;
}
v_reusejp_182_:
{
return v___x_183_;
}
}
}
}
}
}
}
LEAN_EXPORT lean_object* l_one___boxed(lean_object* v_base_189_, lean_object* v_v_190_, lean_object* v_i_191_, lean_object* v_a_192_){
_start:
{
lean_object* v_res_193_; 
v_res_193_ = l_one(v_base_189_, v_v_190_, v_i_191_);
return v_res_193_;
}
}
static lean_object* _init_l_commands___closed__0(void){
_start:
{
lean_object* v___x_194_; lean_object* v___x_195_; lean_object* v___x_196_; 
v___x_194_ = lean_unsigned_to_nat(32u);
v___x_195_ = lean_mk_empty_array_with_capacity(v___x_194_);
v___x_196_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_196_, 0, v___x_195_);
return v___x_196_;
}
}
static lean_object* _init_l_commands___closed__1(void){
_start:
{
size_t v___x_197_; lean_object* v___x_198_; lean_object* v___x_199_; lean_object* v___x_200_; lean_object* v___x_201_; lean_object* v___x_202_; 
v___x_197_ = ((size_t)5ULL);
v___x_198_ = lean_unsigned_to_nat(0u);
v___x_199_ = lean_unsigned_to_nat(32u);
v___x_200_ = lean_mk_empty_array_with_capacity(v___x_199_);
v___x_201_ = lean_obj_once(&l_commands___closed__0, &l_commands___closed__0_once, _init_l_commands___closed__0);
v___x_202_ = lean_alloc_ctor(0, 4, sizeof(size_t)*1);
lean_ctor_set(v___x_202_, 0, v___x_201_);
lean_ctor_set(v___x_202_, 1, v___x_200_);
lean_ctor_set(v___x_202_, 2, v___x_198_);
lean_ctor_set(v___x_202_, 3, v___x_198_);
lean_ctor_set_usize(v___x_202_, 4, v___x_197_);
return v___x_202_;
}
}
static lean_object* _init_l_commands___closed__2(void){
_start:
{
lean_object* v___x_203_; lean_object* v___x_204_; lean_object* v___x_205_; 
v___x_203_ = lean_box(1);
v___x_204_ = lean_obj_once(&l_commands___closed__1, &l_commands___closed__1_once, _init_l_commands___closed__1);
v___x_205_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_205_, 0, v___x_204_);
lean_ctor_set(v___x_205_, 1, v___x_204_);
lean_ctor_set(v___x_205_, 2, v___x_203_);
return v___x_205_;
}
}
LEAN_EXPORT lean_object* l_commands(lean_object* v_rows_209_, lean_object* v_messages_210_, lean_object* v_a_211_, lean_object* v_a_212_){
_start:
{
lean_object* v___x_214_; 
v___x_214_ = l_Lean_Elab_Frontend_updateCmdPos___redArg(v_a_212_);
if (lean_obj_tag(v___x_214_) == 0)
{
lean_object* v___x_215_; lean_object* v_commandState_216_; lean_object* v_parserState_217_; lean_object* v___x_219_; uint8_t v_isShared_220_; uint8_t v_isSharedCheck_365_; 
lean_dec_ref_known(v___x_214_, 1);
v___x_215_ = lean_st_ref_get(v_a_212_);
v_commandState_216_ = lean_ctor_get(v___x_215_, 0);
v_parserState_217_ = lean_ctor_get(v___x_215_, 1);
v_isSharedCheck_365_ = !lean_is_exclusive(v___x_215_);
if (v_isSharedCheck_365_ == 0)
{
lean_object* v_unused_366_; lean_object* v_unused_367_; 
v_unused_366_ = lean_ctor_get(v___x_215_, 3);
lean_dec(v_unused_366_);
v_unused_367_ = lean_ctor_get(v___x_215_, 2);
lean_dec(v_unused_367_);
v___x_219_ = v___x_215_;
v_isShared_220_ = v_isSharedCheck_365_;
goto v_resetjp_218_;
}
else
{
lean_inc(v_parserState_217_);
lean_inc(v_commandState_216_);
lean_dec(v___x_215_);
v___x_219_ = lean_box(0);
v_isShared_220_ = v_isSharedCheck_365_;
goto v_resetjp_218_;
}
v_resetjp_218_:
{
lean_object* v_env_221_; lean_object* v_scopes_222_; lean_object* v___x_223_; lean_object* v___x_224_; lean_object* v_opts_225_; lean_object* v_currNamespace_226_; lean_object* v_openDecls_227_; lean_object* v___x_229_; 
v_env_221_ = lean_ctor_get(v_commandState_216_, 0);
lean_inc_ref(v_env_221_);
v_scopes_222_ = lean_ctor_get(v_commandState_216_, 2);
lean_inc(v_scopes_222_);
lean_dec_ref(v_commandState_216_);
v___x_223_ = l_Lean_Elab_Command_instInhabitedScope_default;
v___x_224_ = l_List_head_x21___redArg(v___x_223_, v_scopes_222_);
lean_dec(v_scopes_222_);
v_opts_225_ = lean_ctor_get(v___x_224_, 1);
lean_inc_ref(v_opts_225_);
v_currNamespace_226_ = lean_ctor_get(v___x_224_, 2);
lean_inc(v_currNamespace_226_);
v_openDecls_227_ = lean_ctor_get(v___x_224_, 3);
lean_inc(v_openDecls_227_);
lean_dec(v___x_224_);
if (v_isShared_220_ == 0)
{
lean_ctor_set(v___x_219_, 3, v_openDecls_227_);
lean_ctor_set(v___x_219_, 2, v_currNamespace_226_);
lean_ctor_set(v___x_219_, 1, v_opts_225_);
lean_ctor_set(v___x_219_, 0, v_env_221_);
v___x_229_ = v___x_219_;
goto v_reusejp_228_;
}
else
{
lean_object* v_reuseFailAlloc_364_; 
v_reuseFailAlloc_364_ = lean_alloc_ctor(0, 4, 0);
lean_ctor_set(v_reuseFailAlloc_364_, 0, v_env_221_);
lean_ctor_set(v_reuseFailAlloc_364_, 1, v_opts_225_);
lean_ctor_set(v_reuseFailAlloc_364_, 2, v_currNamespace_226_);
lean_ctor_set(v_reuseFailAlloc_364_, 3, v_openDecls_227_);
v___x_229_ = v_reuseFailAlloc_364_;
goto v_reusejp_228_;
}
v_reusejp_228_:
{
lean_object* v___x_230_; lean_object* v___x_231_; lean_object* v_snd_232_; lean_object* v_fst_233_; lean_object* v___x_235_; uint8_t v_isShared_236_; uint8_t v_isSharedCheck_363_; 
v___x_230_ = lean_obj_once(&l_commands___closed__2, &l_commands___closed__2_once, _init_l_commands___closed__2);
lean_inc_ref(v_parserState_217_);
lean_inc_ref(v_a_211_);
v___x_231_ = l_Lean_Parser_parseCommand(v_a_211_, v___x_229_, v_parserState_217_, v___x_230_);
v_snd_232_ = lean_ctor_get(v___x_231_, 1);
v_fst_233_ = lean_ctor_get(v___x_231_, 0);
v_isSharedCheck_363_ = !lean_is_exclusive(v___x_231_);
if (v_isSharedCheck_363_ == 0)
{
v___x_235_ = v___x_231_;
v_isShared_236_ = v_isSharedCheck_363_;
goto v_resetjp_234_;
}
else
{
lean_inc(v_snd_232_);
lean_inc(v_fst_233_);
lean_dec(v___x_231_);
v___x_235_ = lean_box(0);
v_isShared_236_ = v_isSharedCheck_363_;
goto v_resetjp_234_;
}
v_resetjp_234_:
{
lean_object* v_fst_237_; lean_object* v_snd_238_; lean_object* v___x_240_; uint8_t v_isShared_241_; uint8_t v_isSharedCheck_362_; 
v_fst_237_ = lean_ctor_get(v_snd_232_, 0);
v_snd_238_ = lean_ctor_get(v_snd_232_, 1);
v_isSharedCheck_362_ = !lean_is_exclusive(v_snd_232_);
if (v_isSharedCheck_362_ == 0)
{
v___x_240_ = v_snd_232_;
v_isShared_241_ = v_isSharedCheck_362_;
goto v_resetjp_239_;
}
else
{
lean_inc(v_snd_238_);
lean_inc(v_fst_237_);
lean_dec(v_snd_232_);
v___x_240_ = lean_box(0);
v_isShared_241_ = v_isSharedCheck_362_;
goto v_resetjp_239_;
}
v_resetjp_239_:
{
lean_object* v___x_242_; lean_object* v_commandState_243_; lean_object* v_parserState_244_; lean_object* v_cmdPos_245_; lean_object* v_commands_246_; lean_object* v___x_248_; uint8_t v_isShared_249_; uint8_t v_isSharedCheck_361_; 
v___x_242_ = lean_st_ref_take(v_a_212_);
v_commandState_243_ = lean_ctor_get(v___x_242_, 0);
v_parserState_244_ = lean_ctor_get(v___x_242_, 1);
v_cmdPos_245_ = lean_ctor_get(v___x_242_, 2);
v_commands_246_ = lean_ctor_get(v___x_242_, 3);
v_isSharedCheck_361_ = !lean_is_exclusive(v___x_242_);
if (v_isSharedCheck_361_ == 0)
{
v___x_248_ = v___x_242_;
v_isShared_249_ = v_isSharedCheck_361_;
goto v_resetjp_247_;
}
else
{
lean_inc(v_commands_246_);
lean_inc(v_cmdPos_245_);
lean_inc(v_parserState_244_);
lean_inc(v_commandState_243_);
lean_dec(v___x_242_);
v___x_248_ = lean_box(0);
v_isShared_249_ = v_isSharedCheck_361_;
goto v_resetjp_247_;
}
v_resetjp_247_:
{
lean_object* v___x_250_; lean_object* v___x_252_; 
lean_inc(v_fst_233_);
v___x_250_ = lean_array_push(v_commands_246_, v_fst_233_);
if (v_isShared_249_ == 0)
{
lean_ctor_set(v___x_248_, 3, v___x_250_);
v___x_252_ = v___x_248_;
goto v_reusejp_251_;
}
else
{
lean_object* v_reuseFailAlloc_360_; 
v_reuseFailAlloc_360_ = lean_alloc_ctor(0, 4, 0);
lean_ctor_set(v_reuseFailAlloc_360_, 0, v_commandState_243_);
lean_ctor_set(v_reuseFailAlloc_360_, 1, v_parserState_244_);
lean_ctor_set(v_reuseFailAlloc_360_, 2, v_cmdPos_245_);
lean_ctor_set(v_reuseFailAlloc_360_, 3, v___x_250_);
v___x_252_ = v_reuseFailAlloc_360_;
goto v_reusejp_251_;
}
v_reusejp_251_:
{
lean_object* v___x_253_; lean_object* v___x_254_; 
v___x_253_ = lean_st_ref_set(v_a_212_, v___x_252_);
lean_inc(v_fst_237_);
v___x_254_ = l_Lean_Elab_Frontend_setParserState___redArg(v_fst_237_, v_a_212_);
if (lean_obj_tag(v___x_254_) == 0)
{
lean_object* v___x_255_; 
lean_dec_ref_known(v___x_254_, 1);
lean_inc(v_snd_238_);
v___x_255_ = l_Lean_Elab_Frontend_setMessages___redArg(v_snd_238_, v_a_212_);
if (lean_obj_tag(v___x_255_) == 0)
{
lean_object* v___x_256_; 
lean_dec_ref_known(v___x_255_, 1);
v___x_256_ = rv_thread_cpu_ns();
if (lean_obj_tag(v___x_256_) == 0)
{
lean_object* v_a_257_; lean_object* v___x_258_; lean_object* v___x_259_; 
v_a_257_ = lean_ctor_get(v___x_256_, 0);
lean_inc(v_a_257_);
lean_dec_ref_known(v___x_256_, 1);
v___x_258_ = lean_io_get_num_heartbeats();
lean_inc(v_fst_233_);
v___x_259_ = l_Lean_Elab_Frontend_elabCommandAtFrontend(v_fst_233_, v_a_211_, v_a_212_);
if (lean_obj_tag(v___x_259_) == 0)
{
lean_object* v___x_260_; lean_object* v___x_261_; 
lean_dec_ref_known(v___x_259_, 1);
v___x_260_ = lean_io_get_num_heartbeats();
v___x_261_ = rv_thread_cpu_ns();
if (lean_obj_tag(v___x_261_) == 0)
{
lean_object* v_a_262_; lean_object* v___x_264_; uint8_t v_isShared_265_; uint8_t v_isSharedCheck_319_; 
v_a_262_ = lean_ctor_get(v___x_261_, 0);
v_isSharedCheck_319_ = !lean_is_exclusive(v___x_261_);
if (v_isSharedCheck_319_ == 0)
{
v___x_264_ = v___x_261_;
v_isShared_265_ = v_isSharedCheck_319_;
goto v_resetjp_263_;
}
else
{
lean_inc(v_a_262_);
lean_dec(v___x_261_);
v___x_264_ = lean_box(0);
v_isShared_265_ = v_isSharedCheck_319_;
goto v_resetjp_263_;
}
v_resetjp_263_:
{
lean_object* v___x_266_; lean_object* v_commandState_267_; lean_object* v_pos_268_; lean_object* v_pos_269_; lean_object* v_messages_270_; lean_object* v___x_271_; lean_object* v___x_272_; lean_object* v___x_273_; lean_object* v___x_274_; lean_object* v___x_276_; 
v___x_266_ = lean_st_ref_get(v_a_212_);
v_commandState_267_ = lean_ctor_get(v___x_266_, 0);
lean_inc_ref(v_commandState_267_);
lean_dec(v___x_266_);
v_pos_268_ = lean_ctor_get(v_parserState_217_, 0);
lean_inc(v_pos_268_);
lean_dec_ref(v_parserState_217_);
v_pos_269_ = lean_ctor_get(v_fst_237_, 0);
lean_inc(v_pos_269_);
lean_dec(v_fst_237_);
v_messages_270_ = lean_ctor_get(v_commandState_267_, 1);
lean_inc_ref(v_messages_270_);
lean_dec_ref(v_commandState_267_);
v___x_271_ = ((lean_object*)(l_instToJsonUnitRow_toJson___closed__1));
v___x_272_ = lean_nat_sub(v___x_260_, v___x_258_);
lean_dec(v___x_258_);
lean_dec(v___x_260_);
v___x_273_ = l_Lean_JsonNumber_fromNat(v___x_272_);
v___x_274_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_274_, 0, v___x_273_);
if (v_isShared_241_ == 0)
{
lean_ctor_set(v___x_240_, 1, v___x_274_);
lean_ctor_set(v___x_240_, 0, v___x_271_);
v___x_276_ = v___x_240_;
goto v_reusejp_275_;
}
else
{
lean_object* v_reuseFailAlloc_318_; 
v_reuseFailAlloc_318_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_318_, 0, v___x_271_);
lean_ctor_set(v_reuseFailAlloc_318_, 1, v___x_274_);
v___x_276_ = v_reuseFailAlloc_318_;
goto v_reusejp_275_;
}
v_reusejp_275_:
{
lean_object* v___x_277_; uint64_t v___x_278_; uint64_t v___x_279_; uint64_t v___x_280_; lean_object* v___x_281_; lean_object* v___x_282_; lean_object* v___x_284_; 
v___x_277_ = ((lean_object*)(l_instToJsonUnitRow_toJson___closed__2));
v___x_278_ = lean_unbox_uint64(v_a_262_);
lean_dec(v_a_262_);
v___x_279_ = lean_unbox_uint64(v_a_257_);
lean_dec(v_a_257_);
v___x_280_ = lean_uint64_sub(v___x_278_, v___x_279_);
v___x_281_ = lean_uint64_to_nat(v___x_280_);
v___x_282_ = l_Lean_bignumToJson(v___x_281_);
if (v_isShared_236_ == 0)
{
lean_ctor_set(v___x_235_, 1, v___x_282_);
lean_ctor_set(v___x_235_, 0, v___x_277_);
v___x_284_ = v___x_235_;
goto v_reusejp_283_;
}
else
{
lean_object* v_reuseFailAlloc_317_; 
v_reuseFailAlloc_317_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_317_, 0, v___x_277_);
lean_ctor_set(v_reuseFailAlloc_317_, 1, v___x_282_);
v___x_284_ = v_reuseFailAlloc_317_;
goto v_reusejp_283_;
}
v_reusejp_283_:
{
lean_object* v___x_285_; lean_object* v___x_286_; lean_object* v___x_287_; lean_object* v___x_288_; lean_object* v___x_289_; lean_object* v___x_290_; lean_object* v___x_291_; lean_object* v___x_292_; lean_object* v___x_293_; lean_object* v___x_294_; uint8_t v___x_295_; lean_object* v___x_296_; lean_object* v___x_297_; lean_object* v___x_298_; lean_object* v___x_299_; lean_object* v___x_300_; lean_object* v___x_301_; lean_object* v___x_302_; lean_object* v___x_303_; lean_object* v___x_304_; lean_object* v___x_305_; lean_object* v___x_306_; lean_object* v___x_307_; lean_object* v___x_308_; lean_object* v___x_309_; lean_object* v___x_310_; uint8_t v___x_311_; 
v___x_285_ = ((lean_object*)(l_commands___closed__3));
v___x_286_ = l_Lean_JsonNumber_fromNat(v_pos_268_);
v___x_287_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_287_, 0, v___x_286_);
v___x_288_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_288_, 0, v___x_285_);
lean_ctor_set(v___x_288_, 1, v___x_287_);
v___x_289_ = ((lean_object*)(l_commands___closed__4));
v___x_290_ = l_Lean_JsonNumber_fromNat(v_pos_269_);
v___x_291_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_291_, 0, v___x_290_);
v___x_292_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_292_, 0, v___x_289_);
lean_ctor_set(v___x_292_, 1, v___x_291_);
v___x_293_ = ((lean_object*)(l_commands___closed__5));
lean_inc(v_fst_233_);
v___x_294_ = l_Lean_Syntax_getKind(v_fst_233_);
v___x_295_ = 1;
v___x_296_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v___x_294_, v___x_295_);
v___x_297_ = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(v___x_297_, 0, v___x_296_);
v___x_298_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_298_, 0, v___x_293_);
lean_ctor_set(v___x_298_, 1, v___x_297_);
v___x_299_ = lean_box(0);
v___x_300_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_300_, 0, v___x_298_);
lean_ctor_set(v___x_300_, 1, v___x_299_);
v___x_301_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_301_, 0, v___x_292_);
lean_ctor_set(v___x_301_, 1, v___x_300_);
v___x_302_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_302_, 0, v___x_288_);
lean_ctor_set(v___x_302_, 1, v___x_301_);
v___x_303_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_303_, 0, v___x_284_);
lean_ctor_set(v___x_303_, 1, v___x_302_);
v___x_304_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_304_, 0, v___x_276_);
lean_ctor_set(v___x_304_, 1, v___x_303_);
v___x_305_ = l_Lean_Json_mkObj(v___x_304_);
lean_dec_ref_known(v___x_304_, 2);
v___x_306_ = lean_array_push(v_rows_209_, v___x_305_);
v___x_307_ = l_Lean_MessageLog_toArray(v_snd_238_);
lean_dec(v_snd_238_);
v___x_308_ = l_Array_append___redArg(v_messages_210_, v___x_307_);
lean_dec_ref(v___x_307_);
v___x_309_ = l_Lean_MessageLog_toArray(v_messages_270_);
lean_dec_ref(v_messages_270_);
v___x_310_ = l_Array_append___redArg(v___x_308_, v___x_309_);
lean_dec_ref(v___x_309_);
v___x_311_ = l_Lean_Parser_isTerminalCommand(v_fst_233_);
if (v___x_311_ == 0)
{
lean_del_object(v___x_264_);
v_rows_209_ = v___x_306_;
v_messages_210_ = v___x_310_;
goto _start;
}
else
{
lean_object* v___x_313_; lean_object* v___x_315_; 
v___x_313_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_313_, 0, v___x_306_);
lean_ctor_set(v___x_313_, 1, v___x_310_);
if (v_isShared_265_ == 0)
{
lean_ctor_set(v___x_264_, 0, v___x_313_);
v___x_315_ = v___x_264_;
goto v_reusejp_314_;
}
else
{
lean_object* v_reuseFailAlloc_316_; 
v_reuseFailAlloc_316_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_316_, 0, v___x_313_);
v___x_315_ = v_reuseFailAlloc_316_;
goto v_reusejp_314_;
}
v_reusejp_314_:
{
return v___x_315_;
}
}
}
}
}
}
else
{
lean_object* v_a_320_; lean_object* v___x_322_; uint8_t v_isShared_323_; uint8_t v_isSharedCheck_327_; 
lean_dec(v___x_260_);
lean_dec(v___x_258_);
lean_dec(v_a_257_);
lean_del_object(v___x_240_);
lean_dec(v_snd_238_);
lean_dec(v_fst_237_);
lean_del_object(v___x_235_);
lean_dec(v_fst_233_);
lean_dec_ref(v_parserState_217_);
lean_dec_ref(v_messages_210_);
lean_dec_ref(v_rows_209_);
v_a_320_ = lean_ctor_get(v___x_261_, 0);
v_isSharedCheck_327_ = !lean_is_exclusive(v___x_261_);
if (v_isSharedCheck_327_ == 0)
{
v___x_322_ = v___x_261_;
v_isShared_323_ = v_isSharedCheck_327_;
goto v_resetjp_321_;
}
else
{
lean_inc(v_a_320_);
lean_dec(v___x_261_);
v___x_322_ = lean_box(0);
v_isShared_323_ = v_isSharedCheck_327_;
goto v_resetjp_321_;
}
v_resetjp_321_:
{
lean_object* v___x_325_; 
if (v_isShared_323_ == 0)
{
v___x_325_ = v___x_322_;
goto v_reusejp_324_;
}
else
{
lean_object* v_reuseFailAlloc_326_; 
v_reuseFailAlloc_326_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_326_, 0, v_a_320_);
v___x_325_ = v_reuseFailAlloc_326_;
goto v_reusejp_324_;
}
v_reusejp_324_:
{
return v___x_325_;
}
}
}
}
else
{
lean_object* v_a_328_; lean_object* v___x_330_; uint8_t v_isShared_331_; uint8_t v_isSharedCheck_335_; 
lean_dec(v___x_258_);
lean_dec(v_a_257_);
lean_del_object(v___x_240_);
lean_dec(v_snd_238_);
lean_dec(v_fst_237_);
lean_del_object(v___x_235_);
lean_dec(v_fst_233_);
lean_dec_ref(v_parserState_217_);
lean_dec_ref(v_messages_210_);
lean_dec_ref(v_rows_209_);
v_a_328_ = lean_ctor_get(v___x_259_, 0);
v_isSharedCheck_335_ = !lean_is_exclusive(v___x_259_);
if (v_isSharedCheck_335_ == 0)
{
v___x_330_ = v___x_259_;
v_isShared_331_ = v_isSharedCheck_335_;
goto v_resetjp_329_;
}
else
{
lean_inc(v_a_328_);
lean_dec(v___x_259_);
v___x_330_ = lean_box(0);
v_isShared_331_ = v_isSharedCheck_335_;
goto v_resetjp_329_;
}
v_resetjp_329_:
{
lean_object* v___x_333_; 
if (v_isShared_331_ == 0)
{
v___x_333_ = v___x_330_;
goto v_reusejp_332_;
}
else
{
lean_object* v_reuseFailAlloc_334_; 
v_reuseFailAlloc_334_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_334_, 0, v_a_328_);
v___x_333_ = v_reuseFailAlloc_334_;
goto v_reusejp_332_;
}
v_reusejp_332_:
{
return v___x_333_;
}
}
}
}
else
{
lean_object* v_a_336_; lean_object* v___x_338_; uint8_t v_isShared_339_; uint8_t v_isSharedCheck_343_; 
lean_del_object(v___x_240_);
lean_dec(v_snd_238_);
lean_dec(v_fst_237_);
lean_del_object(v___x_235_);
lean_dec(v_fst_233_);
lean_dec_ref(v_parserState_217_);
lean_dec_ref(v_messages_210_);
lean_dec_ref(v_rows_209_);
v_a_336_ = lean_ctor_get(v___x_256_, 0);
v_isSharedCheck_343_ = !lean_is_exclusive(v___x_256_);
if (v_isSharedCheck_343_ == 0)
{
v___x_338_ = v___x_256_;
v_isShared_339_ = v_isSharedCheck_343_;
goto v_resetjp_337_;
}
else
{
lean_inc(v_a_336_);
lean_dec(v___x_256_);
v___x_338_ = lean_box(0);
v_isShared_339_ = v_isSharedCheck_343_;
goto v_resetjp_337_;
}
v_resetjp_337_:
{
lean_object* v___x_341_; 
if (v_isShared_339_ == 0)
{
v___x_341_ = v___x_338_;
goto v_reusejp_340_;
}
else
{
lean_object* v_reuseFailAlloc_342_; 
v_reuseFailAlloc_342_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_342_, 0, v_a_336_);
v___x_341_ = v_reuseFailAlloc_342_;
goto v_reusejp_340_;
}
v_reusejp_340_:
{
return v___x_341_;
}
}
}
}
else
{
lean_object* v_a_344_; lean_object* v___x_346_; uint8_t v_isShared_347_; uint8_t v_isSharedCheck_351_; 
lean_del_object(v___x_240_);
lean_dec(v_snd_238_);
lean_dec(v_fst_237_);
lean_del_object(v___x_235_);
lean_dec(v_fst_233_);
lean_dec_ref(v_parserState_217_);
lean_dec_ref(v_messages_210_);
lean_dec_ref(v_rows_209_);
v_a_344_ = lean_ctor_get(v___x_255_, 0);
v_isSharedCheck_351_ = !lean_is_exclusive(v___x_255_);
if (v_isSharedCheck_351_ == 0)
{
v___x_346_ = v___x_255_;
v_isShared_347_ = v_isSharedCheck_351_;
goto v_resetjp_345_;
}
else
{
lean_inc(v_a_344_);
lean_dec(v___x_255_);
v___x_346_ = lean_box(0);
v_isShared_347_ = v_isSharedCheck_351_;
goto v_resetjp_345_;
}
v_resetjp_345_:
{
lean_object* v___x_349_; 
if (v_isShared_347_ == 0)
{
v___x_349_ = v___x_346_;
goto v_reusejp_348_;
}
else
{
lean_object* v_reuseFailAlloc_350_; 
v_reuseFailAlloc_350_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_350_, 0, v_a_344_);
v___x_349_ = v_reuseFailAlloc_350_;
goto v_reusejp_348_;
}
v_reusejp_348_:
{
return v___x_349_;
}
}
}
}
else
{
lean_object* v_a_352_; lean_object* v___x_354_; uint8_t v_isShared_355_; uint8_t v_isSharedCheck_359_; 
lean_del_object(v___x_240_);
lean_dec(v_snd_238_);
lean_dec(v_fst_237_);
lean_del_object(v___x_235_);
lean_dec(v_fst_233_);
lean_dec_ref(v_parserState_217_);
lean_dec_ref(v_messages_210_);
lean_dec_ref(v_rows_209_);
v_a_352_ = lean_ctor_get(v___x_254_, 0);
v_isSharedCheck_359_ = !lean_is_exclusive(v___x_254_);
if (v_isSharedCheck_359_ == 0)
{
v___x_354_ = v___x_254_;
v_isShared_355_ = v_isSharedCheck_359_;
goto v_resetjp_353_;
}
else
{
lean_inc(v_a_352_);
lean_dec(v___x_254_);
v___x_354_ = lean_box(0);
v_isShared_355_ = v_isSharedCheck_359_;
goto v_resetjp_353_;
}
v_resetjp_353_:
{
lean_object* v___x_357_; 
if (v_isShared_355_ == 0)
{
v___x_357_ = v___x_354_;
goto v_reusejp_356_;
}
else
{
lean_object* v_reuseFailAlloc_358_; 
v_reuseFailAlloc_358_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_358_, 0, v_a_352_);
v___x_357_ = v_reuseFailAlloc_358_;
goto v_reusejp_356_;
}
v_reusejp_356_:
{
return v___x_357_;
}
}
}
}
}
}
}
}
}
}
else
{
lean_object* v_a_368_; lean_object* v___x_370_; uint8_t v_isShared_371_; uint8_t v_isSharedCheck_375_; 
lean_dec_ref(v_messages_210_);
lean_dec_ref(v_rows_209_);
v_a_368_ = lean_ctor_get(v___x_214_, 0);
v_isSharedCheck_375_ = !lean_is_exclusive(v___x_214_);
if (v_isSharedCheck_375_ == 0)
{
v___x_370_ = v___x_214_;
v_isShared_371_ = v_isSharedCheck_375_;
goto v_resetjp_369_;
}
else
{
lean_inc(v_a_368_);
lean_dec(v___x_214_);
v___x_370_ = lean_box(0);
v_isShared_371_ = v_isSharedCheck_375_;
goto v_resetjp_369_;
}
v_resetjp_369_:
{
lean_object* v___x_373_; 
if (v_isShared_371_ == 0)
{
v___x_373_ = v___x_370_;
goto v_reusejp_372_;
}
else
{
lean_object* v_reuseFailAlloc_374_; 
v_reuseFailAlloc_374_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_374_, 0, v_a_368_);
v___x_373_ = v_reuseFailAlloc_374_;
goto v_reusejp_372_;
}
v_reusejp_372_:
{
return v___x_373_;
}
}
}
}
}
LEAN_EXPORT lean_object* l_commands___boxed(lean_object* v_rows_376_, lean_object* v_messages_377_, lean_object* v_a_378_, lean_object* v_a_379_, lean_object* v_a_380_){
_start:
{
lean_object* v_res_381_; 
v_res_381_ = l_commands(v_rows_376_, v_messages_377_, v_a_378_, v_a_379_);
lean_dec(v_a_379_);
lean_dec_ref(v_a_378_);
return v_res_381_;
}
}
LEAN_EXPORT lean_object* l_Lean_collectAxioms___at___00elaborateOne_spec__1___redArg(lean_object* v_constName_382_, lean_object* v___y_383_){
_start:
{
lean_object* v___x_385_; lean_object* v_env_386_; lean_object* v___x_387_; uint8_t v___x_388_; lean_object* v_privateEnv_389_; lean_object* v___x_390_; lean_object* v___x_391_; lean_object* v___x_392_; lean_object* v_s_393_; lean_object* v___x_394_; lean_object* v___x_395_; lean_object* v___x_396_; lean_object* v___x_397_; 
v___x_385_ = lean_st_ref_get(v___y_383_);
v_env_386_ = lean_ctor_get(v___x_385_, 0);
lean_inc_ref_n(v_env_386_, 2);
lean_dec(v___x_385_);
v___x_387_ = l___private_Lean_Util_CollectAxioms_0__Lean_instInhabitedExportedAxiomsState;
v___x_388_ = 0;
v_privateEnv_389_ = l_Lean_Environment_setExporting(v_env_386_, v___x_388_);
v___x_390_ = l___private_Lean_Util_CollectAxioms_0__Lean_exportedAxiomsExt;
v___x_391_ = lean_box(2);
v___x_392_ = lean_box(0);
v_s_393_ = l_Lean_PersistentEnvExtension_getState___redArg(v___x_387_, v___x_390_, v_env_386_, v___x_391_, v___x_392_);
v___x_394_ = lean_alloc_closure((void*)(l___private_Lean_Util_CollectAxioms_0__Lean_ExportedAxiomsState_find_x3f___boxed), 3, 1);
lean_closure_set(v___x_394_, 0, v_s_393_);
v___x_395_ = lean_alloc_closure((void*)(l___private_Lean_Util_CollectAxioms_0__Lean_CollectAxioms_collectAndGet___boxed), 4, 2);
lean_closure_set(v___x_395_, 0, v___x_394_);
lean_closure_set(v___x_395_, 1, v_constName_382_);
v___x_396_ = l___private_Lean_Util_CollectAxioms_0__Lean_CollectAxioms_runM___redArg(v_privateEnv_389_, v___x_395_);
v___x_397_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_397_, 0, v___x_396_);
return v___x_397_;
}
}
LEAN_EXPORT lean_object* l_Lean_collectAxioms___at___00elaborateOne_spec__1___redArg___boxed(lean_object* v_constName_398_, lean_object* v___y_399_, lean_object* v___y_400_){
_start:
{
lean_object* v_res_401_; 
v_res_401_ = l_Lean_collectAxioms___at___00elaborateOne_spec__1___redArg(v_constName_398_, v___y_399_);
lean_dec(v___y_399_);
return v_res_401_;
}
}
LEAN_EXPORT lean_object* l_Lean_collectAxioms___at___00elaborateOne_spec__1(lean_object* v_constName_402_, lean_object* v___y_403_, lean_object* v___y_404_){
_start:
{
lean_object* v___x_406_; 
v___x_406_ = l_Lean_collectAxioms___at___00elaborateOne_spec__1___redArg(v_constName_402_, v___y_404_);
return v___x_406_;
}
}
LEAN_EXPORT lean_object* l_Lean_collectAxioms___at___00elaborateOne_spec__1___boxed(lean_object* v_constName_407_, lean_object* v___y_408_, lean_object* v___y_409_, lean_object* v___y_410_){
_start:
{
lean_object* v_res_411_; 
v_res_411_ = l_Lean_collectAxioms___at___00elaborateOne_spec__1(v_constName_407_, v___y_408_, v___y_409_);
lean_dec(v___y_409_);
lean_dec_ref(v___y_408_);
return v_res_411_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00elaborateOne_spec__0(lean_object* v_as_412_, size_t v_sz_413_, size_t v_i_414_, lean_object* v_b_415_){
_start:
{
lean_object* v_a_418_; uint8_t v___x_422_; 
v___x_422_ = lean_usize_dec_lt(v_i_414_, v_sz_413_);
if (v___x_422_ == 0)
{
lean_object* v___x_423_; 
v___x_423_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_423_, 0, v_b_415_);
return v___x_423_;
}
else
{
lean_object* v_a_424_; uint8_t v_severity_425_; lean_object* v_data_426_; uint8_t v___x_427_; uint8_t v___x_428_; 
v_a_424_ = lean_array_uget_borrowed(v_as_412_, v_i_414_);
v_severity_425_ = lean_ctor_get_uint8(v_a_424_, sizeof(void*)*5 + 1);
v_data_426_ = lean_ctor_get(v_a_424_, 4);
v___x_427_ = 2;
v___x_428_ = l_Lean_instBEqMessageSeverity_beq(v_severity_425_, v___x_427_);
if (v___x_428_ == 0)
{
v_a_418_ = v_b_415_;
goto v___jp_417_;
}
else
{
lean_object* v___x_429_; lean_object* v___x_430_; 
lean_inc(v_data_426_);
v___x_429_ = l_Lean_MessageData_toString(v_data_426_);
v___x_430_ = lean_array_push(v_b_415_, v___x_429_);
v_a_418_ = v___x_430_;
goto v___jp_417_;
}
}
v___jp_417_:
{
size_t v___x_419_; size_t v___x_420_; 
v___x_419_ = ((size_t)1ULL);
v___x_420_ = lean_usize_add(v_i_414_, v___x_419_);
v_i_414_ = v___x_420_;
v_b_415_ = v_a_418_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00elaborateOne_spec__0___boxed(lean_object* v_as_431_, lean_object* v_sz_432_, lean_object* v_i_433_, lean_object* v_b_434_, lean_object* v___y_435_){
_start:
{
size_t v_sz_boxed_436_; size_t v_i_boxed_437_; lean_object* v_res_438_; 
v_sz_boxed_436_ = lean_unbox_usize(v_sz_432_);
lean_dec(v_sz_432_);
v_i_boxed_437_ = lean_unbox_usize(v_i_433_);
lean_dec(v_i_433_);
v_res_438_ = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00elaborateOne_spec__0(v_as_431_, v_sz_boxed_436_, v_i_boxed_437_, v_b_434_);
lean_dec_ref(v_as_431_);
return v_res_438_;
}
}
static lean_object* _init_l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__2(void){
_start:
{
lean_object* v___x_442_; 
v___x_442_ = l_Lean_PersistentHashMap_mkEmptyEntriesArray(lean_box(0), lean_box(0));
return v___x_442_;
}
}
static lean_object* _init_l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__3(void){
_start:
{
lean_object* v___x_443_; lean_object* v___x_444_; 
v___x_443_ = lean_obj_once(&l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__2, &l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__2_once, _init_l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__2);
v___x_444_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_444_, 0, v___x_443_);
return v___x_444_;
}
}
static lean_object* _init_l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__4(void){
_start:
{
lean_object* v___x_445_; lean_object* v___x_446_; 
v___x_445_ = lean_obj_once(&l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__3, &l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__3_once, _init_l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__3);
v___x_446_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_446_, 0, v___x_445_);
lean_ctor_set(v___x_446_, 1, v___x_445_);
return v___x_446_;
}
}
static lean_object* _init_l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__9(void){
_start:
{
lean_object* v___x_457_; uint64_t v___x_458_; lean_object* v___x_459_; 
v___x_457_ = lean_obj_once(&l_commands___closed__1, &l_commands___closed__1_once, _init_l_commands___closed__1);
v___x_458_ = 0ULL;
v___x_459_ = lean_alloc_ctor(0, 1, 8);
lean_ctor_set(v___x_459_, 0, v___x_457_);
lean_ctor_set_uint64(v___x_459_, sizeof(void*)*1, v___x_458_);
return v___x_459_;
}
}
static lean_object* _init_l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__10(void){
_start:
{
lean_object* v___x_460_; lean_object* v___x_461_; uint8_t v___x_462_; lean_object* v___x_463_; 
v___x_460_ = lean_obj_once(&l_commands___closed__1, &l_commands___closed__1_once, _init_l_commands___closed__1);
v___x_461_ = lean_obj_once(&l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__3, &l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__3_once, _init_l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__3);
v___x_462_ = 1;
v___x_463_ = lean_alloc_ctor(0, 3, 1);
lean_ctor_set(v___x_463_, 0, v___x_461_);
lean_ctor_set(v___x_463_, 1, v___x_461_);
lean_ctor_set(v___x_463_, 2, v___x_460_);
lean_ctor_set_uint8(v___x_463_, sizeof(void*)*3, v___x_462_);
return v___x_463_;
}
}
static lean_object* _init_l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__12(void){
_start:
{
lean_object* v___x_466_; lean_object* v___x_467_; 
v___x_466_ = l_Lean_Options_empty;
v___x_467_ = l_Lean_Core_getMaxHeartbeats(v___x_466_);
return v___x_467_;
}
}
static uint8_t _init_l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__13(void){
_start:
{
lean_object* v___x_468_; lean_object* v___x_469_; uint8_t v___x_470_; 
v___x_468_ = l_Lean_diagnostics;
v___x_469_ = l_Lean_Options_empty;
v___x_470_ = l_Lean_Option_get___at___00Lean_Elab_addMacroStack___at___00Lean_throwError___at___00Lean_throwErrorAt___at___00Lean_throwUnknownIdentifierAt___at___00Lean_throwUnknownConstantAt___at___00Lean_throwUnknownConstant___at___00Lean_getConstVal___at___00Lean_mkConstWithLevelParams___at___00Lean_Elab_addConstInfo___at___00Lean_Elab_PostprocessTraces_elabStoreTraceAs_spec__3_spec__5_spec__6_spec__9_spec__12_spec__14_spec__16_spec__18_spec__20_spec__21(v___x_469_, v___x_468_);
return v___x_470_;
}
}
LEAN_EXPORT lean_object* l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg(lean_object* v___x_471_, lean_object* v_ctx_472_, lean_object* v_file_473_, lean_object* v_base_474_, lean_object* v_as_x27_475_, lean_object* v_b_476_){
_start:
{
lean_object* v___x_478_; lean_object* v___x_479_; 
v___x_478_ = lean_unsigned_to_nat(0u);
v___x_479_ = lean_obj_once(&l_commands___closed__2, &l_commands___closed__2_once, _init_l_commands___closed__2);
if (lean_obj_tag(v_as_x27_475_) == 0)
{
lean_object* v___x_480_; 
lean_dec_ref(v_base_474_);
lean_dec_ref(v_file_473_);
lean_dec_ref(v___x_471_);
v___x_480_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_480_, 0, v_b_476_);
return v___x_480_;
}
else
{
lean_object* v_head_481_; lean_object* v_snd_482_; lean_object* v_tail_483_; lean_object* v_fst_484_; lean_object* v_snd_485_; lean_object* v_fst_486_; lean_object* v___x_488_; uint8_t v_isShared_489_; uint8_t v_isSharedCheck_592_; 
v_head_481_ = lean_ctor_get(v_as_x27_475_, 0);
v_snd_482_ = lean_ctor_get(v_b_476_, 1);
lean_inc(v_snd_482_);
v_tail_483_ = lean_ctor_get(v_as_x27_475_, 1);
v_fst_484_ = lean_ctor_get(v_head_481_, 0);
v_snd_485_ = lean_ctor_get(v_head_481_, 1);
v_fst_486_ = lean_ctor_get(v_b_476_, 0);
v_isSharedCheck_592_ = !lean_is_exclusive(v_b_476_);
if (v_isSharedCheck_592_ == 0)
{
lean_object* v_unused_593_; 
v_unused_593_ = lean_ctor_get(v_b_476_, 1);
lean_dec(v_unused_593_);
v___x_488_ = v_b_476_;
v_isShared_489_ = v_isSharedCheck_592_;
goto v_resetjp_487_;
}
else
{
lean_inc(v_fst_486_);
lean_dec(v_b_476_);
v___x_488_ = lean_box(0);
v_isShared_489_ = v_isSharedCheck_592_;
goto v_resetjp_487_;
}
v_resetjp_487_:
{
lean_object* v_fst_490_; lean_object* v_snd_491_; lean_object* v___x_493_; uint8_t v_isShared_494_; uint8_t v_isSharedCheck_591_; 
v_fst_490_ = lean_ctor_get(v_snd_482_, 0);
v_snd_491_ = lean_ctor_get(v_snd_482_, 1);
v_isSharedCheck_591_ = !lean_is_exclusive(v_snd_482_);
if (v_isSharedCheck_591_ == 0)
{
v___x_493_ = v_snd_482_;
v_isShared_494_ = v_isSharedCheck_591_;
goto v_resetjp_492_;
}
else
{
lean_inc(v_snd_491_);
lean_inc(v_fst_490_);
lean_dec(v_snd_482_);
v___x_493_ = lean_box(0);
v_isShared_494_ = v_isSharedCheck_591_;
goto v_resetjp_492_;
}
v_resetjp_492_:
{
uint8_t v___x_495_; uint8_t v___y_497_; lean_object* v___y_498_; lean_object* v___y_499_; lean_object* v___y_500_; lean_object* v___y_501_; lean_object* v___y_502_; lean_object* v___y_503_; uint8_t v___y_525_; lean_object* v___y_526_; lean_object* v___y_527_; lean_object* v___y_528_; lean_object* v___y_529_; lean_object* v___y_530_; lean_object* v___y_531_; uint8_t v___y_532_; uint8_t v___x_552_; 
v___x_495_ = 1;
lean_inc(v_fst_484_);
lean_inc_ref(v_base_474_);
v___x_552_ = l_Lean_Environment_contains(v_base_474_, v_fst_484_, v___x_495_);
if (v___x_552_ == 0)
{
lean_object* v___x_553_; lean_object* v_newAxioms_555_; 
v___x_553_ = l_Lean_Options_empty;
if (lean_obj_tag(v_snd_485_) == 0)
{
lean_object* v___x_586_; lean_object* v___x_587_; 
lean_inc(v_fst_484_);
v___x_586_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v_fst_484_, v___x_495_);
v___x_587_ = lean_array_push(v_snd_491_, v___x_586_);
v_newAxioms_555_ = v___x_587_;
goto v___jp_554_;
}
else
{
v_newAxioms_555_ = v_snd_491_;
goto v___jp_554_;
}
v___jp_554_:
{
if (lean_obj_tag(v_snd_485_) == 2)
{
lean_object* v___x_556_; lean_object* v___x_557_; lean_object* v___x_558_; lean_object* v___x_559_; lean_object* v___x_560_; lean_object* v___x_561_; lean_object* v___x_562_; lean_object* v___x_563_; lean_object* v___x_564_; lean_object* v___x_565_; lean_object* v___x_566_; lean_object* v___x_567_; lean_object* v___x_568_; lean_object* v___x_569_; lean_object* v___x_570_; lean_object* v___x_571_; lean_object* v___x_572_; lean_object* v_fileMap_573_; lean_object* v___x_574_; lean_object* v___x_575_; lean_object* v___x_576_; lean_object* v___x_577_; lean_object* v___x_578_; lean_object* v_env_579_; lean_object* v___x_580_; uint8_t v___x_581_; uint8_t v___x_582_; 
v___x_556_ = lean_obj_once(&l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__4, &l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__4_once, _init_l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__4);
v___x_557_ = lean_io_get_num_heartbeats();
lean_inc(v_fst_484_);
v___x_558_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v_fst_484_, v___x_495_);
v___x_559_ = lean_unsigned_to_nat(1u);
v___x_560_ = ((lean_object*)(l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__7));
v___x_561_ = lean_box(0);
v___x_562_ = lean_unsigned_to_nat(2u);
v___x_563_ = lean_box(0);
v___x_564_ = ((lean_object*)(l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__8));
v___x_565_ = lean_obj_once(&l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__9, &l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__9_once, _init_l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__9);
v___x_566_ = lean_obj_once(&l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__10, &l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__10_once, _init_l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__10);
v___x_567_ = ((lean_object*)(l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__11));
lean_inc_ref(v___x_471_);
v___x_568_ = lean_alloc_ctor(0, 9, 0);
lean_ctor_set(v___x_568_, 0, v___x_471_);
lean_ctor_set(v___x_568_, 1, v___x_562_);
lean_ctor_set(v___x_568_, 2, v___x_560_);
lean_ctor_set(v___x_568_, 3, v___x_564_);
lean_ctor_set(v___x_568_, 4, v___x_565_);
lean_ctor_set(v___x_568_, 5, v___x_556_);
lean_ctor_set(v___x_568_, 6, v___x_479_);
lean_ctor_set(v___x_568_, 7, v___x_566_);
lean_ctor_set(v___x_568_, 8, v___x_567_);
v___x_569_ = lean_st_mk_ref(v___x_568_);
v___x_570_ = l_Lean_inheritedTraceOptions;
v___x_571_ = lean_st_ref_get(v___x_570_);
v___x_572_ = lean_st_ref_get(v___x_569_);
v_fileMap_573_ = lean_ctor_get(v_ctx_472_, 2);
v___x_574_ = lean_unsigned_to_nat(1000u);
v___x_575_ = lean_box(0);
v___x_576_ = lean_obj_once(&l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__12, &l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__12_once, _init_l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__12);
v___x_577_ = lean_box(0);
lean_inc_ref(v_fileMap_573_);
lean_inc_ref(v_file_473_);
v___x_578_ = lean_alloc_ctor(0, 14, 2);
lean_ctor_set(v___x_578_, 0, v_file_473_);
lean_ctor_set(v___x_578_, 1, v_fileMap_573_);
lean_ctor_set(v___x_578_, 2, v___x_553_);
lean_ctor_set(v___x_578_, 3, v___x_478_);
lean_ctor_set(v___x_578_, 4, v___x_574_);
lean_ctor_set(v___x_578_, 5, v___x_575_);
lean_ctor_set(v___x_578_, 6, v___x_561_);
lean_ctor_set(v___x_578_, 7, v___x_563_);
lean_ctor_set(v___x_578_, 8, v___x_557_);
lean_ctor_set(v___x_578_, 9, v___x_576_);
lean_ctor_set(v___x_578_, 10, v___x_561_);
lean_ctor_set(v___x_578_, 11, v___x_559_);
lean_ctor_set(v___x_578_, 12, v___x_577_);
lean_ctor_set(v___x_578_, 13, v___x_571_);
lean_ctor_set_uint8(v___x_578_, sizeof(void*)*14, v___x_552_);
lean_ctor_set_uint8(v___x_578_, sizeof(void*)*14 + 1, v___x_552_);
v_env_579_ = lean_ctor_get(v___x_572_, 0);
lean_inc_ref(v_env_579_);
lean_dec(v___x_572_);
lean_inc_ref(v___x_558_);
v___x_580_ = lean_array_push(v_fst_486_, v___x_558_);
v___x_581_ = lean_uint8_once(&l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__13, &l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__13_once, _init_l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__13);
v___x_582_ = l_Lean_Kernel_isDiagnosticsEnabled(v_env_579_);
lean_dec_ref(v_env_579_);
if (v___x_582_ == 0)
{
if (v___x_581_ == 0)
{
lean_inc(v___x_569_);
v___y_497_ = v___x_581_;
v___y_498_ = v___x_580_;
v___y_499_ = v___x_569_;
v___y_500_ = v_newAxioms_555_;
v___y_501_ = v___x_558_;
v___y_502_ = v___x_578_;
v___y_503_ = v___x_569_;
goto v___jp_496_;
}
else
{
v___y_525_ = v___x_581_;
v___y_526_ = v___x_580_;
v___y_527_ = v___x_569_;
v___y_528_ = v___x_578_;
v___y_529_ = v___x_556_;
v___y_530_ = v_newAxioms_555_;
v___y_531_ = v___x_558_;
v___y_532_ = v___x_582_;
goto v___jp_524_;
}
}
else
{
v___y_525_ = v___x_581_;
v___y_526_ = v___x_580_;
v___y_527_ = v___x_569_;
v___y_528_ = v___x_578_;
v___y_529_ = v___x_556_;
v___y_530_ = v_newAxioms_555_;
v___y_531_ = v___x_558_;
v___y_532_ = v___x_581_;
goto v___jp_524_;
}
}
else
{
lean_object* v___x_583_; lean_object* v___x_584_; 
lean_del_object(v___x_493_);
lean_del_object(v___x_488_);
v___x_583_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_583_, 0, v_fst_490_);
lean_ctor_set(v___x_583_, 1, v_newAxioms_555_);
v___x_584_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_584_, 0, v_fst_486_);
lean_ctor_set(v___x_584_, 1, v___x_583_);
v_as_x27_475_ = v_tail_483_;
v_b_476_ = v___x_584_;
goto _start;
}
}
}
else
{
lean_object* v___x_588_; lean_object* v___x_589_; 
lean_del_object(v___x_493_);
lean_del_object(v___x_488_);
v___x_588_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_588_, 0, v_fst_490_);
lean_ctor_set(v___x_588_, 1, v_snd_491_);
v___x_589_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_589_, 0, v_fst_486_);
lean_ctor_set(v___x_589_, 1, v___x_588_);
v_as_x27_475_ = v_tail_483_;
v_b_476_ = v___x_589_;
goto _start;
}
v___jp_496_:
{
lean_object* v___x_504_; lean_object* v_a_505_; lean_object* v___x_506_; lean_object* v___x_507_; uint8_t v___x_508_; 
lean_dec_ref(v___y_502_);
lean_inc(v_fst_484_);
v___x_504_ = l_Lean_collectAxioms___at___00elaborateOne_spec__1___redArg(v_fst_484_, v___y_503_);
lean_dec(v___y_503_);
v_a_505_ = lean_ctor_get(v___x_504_, 0);
lean_inc(v_a_505_);
lean_dec_ref(v___x_504_);
v___x_506_ = lean_st_ref_get(v___y_499_);
lean_dec(v___y_499_);
lean_dec(v___x_506_);
v___x_507_ = ((lean_object*)(l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__1));
v___x_508_ = l_Array_contains___at___00__private_Lean_Linter_CheckUnivs_0__Lean_Linter_CheckUnivs_badParams_spec__0(v_a_505_, v___x_507_);
lean_dec(v_a_505_);
if (v___x_508_ == 0)
{
lean_object* v___x_510_; 
lean_dec_ref(v___y_501_);
if (v_isShared_494_ == 0)
{
lean_ctor_set(v___x_493_, 1, v___y_500_);
v___x_510_ = v___x_493_;
goto v_reusejp_509_;
}
else
{
lean_object* v_reuseFailAlloc_515_; 
v_reuseFailAlloc_515_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_515_, 0, v_fst_490_);
lean_ctor_set(v_reuseFailAlloc_515_, 1, v___y_500_);
v___x_510_ = v_reuseFailAlloc_515_;
goto v_reusejp_509_;
}
v_reusejp_509_:
{
lean_object* v___x_512_; 
if (v_isShared_489_ == 0)
{
lean_ctor_set(v___x_488_, 1, v___x_510_);
lean_ctor_set(v___x_488_, 0, v___y_498_);
v___x_512_ = v___x_488_;
goto v_reusejp_511_;
}
else
{
lean_object* v_reuseFailAlloc_514_; 
v_reuseFailAlloc_514_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_514_, 0, v___y_498_);
lean_ctor_set(v_reuseFailAlloc_514_, 1, v___x_510_);
v___x_512_ = v_reuseFailAlloc_514_;
goto v_reusejp_511_;
}
v_reusejp_511_:
{
v_as_x27_475_ = v_tail_483_;
v_b_476_ = v___x_512_;
goto _start;
}
}
}
else
{
lean_object* v___x_516_; lean_object* v___x_518_; 
v___x_516_ = lean_array_push(v_fst_490_, v___y_501_);
if (v_isShared_494_ == 0)
{
lean_ctor_set(v___x_493_, 1, v___y_500_);
lean_ctor_set(v___x_493_, 0, v___x_516_);
v___x_518_ = v___x_493_;
goto v_reusejp_517_;
}
else
{
lean_object* v_reuseFailAlloc_523_; 
v_reuseFailAlloc_523_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_523_, 0, v___x_516_);
lean_ctor_set(v_reuseFailAlloc_523_, 1, v___y_500_);
v___x_518_ = v_reuseFailAlloc_523_;
goto v_reusejp_517_;
}
v_reusejp_517_:
{
lean_object* v___x_520_; 
if (v_isShared_489_ == 0)
{
lean_ctor_set(v___x_488_, 1, v___x_518_);
lean_ctor_set(v___x_488_, 0, v___y_498_);
v___x_520_ = v___x_488_;
goto v_reusejp_519_;
}
else
{
lean_object* v_reuseFailAlloc_522_; 
v_reuseFailAlloc_522_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_522_, 0, v___y_498_);
lean_ctor_set(v_reuseFailAlloc_522_, 1, v___x_518_);
v___x_520_ = v_reuseFailAlloc_522_;
goto v_reusejp_519_;
}
v_reusejp_519_:
{
v_as_x27_475_ = v_tail_483_;
v_b_476_ = v___x_520_;
goto _start;
}
}
}
}
v___jp_524_:
{
if (v___y_532_ == 0)
{
lean_object* v___x_533_; lean_object* v_env_534_; lean_object* v_nextMacroScope_535_; lean_object* v_ngen_536_; lean_object* v_auxDeclNGen_537_; lean_object* v_traceState_538_; lean_object* v_messages_539_; lean_object* v_infoState_540_; lean_object* v_snapshotTasks_541_; lean_object* v___x_543_; uint8_t v_isShared_544_; uint8_t v_isSharedCheck_550_; 
v___x_533_ = lean_st_ref_take(v___y_527_);
v_env_534_ = lean_ctor_get(v___x_533_, 0);
v_nextMacroScope_535_ = lean_ctor_get(v___x_533_, 1);
v_ngen_536_ = lean_ctor_get(v___x_533_, 2);
v_auxDeclNGen_537_ = lean_ctor_get(v___x_533_, 3);
v_traceState_538_ = lean_ctor_get(v___x_533_, 4);
v_messages_539_ = lean_ctor_get(v___x_533_, 6);
v_infoState_540_ = lean_ctor_get(v___x_533_, 7);
v_snapshotTasks_541_ = lean_ctor_get(v___x_533_, 8);
v_isSharedCheck_550_ = !lean_is_exclusive(v___x_533_);
if (v_isSharedCheck_550_ == 0)
{
lean_object* v_unused_551_; 
v_unused_551_ = lean_ctor_get(v___x_533_, 5);
lean_dec(v_unused_551_);
v___x_543_ = v___x_533_;
v_isShared_544_ = v_isSharedCheck_550_;
goto v_resetjp_542_;
}
else
{
lean_inc(v_snapshotTasks_541_);
lean_inc(v_infoState_540_);
lean_inc(v_messages_539_);
lean_inc(v_traceState_538_);
lean_inc(v_auxDeclNGen_537_);
lean_inc(v_ngen_536_);
lean_inc(v_nextMacroScope_535_);
lean_inc(v_env_534_);
lean_dec(v___x_533_);
v___x_543_ = lean_box(0);
v_isShared_544_ = v_isSharedCheck_550_;
goto v_resetjp_542_;
}
v_resetjp_542_:
{
lean_object* v___x_545_; lean_object* v___x_547_; 
v___x_545_ = l_Lean_Kernel_enableDiag(v_env_534_, v___y_525_);
lean_inc_ref(v___y_529_);
if (v_isShared_544_ == 0)
{
lean_ctor_set(v___x_543_, 5, v___y_529_);
lean_ctor_set(v___x_543_, 0, v___x_545_);
v___x_547_ = v___x_543_;
goto v_reusejp_546_;
}
else
{
lean_object* v_reuseFailAlloc_549_; 
v_reuseFailAlloc_549_ = lean_alloc_ctor(0, 9, 0);
lean_ctor_set(v_reuseFailAlloc_549_, 0, v___x_545_);
lean_ctor_set(v_reuseFailAlloc_549_, 1, v_nextMacroScope_535_);
lean_ctor_set(v_reuseFailAlloc_549_, 2, v_ngen_536_);
lean_ctor_set(v_reuseFailAlloc_549_, 3, v_auxDeclNGen_537_);
lean_ctor_set(v_reuseFailAlloc_549_, 4, v_traceState_538_);
lean_ctor_set(v_reuseFailAlloc_549_, 5, v___y_529_);
lean_ctor_set(v_reuseFailAlloc_549_, 6, v_messages_539_);
lean_ctor_set(v_reuseFailAlloc_549_, 7, v_infoState_540_);
lean_ctor_set(v_reuseFailAlloc_549_, 8, v_snapshotTasks_541_);
v___x_547_ = v_reuseFailAlloc_549_;
goto v_reusejp_546_;
}
v_reusejp_546_:
{
lean_object* v___x_548_; 
v___x_548_ = lean_st_ref_set(v___y_527_, v___x_547_);
lean_inc(v___y_527_);
v___y_497_ = v___y_525_;
v___y_498_ = v___y_526_;
v___y_499_ = v___y_527_;
v___y_500_ = v___y_530_;
v___y_501_ = v___y_531_;
v___y_502_ = v___y_528_;
v___y_503_ = v___y_527_;
goto v___jp_496_;
}
}
}
else
{
lean_inc(v___y_527_);
v___y_497_ = v___y_525_;
v___y_498_ = v___y_526_;
v___y_499_ = v___y_527_;
v___y_500_ = v___y_530_;
v___y_501_ = v___y_531_;
v___y_502_ = v___y_528_;
v___y_503_ = v___y_527_;
goto v___jp_496_;
}
}
}
}
}
}
}
LEAN_EXPORT lean_object* l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___boxed(lean_object* v___x_594_, lean_object* v_ctx_595_, lean_object* v_file_596_, lean_object* v_base_597_, lean_object* v_as_x27_598_, lean_object* v_b_599_, lean_object* v___y_600_){
_start:
{
lean_object* v_res_601_; 
v_res_601_ = l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg(v___x_594_, v_ctx_595_, v_file_596_, v_base_597_, v_as_x27_598_, v_b_599_);
lean_dec(v_as_x27_598_);
lean_dec_ref(v_ctx_595_);
return v_res_601_;
}
}
static lean_object* _init_l_elaborateOne___closed__2(void){
_start:
{
lean_object* v___x_605_; lean_object* v___x_606_; lean_object* v___x_607_; lean_object* v___x_608_; 
v___x_605_ = lean_unsigned_to_nat(2000000u);
v___x_606_ = ((lean_object*)(l_elaborateOne___closed__1));
v___x_607_ = l_Lean_Options_empty;
v___x_608_ = l_Lean_Options_set___at___00Lean_Option_set___at___00__private_Lean_Shell_0__Lean_ShellOptions_process_spec__2_spec__3(v___x_607_, v___x_606_, v___x_605_);
return v___x_608_;
}
}
static lean_object* _init_l_elaborateOne___closed__5(void){
_start:
{
lean_object* v___x_612_; lean_object* v___x_613_; lean_object* v___x_614_; lean_object* v___x_615_; 
v___x_612_ = lean_unsigned_to_nat(20000u);
v___x_613_ = ((lean_object*)(l_elaborateOne___closed__4));
v___x_614_ = lean_obj_once(&l_elaborateOne___closed__2, &l_elaborateOne___closed__2_once, _init_l_elaborateOne___closed__2);
v___x_615_ = l_Lean_Options_set___at___00Lean_Option_set___at___00__private_Lean_Shell_0__Lean_ShellOptions_process_spec__2_spec__3(v___x_614_, v___x_613_, v___x_612_);
return v___x_615_;
}
}
static lean_object* _init_l_elaborateOne___closed__9(void){
_start:
{
uint8_t v___x_621_; lean_object* v___x_622_; lean_object* v___x_623_; lean_object* v_opts_624_; 
v___x_621_ = 0;
v___x_622_ = ((lean_object*)(l_elaborateOne___closed__8));
v___x_623_ = lean_obj_once(&l_elaborateOne___closed__5, &l_elaborateOne___closed__5_once, _init_l_elaborateOne___closed__5);
v_opts_624_ = l_Lean_Options_set___at___00Lean_Option_set___at___00__private_Lean_Shell_0__Lean_ShellOptions_process_spec__1_spec__1(v___x_623_, v___x_622_, v___x_621_);
return v_opts_624_;
}
}
LEAN_EXPORT lean_object* l_elaborateOne(lean_object* v_base_652_, lean_object* v_ctx_653_, lean_object* v_ps_654_, lean_object* v_headerMsgs_655_, lean_object* v_file_656_, lean_object* v_moduleText_657_, lean_object* v_workers_658_, lean_object* v_index_659_){
_start:
{
lean_object* v___x_661_; lean_object* v___x_662_; lean_object* v_pos_663_; lean_object* v_opts_664_; lean_object* v___x_665_; lean_object* v___x_666_; lean_object* v___x_667_; lean_object* v___x_668_; lean_object* v___x_669_; 
v___x_661_ = lean_unsigned_to_nat(0u);
v___x_662_ = lean_obj_once(&l_commands___closed__2, &l_commands___closed__2_once, _init_l_commands___closed__2);
v_pos_663_ = lean_ctor_get(v_ps_654_, 0);
lean_inc(v_pos_663_);
v_opts_664_ = lean_obj_once(&l_elaborateOne___closed__9, &l_elaborateOne___closed__9_once, _init_l_elaborateOne___closed__9);
lean_inc_ref(v_base_652_);
v___x_665_ = l_Lean_Elab_Command_mkState(v_base_652_, v___x_662_, v_opts_664_);
v___x_666_ = ((lean_object*)(l_elaborateOne___closed__10));
v___x_667_ = lean_alloc_ctor(0, 4, 0);
lean_ctor_set(v___x_667_, 0, v___x_665_);
lean_ctor_set(v___x_667_, 1, v_ps_654_);
lean_ctor_set(v___x_667_, 2, v_pos_663_);
lean_ctor_set(v___x_667_, 3, v___x_666_);
v___x_668_ = lean_st_mk_ref(v___x_667_);
v___x_669_ = l_commands(v___x_666_, v___x_666_, v_ctx_653_, v___x_668_);
if (lean_obj_tag(v___x_669_) == 0)
{
lean_object* v_a_670_; lean_object* v___x_672_; uint8_t v_isShared_673_; uint8_t v_isSharedCheck_834_; 
v_a_670_ = lean_ctor_get(v___x_669_, 0);
v_isSharedCheck_834_ = !lean_is_exclusive(v___x_669_);
if (v_isSharedCheck_834_ == 0)
{
v___x_672_ = v___x_669_;
v_isShared_673_ = v_isSharedCheck_834_;
goto v_resetjp_671_;
}
else
{
lean_inc(v_a_670_);
lean_dec(v___x_669_);
v___x_672_ = lean_box(0);
v_isShared_673_ = v_isSharedCheck_834_;
goto v_resetjp_671_;
}
v_resetjp_671_:
{
lean_object* v___x_674_; lean_object* v_fst_675_; lean_object* v_snd_676_; lean_object* v___x_678_; uint8_t v_isShared_679_; uint8_t v_isSharedCheck_833_; 
v___x_674_ = lean_st_ref_get(v___x_668_);
lean_dec(v___x_668_);
v_fst_675_ = lean_ctor_get(v_a_670_, 0);
v_snd_676_ = lean_ctor_get(v_a_670_, 1);
v_isSharedCheck_833_ = !lean_is_exclusive(v_a_670_);
if (v_isSharedCheck_833_ == 0)
{
v___x_678_ = v_a_670_;
v_isShared_679_ = v_isSharedCheck_833_;
goto v_resetjp_677_;
}
else
{
lean_inc(v_snd_676_);
lean_inc(v_fst_675_);
lean_dec(v_a_670_);
v___x_678_ = lean_box(0);
v_isShared_679_ = v_isSharedCheck_833_;
goto v_resetjp_677_;
}
v_resetjp_677_:
{
lean_object* v___y_681_; lean_object* v___y_682_; lean_object* v___y_683_; lean_object* v___y_684_; lean_object* v___y_685_; lean_object* v___y_686_; lean_object* v___y_687_; lean_object* v___y_688_; lean_object* v___y_689_; lean_object* v___y_690_; lean_object* v___x_713_; lean_object* v___x_714_; size_t v_sz_715_; size_t v___x_716_; lean_object* v___x_717_; 
v___x_713_ = l_Lean_MessageLog_toArray(v_headerMsgs_655_);
v___x_714_ = l_Array_append___redArg(v___x_713_, v_snd_676_);
lean_dec(v_snd_676_);
v_sz_715_ = lean_array_size(v___x_714_);
v___x_716_ = ((size_t)0ULL);
v___x_717_ = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00elaborateOne_spec__0(v___x_714_, v_sz_715_, v___x_716_, v___x_666_);
lean_dec_ref(v___x_714_);
if (lean_obj_tag(v___x_717_) == 0)
{
lean_object* v_commandState_718_; lean_object* v_a_719_; lean_object* v_env_720_; lean_object* v___x_721_; lean_object* v_map_u2082_722_; lean_object* v___x_723_; lean_object* v___x_724_; lean_object* v___x_725_; 
v_commandState_718_ = lean_ctor_get(v___x_674_, 0);
lean_inc_ref(v_commandState_718_);
lean_dec(v___x_674_);
v_a_719_ = lean_ctor_get(v___x_717_, 0);
lean_inc(v_a_719_);
lean_dec_ref_known(v___x_717_, 1);
v_env_720_ = lean_ctor_get(v_commandState_718_, 0);
lean_inc_ref_n(v_env_720_, 2);
lean_dec_ref(v_commandState_718_);
v___x_721_ = l_Lean_Environment_constants(v_env_720_);
v_map_u2082_722_ = lean_ctor_get(v___x_721_, 1);
lean_inc_ref(v_map_u2082_722_);
lean_dec_ref(v___x_721_);
v___x_723_ = l_Lean_PersistentHashMap_toList___at___00__private_Lean_Linter_TacticTypeCheck_0__Lean_Linter_tacticCheckInstances_spec__6___redArg(v_map_u2082_722_);
lean_dec_ref(v_map_u2082_722_);
v___x_724_ = ((lean_object*)(l_elaborateOne___closed__18));
v___x_725_ = l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg(v_env_720_, v_ctx_653_, v_file_656_, v_base_652_, v___x_723_, v___x_724_);
lean_dec(v___x_723_);
if (lean_obj_tag(v___x_725_) == 0)
{
lean_object* v_a_726_; lean_object* v_fst_727_; lean_object* v_snd_728_; lean_object* v___x_730_; uint8_t v_isShared_731_; uint8_t v_isSharedCheck_816_; 
v_a_726_ = lean_ctor_get(v___x_725_, 0);
lean_inc(v_a_726_);
lean_dec_ref_known(v___x_725_, 1);
v_fst_727_ = lean_ctor_get(v_a_726_, 0);
v_snd_728_ = lean_ctor_get(v_a_726_, 1);
v_isSharedCheck_816_ = !lean_is_exclusive(v_a_726_);
if (v_isSharedCheck_816_ == 0)
{
v___x_730_ = v_a_726_;
v_isShared_731_ = v_isSharedCheck_816_;
goto v_resetjp_729_;
}
else
{
lean_inc(v_snd_728_);
lean_inc(v_fst_727_);
lean_dec(v_a_726_);
v___x_730_ = lean_box(0);
v_isShared_731_ = v_isSharedCheck_816_;
goto v_resetjp_729_;
}
v_resetjp_729_:
{
lean_object* v___y_733_; lean_object* v___y_734_; lean_object* v___y_735_; lean_object* v___y_736_; lean_object* v___y_737_; lean_object* v___y_738_; lean_object* v___y_739_; lean_object* v___y_740_; lean_object* v___y_741_; lean_object* v___y_742_; lean_object* v___y_743_; lean_object* v___y_744_; lean_object* v___y_747_; lean_object* v___y_748_; lean_object* v___y_749_; lean_object* v___y_750_; lean_object* v___y_751_; lean_object* v___y_752_; lean_object* v___y_753_; lean_object* v___y_754_; lean_object* v___y_755_; lean_object* v___y_756_; lean_object* v___y_757_; lean_object* v___y_758_; lean_object* v_fst_760_; lean_object* v_snd_761_; lean_object* v___x_763_; uint8_t v_isShared_764_; uint8_t v_isSharedCheck_815_; 
v_fst_760_ = lean_ctor_get(v_snd_728_, 0);
v_snd_761_ = lean_ctor_get(v_snd_728_, 1);
v_isSharedCheck_815_ = !lean_is_exclusive(v_snd_728_);
if (v_isSharedCheck_815_ == 0)
{
v___x_763_ = v_snd_728_;
v_isShared_764_ = v_isSharedCheck_815_;
goto v_resetjp_762_;
}
else
{
lean_inc(v_snd_761_);
lean_inc(v_fst_760_);
lean_dec(v_snd_728_);
v___x_763_ = lean_box(0);
v_isShared_764_ = v_isSharedCheck_815_;
goto v_resetjp_762_;
}
v___jp_732_:
{
lean_object* v___x_745_; 
v___x_745_ = l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00__private_Lean_Elab_DocString_Builtin_0__Lean_Doc_validateCat_spec__3___redArg(v___y_738_, v_fst_727_, v___y_736_, v___y_744_);
lean_dec(v___y_744_);
lean_dec(v___y_738_);
v___y_681_ = v___y_733_;
v___y_682_ = v___y_734_;
v___y_683_ = v___y_735_;
v___y_684_ = v___y_737_;
v___y_685_ = v___y_740_;
v___y_686_ = v___y_739_;
v___y_687_ = v___y_741_;
v___y_688_ = v___y_743_;
v___y_689_ = v___y_742_;
v___y_690_ = v___x_745_;
goto v___jp_680_;
}
v___jp_746_:
{
uint8_t v___x_759_; 
v___x_759_ = lean_nat_dec_le(v___y_758_, v___y_748_);
if (v___x_759_ == 0)
{
lean_dec(v___y_748_);
lean_inc(v___y_758_);
v___y_733_ = v___y_747_;
v___y_734_ = v___y_749_;
v___y_735_ = v___y_750_;
v___y_736_ = v___y_758_;
v___y_737_ = v___y_752_;
v___y_738_ = v___y_751_;
v___y_739_ = v___y_754_;
v___y_740_ = v___y_753_;
v___y_741_ = v___y_755_;
v___y_742_ = v___y_757_;
v___y_743_ = v___y_756_;
v___y_744_ = v___y_758_;
goto v___jp_732_;
}
else
{
v___y_733_ = v___y_747_;
v___y_734_ = v___y_749_;
v___y_735_ = v___y_750_;
v___y_736_ = v___y_758_;
v___y_737_ = v___y_752_;
v___y_738_ = v___y_751_;
v___y_739_ = v___y_754_;
v___y_740_ = v___y_753_;
v___y_741_ = v___y_755_;
v___y_742_ = v___y_757_;
v___y_743_ = v___y_756_;
v___y_744_ = v___y_748_;
goto v___jp_732_;
}
}
v_resetjp_762_:
{
lean_object* v___y_766_; lean_object* v___x_807_; uint8_t v___x_808_; 
v___x_807_ = lean_array_get_size(v_a_719_);
v___x_808_ = lean_nat_dec_eq(v___x_807_, v___x_661_);
if (v___x_808_ == 0)
{
lean_object* v___x_809_; 
v___x_809_ = ((lean_object*)(l_elaborateOne___closed__27));
v___y_766_ = v___x_809_;
goto v___jp_765_;
}
else
{
lean_object* v___x_810_; uint8_t v___x_811_; 
v___x_810_ = lean_array_get_size(v_fst_760_);
v___x_811_ = lean_nat_dec_eq(v___x_810_, v___x_661_);
if (v___x_811_ == 0)
{
goto v___jp_805_;
}
else
{
lean_object* v___x_812_; uint8_t v___x_813_; 
v___x_812_ = lean_array_get_size(v_snd_761_);
v___x_813_ = lean_nat_dec_eq(v___x_812_, v___x_661_);
if (v___x_813_ == 0)
{
goto v___jp_805_;
}
else
{
lean_object* v___x_814_; 
v___x_814_ = ((lean_object*)(l_one___closed__4));
v___y_766_ = v___x_814_;
goto v___jp_765_;
}
}
}
v___jp_765_:
{
uint64_t v___x_767_; lean_object* v___x_768_; lean_object* v___x_769_; lean_object* v___x_771_; 
v___x_767_ = lean_io_get_tid();
v___x_768_ = ((lean_object*)(l_elaborateOne___closed__19));
v___x_769_ = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(v___x_769_, 0, v_moduleText_657_);
if (v_isShared_764_ == 0)
{
lean_ctor_set(v___x_763_, 1, v___x_769_);
lean_ctor_set(v___x_763_, 0, v___x_768_);
v___x_771_ = v___x_763_;
goto v_reusejp_770_;
}
else
{
lean_object* v_reuseFailAlloc_804_; 
v_reuseFailAlloc_804_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_804_, 0, v___x_768_);
lean_ctor_set(v_reuseFailAlloc_804_, 1, v___x_769_);
v___x_771_ = v_reuseFailAlloc_804_;
goto v_reusejp_770_;
}
v_reusejp_770_:
{
lean_object* v___x_772_; lean_object* v___x_773_; lean_object* v___x_774_; lean_object* v___x_776_; 
v___x_772_ = ((lean_object*)(l_elaborateOne___closed__20));
v___x_773_ = l_Lean_JsonNumber_fromNat(v_workers_658_);
v___x_774_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_774_, 0, v___x_773_);
if (v_isShared_731_ == 0)
{
lean_ctor_set(v___x_730_, 1, v___x_774_);
lean_ctor_set(v___x_730_, 0, v___x_772_);
v___x_776_ = v___x_730_;
goto v_reusejp_775_;
}
else
{
lean_object* v_reuseFailAlloc_803_; 
v_reuseFailAlloc_803_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_803_, 0, v___x_772_);
lean_ctor_set(v_reuseFailAlloc_803_, 1, v___x_774_);
v___x_776_ = v_reuseFailAlloc_803_;
goto v_reusejp_775_;
}
v_reusejp_775_:
{
lean_object* v___x_777_; lean_object* v___x_778_; lean_object* v___x_779_; lean_object* v___x_780_; lean_object* v___x_781_; lean_object* v___x_782_; lean_object* v___x_783_; lean_object* v___x_784_; lean_object* v___x_785_; lean_object* v___x_786_; lean_object* v___x_787_; lean_object* v___x_788_; lean_object* v___x_789_; lean_object* v___x_790_; lean_object* v___x_791_; lean_object* v___x_792_; lean_object* v___x_793_; lean_object* v___x_794_; lean_object* v___x_795_; lean_object* v___x_796_; lean_object* v___x_797_; lean_object* v___x_798_; uint8_t v___x_799_; 
v___x_777_ = ((lean_object*)(l_elaborateOne___closed__21));
v___x_778_ = l_Lean_JsonNumber_fromNat(v_index_659_);
v___x_779_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_779_, 0, v___x_778_);
v___x_780_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_780_, 0, v___x_777_);
lean_ctor_set(v___x_780_, 1, v___x_779_);
v___x_781_ = ((lean_object*)(l_instToJsonUnitRow_toJson___closed__6));
v___x_782_ = lean_uint64_to_nat(v___x_767_);
v___x_783_ = l_Lean_bignumToJson(v___x_782_);
v___x_784_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_784_, 0, v___x_781_);
lean_ctor_set(v___x_784_, 1, v___x_783_);
v___x_785_ = ((lean_object*)(l_instToJsonUnitRow_toJson___closed__4));
lean_inc_ref(v___y_766_);
v___x_786_ = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(v___x_786_, 0, v___y_766_);
v___x_787_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_787_, 0, v___x_785_);
lean_ctor_set(v___x_787_, 1, v___x_786_);
v___x_788_ = ((lean_object*)(l_elaborateOne___closed__22));
v___x_789_ = l_Lean_Array_toJson___at___00Lean_Server_Test_Runner_Client_instToJsonHyp_toJson_spec__1(v_a_719_);
v___x_790_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_790_, 0, v___x_788_);
lean_ctor_set(v___x_790_, 1, v___x_789_);
v___x_791_ = ((lean_object*)(l_elaborateOne___closed__23));
v___x_792_ = l_Lean_Array_toJson___at___00Lean_Server_Test_Runner_Client_instToJsonHyp_toJson_spec__1(v_fst_760_);
v___x_793_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_793_, 0, v___x_791_);
lean_ctor_set(v___x_793_, 1, v___x_792_);
v___x_794_ = ((lean_object*)(l_elaborateOne___closed__24));
v___x_795_ = l_Lean_Array_toJson___at___00Lean_Server_Test_Runner_Client_instToJsonHyp_toJson_spec__1(v_snd_761_);
v___x_796_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_796_, 0, v___x_794_);
lean_ctor_set(v___x_796_, 1, v___x_795_);
v___x_797_ = ((lean_object*)(l_elaborateOne___closed__25));
v___x_798_ = lean_array_get_size(v_fst_727_);
v___x_799_ = lean_nat_dec_eq(v___x_798_, v___x_661_);
if (v___x_799_ == 0)
{
lean_object* v___x_800_; lean_object* v___x_801_; uint8_t v___x_802_; 
v___x_800_ = lean_unsigned_to_nat(1u);
v___x_801_ = lean_nat_sub(v___x_798_, v___x_800_);
v___x_802_ = lean_nat_dec_le(v___x_661_, v___x_801_);
if (v___x_802_ == 0)
{
lean_inc(v___x_801_);
v___y_747_ = v___x_771_;
v___y_748_ = v___x_801_;
v___y_749_ = v___x_796_;
v___y_750_ = v___x_793_;
v___y_751_ = v___x_798_;
v___y_752_ = v___x_787_;
v___y_753_ = v___x_790_;
v___y_754_ = v___x_797_;
v___y_755_ = v___x_780_;
v___y_756_ = v___x_776_;
v___y_757_ = v___x_784_;
v___y_758_ = v___x_801_;
goto v___jp_746_;
}
else
{
v___y_747_ = v___x_771_;
v___y_748_ = v___x_801_;
v___y_749_ = v___x_796_;
v___y_750_ = v___x_793_;
v___y_751_ = v___x_798_;
v___y_752_ = v___x_787_;
v___y_753_ = v___x_790_;
v___y_754_ = v___x_797_;
v___y_755_ = v___x_780_;
v___y_756_ = v___x_776_;
v___y_757_ = v___x_784_;
v___y_758_ = v___x_661_;
goto v___jp_746_;
}
}
else
{
v___y_681_ = v___x_771_;
v___y_682_ = v___x_796_;
v___y_683_ = v___x_793_;
v___y_684_ = v___x_787_;
v___y_685_ = v___x_790_;
v___y_686_ = v___x_797_;
v___y_687_ = v___x_780_;
v___y_688_ = v___x_776_;
v___y_689_ = v___x_784_;
v___y_690_ = v_fst_727_;
goto v___jp_680_;
}
}
}
}
v___jp_805_:
{
lean_object* v___x_806_; 
v___x_806_ = ((lean_object*)(l_elaborateOne___closed__26));
v___y_766_ = v___x_806_;
goto v___jp_765_;
}
}
}
}
else
{
lean_object* v_a_817_; lean_object* v___x_819_; uint8_t v_isShared_820_; uint8_t v_isSharedCheck_824_; 
lean_dec(v_a_719_);
lean_del_object(v___x_678_);
lean_dec(v_fst_675_);
lean_del_object(v___x_672_);
lean_dec(v_index_659_);
lean_dec(v_workers_658_);
lean_dec_ref(v_moduleText_657_);
v_a_817_ = lean_ctor_get(v___x_725_, 0);
v_isSharedCheck_824_ = !lean_is_exclusive(v___x_725_);
if (v_isSharedCheck_824_ == 0)
{
v___x_819_ = v___x_725_;
v_isShared_820_ = v_isSharedCheck_824_;
goto v_resetjp_818_;
}
else
{
lean_inc(v_a_817_);
lean_dec(v___x_725_);
v___x_819_ = lean_box(0);
v_isShared_820_ = v_isSharedCheck_824_;
goto v_resetjp_818_;
}
v_resetjp_818_:
{
lean_object* v___x_822_; 
if (v_isShared_820_ == 0)
{
v___x_822_ = v___x_819_;
goto v_reusejp_821_;
}
else
{
lean_object* v_reuseFailAlloc_823_; 
v_reuseFailAlloc_823_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_823_, 0, v_a_817_);
v___x_822_ = v_reuseFailAlloc_823_;
goto v_reusejp_821_;
}
v_reusejp_821_:
{
return v___x_822_;
}
}
}
}
else
{
lean_object* v_a_825_; lean_object* v___x_827_; uint8_t v_isShared_828_; uint8_t v_isSharedCheck_832_; 
lean_del_object(v___x_678_);
lean_dec(v_fst_675_);
lean_dec(v___x_674_);
lean_del_object(v___x_672_);
lean_dec(v_index_659_);
lean_dec(v_workers_658_);
lean_dec_ref(v_moduleText_657_);
lean_dec_ref(v_file_656_);
lean_dec_ref(v_base_652_);
v_a_825_ = lean_ctor_get(v___x_717_, 0);
v_isSharedCheck_832_ = !lean_is_exclusive(v___x_717_);
if (v_isSharedCheck_832_ == 0)
{
v___x_827_ = v___x_717_;
v_isShared_828_ = v_isSharedCheck_832_;
goto v_resetjp_826_;
}
else
{
lean_inc(v_a_825_);
lean_dec(v___x_717_);
v___x_827_ = lean_box(0);
v_isShared_828_ = v_isSharedCheck_832_;
goto v_resetjp_826_;
}
v_resetjp_826_:
{
lean_object* v___x_830_; 
if (v_isShared_828_ == 0)
{
v___x_830_ = v___x_827_;
goto v_reusejp_829_;
}
else
{
lean_object* v_reuseFailAlloc_831_; 
v_reuseFailAlloc_831_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_831_, 0, v_a_825_);
v___x_830_ = v_reuseFailAlloc_831_;
goto v_reusejp_829_;
}
v_reusejp_829_:
{
return v___x_830_;
}
}
}
v___jp_680_:
{
lean_object* v___x_691_; lean_object* v___x_693_; 
v___x_691_ = l_Lean_Array_toJson___at___00Lean_Server_Test_Runner_Client_instToJsonHyp_toJson_spec__1(v___y_690_);
lean_inc_ref(v___y_686_);
if (v_isShared_679_ == 0)
{
lean_ctor_set(v___x_678_, 1, v___x_691_);
lean_ctor_set(v___x_678_, 0, v___y_686_);
v___x_693_ = v___x_678_;
goto v_reusejp_692_;
}
else
{
lean_object* v_reuseFailAlloc_712_; 
v_reuseFailAlloc_712_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_712_, 0, v___y_686_);
lean_ctor_set(v_reuseFailAlloc_712_, 1, v___x_691_);
v___x_693_ = v_reuseFailAlloc_712_;
goto v_reusejp_692_;
}
v_reusejp_692_:
{
lean_object* v___x_694_; lean_object* v___x_695_; lean_object* v___x_696_; lean_object* v___x_697_; lean_object* v___x_698_; lean_object* v___x_699_; lean_object* v___x_700_; lean_object* v___x_701_; lean_object* v___x_702_; lean_object* v___x_703_; lean_object* v___x_704_; lean_object* v___x_705_; lean_object* v___x_706_; lean_object* v___x_707_; lean_object* v___x_708_; lean_object* v___x_710_; 
v___x_694_ = ((lean_object*)(l_elaborateOne___closed__11));
v___x_695_ = l_Lean_Array_toJson___at___00Lean_Server_FileWorker_handlePreRequestSpecialCases_x3f_spec__6(v_fst_675_);
v___x_696_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_696_, 0, v___x_694_);
lean_ctor_set(v___x_696_, 1, v___x_695_);
v___x_697_ = ((lean_object*)(l_elaborateOne___closed__16));
v___x_698_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_698_, 0, v___x_696_);
lean_ctor_set(v___x_698_, 1, v___x_697_);
v___x_699_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_699_, 0, v___x_693_);
lean_ctor_set(v___x_699_, 1, v___x_698_);
v___x_700_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_700_, 0, v___y_682_);
lean_ctor_set(v___x_700_, 1, v___x_699_);
v___x_701_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_701_, 0, v___y_683_);
lean_ctor_set(v___x_701_, 1, v___x_700_);
v___x_702_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_702_, 0, v___y_685_);
lean_ctor_set(v___x_702_, 1, v___x_701_);
v___x_703_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_703_, 0, v___y_684_);
lean_ctor_set(v___x_703_, 1, v___x_702_);
v___x_704_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_704_, 0, v___y_689_);
lean_ctor_set(v___x_704_, 1, v___x_703_);
v___x_705_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_705_, 0, v___y_687_);
lean_ctor_set(v___x_705_, 1, v___x_704_);
v___x_706_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_706_, 0, v___y_688_);
lean_ctor_set(v___x_706_, 1, v___x_705_);
v___x_707_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_707_, 0, v___y_681_);
lean_ctor_set(v___x_707_, 1, v___x_706_);
v___x_708_ = l_Lean_Json_mkObj(v___x_707_);
lean_dec_ref_known(v___x_707_, 2);
if (v_isShared_673_ == 0)
{
lean_ctor_set(v___x_672_, 0, v___x_708_);
v___x_710_ = v___x_672_;
goto v_reusejp_709_;
}
else
{
lean_object* v_reuseFailAlloc_711_; 
v_reuseFailAlloc_711_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_711_, 0, v___x_708_);
v___x_710_ = v_reuseFailAlloc_711_;
goto v_reusejp_709_;
}
v_reusejp_709_:
{
return v___x_710_;
}
}
}
}
}
}
else
{
lean_object* v_a_835_; lean_object* v___x_837_; uint8_t v_isShared_838_; uint8_t v_isSharedCheck_842_; 
lean_dec(v___x_668_);
lean_dec(v_index_659_);
lean_dec(v_workers_658_);
lean_dec_ref(v_moduleText_657_);
lean_dec_ref(v_file_656_);
lean_dec_ref(v_base_652_);
v_a_835_ = lean_ctor_get(v___x_669_, 0);
v_isSharedCheck_842_ = !lean_is_exclusive(v___x_669_);
if (v_isSharedCheck_842_ == 0)
{
v___x_837_ = v___x_669_;
v_isShared_838_ = v_isSharedCheck_842_;
goto v_resetjp_836_;
}
else
{
lean_inc(v_a_835_);
lean_dec(v___x_669_);
v___x_837_ = lean_box(0);
v_isShared_838_ = v_isSharedCheck_842_;
goto v_resetjp_836_;
}
v_resetjp_836_:
{
lean_object* v___x_840_; 
if (v_isShared_838_ == 0)
{
v___x_840_ = v___x_837_;
goto v_reusejp_839_;
}
else
{
lean_object* v_reuseFailAlloc_841_; 
v_reuseFailAlloc_841_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_841_, 0, v_a_835_);
v___x_840_ = v_reuseFailAlloc_841_;
goto v_reusejp_839_;
}
v_reusejp_839_:
{
return v___x_840_;
}
}
}
}
}
LEAN_EXPORT lean_object* l_elaborateOne___boxed(lean_object* v_base_843_, lean_object* v_ctx_844_, lean_object* v_ps_845_, lean_object* v_headerMsgs_846_, lean_object* v_file_847_, lean_object* v_moduleText_848_, lean_object* v_workers_849_, lean_object* v_index_850_, lean_object* v_a_851_){
_start:
{
lean_object* v_res_852_; 
v_res_852_ = l_elaborateOne(v_base_843_, v_ctx_844_, v_ps_845_, v_headerMsgs_846_, v_file_847_, v_moduleText_848_, v_workers_849_, v_index_850_);
lean_dec_ref(v_headerMsgs_846_);
lean_dec_ref(v_ctx_844_);
return v_res_852_;
}
}
LEAN_EXPORT lean_object* l_List_forIn_x27_loop___at___00elaborateOne_spec__2(lean_object* v___x_853_, lean_object* v_ctx_854_, lean_object* v_file_855_, lean_object* v_base_856_, lean_object* v_as_857_, lean_object* v_as_x27_858_, lean_object* v_b_859_, lean_object* v_a_860_){
_start:
{
lean_object* v___x_862_; 
v___x_862_ = l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg(v___x_853_, v_ctx_854_, v_file_855_, v_base_856_, v_as_x27_858_, v_b_859_);
return v___x_862_;
}
}
LEAN_EXPORT lean_object* l_List_forIn_x27_loop___at___00elaborateOne_spec__2___boxed(lean_object* v___x_863_, lean_object* v_ctx_864_, lean_object* v_file_865_, lean_object* v_base_866_, lean_object* v_as_867_, lean_object* v_as_x27_868_, lean_object* v_b_869_, lean_object* v_a_870_, lean_object* v___y_871_){
_start:
{
lean_object* v_res_872_; 
v_res_872_ = l_List_forIn_x27_loop___at___00elaborateOne_spec__2(v___x_863_, v_ctx_864_, v_file_865_, v_base_866_, v_as_867_, v_as_x27_868_, v_b_869_, v_a_870_);
lean_dec(v_as_x27_868_);
lean_dec(v_as_867_);
lean_dec_ref(v_ctx_864_);
return v_res_872_;
}
}
LEAN_EXPORT uint8_t l_Option_instBEq_beq___at___00main_spec__1(lean_object* v_x_873_, lean_object* v_x_874_){
_start:
{
if (lean_obj_tag(v_x_873_) == 0)
{
if (lean_obj_tag(v_x_874_) == 0)
{
uint8_t v___x_875_; 
v___x_875_ = 1;
return v___x_875_;
}
else
{
uint8_t v___x_876_; 
v___x_876_ = 0;
return v___x_876_;
}
}
else
{
if (lean_obj_tag(v_x_874_) == 0)
{
uint8_t v___x_877_; 
v___x_877_ = 0;
return v___x_877_;
}
else
{
lean_object* v_val_878_; lean_object* v_val_879_; uint8_t v___x_880_; 
v_val_878_ = lean_ctor_get(v_x_873_, 0);
v_val_879_ = lean_ctor_get(v_x_874_, 0);
v___x_880_ = lean_nat_dec_eq(v_val_878_, v_val_879_);
return v___x_880_;
}
}
}
}
LEAN_EXPORT lean_object* l_Option_instBEq_beq___at___00main_spec__1___boxed(lean_object* v_x_881_, lean_object* v_x_882_){
_start:
{
uint8_t v_res_883_; lean_object* v_r_884_; 
v_res_883_ = l_Option_instBEq_beq___at___00main_spec__1(v_x_881_, v_x_882_);
lean_dec(v_x_882_);
lean_dec(v_x_881_);
v_r_884_ = lean_box(v_res_883_);
return v_r_884_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__3(lean_object* v_head_889_, lean_object* v_as_890_, size_t v_sz_891_, size_t v_i_892_, lean_object* v_b_893_){
_start:
{
lean_object* v_a_896_; uint8_t v___x_900_; 
v___x_900_ = lean_usize_dec_lt(v_i_892_, v_sz_891_);
if (v___x_900_ == 0)
{
lean_object* v___x_901_; 
v___x_901_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_901_, 0, v_b_893_);
return v___x_901_;
}
else
{
lean_object* v_a_902_; lean_object* v_value_903_; lean_object* v___x_904_; uint8_t v___y_906_; lean_object* v___x_909_; uint8_t v___x_910_; uint8_t v___x_918_; 
v_a_902_ = lean_array_uget_borrowed(v_as_890_, v_i_892_);
v_value_903_ = lean_ctor_get(v_a_902_, 1);
v___x_904_ = lean_box(0);
v___x_909_ = ((lean_object*)(l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__3___closed__2));
v___x_910_ = lean_string_dec_eq(v_head_889_, v___x_909_);
v___x_918_ = l_Lean_Expr_hasSorry(v_value_903_);
if (v___x_918_ == 0)
{
goto v___jp_915_;
}
else
{
if (v___x_910_ == 0)
{
goto v___jp_914_;
}
else
{
goto v___jp_915_;
}
}
v___jp_905_:
{
if (v___y_906_ == 0)
{
lean_object* v___x_907_; lean_object* v___x_908_; 
v___x_907_ = ((lean_object*)(l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__3___closed__1));
v___x_908_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_908_, 0, v___x_907_);
return v___x_908_;
}
else
{
v_a_896_ = v___x_904_;
goto v___jp_895_;
}
}
v___jp_911_:
{
lean_object* v_value_912_; uint8_t v___x_913_; 
v_value_912_ = lean_ctor_get(v_a_902_, 1);
v___x_913_ = l_Lean_Expr_hasMVar(v_value_912_);
if (v___x_913_ == 0)
{
v_a_896_ = v___x_904_;
goto v___jp_895_;
}
else
{
v___y_906_ = v___x_910_;
goto v___jp_905_;
}
}
v___jp_914_:
{
if (v___x_910_ == 0)
{
v___y_906_ = v___x_910_;
goto v___jp_905_;
}
else
{
goto v___jp_911_;
}
}
v___jp_915_:
{
lean_object* v_value_916_; uint8_t v___x_917_; 
v_value_916_ = lean_ctor_get(v_a_902_, 1);
v___x_917_ = l_Lean_Expr_hasFVar(v_value_916_);
if (v___x_917_ == 0)
{
goto v___jp_911_;
}
else
{
goto v___jp_914_;
}
}
}
v___jp_895_:
{
size_t v___x_897_; size_t v___x_898_; 
v___x_897_ = ((size_t)1ULL);
v___x_898_ = lean_usize_add(v_i_892_, v___x_897_);
v_i_892_ = v___x_898_;
v_b_893_ = v_a_896_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__3___boxed(lean_object* v_head_919_, lean_object* v_as_920_, lean_object* v_sz_921_, lean_object* v_i_922_, lean_object* v_b_923_, lean_object* v___y_924_){
_start:
{
size_t v_sz_boxed_925_; size_t v_i_boxed_926_; lean_object* v_res_927_; 
v_sz_boxed_925_ = lean_unbox_usize(v_sz_921_);
lean_dec(v_sz_921_);
v_i_boxed_926_ = lean_unbox_usize(v_i_922_);
lean_dec(v_i_922_);
v_res_927_ = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__3(v_head_919_, v_as_920_, v_sz_boxed_925_, v_i_boxed_926_, v_b_923_);
lean_dec_ref(v_as_920_);
lean_dec_ref(v_head_919_);
return v_res_927_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__15(lean_object* v_as_929_, size_t v_sz_930_, size_t v_i_931_, lean_object* v_b_932_){
_start:
{
uint8_t v___x_934_; 
v___x_934_ = lean_usize_dec_lt(v_i_931_, v_sz_930_);
if (v___x_934_ == 0)
{
lean_object* v___x_935_; 
v___x_935_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_935_, 0, v_b_932_);
return v___x_935_;
}
else
{
lean_object* v_a_936_; lean_object* v___x_937_; lean_object* v___x_938_; lean_object* v___x_939_; lean_object* v___x_940_; 
v_a_936_ = lean_array_uget_borrowed(v_as_929_, v_i_931_);
v___x_937_ = ((lean_object*)(l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__15___closed__0));
lean_inc(v_a_936_);
v___x_938_ = l_Lean_Json_compress(v_a_936_);
v___x_939_ = lean_string_append(v___x_937_, v___x_938_);
lean_dec_ref(v___x_938_);
v___x_940_ = l_IO_println___at___00__private_Lean_Shell_0__Lean_ShellOptions_process_spec__3(v___x_939_);
if (lean_obj_tag(v___x_940_) == 0)
{
lean_object* v___x_941_; size_t v___x_942_; size_t v___x_943_; 
lean_dec_ref_known(v___x_940_, 1);
v___x_941_ = lean_box(0);
v___x_942_ = ((size_t)1ULL);
v___x_943_ = lean_usize_add(v_i_931_, v___x_942_);
v_i_931_ = v___x_943_;
v_b_932_ = v___x_941_;
goto _start;
}
else
{
return v___x_940_;
}
}
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__15___boxed(lean_object* v_as_945_, lean_object* v_sz_946_, lean_object* v_i_947_, lean_object* v_b_948_, lean_object* v___y_949_){
_start:
{
size_t v_sz_boxed_950_; size_t v_i_boxed_951_; lean_object* v_res_952_; 
v_sz_boxed_950_ = lean_unbox_usize(v_sz_946_);
lean_dec(v_sz_946_);
v_i_boxed_951_ = lean_unbox_usize(v_i_947_);
lean_dec(v_i_947_);
v_res_952_ = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__15(v_as_945_, v_sz_boxed_950_, v_i_boxed_951_, v_b_948_);
lean_dec_ref(v_as_945_);
return v_res_952_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__16(lean_object* v_as_953_, size_t v_sz_954_, size_t v_i_955_, lean_object* v_b_956_){
_start:
{
uint8_t v___x_958_; 
v___x_958_ = lean_usize_dec_lt(v_i_955_, v_sz_954_);
if (v___x_958_ == 0)
{
lean_object* v___x_959_; 
v___x_959_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_959_, 0, v_b_956_);
return v___x_959_;
}
else
{
lean_object* v_a_960_; lean_object* v___x_961_; 
v_a_960_ = lean_array_uget_borrowed(v_as_953_, v_i_955_);
lean_inc(v_a_960_);
v___x_961_ = lean_task_get_own(v_a_960_);
if (lean_obj_tag(v___x_961_) == 0)
{
lean_object* v_a_962_; lean_object* v___x_964_; uint8_t v_isShared_965_; uint8_t v_isSharedCheck_969_; 
v_a_962_ = lean_ctor_get(v___x_961_, 0);
v_isSharedCheck_969_ = !lean_is_exclusive(v___x_961_);
if (v_isSharedCheck_969_ == 0)
{
v___x_964_ = v___x_961_;
v_isShared_965_ = v_isSharedCheck_969_;
goto v_resetjp_963_;
}
else
{
lean_inc(v_a_962_);
lean_dec(v___x_961_);
v___x_964_ = lean_box(0);
v_isShared_965_ = v_isSharedCheck_969_;
goto v_resetjp_963_;
}
v_resetjp_963_:
{
lean_object* v___x_967_; 
if (v_isShared_965_ == 0)
{
lean_ctor_set_tag(v___x_964_, 1);
v___x_967_ = v___x_964_;
goto v_reusejp_966_;
}
else
{
lean_object* v_reuseFailAlloc_968_; 
v_reuseFailAlloc_968_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_968_, 0, v_a_962_);
v___x_967_ = v_reuseFailAlloc_968_;
goto v_reusejp_966_;
}
v_reusejp_966_:
{
return v___x_967_;
}
}
}
else
{
lean_object* v_a_970_; lean_object* v___x_971_; size_t v_sz_972_; size_t v___x_973_; lean_object* v___x_974_; 
v_a_970_ = lean_ctor_get(v___x_961_, 0);
lean_inc(v_a_970_);
lean_dec_ref_known(v___x_961_, 1);
v___x_971_ = lean_box(0);
v_sz_972_ = lean_array_size(v_a_970_);
v___x_973_ = ((size_t)0ULL);
v___x_974_ = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__15(v_a_970_, v_sz_972_, v___x_973_, v___x_971_);
lean_dec(v_a_970_);
if (lean_obj_tag(v___x_974_) == 0)
{
size_t v___x_975_; size_t v___x_976_; 
lean_dec_ref_known(v___x_974_, 1);
v___x_975_ = ((size_t)1ULL);
v___x_976_ = lean_usize_add(v_i_955_, v___x_975_);
v_i_955_ = v___x_976_;
v_b_956_ = v___x_971_;
goto _start;
}
else
{
return v___x_974_;
}
}
}
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__16___boxed(lean_object* v_as_978_, lean_object* v_sz_979_, lean_object* v_i_980_, lean_object* v_b_981_, lean_object* v___y_982_){
_start:
{
size_t v_sz_boxed_983_; size_t v_i_boxed_984_; lean_object* v_res_985_; 
v_sz_boxed_983_ = lean_unbox_usize(v_sz_979_);
lean_dec(v_sz_979_);
v_i_boxed_984_ = lean_unbox_usize(v_i_980_);
lean_dec(v_i_980_);
v_res_985_ = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__16(v_as_978_, v_sz_boxed_983_, v_i_boxed_984_, v_b_981_);
lean_dec_ref(v_as_978_);
return v_res_985_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_QSort_Basic_0__Array_qpartition_loop___at___00__private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__8_spec__10___redArg(lean_object* v_hi_986_, lean_object* v_pivot_987_, lean_object* v_as_988_, lean_object* v_i_989_, lean_object* v_k_990_){
_start:
{
uint8_t v___x_991_; 
v___x_991_ = lean_nat_dec_lt(v_k_990_, v_hi_986_);
if (v___x_991_ == 0)
{
lean_object* v___x_992_; lean_object* v___x_993_; 
lean_dec(v_k_990_);
v___x_992_ = lean_array_fswap(v_as_988_, v_i_989_, v_hi_986_);
v___x_993_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_993_, 0, v_i_989_);
lean_ctor_set(v___x_993_, 1, v___x_992_);
return v___x_993_;
}
else
{
lean_object* v___x_994_; lean_object* v_target_995_; lean_object* v_target_996_; uint8_t v___x_997_; 
v___x_994_ = lean_array_fget_borrowed(v_as_988_, v_k_990_);
v_target_995_ = lean_ctor_get(v___x_994_, 0);
v_target_996_ = lean_ctor_get(v_pivot_987_, 0);
v___x_997_ = lean_string_dec_lt(v_target_995_, v_target_996_);
if (v___x_997_ == 0)
{
lean_object* v___x_998_; lean_object* v___x_999_; 
v___x_998_ = lean_unsigned_to_nat(1u);
v___x_999_ = lean_nat_add(v_k_990_, v___x_998_);
lean_dec(v_k_990_);
v_k_990_ = v___x_999_;
goto _start;
}
else
{
lean_object* v___x_1001_; lean_object* v___x_1002_; lean_object* v___x_1003_; lean_object* v___x_1004_; 
v___x_1001_ = lean_array_fswap(v_as_988_, v_i_989_, v_k_990_);
v___x_1002_ = lean_unsigned_to_nat(1u);
v___x_1003_ = lean_nat_add(v_i_989_, v___x_1002_);
lean_dec(v_i_989_);
v___x_1004_ = lean_nat_add(v_k_990_, v___x_1002_);
lean_dec(v_k_990_);
v_as_988_ = v___x_1001_;
v_i_989_ = v___x_1003_;
v_k_990_ = v___x_1004_;
goto _start;
}
}
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_QSort_Basic_0__Array_qpartition_loop___at___00__private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__8_spec__10___redArg___boxed(lean_object* v_hi_1006_, lean_object* v_pivot_1007_, lean_object* v_as_1008_, lean_object* v_i_1009_, lean_object* v_k_1010_){
_start:
{
lean_object* v_res_1011_; 
v_res_1011_ = l___private_Init_Data_Array_QSort_Basic_0__Array_qpartition_loop___at___00__private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__8_spec__10___redArg(v_hi_1006_, v_pivot_1007_, v_as_1008_, v_i_1009_, v_k_1010_);
lean_dec_ref(v_pivot_1007_);
lean_dec(v_hi_1006_);
return v_res_1011_;
}
}
LEAN_EXPORT uint8_t l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__8___redArg___lam__0(lean_object* v_a_1012_, lean_object* v_b_1013_){
_start:
{
lean_object* v_target_1014_; lean_object* v_target_1015_; uint8_t v___x_1016_; 
v_target_1014_ = lean_ctor_get(v_a_1012_, 0);
v_target_1015_ = lean_ctor_get(v_b_1013_, 0);
v___x_1016_ = lean_string_dec_lt(v_target_1014_, v_target_1015_);
return v___x_1016_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__8___redArg___lam__0___boxed(lean_object* v_a_1017_, lean_object* v_b_1018_){
_start:
{
uint8_t v_res_1019_; lean_object* v_r_1020_; 
v_res_1019_ = l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__8___redArg___lam__0(v_a_1017_, v_b_1018_);
lean_dec_ref(v_b_1018_);
lean_dec_ref(v_a_1017_);
v_r_1020_ = lean_box(v_res_1019_);
return v_r_1020_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__8___redArg(lean_object* v_n_1021_, lean_object* v_as_1022_, lean_object* v_lo_1023_, lean_object* v_hi_1024_){
_start:
{
lean_object* v___y_1026_; uint8_t v___x_1036_; 
v___x_1036_ = lean_nat_dec_lt(v_lo_1023_, v_hi_1024_);
if (v___x_1036_ == 0)
{
lean_dec(v_lo_1023_);
return v_as_1022_;
}
else
{
lean_object* v___x_1037_; lean_object* v___x_1038_; lean_object* v_mid_1039_; lean_object* v___y_1041_; lean_object* v___y_1047_; lean_object* v___x_1052_; lean_object* v___x_1053_; uint8_t v___x_1054_; 
v___x_1037_ = lean_nat_add(v_lo_1023_, v_hi_1024_);
v___x_1038_ = lean_unsigned_to_nat(1u);
v_mid_1039_ = lean_nat_shiftr(v___x_1037_, v___x_1038_);
lean_dec(v___x_1037_);
v___x_1052_ = lean_array_fget_borrowed(v_as_1022_, v_mid_1039_);
v___x_1053_ = lean_array_fget_borrowed(v_as_1022_, v_lo_1023_);
v___x_1054_ = l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__8___redArg___lam__0(v___x_1052_, v___x_1053_);
if (v___x_1054_ == 0)
{
v___y_1047_ = v_as_1022_;
goto v___jp_1046_;
}
else
{
lean_object* v___x_1055_; 
v___x_1055_ = lean_array_fswap(v_as_1022_, v_lo_1023_, v_mid_1039_);
v___y_1047_ = v___x_1055_;
goto v___jp_1046_;
}
v___jp_1040_:
{
lean_object* v___x_1042_; lean_object* v___x_1043_; uint8_t v___x_1044_; 
v___x_1042_ = lean_array_fget_borrowed(v___y_1041_, v_mid_1039_);
v___x_1043_ = lean_array_fget_borrowed(v___y_1041_, v_hi_1024_);
v___x_1044_ = l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__8___redArg___lam__0(v___x_1042_, v___x_1043_);
if (v___x_1044_ == 0)
{
lean_dec(v_mid_1039_);
v___y_1026_ = v___y_1041_;
goto v___jp_1025_;
}
else
{
lean_object* v___x_1045_; 
v___x_1045_ = lean_array_fswap(v___y_1041_, v_mid_1039_, v_hi_1024_);
lean_dec(v_mid_1039_);
v___y_1026_ = v___x_1045_;
goto v___jp_1025_;
}
}
v___jp_1046_:
{
lean_object* v___x_1048_; lean_object* v___x_1049_; uint8_t v___x_1050_; 
v___x_1048_ = lean_array_fget_borrowed(v___y_1047_, v_hi_1024_);
v___x_1049_ = lean_array_fget_borrowed(v___y_1047_, v_lo_1023_);
v___x_1050_ = l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__8___redArg___lam__0(v___x_1048_, v___x_1049_);
if (v___x_1050_ == 0)
{
v___y_1041_ = v___y_1047_;
goto v___jp_1040_;
}
else
{
lean_object* v___x_1051_; 
v___x_1051_ = lean_array_fswap(v___y_1047_, v_lo_1023_, v_hi_1024_);
v___y_1041_ = v___x_1051_;
goto v___jp_1040_;
}
}
}
v___jp_1025_:
{
lean_object* v_pivot_1027_; lean_object* v___x_1028_; lean_object* v_fst_1029_; lean_object* v_snd_1030_; uint8_t v___x_1031_; 
v_pivot_1027_ = lean_array_fget(v___y_1026_, v_hi_1024_);
lean_inc_n(v_lo_1023_, 2);
v___x_1028_ = l___private_Init_Data_Array_QSort_Basic_0__Array_qpartition_loop___at___00__private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__8_spec__10___redArg(v_hi_1024_, v_pivot_1027_, v___y_1026_, v_lo_1023_, v_lo_1023_);
lean_dec(v_pivot_1027_);
v_fst_1029_ = lean_ctor_get(v___x_1028_, 0);
lean_inc(v_fst_1029_);
v_snd_1030_ = lean_ctor_get(v___x_1028_, 1);
lean_inc(v_snd_1030_);
lean_dec_ref(v___x_1028_);
v___x_1031_ = lean_nat_dec_le(v_hi_1024_, v_fst_1029_);
if (v___x_1031_ == 0)
{
lean_object* v___x_1032_; lean_object* v___x_1033_; lean_object* v___x_1034_; 
v___x_1032_ = l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__8___redArg(v_n_1021_, v_snd_1030_, v_lo_1023_, v_fst_1029_);
v___x_1033_ = lean_unsigned_to_nat(1u);
v___x_1034_ = lean_nat_add(v_fst_1029_, v___x_1033_);
lean_dec(v_fst_1029_);
v_as_1022_ = v___x_1032_;
v_lo_1023_ = v___x_1034_;
goto _start;
}
else
{
lean_dec(v_fst_1029_);
lean_dec(v_lo_1023_);
return v_snd_1030_;
}
}
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__8___redArg___boxed(lean_object* v_n_1056_, lean_object* v_as_1057_, lean_object* v_lo_1058_, lean_object* v_hi_1059_){
_start:
{
lean_object* v_res_1060_; 
v_res_1060_ = l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__8___redArg(v_n_1056_, v_as_1057_, v_lo_1058_, v_hi_1059_);
lean_dec(v_hi_1059_);
lean_dec(v_n_1056_);
return v_res_1060_;
}
}
LEAN_EXPORT lean_object* l_List_forIn_x27_loop___at___00List_forIn_x27_loop___at___00main_spec__2_spec__2___redArg(lean_object* v_a_1064_, lean_object* v___x_1065_, uint8_t v___x_1066_, lean_object* v_head_1067_, lean_object* v_as_x27_1068_, lean_object* v_b_1069_){
_start:
{
if (lean_obj_tag(v_as_x27_1068_) == 0)
{
lean_object* v___x_1071_; 
v___x_1071_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_1071_, 0, v_b_1069_);
return v___x_1071_;
}
else
{
lean_object* v_head_1072_; lean_object* v_tail_1073_; lean_object* v_fst_1074_; lean_object* v_snd_1075_; lean_object* v___x_1076_; uint8_t v___x_1077_; 
v_head_1072_ = lean_ctor_get(v_as_x27_1068_, 0);
v_tail_1073_ = lean_ctor_get(v_as_x27_1068_, 1);
v_fst_1074_ = lean_ctor_get(v_head_1072_, 0);
v_snd_1075_ = lean_ctor_get(v_head_1072_, 1);
v___x_1076_ = l_Lean_Environment_getModuleIdxFor_x3f(v_a_1064_, v_fst_1074_);
v___x_1077_ = l_Option_instBEq_beq___at___00main_spec__1(v___x_1076_, v___x_1065_);
lean_dec(v___x_1076_);
if (v___x_1077_ == 0)
{
v_as_x27_1068_ = v_tail_1073_;
goto _start;
}
else
{
if (lean_obj_tag(v_snd_1075_) == 2)
{
lean_object* v_val_1079_; lean_object* v___x_1080_; uint8_t v___x_1081_; 
v_val_1079_ = lean_ctor_get(v_snd_1075_, 0);
v___x_1080_ = ((lean_object*)(l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__3___closed__2));
v___x_1081_ = lean_string_dec_eq(v_head_1067_, v___x_1080_);
if (v___x_1066_ == 0)
{
goto v___jp_1082_;
}
else
{
lean_object* v_value_1086_; lean_object* v___x_1087_; lean_object* v___x_1088_; lean_object* v___x_1089_; uint8_t v___x_1090_; 
v_value_1086_ = lean_ctor_get(v_val_1079_, 1);
lean_inc_ref(v_value_1086_);
v___x_1087_ = l_Lean_Expr_cleanupAnnotations(v_value_1086_);
v___x_1088_ = l_Lean_Expr_getAppFn(v___x_1087_);
lean_dec_ref(v___x_1087_);
v___x_1089_ = ((lean_object*)(l_List_forIn_x27_loop___at___00List_forIn_x27_loop___at___00main_spec__2_spec__2___redArg___closed__1));
v___x_1090_ = l_Lean_Expr_isConstOf(v___x_1088_, v___x_1089_);
lean_dec_ref(v___x_1088_);
if (v___x_1090_ == 0)
{
v_as_x27_1068_ = v_tail_1073_;
goto _start;
}
else
{
goto v___jp_1082_;
}
}
v___jp_1082_:
{
if (v___x_1081_ == 0)
{
lean_object* v___x_1083_; 
lean_inc_ref(v_val_1079_);
v___x_1083_ = lean_array_push(v_b_1069_, v_val_1079_);
v_as_x27_1068_ = v_tail_1073_;
v_b_1069_ = v___x_1083_;
goto _start;
}
else
{
v_as_x27_1068_ = v_tail_1073_;
goto _start;
}
}
}
else
{
v_as_x27_1068_ = v_tail_1073_;
goto _start;
}
}
}
}
}
LEAN_EXPORT lean_object* l_List_forIn_x27_loop___at___00List_forIn_x27_loop___at___00main_spec__2_spec__2___redArg___boxed(lean_object* v_a_1093_, lean_object* v___x_1094_, lean_object* v___x_1095_, lean_object* v_head_1096_, lean_object* v_as_x27_1097_, lean_object* v_b_1098_, lean_object* v___y_1099_){
_start:
{
uint8_t v___x_18583__boxed_1100_; lean_object* v_res_1101_; 
v___x_18583__boxed_1100_ = lean_unbox(v___x_1095_);
v_res_1101_ = l_List_forIn_x27_loop___at___00List_forIn_x27_loop___at___00main_spec__2_spec__2___redArg(v_a_1093_, v___x_1094_, v___x_18583__boxed_1100_, v_head_1096_, v_as_x27_1097_, v_b_1098_);
lean_dec(v_as_x27_1097_);
lean_dec_ref(v_head_1096_);
lean_dec(v___x_1094_);
lean_dec_ref(v_a_1093_);
return v_res_1101_;
}
}
LEAN_EXPORT lean_object* l_List_forIn_x27_loop___at___00main_spec__2___redArg(lean_object* v_a_1102_, lean_object* v___x_1103_, uint8_t v___x_1104_, lean_object* v_head_1105_, lean_object* v_as_1106_, lean_object* v_as_x27_1107_, lean_object* v_b_1108_){
_start:
{
if (lean_obj_tag(v_as_x27_1107_) == 0)
{
lean_object* v___x_1110_; 
v___x_1110_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_1110_, 0, v_b_1108_);
return v___x_1110_;
}
else
{
lean_object* v_head_1111_; lean_object* v_tail_1112_; lean_object* v_fst_1113_; lean_object* v_snd_1114_; lean_object* v___x_1115_; uint8_t v___x_1116_; 
v_head_1111_ = lean_ctor_get(v_as_x27_1107_, 0);
v_tail_1112_ = lean_ctor_get(v_as_x27_1107_, 1);
v_fst_1113_ = lean_ctor_get(v_head_1111_, 0);
v_snd_1114_ = lean_ctor_get(v_head_1111_, 1);
v___x_1115_ = l_Lean_Environment_getModuleIdxFor_x3f(v_a_1102_, v_fst_1113_);
v___x_1116_ = l_Option_instBEq_beq___at___00main_spec__1(v___x_1115_, v___x_1103_);
lean_dec(v___x_1115_);
if (v___x_1116_ == 0)
{
lean_object* v___x_1117_; 
v___x_1117_ = l_List_forIn_x27_loop___at___00List_forIn_x27_loop___at___00main_spec__2_spec__2___redArg(v_a_1102_, v___x_1103_, v___x_1104_, v_head_1105_, v_tail_1112_, v_b_1108_);
return v___x_1117_;
}
else
{
if (lean_obj_tag(v_snd_1114_) == 2)
{
lean_object* v_val_1118_; lean_object* v___x_1119_; uint8_t v___x_1120_; 
v_val_1118_ = lean_ctor_get(v_snd_1114_, 0);
v___x_1119_ = ((lean_object*)(l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__3___closed__2));
v___x_1120_ = lean_string_dec_eq(v_head_1105_, v___x_1119_);
if (v___x_1104_ == 0)
{
goto v___jp_1121_;
}
else
{
lean_object* v_value_1125_; lean_object* v___x_1126_; lean_object* v___x_1127_; lean_object* v___x_1128_; uint8_t v___x_1129_; 
v_value_1125_ = lean_ctor_get(v_val_1118_, 1);
lean_inc_ref(v_value_1125_);
v___x_1126_ = l_Lean_Expr_cleanupAnnotations(v_value_1125_);
v___x_1127_ = l_Lean_Expr_getAppFn(v___x_1126_);
lean_dec_ref(v___x_1126_);
v___x_1128_ = ((lean_object*)(l_List_forIn_x27_loop___at___00List_forIn_x27_loop___at___00main_spec__2_spec__2___redArg___closed__1));
v___x_1129_ = l_Lean_Expr_isConstOf(v___x_1127_, v___x_1128_);
lean_dec_ref(v___x_1127_);
if (v___x_1129_ == 0)
{
lean_object* v___x_1130_; 
v___x_1130_ = l_List_forIn_x27_loop___at___00List_forIn_x27_loop___at___00main_spec__2_spec__2___redArg(v_a_1102_, v___x_1103_, v___x_1104_, v_head_1105_, v_tail_1112_, v_b_1108_);
return v___x_1130_;
}
else
{
goto v___jp_1121_;
}
}
v___jp_1121_:
{
if (v___x_1120_ == 0)
{
lean_object* v___x_1122_; lean_object* v___x_1123_; 
lean_inc_ref(v_val_1118_);
v___x_1122_ = lean_array_push(v_b_1108_, v_val_1118_);
v___x_1123_ = l_List_forIn_x27_loop___at___00List_forIn_x27_loop___at___00main_spec__2_spec__2___redArg(v_a_1102_, v___x_1103_, v___x_1104_, v_head_1105_, v_tail_1112_, v___x_1122_);
return v___x_1123_;
}
else
{
lean_object* v___x_1124_; 
v___x_1124_ = l_List_forIn_x27_loop___at___00List_forIn_x27_loop___at___00main_spec__2_spec__2___redArg(v_a_1102_, v___x_1103_, v___x_1104_, v_head_1105_, v_tail_1112_, v_b_1108_);
return v___x_1124_;
}
}
}
else
{
lean_object* v___x_1131_; 
v___x_1131_ = l_List_forIn_x27_loop___at___00List_forIn_x27_loop___at___00main_spec__2_spec__2___redArg(v_a_1102_, v___x_1103_, v___x_1104_, v_head_1105_, v_tail_1112_, v_b_1108_);
return v___x_1131_;
}
}
}
}
}
LEAN_EXPORT lean_object* l_List_forIn_x27_loop___at___00main_spec__2___redArg___boxed(lean_object* v_a_1132_, lean_object* v___x_1133_, lean_object* v___x_1134_, lean_object* v_head_1135_, lean_object* v_as_1136_, lean_object* v_as_x27_1137_, lean_object* v_b_1138_, lean_object* v___y_1139_){
_start:
{
uint8_t v___x_18647__boxed_1140_; lean_object* v_res_1141_; 
v___x_18647__boxed_1140_ = lean_unbox(v___x_1134_);
v_res_1141_ = l_List_forIn_x27_loop___at___00main_spec__2___redArg(v_a_1132_, v___x_1133_, v___x_18647__boxed_1140_, v_head_1135_, v_as_1136_, v_as_x27_1137_, v_b_1138_);
lean_dec(v_as_x27_1137_);
lean_dec(v_as_1136_);
lean_dec_ref(v_head_1135_);
lean_dec(v___x_1133_);
lean_dec_ref(v_a_1132_);
return v_res_1141_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__7(lean_object* v_head_1153_, lean_object* v_workers_1154_, lean_object* v___x_1155_, lean_object* v_targets_1156_, lean_object* v_as_1157_, size_t v_sz_1158_, size_t v_i_1159_, lean_object* v_b_1160_){
_start:
{
uint8_t v___x_1162_; 
v___x_1162_ = lean_usize_dec_lt(v_i_1159_, v_sz_1158_);
if (v___x_1162_ == 0)
{
lean_object* v___x_1163_; 
lean_dec(v___x_1155_);
lean_dec(v_workers_1154_);
lean_dec_ref(v_head_1153_);
v___x_1163_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_1163_, 0, v_b_1160_);
return v___x_1163_;
}
else
{
lean_object* v_a_1164_; lean_object* v___x_1165_; lean_object* v___x_1166_; lean_object* v___x_1167_; lean_object* v___x_1168_; lean_object* v___x_1169_; lean_object* v___x_1170_; lean_object* v___x_1171_; lean_object* v___x_1172_; lean_object* v___x_1173_; lean_object* v___x_1174_; lean_object* v___x_1175_; lean_object* v___x_1176_; lean_object* v___x_1177_; lean_object* v___x_1178_; lean_object* v___x_1179_; lean_object* v___x_1180_; lean_object* v___x_1181_; lean_object* v___x_1182_; lean_object* v___x_1183_; lean_object* v___x_1184_; lean_object* v___x_1185_; lean_object* v___x_1186_; lean_object* v___x_1187_; lean_object* v___x_1188_; lean_object* v___x_1189_; lean_object* v___x_1190_; lean_object* v___x_1191_; lean_object* v___x_1192_; lean_object* v___x_1193_; lean_object* v___x_1194_; 
v_a_1164_ = lean_array_uget_borrowed(v_as_1157_, v_i_1159_);
v___x_1165_ = ((lean_object*)(l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__7___closed__0));
v___x_1166_ = ((lean_object*)(l_elaborateOne___closed__19));
lean_inc_ref(v_head_1153_);
v___x_1167_ = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(v___x_1167_, 0, v_head_1153_);
v___x_1168_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1168_, 0, v___x_1166_);
lean_ctor_set(v___x_1168_, 1, v___x_1167_);
v___x_1169_ = ((lean_object*)(l_elaborateOne___closed__20));
lean_inc(v_workers_1154_);
v___x_1170_ = l_Lean_JsonNumber_fromNat(v_workers_1154_);
v___x_1171_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_1171_, 0, v___x_1170_);
v___x_1172_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1172_, 0, v___x_1169_);
lean_ctor_set(v___x_1172_, 1, v___x_1171_);
v___x_1173_ = ((lean_object*)(l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__7___closed__1));
lean_inc(v___x_1155_);
v___x_1174_ = l_Lean_JsonNumber_fromNat(v___x_1155_);
v___x_1175_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_1175_, 0, v___x_1174_);
v___x_1176_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1176_, 0, v___x_1173_);
lean_ctor_set(v___x_1176_, 1, v___x_1175_);
v___x_1177_ = ((lean_object*)(l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__7___closed__2));
v___x_1178_ = lean_array_get_size(v_targets_1156_);
v___x_1179_ = l_Lean_JsonNumber_fromNat(v___x_1178_);
v___x_1180_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_1180_, 0, v___x_1179_);
v___x_1181_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1181_, 0, v___x_1177_);
lean_ctor_set(v___x_1181_, 1, v___x_1180_);
v___x_1182_ = ((lean_object*)(l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__7___closed__3));
lean_inc(v_a_1164_);
v___x_1183_ = l_instToJsonUnitRow_toJson(v_a_1164_);
v___x_1184_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1184_, 0, v___x_1182_);
lean_ctor_set(v___x_1184_, 1, v___x_1183_);
v___x_1185_ = ((lean_object*)(l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__7___closed__6));
v___x_1186_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_1186_, 0, v___x_1184_);
lean_ctor_set(v___x_1186_, 1, v___x_1185_);
v___x_1187_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_1187_, 0, v___x_1181_);
lean_ctor_set(v___x_1187_, 1, v___x_1186_);
v___x_1188_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_1188_, 0, v___x_1176_);
lean_ctor_set(v___x_1188_, 1, v___x_1187_);
v___x_1189_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_1189_, 0, v___x_1172_);
lean_ctor_set(v___x_1189_, 1, v___x_1188_);
v___x_1190_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_1190_, 0, v___x_1168_);
lean_ctor_set(v___x_1190_, 1, v___x_1189_);
v___x_1191_ = l_Lean_Json_mkObj(v___x_1190_);
lean_dec_ref_known(v___x_1190_, 2);
v___x_1192_ = l_Lean_Json_compress(v___x_1191_);
v___x_1193_ = lean_string_append(v___x_1165_, v___x_1192_);
lean_dec_ref(v___x_1192_);
v___x_1194_ = l_IO_println___at___00__private_Lean_Shell_0__Lean_ShellOptions_process_spec__3(v___x_1193_);
if (lean_obj_tag(v___x_1194_) == 0)
{
lean_object* v___x_1195_; size_t v___x_1196_; size_t v___x_1197_; 
lean_dec_ref_known(v___x_1194_, 1);
v___x_1195_ = lean_box(0);
v___x_1196_ = ((size_t)1ULL);
v___x_1197_ = lean_usize_add(v_i_1159_, v___x_1196_);
v_i_1159_ = v___x_1197_;
v_b_1160_ = v___x_1195_;
goto _start;
}
else
{
lean_dec(v___x_1155_);
lean_dec(v_workers_1154_);
lean_dec_ref(v_head_1153_);
return v___x_1194_;
}
}
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__7___boxed(lean_object* v_head_1199_, lean_object* v_workers_1200_, lean_object* v___x_1201_, lean_object* v_targets_1202_, lean_object* v_as_1203_, lean_object* v_sz_1204_, lean_object* v_i_1205_, lean_object* v_b_1206_, lean_object* v___y_1207_){
_start:
{
size_t v_sz_boxed_1208_; size_t v_i_boxed_1209_; lean_object* v_res_1210_; 
v_sz_boxed_1208_ = lean_unbox_usize(v_sz_1204_);
lean_dec(v_sz_1204_);
v_i_boxed_1209_ = lean_unbox_usize(v_i_1205_);
lean_dec(v_i_1205_);
v_res_1210_ = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__7(v_head_1199_, v_workers_1200_, v___x_1201_, v_targets_1202_, v_as_1203_, v_sz_boxed_1208_, v_i_boxed_1209_, v_b_1206_);
lean_dec_ref(v_as_1203_);
lean_dec_ref(v_targets_1202_);
return v_res_1210_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_QSort_Basic_0__Array_qpartition_loop___at___00__private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__12_spec__15___redArg(uint8_t v___x_1211_, lean_object* v_hi_1212_, lean_object* v_pivot_1213_, lean_object* v_as_1214_, lean_object* v_i_1215_, lean_object* v_k_1216_){
_start:
{
uint8_t v___x_1217_; 
v___x_1217_ = lean_nat_dec_lt(v_k_1216_, v_hi_1212_);
if (v___x_1217_ == 0)
{
lean_object* v___x_1218_; lean_object* v___x_1219_; 
lean_dec(v_k_1216_);
lean_dec_ref(v_pivot_1213_);
v___x_1218_ = lean_array_fswap(v_as_1214_, v_i_1215_, v_hi_1212_);
v___x_1219_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1219_, 0, v_i_1215_);
lean_ctor_set(v___x_1219_, 1, v___x_1218_);
return v___x_1219_;
}
else
{
lean_object* v___x_1220_; lean_object* v_toConstantVal_1221_; lean_object* v_toConstantVal_1222_; lean_object* v_name_1223_; lean_object* v_name_1224_; lean_object* v___x_1225_; lean_object* v___x_1226_; uint8_t v___x_1227_; 
v___x_1220_ = lean_array_fget_borrowed(v_as_1214_, v_k_1216_);
v_toConstantVal_1221_ = lean_ctor_get(v___x_1220_, 0);
v_toConstantVal_1222_ = lean_ctor_get(v_pivot_1213_, 0);
v_name_1223_ = lean_ctor_get(v_toConstantVal_1221_, 0);
v_name_1224_ = lean_ctor_get(v_toConstantVal_1222_, 0);
lean_inc(v_name_1223_);
v___x_1225_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v_name_1223_, v___x_1211_);
lean_inc(v_name_1224_);
v___x_1226_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v_name_1224_, v___x_1211_);
v___x_1227_ = lean_string_dec_lt(v___x_1225_, v___x_1226_);
lean_dec_ref(v___x_1226_);
lean_dec_ref(v___x_1225_);
if (v___x_1227_ == 0)
{
lean_object* v___x_1228_; lean_object* v___x_1229_; 
v___x_1228_ = lean_unsigned_to_nat(1u);
v___x_1229_ = lean_nat_add(v_k_1216_, v___x_1228_);
lean_dec(v_k_1216_);
v_k_1216_ = v___x_1229_;
goto _start;
}
else
{
lean_object* v___x_1231_; lean_object* v___x_1232_; lean_object* v___x_1233_; lean_object* v___x_1234_; 
v___x_1231_ = lean_array_fswap(v_as_1214_, v_i_1215_, v_k_1216_);
v___x_1232_ = lean_unsigned_to_nat(1u);
v___x_1233_ = lean_nat_add(v_i_1215_, v___x_1232_);
lean_dec(v_i_1215_);
v___x_1234_ = lean_nat_add(v_k_1216_, v___x_1232_);
lean_dec(v_k_1216_);
v_as_1214_ = v___x_1231_;
v_i_1215_ = v___x_1233_;
v_k_1216_ = v___x_1234_;
goto _start;
}
}
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_QSort_Basic_0__Array_qpartition_loop___at___00__private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__12_spec__15___redArg___boxed(lean_object* v___x_1236_, lean_object* v_hi_1237_, lean_object* v_pivot_1238_, lean_object* v_as_1239_, lean_object* v_i_1240_, lean_object* v_k_1241_){
_start:
{
uint8_t v___x_18821__boxed_1242_; lean_object* v_res_1243_; 
v___x_18821__boxed_1242_ = lean_unbox(v___x_1236_);
v_res_1243_ = l___private_Init_Data_Array_QSort_Basic_0__Array_qpartition_loop___at___00__private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__12_spec__15___redArg(v___x_18821__boxed_1242_, v_hi_1237_, v_pivot_1238_, v_as_1239_, v_i_1240_, v_k_1241_);
lean_dec(v_hi_1237_);
return v_res_1243_;
}
}
LEAN_EXPORT uint8_t l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__12___redArg___lam__0(uint8_t v___x_1244_, lean_object* v_a_1245_, lean_object* v_b_1246_){
_start:
{
lean_object* v_toConstantVal_1247_; lean_object* v_toConstantVal_1248_; lean_object* v_name_1249_; lean_object* v_name_1250_; lean_object* v___x_1251_; lean_object* v___x_1252_; uint8_t v___x_1253_; 
v_toConstantVal_1247_ = lean_ctor_get(v_a_1245_, 0);
lean_inc_ref(v_toConstantVal_1247_);
lean_dec_ref(v_a_1245_);
v_toConstantVal_1248_ = lean_ctor_get(v_b_1246_, 0);
lean_inc_ref(v_toConstantVal_1248_);
lean_dec_ref(v_b_1246_);
v_name_1249_ = lean_ctor_get(v_toConstantVal_1247_, 0);
lean_inc(v_name_1249_);
lean_dec_ref(v_toConstantVal_1247_);
v_name_1250_ = lean_ctor_get(v_toConstantVal_1248_, 0);
lean_inc(v_name_1250_);
lean_dec_ref(v_toConstantVal_1248_);
v___x_1251_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v_name_1249_, v___x_1244_);
v___x_1252_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v_name_1250_, v___x_1244_);
v___x_1253_ = lean_string_dec_lt(v___x_1251_, v___x_1252_);
lean_dec_ref(v___x_1252_);
lean_dec_ref(v___x_1251_);
return v___x_1253_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__12___redArg___lam__0___boxed(lean_object* v___x_1254_, lean_object* v_a_1255_, lean_object* v_b_1256_){
_start:
{
uint8_t v___x_18854__boxed_1257_; uint8_t v_res_1258_; lean_object* v_r_1259_; 
v___x_18854__boxed_1257_ = lean_unbox(v___x_1254_);
v_res_1258_ = l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__12___redArg___lam__0(v___x_18854__boxed_1257_, v_a_1255_, v_b_1256_);
v_r_1259_ = lean_box(v_res_1258_);
return v_r_1259_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__12___redArg(uint8_t v___x_1260_, lean_object* v_n_1261_, lean_object* v_as_1262_, lean_object* v_lo_1263_, lean_object* v_hi_1264_){
_start:
{
lean_object* v___y_1266_; uint8_t v___x_1276_; 
v___x_1276_ = lean_nat_dec_lt(v_lo_1263_, v_hi_1264_);
if (v___x_1276_ == 0)
{
lean_dec(v_lo_1263_);
return v_as_1262_;
}
else
{
lean_object* v___x_1277_; lean_object* v___x_1278_; lean_object* v_mid_1279_; lean_object* v___y_1281_; lean_object* v___y_1287_; lean_object* v___x_1292_; lean_object* v___x_1293_; uint8_t v___x_1294_; 
v___x_1277_ = lean_nat_add(v_lo_1263_, v_hi_1264_);
v___x_1278_ = lean_unsigned_to_nat(1u);
v_mid_1279_ = lean_nat_shiftr(v___x_1277_, v___x_1278_);
lean_dec(v___x_1277_);
v___x_1292_ = lean_array_fget_borrowed(v_as_1262_, v_mid_1279_);
v___x_1293_ = lean_array_fget_borrowed(v_as_1262_, v_lo_1263_);
lean_inc(v___x_1293_);
lean_inc(v___x_1292_);
v___x_1294_ = l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__12___redArg___lam__0(v___x_1260_, v___x_1292_, v___x_1293_);
if (v___x_1294_ == 0)
{
v___y_1287_ = v_as_1262_;
goto v___jp_1286_;
}
else
{
lean_object* v___x_1295_; 
v___x_1295_ = lean_array_fswap(v_as_1262_, v_lo_1263_, v_mid_1279_);
v___y_1287_ = v___x_1295_;
goto v___jp_1286_;
}
v___jp_1280_:
{
lean_object* v___x_1282_; lean_object* v___x_1283_; uint8_t v___x_1284_; 
v___x_1282_ = lean_array_fget_borrowed(v___y_1281_, v_mid_1279_);
v___x_1283_ = lean_array_fget_borrowed(v___y_1281_, v_hi_1264_);
lean_inc(v___x_1283_);
lean_inc(v___x_1282_);
v___x_1284_ = l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__12___redArg___lam__0(v___x_1260_, v___x_1282_, v___x_1283_);
if (v___x_1284_ == 0)
{
lean_dec(v_mid_1279_);
v___y_1266_ = v___y_1281_;
goto v___jp_1265_;
}
else
{
lean_object* v___x_1285_; 
v___x_1285_ = lean_array_fswap(v___y_1281_, v_mid_1279_, v_hi_1264_);
lean_dec(v_mid_1279_);
v___y_1266_ = v___x_1285_;
goto v___jp_1265_;
}
}
v___jp_1286_:
{
lean_object* v___x_1288_; lean_object* v___x_1289_; uint8_t v___x_1290_; 
v___x_1288_ = lean_array_fget_borrowed(v___y_1287_, v_hi_1264_);
v___x_1289_ = lean_array_fget_borrowed(v___y_1287_, v_lo_1263_);
lean_inc(v___x_1289_);
lean_inc(v___x_1288_);
v___x_1290_ = l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__12___redArg___lam__0(v___x_1260_, v___x_1288_, v___x_1289_);
if (v___x_1290_ == 0)
{
v___y_1281_ = v___y_1287_;
goto v___jp_1280_;
}
else
{
lean_object* v___x_1291_; 
v___x_1291_ = lean_array_fswap(v___y_1287_, v_lo_1263_, v_hi_1264_);
v___y_1281_ = v___x_1291_;
goto v___jp_1280_;
}
}
}
v___jp_1265_:
{
lean_object* v_pivot_1267_; lean_object* v___x_1268_; lean_object* v_fst_1269_; lean_object* v_snd_1270_; uint8_t v___x_1271_; 
v_pivot_1267_ = lean_array_fget(v___y_1266_, v_hi_1264_);
lean_inc_n(v_lo_1263_, 2);
v___x_1268_ = l___private_Init_Data_Array_QSort_Basic_0__Array_qpartition_loop___at___00__private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__12_spec__15___redArg(v___x_1260_, v_hi_1264_, v_pivot_1267_, v___y_1266_, v_lo_1263_, v_lo_1263_);
v_fst_1269_ = lean_ctor_get(v___x_1268_, 0);
lean_inc(v_fst_1269_);
v_snd_1270_ = lean_ctor_get(v___x_1268_, 1);
lean_inc(v_snd_1270_);
lean_dec_ref(v___x_1268_);
v___x_1271_ = lean_nat_dec_le(v_hi_1264_, v_fst_1269_);
if (v___x_1271_ == 0)
{
lean_object* v___x_1272_; lean_object* v___x_1273_; lean_object* v___x_1274_; 
v___x_1272_ = l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__12___redArg(v___x_1260_, v_n_1261_, v_snd_1270_, v_lo_1263_, v_fst_1269_);
v___x_1273_ = lean_unsigned_to_nat(1u);
v___x_1274_ = lean_nat_add(v_fst_1269_, v___x_1273_);
lean_dec(v_fst_1269_);
v_as_1262_ = v___x_1272_;
v_lo_1263_ = v___x_1274_;
goto _start;
}
else
{
lean_dec(v_fst_1269_);
lean_dec(v_lo_1263_);
return v_snd_1270_;
}
}
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__12___redArg___boxed(lean_object* v___x_1296_, lean_object* v_n_1297_, lean_object* v_as_1298_, lean_object* v_lo_1299_, lean_object* v_hi_1300_){
_start:
{
uint8_t v___x_18863__boxed_1301_; lean_object* v_res_1302_; 
v___x_18863__boxed_1301_ = lean_unbox(v___x_1296_);
v_res_1302_ = l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__12___redArg(v___x_18863__boxed_1301_, v_n_1297_, v_as_1298_, v_lo_1299_, v_hi_1300_);
lean_dec(v_hi_1300_);
lean_dec(v_n_1297_);
return v_res_1302_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00main_spec__9(uint8_t v___x_1303_, size_t v_sz_1304_, size_t v_i_1305_, lean_object* v_bs_1306_){
_start:
{
uint8_t v___x_1307_; 
v___x_1307_ = lean_usize_dec_lt(v_i_1305_, v_sz_1304_);
if (v___x_1307_ == 0)
{
return v_bs_1306_;
}
else
{
lean_object* v_v_1308_; lean_object* v_toConstantVal_1309_; lean_object* v_name_1310_; lean_object* v___x_1311_; lean_object* v_bs_x27_1312_; lean_object* v___x_1313_; size_t v___x_1314_; size_t v___x_1315_; lean_object* v___x_1316_; 
v_v_1308_ = lean_array_uget_borrowed(v_bs_1306_, v_i_1305_);
v_toConstantVal_1309_ = lean_ctor_get(v_v_1308_, 0);
v_name_1310_ = lean_ctor_get(v_toConstantVal_1309_, 0);
lean_inc(v_name_1310_);
v___x_1311_ = lean_unsigned_to_nat(0u);
v_bs_x27_1312_ = lean_array_uset(v_bs_1306_, v_i_1305_, v___x_1311_);
v___x_1313_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v_name_1310_, v___x_1303_);
v___x_1314_ = ((size_t)1ULL);
v___x_1315_ = lean_usize_add(v_i_1305_, v___x_1314_);
v___x_1316_ = lean_array_uset(v_bs_x27_1312_, v_i_1305_, v___x_1313_);
v_i_1305_ = v___x_1315_;
v_bs_1306_ = v___x_1316_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00main_spec__9___boxed(lean_object* v___x_1318_, lean_object* v_sz_1319_, lean_object* v_i_1320_, lean_object* v_bs_1321_){
_start:
{
uint8_t v___x_18924__boxed_1322_; size_t v_sz_boxed_1323_; size_t v_i_boxed_1324_; lean_object* v_res_1325_; 
v___x_18924__boxed_1322_ = lean_unbox(v___x_1318_);
v_sz_boxed_1323_ = lean_unbox_usize(v_sz_1319_);
lean_dec(v_sz_1319_);
v_i_boxed_1324_ = lean_unbox_usize(v_i_1320_);
lean_dec(v_i_1320_);
v_res_1325_ = l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00main_spec__9(v___x_18924__boxed_1322_, v_sz_boxed_1323_, v_i_boxed_1324_, v_bs_1321_);
return v_res_1325_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__4___redArg(lean_object* v_workers_1326_, lean_object* v_a_1327_, lean_object* v_targets_1328_, lean_object* v___x_1329_, lean_object* v_range_1330_, lean_object* v_b_1331_, lean_object* v_i_1332_){
_start:
{
lean_object* v_stop_1334_; lean_object* v_step_1335_; lean_object* v_a_1337_; uint8_t v___x_1340_; 
v_stop_1334_ = lean_ctor_get(v_range_1330_, 1);
v_step_1335_ = lean_ctor_get(v_range_1330_, 2);
v___x_1340_ = lean_nat_dec_lt(v_i_1332_, v_stop_1334_);
if (v___x_1340_ == 0)
{
lean_object* v___x_1341_; 
lean_dec(v_i_1332_);
lean_dec_ref(v___x_1329_);
v___x_1341_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_1341_, 0, v_b_1331_);
return v___x_1341_;
}
else
{
lean_object* v___x_1342_; uint8_t v___x_1343_; 
v___x_1342_ = lean_nat_mod(v_i_1332_, v_workers_1326_);
v___x_1343_ = lean_nat_dec_eq(v___x_1342_, v_a_1327_);
lean_dec(v___x_1342_);
if (v___x_1343_ == 0)
{
v_a_1337_ = v_b_1331_;
goto v___jp_1336_;
}
else
{
lean_object* v___x_1344_; lean_object* v___x_1345_; lean_object* v___x_1346_; 
v___x_1344_ = l_Lean_instInhabitedTheoremVal_default;
v___x_1345_ = lean_array_get_borrowed(v___x_1344_, v_targets_1328_, v_i_1332_);
lean_inc(v_i_1332_);
lean_inc(v___x_1345_);
lean_inc_ref(v___x_1329_);
v___x_1346_ = l_one(v___x_1329_, v___x_1345_, v_i_1332_);
if (lean_obj_tag(v___x_1346_) == 0)
{
lean_object* v_a_1347_; lean_object* v___x_1348_; 
v_a_1347_ = lean_ctor_get(v___x_1346_, 0);
lean_inc(v_a_1347_);
lean_dec_ref_known(v___x_1346_, 1);
v___x_1348_ = lean_array_push(v_b_1331_, v_a_1347_);
v_a_1337_ = v___x_1348_;
goto v___jp_1336_;
}
else
{
lean_object* v_a_1349_; lean_object* v___x_1351_; uint8_t v_isShared_1352_; uint8_t v_isSharedCheck_1356_; 
lean_dec(v_i_1332_);
lean_dec_ref(v_b_1331_);
lean_dec_ref(v___x_1329_);
v_a_1349_ = lean_ctor_get(v___x_1346_, 0);
v_isSharedCheck_1356_ = !lean_is_exclusive(v___x_1346_);
if (v_isSharedCheck_1356_ == 0)
{
v___x_1351_ = v___x_1346_;
v_isShared_1352_ = v_isSharedCheck_1356_;
goto v_resetjp_1350_;
}
else
{
lean_inc(v_a_1349_);
lean_dec(v___x_1346_);
v___x_1351_ = lean_box(0);
v_isShared_1352_ = v_isSharedCheck_1356_;
goto v_resetjp_1350_;
}
v_resetjp_1350_:
{
lean_object* v___x_1354_; 
if (v_isShared_1352_ == 0)
{
v___x_1354_ = v___x_1351_;
goto v_reusejp_1353_;
}
else
{
lean_object* v_reuseFailAlloc_1355_; 
v_reuseFailAlloc_1355_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1355_, 0, v_a_1349_);
v___x_1354_ = v_reuseFailAlloc_1355_;
goto v_reusejp_1353_;
}
v_reusejp_1353_:
{
return v___x_1354_;
}
}
}
}
}
v___jp_1336_:
{
lean_object* v___x_1338_; 
v___x_1338_ = lean_nat_add(v_i_1332_, v_step_1335_);
lean_dec(v_i_1332_);
v_b_1331_ = v_a_1337_;
v_i_1332_ = v___x_1338_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__4___redArg___boxed(lean_object* v_workers_1357_, lean_object* v_a_1358_, lean_object* v_targets_1359_, lean_object* v___x_1360_, lean_object* v_range_1361_, lean_object* v_b_1362_, lean_object* v_i_1363_, lean_object* v___y_1364_){
_start:
{
lean_object* v_res_1365_; 
v_res_1365_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__4___redArg(v_workers_1357_, v_a_1358_, v_targets_1359_, v___x_1360_, v_range_1361_, v_b_1362_, v_i_1363_);
lean_dec_ref(v_range_1361_);
lean_dec_ref(v_targets_1359_);
lean_dec(v_a_1358_);
lean_dec(v_workers_1357_);
return v_res_1365_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__5___redArg___lam__0(lean_object* v___x_1366_, lean_object* v___x_1367_, lean_object* v_targets_1368_, lean_object* v___x_1369_, lean_object* v_workers_1370_, lean_object* v_i_1371_, lean_object* v___x_1372_){
_start:
{
lean_object* v___x_1374_; lean_object* v___x_1375_; lean_object* v___x_1376_; lean_object* v___x_1377_; lean_object* v___x_1378_; 
v___x_1374_ = lean_io_wait(v___x_1366_);
lean_dec(v___x_1374_);
v___x_1375_ = lean_mk_empty_array_with_capacity(v___x_1367_);
v___x_1376_ = lean_array_get_size(v_targets_1368_);
lean_inc(v___x_1367_);
v___x_1377_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_1377_, 0, v___x_1367_);
lean_ctor_set(v___x_1377_, 1, v___x_1376_);
lean_ctor_set(v___x_1377_, 2, v___x_1369_);
v___x_1378_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__4___redArg(v_workers_1370_, v_i_1371_, v_targets_1368_, v___x_1372_, v___x_1377_, v___x_1375_, v___x_1367_);
lean_dec_ref_known(v___x_1377_, 3);
if (lean_obj_tag(v___x_1378_) == 0)
{
lean_object* v_a_1379_; lean_object* v___x_1381_; uint8_t v_isShared_1382_; uint8_t v_isSharedCheck_1386_; 
v_a_1379_ = lean_ctor_get(v___x_1378_, 0);
v_isSharedCheck_1386_ = !lean_is_exclusive(v___x_1378_);
if (v_isSharedCheck_1386_ == 0)
{
v___x_1381_ = v___x_1378_;
v_isShared_1382_ = v_isSharedCheck_1386_;
goto v_resetjp_1380_;
}
else
{
lean_inc(v_a_1379_);
lean_dec(v___x_1378_);
v___x_1381_ = lean_box(0);
v_isShared_1382_ = v_isSharedCheck_1386_;
goto v_resetjp_1380_;
}
v_resetjp_1380_:
{
lean_object* v___x_1384_; 
if (v_isShared_1382_ == 0)
{
lean_ctor_set_tag(v___x_1381_, 1);
v___x_1384_ = v___x_1381_;
goto v_reusejp_1383_;
}
else
{
lean_object* v_reuseFailAlloc_1385_; 
v_reuseFailAlloc_1385_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1385_, 0, v_a_1379_);
v___x_1384_ = v_reuseFailAlloc_1385_;
goto v_reusejp_1383_;
}
v_reusejp_1383_:
{
return v___x_1384_;
}
}
}
else
{
lean_object* v_a_1387_; lean_object* v___x_1389_; uint8_t v_isShared_1390_; uint8_t v_isSharedCheck_1394_; 
v_a_1387_ = lean_ctor_get(v___x_1378_, 0);
v_isSharedCheck_1394_ = !lean_is_exclusive(v___x_1378_);
if (v_isSharedCheck_1394_ == 0)
{
v___x_1389_ = v___x_1378_;
v_isShared_1390_ = v_isSharedCheck_1394_;
goto v_resetjp_1388_;
}
else
{
lean_inc(v_a_1387_);
lean_dec(v___x_1378_);
v___x_1389_ = lean_box(0);
v_isShared_1390_ = v_isSharedCheck_1394_;
goto v_resetjp_1388_;
}
v_resetjp_1388_:
{
lean_object* v___x_1392_; 
if (v_isShared_1390_ == 0)
{
lean_ctor_set_tag(v___x_1389_, 0);
v___x_1392_ = v___x_1389_;
goto v_reusejp_1391_;
}
else
{
lean_object* v_reuseFailAlloc_1393_; 
v_reuseFailAlloc_1393_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1393_, 0, v_a_1387_);
v___x_1392_ = v_reuseFailAlloc_1393_;
goto v_reusejp_1391_;
}
v_reusejp_1391_:
{
return v___x_1392_;
}
}
}
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__5___redArg___lam__0___boxed(lean_object* v___x_1395_, lean_object* v___x_1396_, lean_object* v_targets_1397_, lean_object* v___x_1398_, lean_object* v_workers_1399_, lean_object* v_i_1400_, lean_object* v___x_1401_, lean_object* v___y_1402_){
_start:
{
lean_object* v_res_1403_; 
v_res_1403_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__5___redArg___lam__0(v___x_1395_, v___x_1396_, v_targets_1397_, v___x_1398_, v_workers_1399_, v_i_1400_, v___x_1401_);
lean_dec(v_i_1400_);
lean_dec(v_workers_1399_);
lean_dec_ref(v_targets_1397_);
return v_res_1403_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__5_spec__6___redArg(lean_object* v_val_1404_, lean_object* v_targets_1405_, lean_object* v_workers_1406_, lean_object* v___x_1407_, lean_object* v_range_1408_, lean_object* v_b_1409_, lean_object* v_i_1410_){
_start:
{
lean_object* v_stop_1412_; lean_object* v_step_1413_; uint8_t v___x_1414_; 
v_stop_1412_ = lean_ctor_get(v_range_1408_, 1);
v_step_1413_ = lean_ctor_get(v_range_1408_, 2);
v___x_1414_ = lean_nat_dec_lt(v_i_1410_, v_stop_1412_);
if (v___x_1414_ == 0)
{
lean_object* v___x_1415_; 
lean_dec(v_i_1410_);
lean_dec_ref(v___x_1407_);
lean_dec(v_workers_1406_);
lean_dec_ref(v_targets_1405_);
v___x_1415_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_1415_, 0, v_b_1409_);
return v___x_1415_;
}
else
{
lean_object* v___x_1416_; lean_object* v___x_1417_; lean_object* v___x_1418_; lean_object* v___f_1419_; lean_object* v___x_1420_; lean_object* v___x_1421_; lean_object* v___x_1422_; 
v___x_1416_ = lean_unsigned_to_nat(0u);
v___x_1417_ = lean_unsigned_to_nat(1u);
v___x_1418_ = l_IO_Promise_result_x21___redArg(v_val_1404_);
lean_inc_ref(v___x_1407_);
lean_inc(v_i_1410_);
lean_inc(v_workers_1406_);
lean_inc_ref(v_targets_1405_);
v___f_1419_ = lean_alloc_closure((void*)(l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__5___redArg___lam__0___boxed), 8, 7);
lean_closure_set(v___f_1419_, 0, v___x_1418_);
lean_closure_set(v___f_1419_, 1, v___x_1416_);
lean_closure_set(v___f_1419_, 2, v_targets_1405_);
lean_closure_set(v___f_1419_, 3, v___x_1417_);
lean_closure_set(v___f_1419_, 4, v_workers_1406_);
lean_closure_set(v___f_1419_, 5, v_i_1410_);
lean_closure_set(v___f_1419_, 6, v___x_1407_);
v___x_1420_ = lean_io_as_task(v___f_1419_, v___x_1416_);
v___x_1421_ = lean_array_push(v_b_1409_, v___x_1420_);
v___x_1422_ = lean_nat_add(v_i_1410_, v_step_1413_);
lean_dec(v_i_1410_);
v_b_1409_ = v___x_1421_;
v_i_1410_ = v___x_1422_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__5_spec__6___redArg___boxed(lean_object* v_val_1424_, lean_object* v_targets_1425_, lean_object* v_workers_1426_, lean_object* v___x_1427_, lean_object* v_range_1428_, lean_object* v_b_1429_, lean_object* v_i_1430_, lean_object* v___y_1431_){
_start:
{
lean_object* v_res_1432_; 
v_res_1432_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__5_spec__6___redArg(v_val_1424_, v_targets_1425_, v_workers_1426_, v___x_1427_, v_range_1428_, v_b_1429_, v_i_1430_);
lean_dec_ref(v_range_1428_);
lean_dec(v_val_1424_);
return v_res_1432_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__5___redArg(lean_object* v_workers_1433_, lean_object* v_targets_1434_, lean_object* v___x_1435_, lean_object* v_val_1436_, lean_object* v_range_1437_, lean_object* v_b_1438_, lean_object* v_i_1439_){
_start:
{
lean_object* v_stop_1441_; lean_object* v_step_1442_; uint8_t v___x_1443_; 
v_stop_1441_ = lean_ctor_get(v_range_1437_, 1);
v_step_1442_ = lean_ctor_get(v_range_1437_, 2);
v___x_1443_ = lean_nat_dec_lt(v_i_1439_, v_stop_1441_);
if (v___x_1443_ == 0)
{
lean_object* v___x_1444_; 
lean_dec(v_i_1439_);
lean_dec_ref(v___x_1435_);
lean_dec_ref(v_targets_1434_);
lean_dec(v_workers_1433_);
v___x_1444_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_1444_, 0, v_b_1438_);
return v___x_1444_;
}
else
{
lean_object* v___x_1445_; lean_object* v___x_1446_; lean_object* v___x_1447_; lean_object* v___f_1448_; lean_object* v___x_1449_; lean_object* v___x_1450_; lean_object* v___x_1451_; lean_object* v___x_1452_; 
v___x_1445_ = lean_unsigned_to_nat(0u);
v___x_1446_ = lean_unsigned_to_nat(1u);
v___x_1447_ = l_IO_Promise_result_x21___redArg(v_val_1436_);
lean_inc_ref(v___x_1435_);
lean_inc(v_i_1439_);
lean_inc(v_workers_1433_);
lean_inc_ref(v_targets_1434_);
v___f_1448_ = lean_alloc_closure((void*)(l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__5___redArg___lam__0___boxed), 8, 7);
lean_closure_set(v___f_1448_, 0, v___x_1447_);
lean_closure_set(v___f_1448_, 1, v___x_1445_);
lean_closure_set(v___f_1448_, 2, v_targets_1434_);
lean_closure_set(v___f_1448_, 3, v___x_1446_);
lean_closure_set(v___f_1448_, 4, v_workers_1433_);
lean_closure_set(v___f_1448_, 5, v_i_1439_);
lean_closure_set(v___f_1448_, 6, v___x_1435_);
v___x_1449_ = lean_io_as_task(v___f_1448_, v___x_1445_);
v___x_1450_ = lean_array_push(v_b_1438_, v___x_1449_);
v___x_1451_ = lean_nat_add(v_i_1439_, v_step_1442_);
lean_dec(v_i_1439_);
v___x_1452_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__5_spec__6___redArg(v_val_1436_, v_targets_1434_, v_workers_1433_, v___x_1435_, v_range_1437_, v___x_1450_, v___x_1451_);
return v___x_1452_;
}
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__5___redArg___boxed(lean_object* v_workers_1453_, lean_object* v_targets_1454_, lean_object* v___x_1455_, lean_object* v_val_1456_, lean_object* v_range_1457_, lean_object* v_b_1458_, lean_object* v_i_1459_, lean_object* v___y_1460_){
_start:
{
lean_object* v_res_1461_; 
v_res_1461_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__5___redArg(v_workers_1453_, v_targets_1454_, v___x_1455_, v_val_1456_, v_range_1457_, v_b_1458_, v_i_1459_);
lean_dec_ref(v_range_1457_);
lean_dec(v_val_1456_);
return v_res_1461_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__10___redArg(lean_object* v___x_1462_, lean_object* v___y_1463_, lean_object* v___y_1464_, lean_object* v_range_1465_, lean_object* v_b_1466_, lean_object* v_i_1467_){
_start:
{
lean_object* v_stop_1469_; lean_object* v_step_1470_; uint8_t v___x_1471_; 
v_stop_1469_ = lean_ctor_get(v_range_1465_, 1);
v_step_1470_ = lean_ctor_get(v_range_1465_, 2);
v___x_1471_ = lean_nat_dec_lt(v_i_1467_, v_stop_1469_);
if (v___x_1471_ == 0)
{
lean_object* v___x_1472_; 
lean_dec(v_i_1467_);
v___x_1472_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_1472_, 0, v_b_1466_);
return v___x_1472_;
}
else
{
lean_object* v___x_1473_; lean_object* v___x_1474_; lean_object* v___x_1475_; lean_object* v___x_1476_; lean_object* v___x_1477_; lean_object* v___x_1478_; lean_object* v___x_1479_; lean_object* v___x_1480_; lean_object* v___x_1481_; 
v___x_1473_ = lean_unsigned_to_nat(1u);
v___x_1474_ = l_Lean_instInhabitedTheoremVal_default;
v___x_1475_ = lean_nat_sub(v___x_1462_, v___x_1473_);
v___x_1476_ = lean_nat_mul(v_i_1467_, v___x_1475_);
lean_dec(v___x_1475_);
v___x_1477_ = lean_nat_sub(v___y_1463_, v___x_1473_);
v___x_1478_ = lean_nat_div(v___x_1476_, v___x_1477_);
lean_dec(v___x_1477_);
lean_dec(v___x_1476_);
v___x_1479_ = lean_array_get_borrowed(v___x_1474_, v___y_1464_, v___x_1478_);
lean_dec(v___x_1478_);
lean_inc(v___x_1479_);
v___x_1480_ = lean_array_push(v_b_1466_, v___x_1479_);
v___x_1481_ = lean_nat_add(v_i_1467_, v_step_1470_);
lean_dec(v_i_1467_);
v_b_1466_ = v___x_1480_;
v_i_1467_ = v___x_1481_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__10___redArg___boxed(lean_object* v___x_1483_, lean_object* v___y_1484_, lean_object* v___y_1485_, lean_object* v_range_1486_, lean_object* v_b_1487_, lean_object* v_i_1488_, lean_object* v___y_1489_){
_start:
{
lean_object* v_res_1490_; 
v_res_1490_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__10___redArg(v___x_1483_, v___y_1484_, v___y_1485_, v_range_1486_, v_b_1487_, v_i_1488_);
lean_dec_ref(v_range_1486_);
lean_dec_ref(v___y_1485_);
lean_dec(v___y_1484_);
lean_dec(v___x_1483_);
return v_res_1490_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__6(lean_object* v_as_1491_, size_t v_sz_1492_, size_t v_i_1493_, lean_object* v_b_1494_){
_start:
{
uint8_t v___x_1496_; 
v___x_1496_ = lean_usize_dec_lt(v_i_1493_, v_sz_1492_);
if (v___x_1496_ == 0)
{
lean_object* v___x_1497_; 
v___x_1497_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_1497_, 0, v_b_1494_);
return v___x_1497_;
}
else
{
lean_object* v_a_1498_; lean_object* v___x_1499_; 
v_a_1498_ = lean_array_uget_borrowed(v_as_1491_, v_i_1493_);
lean_inc(v_a_1498_);
v___x_1499_ = lean_task_get_own(v_a_1498_);
if (lean_obj_tag(v___x_1499_) == 0)
{
lean_object* v_a_1500_; lean_object* v___x_1502_; uint8_t v_isShared_1503_; uint8_t v_isSharedCheck_1507_; 
lean_dec_ref(v_b_1494_);
v_a_1500_ = lean_ctor_get(v___x_1499_, 0);
v_isSharedCheck_1507_ = !lean_is_exclusive(v___x_1499_);
if (v_isSharedCheck_1507_ == 0)
{
v___x_1502_ = v___x_1499_;
v_isShared_1503_ = v_isSharedCheck_1507_;
goto v_resetjp_1501_;
}
else
{
lean_inc(v_a_1500_);
lean_dec(v___x_1499_);
v___x_1502_ = lean_box(0);
v_isShared_1503_ = v_isSharedCheck_1507_;
goto v_resetjp_1501_;
}
v_resetjp_1501_:
{
lean_object* v___x_1505_; 
if (v_isShared_1503_ == 0)
{
lean_ctor_set_tag(v___x_1502_, 1);
v___x_1505_ = v___x_1502_;
goto v_reusejp_1504_;
}
else
{
lean_object* v_reuseFailAlloc_1506_; 
v_reuseFailAlloc_1506_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1506_, 0, v_a_1500_);
v___x_1505_ = v_reuseFailAlloc_1506_;
goto v_reusejp_1504_;
}
v_reusejp_1504_:
{
return v___x_1505_;
}
}
}
else
{
lean_object* v_a_1508_; lean_object* v___x_1509_; size_t v___x_1510_; size_t v___x_1511_; 
v_a_1508_ = lean_ctor_get(v___x_1499_, 0);
lean_inc(v_a_1508_);
lean_dec_ref_known(v___x_1499_, 1);
v___x_1509_ = l_Array_append___redArg(v_b_1494_, v_a_1508_);
lean_dec(v_a_1508_);
v___x_1510_ = ((size_t)1ULL);
v___x_1511_ = lean_usize_add(v_i_1493_, v___x_1510_);
v_i_1493_ = v___x_1511_;
v_b_1494_ = v___x_1509_;
goto _start;
}
}
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__6___boxed(lean_object* v_as_1513_, lean_object* v_sz_1514_, lean_object* v_i_1515_, lean_object* v_b_1516_, lean_object* v___y_1517_){
_start:
{
size_t v_sz_boxed_1518_; size_t v_i_boxed_1519_; lean_object* v_res_1520_; 
v_sz_boxed_1518_ = lean_unbox_usize(v_sz_1514_);
lean_dec(v_sz_1514_);
v_i_boxed_1519_ = lean_unbox_usize(v_i_1515_);
lean_dec(v_i_1515_);
v_res_1520_ = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__6(v_as_1513_, v_sz_boxed_1518_, v_i_boxed_1519_, v_b_1516_);
lean_dec_ref(v_as_1513_);
return v_res_1520_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__13___redArg(lean_object* v_workers_1521_, lean_object* v_a_1522_, lean_object* v___x_1523_, lean_object* v___x_1524_, lean_object* v_fst_1525_, lean_object* v_snd_1526_, lean_object* v_head_1527_, lean_object* v_head_1528_, lean_object* v_range_1529_, lean_object* v_b_1530_, lean_object* v_i_1531_){
_start:
{
lean_object* v_stop_1533_; lean_object* v_step_1534_; lean_object* v_a_1536_; uint8_t v___x_1539_; 
v_stop_1533_ = lean_ctor_get(v_range_1529_, 1);
v_step_1534_ = lean_ctor_get(v_range_1529_, 2);
v___x_1539_ = lean_nat_dec_lt(v_i_1531_, v_stop_1533_);
if (v___x_1539_ == 0)
{
lean_object* v___x_1540_; 
lean_dec(v_i_1531_);
lean_dec_ref(v_head_1528_);
lean_dec_ref(v_head_1527_);
lean_dec_ref(v_fst_1525_);
lean_dec_ref(v___x_1523_);
lean_dec(v_workers_1521_);
v___x_1540_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_1540_, 0, v_b_1530_);
return v___x_1540_;
}
else
{
lean_object* v___x_1541_; uint8_t v___x_1542_; 
v___x_1541_ = lean_nat_mod(v_i_1531_, v_workers_1521_);
v___x_1542_ = lean_nat_dec_eq(v___x_1541_, v_a_1522_);
lean_dec(v___x_1541_);
if (v___x_1542_ == 0)
{
v_a_1536_ = v_b_1530_;
goto v___jp_1535_;
}
else
{
lean_object* v___x_1543_; 
lean_inc(v_i_1531_);
lean_inc(v_workers_1521_);
lean_inc_ref(v_head_1528_);
lean_inc_ref(v_head_1527_);
lean_inc_ref(v_fst_1525_);
lean_inc_ref(v___x_1523_);
v___x_1543_ = l_elaborateOne(v___x_1523_, v___x_1524_, v_fst_1525_, v_snd_1526_, v_head_1527_, v_head_1528_, v_workers_1521_, v_i_1531_);
if (lean_obj_tag(v___x_1543_) == 0)
{
lean_object* v_a_1544_; lean_object* v___x_1545_; 
v_a_1544_ = lean_ctor_get(v___x_1543_, 0);
lean_inc(v_a_1544_);
lean_dec_ref_known(v___x_1543_, 1);
v___x_1545_ = lean_array_push(v_b_1530_, v_a_1544_);
v_a_1536_ = v___x_1545_;
goto v___jp_1535_;
}
else
{
lean_object* v_a_1546_; lean_object* v___x_1548_; uint8_t v_isShared_1549_; uint8_t v_isSharedCheck_1553_; 
lean_dec(v_i_1531_);
lean_dec_ref(v_b_1530_);
lean_dec_ref(v_head_1528_);
lean_dec_ref(v_head_1527_);
lean_dec_ref(v_fst_1525_);
lean_dec_ref(v___x_1523_);
lean_dec(v_workers_1521_);
v_a_1546_ = lean_ctor_get(v___x_1543_, 0);
v_isSharedCheck_1553_ = !lean_is_exclusive(v___x_1543_);
if (v_isSharedCheck_1553_ == 0)
{
v___x_1548_ = v___x_1543_;
v_isShared_1549_ = v_isSharedCheck_1553_;
goto v_resetjp_1547_;
}
else
{
lean_inc(v_a_1546_);
lean_dec(v___x_1543_);
v___x_1548_ = lean_box(0);
v_isShared_1549_ = v_isSharedCheck_1553_;
goto v_resetjp_1547_;
}
v_resetjp_1547_:
{
lean_object* v___x_1551_; 
if (v_isShared_1549_ == 0)
{
v___x_1551_ = v___x_1548_;
goto v_reusejp_1550_;
}
else
{
lean_object* v_reuseFailAlloc_1552_; 
v_reuseFailAlloc_1552_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1552_, 0, v_a_1546_);
v___x_1551_ = v_reuseFailAlloc_1552_;
goto v_reusejp_1550_;
}
v_reusejp_1550_:
{
return v___x_1551_;
}
}
}
}
}
v___jp_1535_:
{
lean_object* v___x_1537_; 
v___x_1537_ = lean_nat_add(v_i_1531_, v_step_1534_);
lean_dec(v_i_1531_);
v_b_1530_ = v_a_1536_;
v_i_1531_ = v___x_1537_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__13___redArg___boxed(lean_object* v_workers_1554_, lean_object* v_a_1555_, lean_object* v___x_1556_, lean_object* v___x_1557_, lean_object* v_fst_1558_, lean_object* v_snd_1559_, lean_object* v_head_1560_, lean_object* v_head_1561_, lean_object* v_range_1562_, lean_object* v_b_1563_, lean_object* v_i_1564_, lean_object* v___y_1565_){
_start:
{
lean_object* v_res_1566_; 
v_res_1566_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__13___redArg(v_workers_1554_, v_a_1555_, v___x_1556_, v___x_1557_, v_fst_1558_, v_snd_1559_, v_head_1560_, v_head_1561_, v_range_1562_, v_b_1563_, v_i_1564_);
lean_dec_ref(v_range_1562_);
lean_dec_ref(v_snd_1559_);
lean_dec_ref(v___x_1557_);
lean_dec(v_a_1555_);
return v_res_1566_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__14___redArg___lam__0(lean_object* v___x_1567_, lean_object* v___x_1568_, lean_object* v___x_1569_, lean_object* v_workers_1570_, lean_object* v_i_1571_, lean_object* v___x_1572_, lean_object* v___x_1573_, lean_object* v_fst_1574_, lean_object* v_snd_1575_, lean_object* v_head_1576_, lean_object* v_head_1577_){
_start:
{
lean_object* v___x_1579_; lean_object* v___x_1580_; lean_object* v___x_1581_; lean_object* v___x_1582_; lean_object* v___x_1583_; 
v___x_1579_ = lean_io_wait(v___x_1567_);
lean_dec(v___x_1579_);
v___x_1580_ = lean_mk_empty_array_with_capacity(v___x_1568_);
v___x_1581_ = lean_unsigned_to_nat(8u);
lean_inc(v___x_1568_);
v___x_1582_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_1582_, 0, v___x_1568_);
lean_ctor_set(v___x_1582_, 1, v___x_1581_);
lean_ctor_set(v___x_1582_, 2, v___x_1569_);
v___x_1583_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__13___redArg(v_workers_1570_, v_i_1571_, v___x_1572_, v___x_1573_, v_fst_1574_, v_snd_1575_, v_head_1576_, v_head_1577_, v___x_1582_, v___x_1580_, v___x_1568_);
lean_dec_ref_known(v___x_1582_, 3);
if (lean_obj_tag(v___x_1583_) == 0)
{
lean_object* v_a_1584_; lean_object* v___x_1586_; uint8_t v_isShared_1587_; uint8_t v_isSharedCheck_1591_; 
v_a_1584_ = lean_ctor_get(v___x_1583_, 0);
v_isSharedCheck_1591_ = !lean_is_exclusive(v___x_1583_);
if (v_isSharedCheck_1591_ == 0)
{
v___x_1586_ = v___x_1583_;
v_isShared_1587_ = v_isSharedCheck_1591_;
goto v_resetjp_1585_;
}
else
{
lean_inc(v_a_1584_);
lean_dec(v___x_1583_);
v___x_1586_ = lean_box(0);
v_isShared_1587_ = v_isSharedCheck_1591_;
goto v_resetjp_1585_;
}
v_resetjp_1585_:
{
lean_object* v___x_1589_; 
if (v_isShared_1587_ == 0)
{
lean_ctor_set_tag(v___x_1586_, 1);
v___x_1589_ = v___x_1586_;
goto v_reusejp_1588_;
}
else
{
lean_object* v_reuseFailAlloc_1590_; 
v_reuseFailAlloc_1590_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1590_, 0, v_a_1584_);
v___x_1589_ = v_reuseFailAlloc_1590_;
goto v_reusejp_1588_;
}
v_reusejp_1588_:
{
return v___x_1589_;
}
}
}
else
{
lean_object* v_a_1592_; lean_object* v___x_1594_; uint8_t v_isShared_1595_; uint8_t v_isSharedCheck_1599_; 
v_a_1592_ = lean_ctor_get(v___x_1583_, 0);
v_isSharedCheck_1599_ = !lean_is_exclusive(v___x_1583_);
if (v_isSharedCheck_1599_ == 0)
{
v___x_1594_ = v___x_1583_;
v_isShared_1595_ = v_isSharedCheck_1599_;
goto v_resetjp_1593_;
}
else
{
lean_inc(v_a_1592_);
lean_dec(v___x_1583_);
v___x_1594_ = lean_box(0);
v_isShared_1595_ = v_isSharedCheck_1599_;
goto v_resetjp_1593_;
}
v_resetjp_1593_:
{
lean_object* v___x_1597_; 
if (v_isShared_1595_ == 0)
{
lean_ctor_set_tag(v___x_1594_, 0);
v___x_1597_ = v___x_1594_;
goto v_reusejp_1596_;
}
else
{
lean_object* v_reuseFailAlloc_1598_; 
v_reuseFailAlloc_1598_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1598_, 0, v_a_1592_);
v___x_1597_ = v_reuseFailAlloc_1598_;
goto v_reusejp_1596_;
}
v_reusejp_1596_:
{
return v___x_1597_;
}
}
}
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__14___redArg___lam__0___boxed(lean_object* v___x_1600_, lean_object* v___x_1601_, lean_object* v___x_1602_, lean_object* v_workers_1603_, lean_object* v_i_1604_, lean_object* v___x_1605_, lean_object* v___x_1606_, lean_object* v_fst_1607_, lean_object* v_snd_1608_, lean_object* v_head_1609_, lean_object* v_head_1610_, lean_object* v___y_1611_){
_start:
{
lean_object* v_res_1612_; 
v_res_1612_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__14___redArg___lam__0(v___x_1600_, v___x_1601_, v___x_1602_, v_workers_1603_, v_i_1604_, v___x_1605_, v___x_1606_, v_fst_1607_, v_snd_1608_, v_head_1609_, v_head_1610_);
lean_dec_ref(v_snd_1608_);
lean_dec_ref(v___x_1606_);
lean_dec(v_i_1604_);
return v_res_1612_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__14_spec__18___redArg(lean_object* v_val_1613_, lean_object* v_workers_1614_, lean_object* v___x_1615_, lean_object* v___x_1616_, lean_object* v_fst_1617_, lean_object* v_snd_1618_, lean_object* v_head_1619_, lean_object* v_head_1620_, lean_object* v_range_1621_, lean_object* v_b_1622_, lean_object* v_i_1623_){
_start:
{
lean_object* v_stop_1625_; lean_object* v_step_1626_; uint8_t v___x_1627_; 
v_stop_1625_ = lean_ctor_get(v_range_1621_, 1);
v_step_1626_ = lean_ctor_get(v_range_1621_, 2);
v___x_1627_ = lean_nat_dec_lt(v_i_1623_, v_stop_1625_);
if (v___x_1627_ == 0)
{
lean_object* v___x_1628_; 
lean_dec(v_i_1623_);
lean_dec_ref(v_head_1620_);
lean_dec_ref(v_head_1619_);
lean_dec_ref(v_snd_1618_);
lean_dec_ref(v_fst_1617_);
lean_dec_ref(v___x_1616_);
lean_dec_ref(v___x_1615_);
lean_dec(v_workers_1614_);
v___x_1628_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_1628_, 0, v_b_1622_);
return v___x_1628_;
}
else
{
lean_object* v___x_1629_; lean_object* v___x_1630_; lean_object* v___x_1631_; lean_object* v___f_1632_; lean_object* v___x_1633_; lean_object* v___x_1634_; lean_object* v___x_1635_; 
v___x_1629_ = lean_unsigned_to_nat(0u);
v___x_1630_ = lean_unsigned_to_nat(1u);
v___x_1631_ = l_IO_Promise_result_x21___redArg(v_val_1613_);
lean_inc_ref(v_head_1620_);
lean_inc_ref(v_head_1619_);
lean_inc_ref(v_snd_1618_);
lean_inc_ref(v_fst_1617_);
lean_inc_ref(v___x_1616_);
lean_inc_ref(v___x_1615_);
lean_inc(v_i_1623_);
lean_inc(v_workers_1614_);
v___f_1632_ = lean_alloc_closure((void*)(l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__14___redArg___lam__0___boxed), 12, 11);
lean_closure_set(v___f_1632_, 0, v___x_1631_);
lean_closure_set(v___f_1632_, 1, v___x_1629_);
lean_closure_set(v___f_1632_, 2, v___x_1630_);
lean_closure_set(v___f_1632_, 3, v_workers_1614_);
lean_closure_set(v___f_1632_, 4, v_i_1623_);
lean_closure_set(v___f_1632_, 5, v___x_1615_);
lean_closure_set(v___f_1632_, 6, v___x_1616_);
lean_closure_set(v___f_1632_, 7, v_fst_1617_);
lean_closure_set(v___f_1632_, 8, v_snd_1618_);
lean_closure_set(v___f_1632_, 9, v_head_1619_);
lean_closure_set(v___f_1632_, 10, v_head_1620_);
v___x_1633_ = lean_io_as_task(v___f_1632_, v___x_1629_);
v___x_1634_ = lean_array_push(v_b_1622_, v___x_1633_);
v___x_1635_ = lean_nat_add(v_i_1623_, v_step_1626_);
lean_dec(v_i_1623_);
v_b_1622_ = v___x_1634_;
v_i_1623_ = v___x_1635_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__14_spec__18___redArg___boxed(lean_object* v_val_1637_, lean_object* v_workers_1638_, lean_object* v___x_1639_, lean_object* v___x_1640_, lean_object* v_fst_1641_, lean_object* v_snd_1642_, lean_object* v_head_1643_, lean_object* v_head_1644_, lean_object* v_range_1645_, lean_object* v_b_1646_, lean_object* v_i_1647_, lean_object* v___y_1648_){
_start:
{
lean_object* v_res_1649_; 
v_res_1649_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__14_spec__18___redArg(v_val_1637_, v_workers_1638_, v___x_1639_, v___x_1640_, v_fst_1641_, v_snd_1642_, v_head_1643_, v_head_1644_, v_range_1645_, v_b_1646_, v_i_1647_);
lean_dec_ref(v_range_1645_);
lean_dec(v_val_1637_);
return v_res_1649_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__14___redArg(lean_object* v_workers_1650_, lean_object* v___x_1651_, lean_object* v___x_1652_, lean_object* v_fst_1653_, lean_object* v_snd_1654_, lean_object* v_head_1655_, lean_object* v_head_1656_, lean_object* v_val_1657_, lean_object* v_range_1658_, lean_object* v_b_1659_, lean_object* v_i_1660_){
_start:
{
lean_object* v_stop_1662_; lean_object* v_step_1663_; uint8_t v___x_1664_; 
v_stop_1662_ = lean_ctor_get(v_range_1658_, 1);
v_step_1663_ = lean_ctor_get(v_range_1658_, 2);
v___x_1664_ = lean_nat_dec_lt(v_i_1660_, v_stop_1662_);
if (v___x_1664_ == 0)
{
lean_object* v___x_1665_; 
lean_dec(v_i_1660_);
lean_dec_ref(v_head_1656_);
lean_dec_ref(v_head_1655_);
lean_dec_ref(v_snd_1654_);
lean_dec_ref(v_fst_1653_);
lean_dec_ref(v___x_1652_);
lean_dec_ref(v___x_1651_);
lean_dec(v_workers_1650_);
v___x_1665_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_1665_, 0, v_b_1659_);
return v___x_1665_;
}
else
{
lean_object* v___x_1666_; lean_object* v___x_1667_; lean_object* v___x_1668_; lean_object* v___f_1669_; lean_object* v___x_1670_; lean_object* v___x_1671_; lean_object* v___x_1672_; lean_object* v___x_1673_; 
v___x_1666_ = lean_unsigned_to_nat(0u);
v___x_1667_ = lean_unsigned_to_nat(1u);
v___x_1668_ = l_IO_Promise_result_x21___redArg(v_val_1657_);
lean_inc_ref(v_head_1656_);
lean_inc_ref(v_head_1655_);
lean_inc_ref(v_snd_1654_);
lean_inc_ref(v_fst_1653_);
lean_inc_ref(v___x_1652_);
lean_inc_ref(v___x_1651_);
lean_inc(v_i_1660_);
lean_inc(v_workers_1650_);
v___f_1669_ = lean_alloc_closure((void*)(l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__14___redArg___lam__0___boxed), 12, 11);
lean_closure_set(v___f_1669_, 0, v___x_1668_);
lean_closure_set(v___f_1669_, 1, v___x_1666_);
lean_closure_set(v___f_1669_, 2, v___x_1667_);
lean_closure_set(v___f_1669_, 3, v_workers_1650_);
lean_closure_set(v___f_1669_, 4, v_i_1660_);
lean_closure_set(v___f_1669_, 5, v___x_1651_);
lean_closure_set(v___f_1669_, 6, v___x_1652_);
lean_closure_set(v___f_1669_, 7, v_fst_1653_);
lean_closure_set(v___f_1669_, 8, v_snd_1654_);
lean_closure_set(v___f_1669_, 9, v_head_1655_);
lean_closure_set(v___f_1669_, 10, v_head_1656_);
v___x_1670_ = lean_io_as_task(v___f_1669_, v___x_1666_);
v___x_1671_ = lean_array_push(v_b_1659_, v___x_1670_);
v___x_1672_ = lean_nat_add(v_i_1660_, v_step_1663_);
lean_dec(v_i_1660_);
v___x_1673_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__14_spec__18___redArg(v_val_1657_, v_workers_1650_, v___x_1651_, v___x_1652_, v_fst_1653_, v_snd_1654_, v_head_1655_, v_head_1656_, v_range_1658_, v___x_1671_, v___x_1672_);
return v___x_1673_;
}
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__14___redArg___boxed(lean_object* v_workers_1674_, lean_object* v___x_1675_, lean_object* v___x_1676_, lean_object* v_fst_1677_, lean_object* v_snd_1678_, lean_object* v_head_1679_, lean_object* v_head_1680_, lean_object* v_val_1681_, lean_object* v_range_1682_, lean_object* v_b_1683_, lean_object* v_i_1684_, lean_object* v___y_1685_){
_start:
{
lean_object* v_res_1686_; 
v_res_1686_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__14___redArg(v_workers_1674_, v___x_1675_, v___x_1676_, v_fst_1677_, v_snd_1678_, v_head_1679_, v_head_1680_, v_val_1681_, v_range_1682_, v_b_1683_, v_i_1684_);
lean_dec_ref(v_range_1682_);
lean_dec(v_val_1681_);
return v_res_1686_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__11(uint8_t v___x_1691_, lean_object* v_as_1692_, size_t v_sz_1693_, size_t v_i_1694_, lean_object* v_b_1695_){
_start:
{
uint8_t v___x_1696_; 
v___x_1696_ = lean_usize_dec_lt(v_i_1694_, v_sz_1693_);
if (v___x_1696_ == 0)
{
lean_inc_ref(v_b_1695_);
return v_b_1695_;
}
else
{
lean_object* v_a_1697_; lean_object* v_toConstantVal_1698_; lean_object* v_name_1699_; lean_object* v___x_1700_; lean_object* v___x_1701_; lean_object* v___x_1702_; uint8_t v___x_1703_; 
v_a_1697_ = lean_array_uget_borrowed(v_as_1692_, v_i_1694_);
v_toConstantVal_1698_ = lean_ctor_get(v_a_1697_, 0);
v_name_1699_ = lean_ctor_get(v_toConstantVal_1698_, 0);
v___x_1700_ = ((lean_object*)(l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__11___closed__0));
v___x_1701_ = lean_box(0);
lean_inc(v_name_1699_);
v___x_1702_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v_name_1699_, v___x_1691_);
v___x_1703_ = lean_string_dec_eq(v___x_1702_, v___x_1700_);
lean_dec_ref(v___x_1702_);
if (v___x_1703_ == 0)
{
lean_object* v___x_1704_; size_t v___x_1705_; size_t v___x_1706_; 
v___x_1704_ = ((lean_object*)(l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__11___closed__1));
v___x_1705_ = ((size_t)1ULL);
v___x_1706_ = lean_usize_add(v_i_1694_, v___x_1705_);
v_i_1694_ = v___x_1706_;
v_b_1695_ = v___x_1704_;
goto _start;
}
else
{
lean_object* v___x_1708_; lean_object* v___x_1709_; lean_object* v___x_1710_; 
lean_inc(v_a_1697_);
v___x_1708_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_1708_, 0, v_a_1697_);
v___x_1709_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_1709_, 0, v___x_1708_);
v___x_1710_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1710_, 0, v___x_1709_);
lean_ctor_set(v___x_1710_, 1, v___x_1701_);
return v___x_1710_;
}
}
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__11___boxed(lean_object* v___x_1711_, lean_object* v_as_1712_, lean_object* v_sz_1713_, lean_object* v_i_1714_, lean_object* v_b_1715_){
_start:
{
uint8_t v___x_19402__boxed_1716_; size_t v_sz_boxed_1717_; size_t v_i_boxed_1718_; lean_object* v_res_1719_; 
v___x_19402__boxed_1716_ = lean_unbox(v___x_1711_);
v_sz_boxed_1717_ = lean_unbox_usize(v_sz_1713_);
lean_dec(v_sz_1713_);
v_i_boxed_1718_ = lean_unbox_usize(v_i_1714_);
lean_dec(v_i_1714_);
v_res_1719_ = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__11(v___x_19402__boxed_1716_, v_as_1712_, v_sz_boxed_1717_, v_i_boxed_1718_, v_b_1715_);
lean_dec_ref(v_b_1715_);
lean_dec_ref(v_as_1712_);
return v_res_1719_;
}
}
LEAN_EXPORT uint8_t l_List_any___at___00main_spec__0(lean_object* v_head_1720_, lean_object* v_head_1721_, lean_object* v_x_1722_){
_start:
{
if (lean_obj_tag(v_x_1722_) == 0)
{
uint8_t v___x_1723_; 
v___x_1723_ = 0;
return v___x_1723_;
}
else
{
lean_object* v_head_1724_; lean_object* v_tail_1725_; uint8_t v___y_1727_; lean_object* v___x_1729_; lean_object* v___x_1730_; uint8_t v___x_1731_; 
v_head_1724_ = lean_ctor_get(v_x_1722_, 0);
v_tail_1725_ = lean_ctor_get(v_x_1722_, 1);
v___x_1729_ = lean_string_utf8_byte_size(v_head_1720_);
v___x_1730_ = lean_string_utf8_byte_size(v_head_1724_);
v___x_1731_ = lean_nat_dec_le(v___x_1730_, v___x_1729_);
if (v___x_1731_ == 0)
{
lean_object* v___x_1732_; uint8_t v___x_1733_; 
v___x_1732_ = ((lean_object*)(l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__3___closed__2));
v___x_1733_ = lean_string_dec_eq(v_head_1721_, v___x_1732_);
v___y_1727_ = v___x_1733_;
goto v___jp_1726_;
}
else
{
lean_object* v___x_1734_; lean_object* v___x_1735_; uint8_t v___x_1736_; 
v___x_1734_ = lean_unsigned_to_nat(0u);
v___x_1735_ = lean_nat_sub(v___x_1729_, v___x_1730_);
v___x_1736_ = lean_string_memcmp(v_head_1720_, v_head_1724_, v___x_1735_, v___x_1734_, v___x_1730_);
lean_dec(v___x_1735_);
v___y_1727_ = v___x_1736_;
goto v___jp_1726_;
}
v___jp_1726_:
{
if (v___y_1727_ == 0)
{
v_x_1722_ = v_tail_1725_;
goto _start;
}
else
{
return v___y_1727_;
}
}
}
}
}
LEAN_EXPORT lean_object* l_List_any___at___00main_spec__0___boxed(lean_object* v_head_1737_, lean_object* v_head_1738_, lean_object* v_x_1739_){
_start:
{
uint8_t v_res_1740_; lean_object* v_r_1741_; 
v_res_1740_ = l_List_any___at___00main_spec__0(v_head_1737_, v_head_1738_, v_x_1739_);
lean_dec(v_x_1739_);
lean_dec_ref(v_head_1738_);
lean_dec_ref(v_head_1737_);
v_r_1741_ = lean_box(v_res_1740_);
return v_r_1741_;
}
}
static lean_object* _init_l_main___boxed__const__1(void){
_start:
{
uint32_t v___x_1779_; lean_object* v___x_1780_; 
v___x_1779_ = 0;
v___x_1780_ = lean_box_uint32(v___x_1779_);
return v___x_1780_;
}
}
LEAN_EXPORT lean_object* _lean_main(lean_object* v_args_1781_){
_start:
{
if (lean_obj_tag(v_args_1781_) == 1)
{
lean_object* v_tail_1789_; 
v_tail_1789_ = lean_ctor_get(v_args_1781_, 1);
lean_inc(v_tail_1789_);
if (lean_obj_tag(v_tail_1789_) == 1)
{
lean_object* v_tail_1790_; 
v_tail_1790_ = lean_ctor_get(v_tail_1789_, 1);
lean_inc(v_tail_1790_);
if (lean_obj_tag(v_tail_1790_) == 1)
{
lean_object* v_tail_1791_; 
v_tail_1791_ = lean_ctor_get(v_tail_1790_, 1);
lean_inc(v_tail_1791_);
if (lean_obj_tag(v_tail_1791_) == 1)
{
lean_object* v_tail_1792_; 
v_tail_1792_ = lean_ctor_get(v_tail_1791_, 1);
lean_inc(v_tail_1792_);
if (lean_obj_tag(v_tail_1792_) == 0)
{
lean_object* v_head_1793_; lean_object* v___x_1795_; uint8_t v_isShared_1796_; uint8_t v_isSharedCheck_2194_; 
v_head_1793_ = lean_ctor_get(v_args_1781_, 0);
v_isSharedCheck_2194_ = !lean_is_exclusive(v_args_1781_);
if (v_isSharedCheck_2194_ == 0)
{
lean_object* v_unused_2195_; 
v_unused_2195_ = lean_ctor_get(v_args_1781_, 1);
lean_dec(v_unused_2195_);
v___x_1795_ = v_args_1781_;
v_isShared_1796_ = v_isSharedCheck_2194_;
goto v_resetjp_1794_;
}
else
{
lean_inc(v_head_1793_);
lean_dec(v_args_1781_);
v___x_1795_ = lean_box(0);
v_isShared_1796_ = v_isSharedCheck_2194_;
goto v_resetjp_1794_;
}
v_resetjp_1794_:
{
lean_object* v_head_1797_; lean_object* v___x_1799_; uint8_t v_isShared_1800_; uint8_t v_isSharedCheck_2192_; 
v_head_1797_ = lean_ctor_get(v_tail_1789_, 0);
v_isSharedCheck_2192_ = !lean_is_exclusive(v_tail_1789_);
if (v_isSharedCheck_2192_ == 0)
{
lean_object* v_unused_2193_; 
v_unused_2193_ = lean_ctor_get(v_tail_1789_, 1);
lean_dec(v_unused_2193_);
v___x_1799_ = v_tail_1789_;
v_isShared_1800_ = v_isSharedCheck_2192_;
goto v_resetjp_1798_;
}
else
{
lean_inc(v_head_1797_);
lean_dec(v_tail_1789_);
v___x_1799_ = lean_box(0);
v_isShared_1800_ = v_isSharedCheck_2192_;
goto v_resetjp_1798_;
}
v_resetjp_1798_:
{
lean_object* v_head_1801_; lean_object* v___x_1803_; uint8_t v_isShared_1804_; uint8_t v_isSharedCheck_2190_; 
v_head_1801_ = lean_ctor_get(v_tail_1790_, 0);
v_isSharedCheck_2190_ = !lean_is_exclusive(v_tail_1790_);
if (v_isSharedCheck_2190_ == 0)
{
lean_object* v_unused_2191_; 
v_unused_2191_ = lean_ctor_get(v_tail_1790_, 1);
lean_dec(v_unused_2191_);
v___x_1803_ = v_tail_1790_;
v_isShared_1804_ = v_isSharedCheck_2190_;
goto v_resetjp_1802_;
}
else
{
lean_inc(v_head_1801_);
lean_dec(v_tail_1790_);
v___x_1803_ = lean_box(0);
v_isShared_1804_ = v_isSharedCheck_2190_;
goto v_resetjp_1802_;
}
v_resetjp_1802_:
{
lean_object* v_head_1805_; lean_object* v___x_1807_; uint8_t v_isShared_1808_; uint8_t v_isSharedCheck_2188_; 
v_head_1805_ = lean_ctor_get(v_tail_1791_, 0);
v_isSharedCheck_2188_ = !lean_is_exclusive(v_tail_1791_);
if (v_isSharedCheck_2188_ == 0)
{
lean_object* v_unused_2189_; 
v_unused_2189_ = lean_ctor_get(v_tail_1791_, 1);
lean_dec(v_unused_2189_);
v___x_1807_ = v_tail_1791_;
v_isShared_1808_ = v_isSharedCheck_2188_;
goto v_resetjp_1806_;
}
else
{
lean_inc(v_head_1805_);
lean_dec(v_tail_1791_);
v___x_1807_ = lean_box(0);
v_isShared_1808_ = v_isSharedCheck_2188_;
goto v_resetjp_1806_;
}
v_resetjp_1806_:
{
lean_object* v___x_1809_; lean_object* v___x_1810_; lean_object* v___x_1811_; lean_object* v_workers_1812_; size_t v___y_1814_; lean_object* v___y_1815_; lean_object* v___y_1816_; lean_object* v___y_1817_; lean_object* v___y_1818_; size_t v___y_1830_; lean_object* v___y_1831_; lean_object* v___y_1832_; lean_object* v___y_1833_; lean_object* v___y_1834_; lean_object* v___y_1835_; lean_object* v___y_1836_; lean_object* v___y_1837_; size_t v___y_1840_; lean_object* v___y_1841_; lean_object* v___y_1842_; lean_object* v___y_1843_; lean_object* v___y_1844_; lean_object* v___y_1845_; lean_object* v___y_1846_; lean_object* v___y_1847_; lean_object* v___x_1849_; lean_object* v___x_1850_; lean_object* v___x_1851_; lean_object* v___x_1852_; uint8_t v___x_1853_; lean_object* v___y_1855_; lean_object* v___y_1856_; uint32_t v___y_1857_; lean_object* v_targets_1858_; lean_object* v___y_1946_; lean_object* v___y_1947_; lean_object* v___y_1948_; lean_object* v___y_1949_; uint32_t v___y_1950_; uint8_t v___y_1951_; 
v___x_1809_ = lean_unsigned_to_nat(0u);
v___x_1810_ = lean_string_utf8_byte_size(v_head_1805_);
v___x_1811_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_1811_, 0, v_head_1805_);
lean_ctor_set(v___x_1811_, 1, v___x_1809_);
lean_ctor_set(v___x_1811_, 2, v___x_1810_);
v_workers_1812_ = l_String_Slice_toNat_x21(v___x_1811_);
lean_dec_ref_known(v___x_1811_, 3);
v___x_1849_ = lean_unsigned_to_nat(1u);
v___x_1850_ = lean_unsigned_to_nat(8u);
v___x_1851_ = lean_box(0);
v___x_1852_ = ((lean_object*)(l_main___closed__5));
v___x_1853_ = l_List_elem___at___00Lean_Meta_Grind_Arith_Cutsat_checkElimEqs_spec__0(v_workers_1812_, v___x_1852_);
if (v___x_1853_ == 0)
{
lean_object* v___x_1960_; lean_object* v___x_1961_; 
lean_dec(v_workers_1812_);
lean_del_object(v___x_1807_);
lean_del_object(v___x_1803_);
lean_dec(v_head_1801_);
lean_del_object(v___x_1799_);
lean_dec(v_head_1797_);
lean_del_object(v___x_1795_);
lean_dec(v_head_1793_);
v___x_1960_ = ((lean_object*)(l_main___closed__10));
v___x_1961_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_1961_, 0, v___x_1960_);
return v___x_1961_;
}
else
{
lean_object* v___x_1962_; lean_object* v___x_1963_; 
v___x_1962_ = ((lean_object*)(l_main___closed__11));
v___x_1963_ = l_Lean_findSysroot(v___x_1962_);
if (lean_obj_tag(v___x_1963_) == 0)
{
lean_object* v_a_1964_; lean_object* v___x_1966_; uint8_t v_isShared_1967_; uint8_t v_isSharedCheck_2179_; 
v_a_1964_ = lean_ctor_get(v___x_1963_, 0);
v_isSharedCheck_2179_ = !lean_is_exclusive(v___x_1963_);
if (v_isSharedCheck_2179_ == 0)
{
v___x_1966_ = v___x_1963_;
v_isShared_1967_ = v_isSharedCheck_2179_;
goto v_resetjp_1965_;
}
else
{
lean_inc(v_a_1964_);
lean_dec(v___x_1963_);
v___x_1966_ = lean_box(0);
v_isShared_1967_ = v_isSharedCheck_2179_;
goto v_resetjp_1965_;
}
v_resetjp_1965_:
{
lean_object* v___x_1968_; 
v___x_1968_ = l_Lean_initSearchPath(v_a_1964_, v___x_1851_);
if (lean_obj_tag(v___x_1968_) == 0)
{
lean_object* v___x_1970_; uint8_t v_isShared_1971_; uint8_t v_isSharedCheck_2169_; 
v_isSharedCheck_2169_ = !lean_is_exclusive(v___x_1968_);
if (v_isSharedCheck_2169_ == 0)
{
lean_object* v_unused_2170_; 
v_unused_2170_ = lean_ctor_get(v___x_1968_, 0);
lean_dec(v_unused_2170_);
v___x_1970_ = v___x_1968_;
v_isShared_1971_ = v_isSharedCheck_2169_;
goto v_resetjp_1969_;
}
else
{
lean_dec(v___x_1968_);
v___x_1970_ = lean_box(0);
v_isShared_1971_ = v_isSharedCheck_2169_;
goto v_resetjp_1969_;
}
v_resetjp_1969_:
{
lean_object* v___x_1972_; lean_object* v___x_1973_; lean_object* v___x_1974_; uint8_t v___x_1975_; lean_object* v___y_1977_; lean_object* v___y_1978_; lean_object* v___y_1979_; lean_object* v___y_1980_; uint32_t v___y_1981_; lean_object* v___y_1982_; lean_object* v___y_1983_; lean_object* v___y_2001_; lean_object* v___y_2002_; lean_object* v___y_2003_; uint32_t v___y_2004_; lean_object* v___y_2005_; lean_object* v___y_2019_; lean_object* v___y_2020_; lean_object* v___y_2021_; lean_object* v___y_2022_; lean_object* v___y_2023_; uint32_t v___y_2024_; lean_object* v___y_2025_; lean_object* v___y_2026_; lean_object* v___y_2029_; lean_object* v___y_2030_; lean_object* v___y_2031_; lean_object* v___y_2032_; lean_object* v___y_2033_; lean_object* v___y_2034_; uint32_t v___y_2035_; lean_object* v___y_2036_; uint8_t v___y_2039_; 
v___x_1972_ = lean_enable_initializer_execution();
lean_inc(v_head_1797_);
v___x_1973_ = l_String_toName(v_head_1797_);
v___x_1974_ = ((lean_object*)(l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__3___closed__2));
v___x_1975_ = lean_string_dec_eq(v_head_1793_, v___x_1974_);
if (v___x_1975_ == 0)
{
lean_object* v___x_2096_; uint8_t v___x_2097_; 
lean_dec(v_head_1801_);
v___x_2096_ = ((lean_object*)(l_main___closed__22));
v___x_2097_ = lean_string_dec_eq(v_head_1793_, v___x_2096_);
if (v___x_2097_ == 0)
{
lean_object* v___x_2098_; uint8_t v___x_2099_; 
v___x_2098_ = ((lean_object*)(l_main___closed__6));
v___x_2099_ = lean_string_dec_eq(v_head_1793_, v___x_2098_);
v___y_2039_ = v___x_2099_;
goto v___jp_2038_;
}
else
{
v___y_2039_ = v___x_1853_;
goto v___jp_2038_;
}
}
else
{
lean_object* v___x_2100_; 
lean_del_object(v___x_1970_);
lean_del_object(v___x_1966_);
lean_del_object(v___x_1807_);
lean_del_object(v___x_1803_);
lean_del_object(v___x_1799_);
lean_del_object(v___x_1795_);
lean_dec(v_head_1793_);
v___x_2100_ = l_IO_FS_readFile(v_head_1801_);
if (lean_obj_tag(v___x_2100_) == 0)
{
lean_object* v_a_2101_; lean_object* v___x_2102_; lean_object* v___x_2103_; lean_object* v___x_2104_; 
v_a_2101_ = lean_ctor_get(v___x_2100_, 0);
lean_inc(v_a_2101_);
lean_dec_ref_known(v___x_2100_, 1);
v___x_2102_ = lean_string_utf8_byte_size(v_a_2101_);
lean_inc(v_head_1801_);
v___x_2103_ = l_Lean_Parser_mkInputContext___redArg(v_a_2101_, v_head_1801_, v___x_1853_, v___x_2102_);
lean_inc_ref(v___x_2103_);
v___x_2104_ = l_Lean_Parser_parseHeader(v___x_2103_);
if (lean_obj_tag(v___x_2104_) == 0)
{
lean_object* v_a_2105_; lean_object* v_snd_2106_; lean_object* v_fst_2107_; lean_object* v_fst_2108_; lean_object* v_snd_2109_; lean_object* v___x_2110_; lean_object* v___x_2111_; uint32_t v___x_2112_; lean_object* v___x_2113_; uint8_t v___x_2114_; uint8_t v___x_2115_; lean_object* v___x_2116_; lean_object* v___x_2117_; 
v_a_2105_ = lean_ctor_get(v___x_2104_, 0);
lean_inc(v_a_2105_);
lean_dec_ref_known(v___x_2104_, 1);
v_snd_2106_ = lean_ctor_get(v_a_2105_, 1);
lean_inc(v_snd_2106_);
v_fst_2107_ = lean_ctor_get(v_a_2105_, 0);
lean_inc(v_fst_2107_);
lean_dec(v_a_2105_);
v_fst_2108_ = lean_ctor_get(v_snd_2106_, 0);
lean_inc(v_fst_2108_);
v_snd_2109_ = lean_ctor_get(v_snd_2106_, 1);
lean_inc(v_snd_2109_);
lean_dec(v_snd_2106_);
v___x_2110_ = l_Lean_Elab_HeaderSyntax_imports(v_fst_2107_, v___x_1853_);
v___x_2111_ = l_Lean_Options_empty;
v___x_2112_ = 0;
v___x_2113_ = ((lean_object*)(l_main___closed__16));
v___x_2114_ = 0;
v___x_2115_ = 2;
v___x_2116_ = lean_box(1);
v___x_2117_ = l_Lean_importModules(v___x_2110_, v___x_2111_, v___x_2112_, v___x_2113_, v___x_2114_, v___x_1853_, v___x_2115_, v___x_2116_);
if (lean_obj_tag(v___x_2117_) == 0)
{
lean_object* v_a_2118_; lean_object* v___x_2119_; lean_object* v___x_2120_; lean_object* v___x_2121_; lean_object* v___x_2122_; 
v_a_2118_ = lean_ctor_get(v___x_2117_, 0);
lean_inc(v_a_2118_);
lean_dec_ref_known(v___x_2117_, 1);
v___x_2119_ = lean_io_promise_new();
v___x_2120_ = l_Lean_Environment_setMainModule(v_a_2118_, v___x_1973_);
lean_inc(v_workers_1812_);
v___x_2121_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_2121_, 0, v___x_1809_);
lean_ctor_set(v___x_2121_, 1, v_workers_1812_);
lean_ctor_set(v___x_2121_, 2, v___x_1849_);
v___x_2122_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__14___redArg(v_workers_1812_, v___x_2120_, v___x_2103_, v_fst_2108_, v_snd_2109_, v_head_1801_, v_head_1797_, v___x_2119_, v___x_2121_, v___x_2113_, v___x_1809_);
lean_dec_ref_known(v___x_2121_, 3);
if (lean_obj_tag(v___x_2122_) == 0)
{
lean_object* v_a_2123_; lean_object* v___x_2124_; lean_object* v___x_2125_; size_t v_sz_2126_; size_t v___x_2127_; lean_object* v___x_2128_; 
v_a_2123_ = lean_ctor_get(v___x_2122_, 0);
lean_inc(v_a_2123_);
lean_dec_ref_known(v___x_2122_, 1);
v___x_2124_ = lean_box(0);
v___x_2125_ = lean_io_promise_resolve(v___x_2124_, v___x_2119_);
lean_dec(v___x_2119_);
v_sz_2126_ = lean_array_size(v_a_2123_);
v___x_2127_ = ((size_t)0ULL);
v___x_2128_ = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__16(v_a_2123_, v_sz_2126_, v___x_2127_, v___x_2124_);
lean_dec(v_a_2123_);
if (lean_obj_tag(v___x_2128_) == 0)
{
lean_dec_ref_known(v___x_2128_, 1);
goto v___jp_1786_;
}
else
{
lean_object* v_a_2129_; lean_object* v___x_2131_; uint8_t v_isShared_2132_; uint8_t v_isSharedCheck_2136_; 
v_a_2129_ = lean_ctor_get(v___x_2128_, 0);
v_isSharedCheck_2136_ = !lean_is_exclusive(v___x_2128_);
if (v_isSharedCheck_2136_ == 0)
{
v___x_2131_ = v___x_2128_;
v_isShared_2132_ = v_isSharedCheck_2136_;
goto v_resetjp_2130_;
}
else
{
lean_inc(v_a_2129_);
lean_dec(v___x_2128_);
v___x_2131_ = lean_box(0);
v_isShared_2132_ = v_isSharedCheck_2136_;
goto v_resetjp_2130_;
}
v_resetjp_2130_:
{
lean_object* v___x_2134_; 
if (v_isShared_2132_ == 0)
{
v___x_2134_ = v___x_2131_;
goto v_reusejp_2133_;
}
else
{
lean_object* v_reuseFailAlloc_2135_; 
v_reuseFailAlloc_2135_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2135_, 0, v_a_2129_);
v___x_2134_ = v_reuseFailAlloc_2135_;
goto v_reusejp_2133_;
}
v_reusejp_2133_:
{
return v___x_2134_;
}
}
}
}
else
{
lean_object* v_a_2137_; lean_object* v___x_2139_; uint8_t v_isShared_2140_; uint8_t v_isSharedCheck_2144_; 
lean_dec(v___x_2119_);
v_a_2137_ = lean_ctor_get(v___x_2122_, 0);
v_isSharedCheck_2144_ = !lean_is_exclusive(v___x_2122_);
if (v_isSharedCheck_2144_ == 0)
{
v___x_2139_ = v___x_2122_;
v_isShared_2140_ = v_isSharedCheck_2144_;
goto v_resetjp_2138_;
}
else
{
lean_inc(v_a_2137_);
lean_dec(v___x_2122_);
v___x_2139_ = lean_box(0);
v_isShared_2140_ = v_isSharedCheck_2144_;
goto v_resetjp_2138_;
}
v_resetjp_2138_:
{
lean_object* v___x_2142_; 
if (v_isShared_2140_ == 0)
{
v___x_2142_ = v___x_2139_;
goto v_reusejp_2141_;
}
else
{
lean_object* v_reuseFailAlloc_2143_; 
v_reuseFailAlloc_2143_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2143_, 0, v_a_2137_);
v___x_2142_ = v_reuseFailAlloc_2143_;
goto v_reusejp_2141_;
}
v_reusejp_2141_:
{
return v___x_2142_;
}
}
}
}
else
{
lean_object* v_a_2145_; lean_object* v___x_2147_; uint8_t v_isShared_2148_; uint8_t v_isSharedCheck_2152_; 
lean_dec(v_snd_2109_);
lean_dec(v_fst_2108_);
lean_dec_ref(v___x_2103_);
lean_dec(v___x_1973_);
lean_dec(v_workers_1812_);
lean_dec(v_head_1801_);
lean_dec(v_head_1797_);
v_a_2145_ = lean_ctor_get(v___x_2117_, 0);
v_isSharedCheck_2152_ = !lean_is_exclusive(v___x_2117_);
if (v_isSharedCheck_2152_ == 0)
{
v___x_2147_ = v___x_2117_;
v_isShared_2148_ = v_isSharedCheck_2152_;
goto v_resetjp_2146_;
}
else
{
lean_inc(v_a_2145_);
lean_dec(v___x_2117_);
v___x_2147_ = lean_box(0);
v_isShared_2148_ = v_isSharedCheck_2152_;
goto v_resetjp_2146_;
}
v_resetjp_2146_:
{
lean_object* v___x_2150_; 
if (v_isShared_2148_ == 0)
{
v___x_2150_ = v___x_2147_;
goto v_reusejp_2149_;
}
else
{
lean_object* v_reuseFailAlloc_2151_; 
v_reuseFailAlloc_2151_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2151_, 0, v_a_2145_);
v___x_2150_ = v_reuseFailAlloc_2151_;
goto v_reusejp_2149_;
}
v_reusejp_2149_:
{
return v___x_2150_;
}
}
}
}
else
{
lean_object* v_a_2153_; lean_object* v___x_2155_; uint8_t v_isShared_2156_; uint8_t v_isSharedCheck_2160_; 
lean_dec_ref(v___x_2103_);
lean_dec(v___x_1973_);
lean_dec(v_workers_1812_);
lean_dec(v_head_1801_);
lean_dec(v_head_1797_);
v_a_2153_ = lean_ctor_get(v___x_2104_, 0);
v_isSharedCheck_2160_ = !lean_is_exclusive(v___x_2104_);
if (v_isSharedCheck_2160_ == 0)
{
v___x_2155_ = v___x_2104_;
v_isShared_2156_ = v_isSharedCheck_2160_;
goto v_resetjp_2154_;
}
else
{
lean_inc(v_a_2153_);
lean_dec(v___x_2104_);
v___x_2155_ = lean_box(0);
v_isShared_2156_ = v_isSharedCheck_2160_;
goto v_resetjp_2154_;
}
v_resetjp_2154_:
{
lean_object* v___x_2158_; 
if (v_isShared_2156_ == 0)
{
v___x_2158_ = v___x_2155_;
goto v_reusejp_2157_;
}
else
{
lean_object* v_reuseFailAlloc_2159_; 
v_reuseFailAlloc_2159_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2159_, 0, v_a_2153_);
v___x_2158_ = v_reuseFailAlloc_2159_;
goto v_reusejp_2157_;
}
v_reusejp_2157_:
{
return v___x_2158_;
}
}
}
}
else
{
lean_object* v_a_2161_; lean_object* v___x_2163_; uint8_t v_isShared_2164_; uint8_t v_isSharedCheck_2168_; 
lean_dec(v___x_1973_);
lean_dec(v_workers_1812_);
lean_dec(v_head_1801_);
lean_dec(v_head_1797_);
v_a_2161_ = lean_ctor_get(v___x_2100_, 0);
v_isSharedCheck_2168_ = !lean_is_exclusive(v___x_2100_);
if (v_isSharedCheck_2168_ == 0)
{
v___x_2163_ = v___x_2100_;
v_isShared_2164_ = v_isSharedCheck_2168_;
goto v_resetjp_2162_;
}
else
{
lean_inc(v_a_2161_);
lean_dec(v___x_2100_);
v___x_2163_ = lean_box(0);
v_isShared_2164_ = v_isSharedCheck_2168_;
goto v_resetjp_2162_;
}
v_resetjp_2162_:
{
lean_object* v___x_2166_; 
if (v_isShared_2164_ == 0)
{
v___x_2166_ = v___x_2163_;
goto v_reusejp_2165_;
}
else
{
lean_object* v_reuseFailAlloc_2167_; 
v_reuseFailAlloc_2167_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2167_, 0, v_a_2161_);
v___x_2166_ = v_reuseFailAlloc_2167_;
goto v_reusejp_2165_;
}
v_reusejp_2165_:
{
return v___x_2166_;
}
}
}
}
v___jp_1976_:
{
lean_object* v___x_1984_; lean_object* v___x_1985_; 
lean_inc(v___y_1983_);
v___x_1984_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_1984_, 0, v___x_1809_);
lean_ctor_set(v___x_1984_, 1, v___y_1983_);
lean_ctor_set(v___x_1984_, 2, v___x_1849_);
v___x_1985_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__10___redArg(v___y_1980_, v___y_1983_, v___y_1977_, v___x_1984_, v___y_1982_, v___x_1809_);
lean_dec_ref_known(v___x_1984_, 3);
lean_dec(v___y_1983_);
if (lean_obj_tag(v___x_1985_) == 0)
{
lean_object* v_a_1986_; lean_object* v___x_1987_; lean_object* v___x_1988_; uint8_t v___x_1989_; 
v_a_1986_ = lean_ctor_get(v___x_1985_, 0);
lean_inc(v_a_1986_);
lean_dec_ref_known(v___x_1985_, 1);
v___x_1987_ = lean_string_utf8_byte_size(v_head_1797_);
v___x_1988_ = lean_string_utf8_byte_size(v___y_1978_);
v___x_1989_ = lean_nat_dec_le(v___x_1988_, v___x_1987_);
if (v___x_1989_ == 0)
{
v___y_1946_ = v___y_1977_;
v___y_1947_ = v_a_1986_;
v___y_1948_ = v___y_1979_;
v___y_1949_ = v___y_1980_;
v___y_1950_ = v___y_1981_;
v___y_1951_ = v___x_1975_;
goto v___jp_1945_;
}
else
{
lean_object* v___x_1990_; uint8_t v___x_1991_; 
v___x_1990_ = lean_nat_sub(v___x_1987_, v___x_1988_);
v___x_1991_ = lean_string_memcmp(v_head_1797_, v___y_1978_, v___x_1990_, v___x_1809_, v___x_1988_);
lean_dec(v___x_1990_);
v___y_1946_ = v___y_1977_;
v___y_1947_ = v_a_1986_;
v___y_1948_ = v___y_1979_;
v___y_1949_ = v___y_1980_;
v___y_1950_ = v___y_1981_;
v___y_1951_ = v___x_1991_;
goto v___jp_1945_;
}
}
else
{
lean_object* v_a_1992_; lean_object* v___x_1994_; uint8_t v_isShared_1995_; uint8_t v_isSharedCheck_1999_; 
lean_dec(v___y_1980_);
lean_dec_ref(v___y_1979_);
lean_dec_ref(v___y_1977_);
lean_dec(v_workers_1812_);
lean_del_object(v___x_1807_);
lean_del_object(v___x_1803_);
lean_del_object(v___x_1799_);
lean_dec(v_head_1797_);
lean_dec(v_head_1793_);
v_a_1992_ = lean_ctor_get(v___x_1985_, 0);
v_isSharedCheck_1999_ = !lean_is_exclusive(v___x_1985_);
if (v_isSharedCheck_1999_ == 0)
{
v___x_1994_ = v___x_1985_;
v_isShared_1995_ = v_isSharedCheck_1999_;
goto v_resetjp_1993_;
}
else
{
lean_inc(v_a_1992_);
lean_dec(v___x_1985_);
v___x_1994_ = lean_box(0);
v_isShared_1995_ = v_isSharedCheck_1999_;
goto v_resetjp_1993_;
}
v_resetjp_1993_:
{
lean_object* v___x_1997_; 
if (v_isShared_1995_ == 0)
{
v___x_1997_ = v___x_1994_;
goto v_reusejp_1996_;
}
else
{
lean_object* v_reuseFailAlloc_1998_; 
v_reuseFailAlloc_1998_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1998_, 0, v_a_1992_);
v___x_1997_ = v_reuseFailAlloc_1998_;
goto v_reusejp_1996_;
}
v_reusejp_1996_:
{
return v___x_1997_;
}
}
}
}
v___jp_2000_:
{
lean_object* v___x_2006_; uint8_t v___x_2007_; 
v___x_2006_ = lean_array_get_size(v___y_2005_);
v___x_2007_ = lean_nat_dec_lt(v___x_1809_, v___x_2006_);
if (v___x_2007_ == 0)
{
lean_object* v___x_2008_; lean_object* v___x_2009_; lean_object* v___x_2010_; lean_object* v___x_2011_; lean_object* v___x_2012_; lean_object* v___x_2013_; lean_object* v___x_2015_; 
lean_dec_ref(v___y_2005_);
lean_dec_ref(v___y_2003_);
lean_dec_ref(v___y_2002_);
lean_dec(v_workers_1812_);
lean_del_object(v___x_1807_);
lean_del_object(v___x_1803_);
lean_del_object(v___x_1799_);
lean_dec(v_head_1797_);
lean_dec(v_head_1793_);
v___x_2008_ = ((lean_object*)(l_main___closed__12));
v___x_2009_ = l_Nat_reprFast(v___x_2006_);
v___x_2010_ = lean_string_append(v___x_2008_, v___x_2009_);
lean_dec_ref(v___x_2009_);
v___x_2011_ = ((lean_object*)(l_main___closed__13));
v___x_2012_ = lean_string_append(v___x_2010_, v___x_2011_);
v___x_2013_ = lean_alloc_ctor(18, 1, 0);
lean_ctor_set(v___x_2013_, 0, v___x_2012_);
if (v_isShared_1971_ == 0)
{
lean_ctor_set_tag(v___x_1970_, 1);
lean_ctor_set(v___x_1970_, 0, v___x_2013_);
v___x_2015_ = v___x_1970_;
goto v_reusejp_2014_;
}
else
{
lean_object* v_reuseFailAlloc_2016_; 
v_reuseFailAlloc_2016_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2016_, 0, v___x_2013_);
v___x_2015_ = v_reuseFailAlloc_2016_;
goto v_reusejp_2014_;
}
v_reusejp_2014_:
{
return v___x_2015_;
}
}
else
{
uint8_t v___x_2017_; 
lean_del_object(v___x_1970_);
v___x_2017_ = lean_nat_dec_le(v___x_1850_, v___x_2006_);
if (v___x_2017_ == 0)
{
v___y_1977_ = v___y_2005_;
v___y_1978_ = v___y_2001_;
v___y_1979_ = v___y_2002_;
v___y_1980_ = v___x_2006_;
v___y_1981_ = v___y_2004_;
v___y_1982_ = v___y_2003_;
v___y_1983_ = v___x_2006_;
goto v___jp_1976_;
}
else
{
v___y_1977_ = v___y_2005_;
v___y_1978_ = v___y_2001_;
v___y_1979_ = v___y_2002_;
v___y_1980_ = v___x_2006_;
v___y_1981_ = v___y_2004_;
v___y_1982_ = v___y_2003_;
v___y_1983_ = v___x_1850_;
goto v___jp_1976_;
}
}
}
v___jp_2018_:
{
lean_object* v___x_2027_; 
v___x_2027_ = l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__12___redArg(v___x_1853_, v___y_2020_, v___y_2023_, v___y_2022_, v___y_2026_);
lean_dec(v___y_2026_);
lean_dec(v___y_2020_);
v___y_2001_ = v___y_2019_;
v___y_2002_ = v___y_2021_;
v___y_2003_ = v___y_2025_;
v___y_2004_ = v___y_2024_;
v___y_2005_ = v___x_2027_;
goto v___jp_2000_;
}
v___jp_2028_:
{
uint8_t v___x_2037_; 
v___x_2037_ = lean_nat_dec_le(v___y_2036_, v___y_2033_);
if (v___x_2037_ == 0)
{
lean_dec(v___y_2033_);
lean_inc(v___y_2036_);
v___y_2019_ = v___y_2029_;
v___y_2020_ = v___y_2030_;
v___y_2021_ = v___y_2031_;
v___y_2022_ = v___y_2036_;
v___y_2023_ = v___y_2032_;
v___y_2024_ = v___y_2035_;
v___y_2025_ = v___y_2034_;
v___y_2026_ = v___y_2036_;
goto v___jp_2018_;
}
else
{
v___y_2019_ = v___y_2029_;
v___y_2020_ = v___y_2030_;
v___y_2021_ = v___y_2031_;
v___y_2022_ = v___y_2036_;
v___y_2023_ = v___y_2032_;
v___y_2024_ = v___y_2035_;
v___y_2025_ = v___y_2034_;
v___y_2026_ = v___y_2033_;
goto v___jp_2018_;
}
}
v___jp_2038_:
{
if (v___y_2039_ == 0)
{
lean_object* v___x_2040_; lean_object* v___x_2042_; 
lean_dec(v___x_1973_);
lean_del_object(v___x_1970_);
lean_dec(v_workers_1812_);
lean_del_object(v___x_1807_);
lean_del_object(v___x_1803_);
lean_del_object(v___x_1799_);
lean_dec(v_head_1797_);
lean_del_object(v___x_1795_);
lean_dec(v_head_1793_);
v___x_2040_ = ((lean_object*)(l_main___closed__15));
if (v_isShared_1967_ == 0)
{
lean_ctor_set_tag(v___x_1966_, 1);
lean_ctor_set(v___x_1966_, 0, v___x_2040_);
v___x_2042_ = v___x_1966_;
goto v_reusejp_2041_;
}
else
{
lean_object* v_reuseFailAlloc_2043_; 
v_reuseFailAlloc_2043_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2043_, 0, v___x_2040_);
v___x_2042_ = v_reuseFailAlloc_2043_;
goto v_reusejp_2041_;
}
v_reusejp_2041_:
{
return v___x_2042_;
}
}
else
{
lean_object* v___x_2044_; lean_object* v___x_2045_; lean_object* v___x_2046_; lean_object* v___x_2047_; uint32_t v___x_2048_; lean_object* v___x_2049_; uint8_t v___x_2050_; lean_object* v___x_2051_; lean_object* v___x_2052_; 
lean_del_object(v___x_1966_);
lean_inc(v___x_1973_);
v___x_2044_ = lean_alloc_ctor(0, 1, 3);
lean_ctor_set(v___x_2044_, 0, v___x_1973_);
lean_ctor_set_uint8(v___x_2044_, sizeof(void*)*1, v___x_1975_);
lean_ctor_set_uint8(v___x_2044_, sizeof(void*)*1 + 1, v___x_1853_);
lean_ctor_set_uint8(v___x_2044_, sizeof(void*)*1 + 2, v___x_1975_);
v___x_2045_ = lean_mk_empty_array_with_capacity(v___x_1849_);
v___x_2046_ = lean_array_push(v___x_2045_, v___x_2044_);
v___x_2047_ = l_Lean_Options_empty;
v___x_2048_ = 0;
v___x_2049_ = ((lean_object*)(l_main___closed__16));
v___x_2050_ = 2;
v___x_2051_ = lean_box(1);
v___x_2052_ = l_Lean_importModules(v___x_2046_, v___x_2047_, v___x_2048_, v___x_2049_, v___x_1975_, v___x_1853_, v___x_2050_, v___x_2051_);
if (lean_obj_tag(v___x_2052_) == 0)
{
lean_object* v_a_2053_; lean_object* v___x_2055_; uint8_t v_isShared_2056_; uint8_t v_isSharedCheck_2087_; 
v_a_2053_ = lean_ctor_get(v___x_2052_, 0);
v_isSharedCheck_2087_ = !lean_is_exclusive(v___x_2052_);
if (v_isSharedCheck_2087_ == 0)
{
v___x_2055_ = v___x_2052_;
v_isShared_2056_ = v_isSharedCheck_2087_;
goto v_resetjp_2054_;
}
else
{
lean_inc(v_a_2053_);
lean_dec(v___x_2052_);
v___x_2055_ = lean_box(0);
v_isShared_2056_ = v_isSharedCheck_2087_;
goto v_resetjp_2054_;
}
v_resetjp_2054_:
{
lean_object* v___x_2057_; 
v___x_2057_ = l_Lean_Environment_getModuleIdx_x3f(v_a_2053_, v___x_1973_);
lean_dec(v___x_1973_);
if (lean_obj_tag(v___x_2057_) == 1)
{
lean_object* v___x_2058_; lean_object* v___x_2059_; lean_object* v___x_2060_; lean_object* v___x_2062_; 
lean_del_object(v___x_2055_);
v___x_2058_ = ((lean_object*)(l_main___closed__17));
v___x_2059_ = ((lean_object*)(l_main___closed__18));
v___x_2060_ = ((lean_object*)(l_main___closed__19));
if (v_isShared_1796_ == 0)
{
lean_ctor_set(v___x_1795_, 1, v_tail_1792_);
lean_ctor_set(v___x_1795_, 0, v___x_2060_);
v___x_2062_ = v___x_1795_;
goto v_reusejp_2061_;
}
else
{
lean_object* v_reuseFailAlloc_2082_; 
v_reuseFailAlloc_2082_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_2082_, 0, v___x_2060_);
lean_ctor_set(v_reuseFailAlloc_2082_, 1, v_tail_1792_);
v___x_2062_ = v_reuseFailAlloc_2082_;
goto v_reusejp_2061_;
}
v_reusejp_2061_:
{
lean_object* v___x_2063_; lean_object* v___x_2064_; uint8_t v___x_2065_; lean_object* v___x_2066_; lean_object* v___x_2067_; lean_object* v___x_2068_; 
v___x_2063_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_2063_, 0, v___x_2059_);
lean_ctor_set(v___x_2063_, 1, v___x_2062_);
v___x_2064_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_2064_, 0, v___x_2058_);
lean_ctor_set(v___x_2064_, 1, v___x_2063_);
v___x_2065_ = l_List_any___at___00main_spec__0(v_head_1797_, v_head_1793_, v___x_2064_);
lean_dec_ref_known(v___x_2064_, 2);
lean_inc(v_a_2053_);
v___x_2066_ = l_Lean_Environment_constants(v_a_2053_);
v___x_2067_ = l_Lean_SMap_toList___at___00__private_Lean_Elab_DocString_Builtin_0__Lean_Doc_getQualified_spec__1___redArg(v___x_2066_);
lean_dec_ref(v___x_2066_);
v___x_2068_ = l_List_forIn_x27_loop___at___00main_spec__2___redArg(v_a_2053_, v___x_2057_, v___x_2065_, v_head_1793_, v___x_2067_, v___x_2067_, v___x_2049_);
lean_dec(v___x_2067_);
lean_dec_ref_known(v___x_2057_, 1);
if (lean_obj_tag(v___x_2068_) == 0)
{
lean_object* v_a_2069_; lean_object* v___x_2070_; uint8_t v___x_2071_; 
v_a_2069_ = lean_ctor_get(v___x_2068_, 0);
lean_inc(v_a_2069_);
lean_dec_ref_known(v___x_2068_, 1);
v___x_2070_ = lean_array_get_size(v_a_2069_);
v___x_2071_ = lean_nat_dec_eq(v___x_2070_, v___x_1809_);
if (v___x_2071_ == 0)
{
lean_object* v___x_2072_; uint8_t v___x_2073_; 
v___x_2072_ = lean_nat_sub(v___x_2070_, v___x_1849_);
v___x_2073_ = lean_nat_dec_le(v___x_1809_, v___x_2072_);
if (v___x_2073_ == 0)
{
lean_inc(v___x_2072_);
v___y_2029_ = v___x_2060_;
v___y_2030_ = v___x_2070_;
v___y_2031_ = v_a_2053_;
v___y_2032_ = v_a_2069_;
v___y_2033_ = v___x_2072_;
v___y_2034_ = v___x_2049_;
v___y_2035_ = v___x_2048_;
v___y_2036_ = v___x_2072_;
goto v___jp_2028_;
}
else
{
v___y_2029_ = v___x_2060_;
v___y_2030_ = v___x_2070_;
v___y_2031_ = v_a_2053_;
v___y_2032_ = v_a_2069_;
v___y_2033_ = v___x_2072_;
v___y_2034_ = v___x_2049_;
v___y_2035_ = v___x_2048_;
v___y_2036_ = v___x_1809_;
goto v___jp_2028_;
}
}
else
{
v___y_2001_ = v___x_2060_;
v___y_2002_ = v_a_2053_;
v___y_2003_ = v___x_2049_;
v___y_2004_ = v___x_2048_;
v___y_2005_ = v_a_2069_;
goto v___jp_2000_;
}
}
else
{
lean_object* v_a_2074_; lean_object* v___x_2076_; uint8_t v_isShared_2077_; uint8_t v_isSharedCheck_2081_; 
lean_dec(v_a_2053_);
lean_del_object(v___x_1970_);
lean_dec(v_workers_1812_);
lean_del_object(v___x_1807_);
lean_del_object(v___x_1803_);
lean_del_object(v___x_1799_);
lean_dec(v_head_1797_);
lean_dec(v_head_1793_);
v_a_2074_ = lean_ctor_get(v___x_2068_, 0);
v_isSharedCheck_2081_ = !lean_is_exclusive(v___x_2068_);
if (v_isSharedCheck_2081_ == 0)
{
v___x_2076_ = v___x_2068_;
v_isShared_2077_ = v_isSharedCheck_2081_;
goto v_resetjp_2075_;
}
else
{
lean_inc(v_a_2074_);
lean_dec(v___x_2068_);
v___x_2076_ = lean_box(0);
v_isShared_2077_ = v_isSharedCheck_2081_;
goto v_resetjp_2075_;
}
v_resetjp_2075_:
{
lean_object* v___x_2079_; 
if (v_isShared_2077_ == 0)
{
v___x_2079_ = v___x_2076_;
goto v_reusejp_2078_;
}
else
{
lean_object* v_reuseFailAlloc_2080_; 
v_reuseFailAlloc_2080_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2080_, 0, v_a_2074_);
v___x_2079_ = v_reuseFailAlloc_2080_;
goto v_reusejp_2078_;
}
v_reusejp_2078_:
{
return v___x_2079_;
}
}
}
}
}
else
{
lean_object* v___x_2083_; lean_object* v___x_2085_; 
lean_dec(v___x_2057_);
lean_dec(v_a_2053_);
lean_del_object(v___x_1970_);
lean_dec(v_workers_1812_);
lean_del_object(v___x_1807_);
lean_del_object(v___x_1803_);
lean_del_object(v___x_1799_);
lean_dec(v_head_1797_);
lean_del_object(v___x_1795_);
lean_dec(v_head_1793_);
v___x_2083_ = ((lean_object*)(l_main___closed__21));
if (v_isShared_2056_ == 0)
{
lean_ctor_set_tag(v___x_2055_, 1);
lean_ctor_set(v___x_2055_, 0, v___x_2083_);
v___x_2085_ = v___x_2055_;
goto v_reusejp_2084_;
}
else
{
lean_object* v_reuseFailAlloc_2086_; 
v_reuseFailAlloc_2086_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2086_, 0, v___x_2083_);
v___x_2085_ = v_reuseFailAlloc_2086_;
goto v_reusejp_2084_;
}
v_reusejp_2084_:
{
return v___x_2085_;
}
}
}
}
else
{
lean_object* v_a_2088_; lean_object* v___x_2090_; uint8_t v_isShared_2091_; uint8_t v_isSharedCheck_2095_; 
lean_dec(v___x_1973_);
lean_del_object(v___x_1970_);
lean_dec(v_workers_1812_);
lean_del_object(v___x_1807_);
lean_del_object(v___x_1803_);
lean_del_object(v___x_1799_);
lean_dec(v_head_1797_);
lean_del_object(v___x_1795_);
lean_dec(v_head_1793_);
v_a_2088_ = lean_ctor_get(v___x_2052_, 0);
v_isSharedCheck_2095_ = !lean_is_exclusive(v___x_2052_);
if (v_isSharedCheck_2095_ == 0)
{
v___x_2090_ = v___x_2052_;
v_isShared_2091_ = v_isSharedCheck_2095_;
goto v_resetjp_2089_;
}
else
{
lean_inc(v_a_2088_);
lean_dec(v___x_2052_);
v___x_2090_ = lean_box(0);
v_isShared_2091_ = v_isSharedCheck_2095_;
goto v_resetjp_2089_;
}
v_resetjp_2089_:
{
lean_object* v___x_2093_; 
if (v_isShared_2091_ == 0)
{
v___x_2093_ = v___x_2090_;
goto v_reusejp_2092_;
}
else
{
lean_object* v_reuseFailAlloc_2094_; 
v_reuseFailAlloc_2094_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2094_, 0, v_a_2088_);
v___x_2093_ = v_reuseFailAlloc_2094_;
goto v_reusejp_2092_;
}
v_reusejp_2092_:
{
return v___x_2093_;
}
}
}
}
}
}
}
else
{
lean_object* v_a_2171_; lean_object* v___x_2173_; uint8_t v_isShared_2174_; uint8_t v_isSharedCheck_2178_; 
lean_del_object(v___x_1966_);
lean_dec(v_workers_1812_);
lean_del_object(v___x_1807_);
lean_del_object(v___x_1803_);
lean_dec(v_head_1801_);
lean_del_object(v___x_1799_);
lean_dec(v_head_1797_);
lean_del_object(v___x_1795_);
lean_dec(v_head_1793_);
v_a_2171_ = lean_ctor_get(v___x_1968_, 0);
v_isSharedCheck_2178_ = !lean_is_exclusive(v___x_1968_);
if (v_isSharedCheck_2178_ == 0)
{
v___x_2173_ = v___x_1968_;
v_isShared_2174_ = v_isSharedCheck_2178_;
goto v_resetjp_2172_;
}
else
{
lean_inc(v_a_2171_);
lean_dec(v___x_1968_);
v___x_2173_ = lean_box(0);
v_isShared_2174_ = v_isSharedCheck_2178_;
goto v_resetjp_2172_;
}
v_resetjp_2172_:
{
lean_object* v___x_2176_; 
if (v_isShared_2174_ == 0)
{
v___x_2176_ = v___x_2173_;
goto v_reusejp_2175_;
}
else
{
lean_object* v_reuseFailAlloc_2177_; 
v_reuseFailAlloc_2177_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2177_, 0, v_a_2171_);
v___x_2176_ = v_reuseFailAlloc_2177_;
goto v_reusejp_2175_;
}
v_reusejp_2175_:
{
return v___x_2176_;
}
}
}
}
}
else
{
lean_object* v_a_2180_; lean_object* v___x_2182_; uint8_t v_isShared_2183_; uint8_t v_isSharedCheck_2187_; 
lean_dec(v_workers_1812_);
lean_del_object(v___x_1807_);
lean_del_object(v___x_1803_);
lean_dec(v_head_1801_);
lean_del_object(v___x_1799_);
lean_dec(v_head_1797_);
lean_del_object(v___x_1795_);
lean_dec(v_head_1793_);
v_a_2180_ = lean_ctor_get(v___x_1963_, 0);
v_isSharedCheck_2187_ = !lean_is_exclusive(v___x_1963_);
if (v_isSharedCheck_2187_ == 0)
{
v___x_2182_ = v___x_1963_;
v_isShared_2183_ = v_isSharedCheck_2187_;
goto v_resetjp_2181_;
}
else
{
lean_inc(v_a_2180_);
lean_dec(v___x_1963_);
v___x_2182_ = lean_box(0);
v_isShared_2183_ = v_isSharedCheck_2187_;
goto v_resetjp_2181_;
}
v_resetjp_2181_:
{
lean_object* v___x_2185_; 
if (v_isShared_2183_ == 0)
{
v___x_2185_ = v___x_2182_;
goto v_reusejp_2184_;
}
else
{
lean_object* v_reuseFailAlloc_2186_; 
v_reuseFailAlloc_2186_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2186_, 0, v_a_2180_);
v___x_2185_ = v_reuseFailAlloc_2186_;
goto v_reusejp_2184_;
}
v_reusejp_2184_:
{
return v___x_2185_;
}
}
}
}
v___jp_1813_:
{
size_t v_sz_1819_; lean_object* v___x_1820_; 
v_sz_1819_ = lean_array_size(v___y_1818_);
v___x_1820_ = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__7(v_head_1797_, v_workers_1812_, v___y_1816_, v___y_1815_, v___y_1818_, v_sz_1819_, v___y_1814_, v___y_1817_);
lean_dec_ref(v___y_1818_);
lean_dec_ref(v___y_1815_);
if (lean_obj_tag(v___x_1820_) == 0)
{
lean_dec_ref_known(v___x_1820_, 1);
goto v___jp_1786_;
}
else
{
lean_object* v_a_1821_; lean_object* v___x_1823_; uint8_t v_isShared_1824_; uint8_t v_isSharedCheck_1828_; 
v_a_1821_ = lean_ctor_get(v___x_1820_, 0);
v_isSharedCheck_1828_ = !lean_is_exclusive(v___x_1820_);
if (v_isSharedCheck_1828_ == 0)
{
v___x_1823_ = v___x_1820_;
v_isShared_1824_ = v_isSharedCheck_1828_;
goto v_resetjp_1822_;
}
else
{
lean_inc(v_a_1821_);
lean_dec(v___x_1820_);
v___x_1823_ = lean_box(0);
v_isShared_1824_ = v_isSharedCheck_1828_;
goto v_resetjp_1822_;
}
v_resetjp_1822_:
{
lean_object* v___x_1826_; 
if (v_isShared_1824_ == 0)
{
v___x_1826_ = v___x_1823_;
goto v_reusejp_1825_;
}
else
{
lean_object* v_reuseFailAlloc_1827_; 
v_reuseFailAlloc_1827_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1827_, 0, v_a_1821_);
v___x_1826_ = v_reuseFailAlloc_1827_;
goto v_reusejp_1825_;
}
v_reusejp_1825_:
{
return v___x_1826_;
}
}
}
}
v___jp_1829_:
{
lean_object* v___x_1838_; 
v___x_1838_ = l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__8___redArg(v___y_1835_, v___y_1833_, v___y_1831_, v___y_1837_);
lean_dec(v___y_1837_);
lean_dec(v___y_1835_);
v___y_1814_ = v___y_1830_;
v___y_1815_ = v___y_1832_;
v___y_1816_ = v___y_1834_;
v___y_1817_ = v___y_1836_;
v___y_1818_ = v___x_1838_;
goto v___jp_1813_;
}
v___jp_1839_:
{
uint8_t v___x_1848_; 
v___x_1848_ = lean_nat_dec_le(v___y_1847_, v___y_1841_);
if (v___x_1848_ == 0)
{
lean_dec(v___y_1841_);
lean_inc(v___y_1847_);
v___y_1830_ = v___y_1840_;
v___y_1831_ = v___y_1847_;
v___y_1832_ = v___y_1842_;
v___y_1833_ = v___y_1843_;
v___y_1834_ = v___y_1844_;
v___y_1835_ = v___y_1845_;
v___y_1836_ = v___y_1846_;
v___y_1837_ = v___y_1847_;
goto v___jp_1829_;
}
else
{
v___y_1830_ = v___y_1840_;
v___y_1831_ = v___y_1847_;
v___y_1832_ = v___y_1842_;
v___y_1833_ = v___y_1843_;
v___y_1834_ = v___y_1844_;
v___y_1835_ = v___y_1845_;
v___y_1836_ = v___y_1846_;
v___y_1837_ = v___y_1841_;
goto v___jp_1829_;
}
}
v___jp_1854_:
{
lean_object* v___x_1859_; size_t v_sz_1860_; size_t v___x_1861_; lean_object* v___x_1862_; 
v___x_1859_ = lean_box(0);
v_sz_1860_ = lean_array_size(v_targets_1858_);
v___x_1861_ = ((size_t)0ULL);
v___x_1862_ = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__3(v_head_1793_, v_targets_1858_, v_sz_1860_, v___x_1861_, v___x_1859_);
if (lean_obj_tag(v___x_1862_) == 0)
{
lean_object* v___x_1863_; uint8_t v___x_1864_; 
lean_dec_ref_known(v___x_1862_, 1);
v___x_1863_ = ((lean_object*)(l_main___closed__6));
v___x_1864_ = lean_string_dec_eq(v_head_1793_, v___x_1863_);
lean_dec(v_head_1793_);
if (v___x_1864_ == 0)
{
lean_object* v___x_1865_; lean_object* v___x_1866_; lean_object* v___x_1867_; lean_object* v___x_1868_; lean_object* v___x_1869_; 
lean_del_object(v___x_1807_);
lean_del_object(v___x_1803_);
lean_del_object(v___x_1799_);
v___x_1865_ = lean_io_promise_new();
v___x_1866_ = ((lean_object*)(l_main___closed__7));
v___x_1867_ = lean_elab_environment_to_kernel_env(v___y_1855_);
lean_inc_n(v_workers_1812_, 2);
v___x_1868_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_1868_, 0, v___x_1809_);
lean_ctor_set(v___x_1868_, 1, v_workers_1812_);
lean_ctor_set(v___x_1868_, 2, v___x_1849_);
lean_inc_ref(v_targets_1858_);
v___x_1869_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__5___redArg(v_workers_1812_, v_targets_1858_, v___x_1867_, v___x_1865_, v___x_1868_, v___x_1866_, v___x_1809_);
lean_dec_ref_known(v___x_1868_, 3);
if (lean_obj_tag(v___x_1869_) == 0)
{
lean_object* v_a_1870_; lean_object* v___x_1871_; size_t v_sz_1872_; lean_object* v___x_1873_; 
v_a_1870_ = lean_ctor_get(v___x_1869_, 0);
lean_inc(v_a_1870_);
lean_dec_ref_known(v___x_1869_, 1);
v___x_1871_ = lean_io_promise_resolve(v___x_1859_, v___x_1865_);
lean_dec(v___x_1865_);
v_sz_1872_ = lean_array_size(v_a_1870_);
v___x_1873_ = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__6(v_a_1870_, v_sz_1872_, v___x_1861_, v___x_1866_);
lean_dec(v_a_1870_);
if (lean_obj_tag(v___x_1873_) == 0)
{
lean_object* v_a_1874_; lean_object* v___x_1875_; uint8_t v___x_1876_; 
v_a_1874_ = lean_ctor_get(v___x_1873_, 0);
lean_inc(v_a_1874_);
lean_dec_ref_known(v___x_1873_, 1);
v___x_1875_ = lean_array_get_size(v_a_1874_);
v___x_1876_ = lean_nat_dec_eq(v___x_1875_, v___x_1809_);
if (v___x_1876_ == 0)
{
lean_object* v___x_1877_; uint8_t v___x_1878_; 
v___x_1877_ = lean_nat_sub(v___x_1875_, v___x_1849_);
v___x_1878_ = lean_nat_dec_le(v___x_1809_, v___x_1877_);
if (v___x_1878_ == 0)
{
lean_inc(v___x_1877_);
v___y_1840_ = v___x_1861_;
v___y_1841_ = v___x_1877_;
v___y_1842_ = v_targets_1858_;
v___y_1843_ = v_a_1874_;
v___y_1844_ = v___y_1856_;
v___y_1845_ = v___x_1875_;
v___y_1846_ = v___x_1859_;
v___y_1847_ = v___x_1877_;
goto v___jp_1839_;
}
else
{
v___y_1840_ = v___x_1861_;
v___y_1841_ = v___x_1877_;
v___y_1842_ = v_targets_1858_;
v___y_1843_ = v_a_1874_;
v___y_1844_ = v___y_1856_;
v___y_1845_ = v___x_1875_;
v___y_1846_ = v___x_1859_;
v___y_1847_ = v___x_1809_;
goto v___jp_1839_;
}
}
else
{
v___y_1814_ = v___x_1861_;
v___y_1815_ = v_targets_1858_;
v___y_1816_ = v___y_1856_;
v___y_1817_ = v___x_1859_;
v___y_1818_ = v_a_1874_;
goto v___jp_1813_;
}
}
else
{
lean_object* v_a_1879_; lean_object* v___x_1881_; uint8_t v_isShared_1882_; uint8_t v_isSharedCheck_1886_; 
lean_dec_ref(v_targets_1858_);
lean_dec(v___y_1856_);
lean_dec(v_workers_1812_);
lean_dec(v_head_1797_);
v_a_1879_ = lean_ctor_get(v___x_1873_, 0);
v_isSharedCheck_1886_ = !lean_is_exclusive(v___x_1873_);
if (v_isSharedCheck_1886_ == 0)
{
v___x_1881_ = v___x_1873_;
v_isShared_1882_ = v_isSharedCheck_1886_;
goto v_resetjp_1880_;
}
else
{
lean_inc(v_a_1879_);
lean_dec(v___x_1873_);
v___x_1881_ = lean_box(0);
v_isShared_1882_ = v_isSharedCheck_1886_;
goto v_resetjp_1880_;
}
v_resetjp_1880_:
{
lean_object* v___x_1884_; 
if (v_isShared_1882_ == 0)
{
v___x_1884_ = v___x_1881_;
goto v_reusejp_1883_;
}
else
{
lean_object* v_reuseFailAlloc_1885_; 
v_reuseFailAlloc_1885_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1885_, 0, v_a_1879_);
v___x_1884_ = v_reuseFailAlloc_1885_;
goto v_reusejp_1883_;
}
v_reusejp_1883_:
{
return v___x_1884_;
}
}
}
}
else
{
lean_object* v_a_1887_; lean_object* v___x_1889_; uint8_t v_isShared_1890_; uint8_t v_isSharedCheck_1894_; 
lean_dec(v___x_1865_);
lean_dec_ref(v_targets_1858_);
lean_dec(v___y_1856_);
lean_dec(v_workers_1812_);
lean_dec(v_head_1797_);
v_a_1887_ = lean_ctor_get(v___x_1869_, 0);
v_isSharedCheck_1894_ = !lean_is_exclusive(v___x_1869_);
if (v_isSharedCheck_1894_ == 0)
{
v___x_1889_ = v___x_1869_;
v_isShared_1890_ = v_isSharedCheck_1894_;
goto v_resetjp_1888_;
}
else
{
lean_inc(v_a_1887_);
lean_dec(v___x_1869_);
v___x_1889_ = lean_box(0);
v_isShared_1890_ = v_isSharedCheck_1894_;
goto v_resetjp_1888_;
}
v_resetjp_1888_:
{
lean_object* v___x_1892_; 
if (v_isShared_1890_ == 0)
{
v___x_1892_ = v___x_1889_;
goto v_reusejp_1891_;
}
else
{
lean_object* v_reuseFailAlloc_1893_; 
v_reuseFailAlloc_1893_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1893_, 0, v_a_1887_);
v___x_1892_ = v_reuseFailAlloc_1893_;
goto v_reusejp_1891_;
}
v_reusejp_1891_:
{
return v___x_1892_;
}
}
}
}
else
{
lean_object* v___x_1895_; lean_object* v___x_1896_; lean_object* v___x_1897_; lean_object* v___x_1898_; lean_object* v___x_1899_; lean_object* v___x_1900_; lean_object* v___x_1901_; lean_object* v___x_1902_; lean_object* v___x_1903_; lean_object* v___x_1904_; lean_object* v___x_1905_; lean_object* v___x_1906_; lean_object* v___x_1908_; 
lean_dec_ref(v___y_1855_);
lean_dec(v_workers_1812_);
v___x_1895_ = ((lean_object*)(l_main___closed__8));
v___x_1896_ = ((lean_object*)(l_elaborateOne___closed__19));
v___x_1897_ = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(v___x_1897_, 0, v_head_1797_);
v___x_1898_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1898_, 0, v___x_1896_);
lean_ctor_set(v___x_1898_, 1, v___x_1897_);
v___x_1899_ = ((lean_object*)(l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__7___closed__1));
v___x_1900_ = l_Lean_JsonNumber_fromNat(v___y_1856_);
v___x_1901_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_1901_, 0, v___x_1900_);
v___x_1902_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1902_, 0, v___x_1899_);
lean_ctor_set(v___x_1902_, 1, v___x_1901_);
v___x_1903_ = ((lean_object*)(l_main___closed__9));
v___x_1904_ = l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00main_spec__9(v___x_1853_, v_sz_1860_, v___x_1861_, v_targets_1858_);
v___x_1905_ = l_Lean_Array_toJson___at___00Lean_Server_Test_Runner_Client_instToJsonHyp_toJson_spec__1(v___x_1904_);
v___x_1906_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1906_, 0, v___x_1903_);
lean_ctor_set(v___x_1906_, 1, v___x_1905_);
if (v_isShared_1808_ == 0)
{
lean_ctor_set(v___x_1807_, 1, v___x_1851_);
lean_ctor_set(v___x_1807_, 0, v___x_1906_);
v___x_1908_ = v___x_1807_;
goto v_reusejp_1907_;
}
else
{
lean_object* v_reuseFailAlloc_1936_; 
v_reuseFailAlloc_1936_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1936_, 0, v___x_1906_);
lean_ctor_set(v_reuseFailAlloc_1936_, 1, v___x_1851_);
v___x_1908_ = v_reuseFailAlloc_1936_;
goto v_reusejp_1907_;
}
v_reusejp_1907_:
{
lean_object* v___x_1910_; 
if (v_isShared_1804_ == 0)
{
lean_ctor_set(v___x_1803_, 1, v___x_1908_);
lean_ctor_set(v___x_1803_, 0, v___x_1902_);
v___x_1910_ = v___x_1803_;
goto v_reusejp_1909_;
}
else
{
lean_object* v_reuseFailAlloc_1935_; 
v_reuseFailAlloc_1935_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1935_, 0, v___x_1902_);
lean_ctor_set(v_reuseFailAlloc_1935_, 1, v___x_1908_);
v___x_1910_ = v_reuseFailAlloc_1935_;
goto v_reusejp_1909_;
}
v_reusejp_1909_:
{
lean_object* v___x_1912_; 
if (v_isShared_1800_ == 0)
{
lean_ctor_set(v___x_1799_, 1, v___x_1910_);
lean_ctor_set(v___x_1799_, 0, v___x_1898_);
v___x_1912_ = v___x_1799_;
goto v_reusejp_1911_;
}
else
{
lean_object* v_reuseFailAlloc_1934_; 
v_reuseFailAlloc_1934_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1934_, 0, v___x_1898_);
lean_ctor_set(v_reuseFailAlloc_1934_, 1, v___x_1910_);
v___x_1912_ = v_reuseFailAlloc_1934_;
goto v_reusejp_1911_;
}
v_reusejp_1911_:
{
lean_object* v___x_1913_; lean_object* v___x_1914_; lean_object* v___x_1915_; lean_object* v___x_1916_; 
v___x_1913_ = l_Lean_Json_mkObj(v___x_1912_);
lean_dec_ref(v___x_1912_);
v___x_1914_ = l_Lean_Json_compress(v___x_1913_);
v___x_1915_ = lean_string_append(v___x_1895_, v___x_1914_);
lean_dec_ref(v___x_1914_);
v___x_1916_ = l_IO_println___at___00__private_Lean_Shell_0__Lean_ShellOptions_process_spec__3(v___x_1915_);
if (lean_obj_tag(v___x_1916_) == 0)
{
lean_object* v___x_1918_; uint8_t v_isShared_1919_; uint8_t v_isSharedCheck_1924_; 
v_isSharedCheck_1924_ = !lean_is_exclusive(v___x_1916_);
if (v_isSharedCheck_1924_ == 0)
{
lean_object* v_unused_1925_; 
v_unused_1925_ = lean_ctor_get(v___x_1916_, 0);
lean_dec(v_unused_1925_);
v___x_1918_ = v___x_1916_;
v_isShared_1919_ = v_isSharedCheck_1924_;
goto v_resetjp_1917_;
}
else
{
lean_dec(v___x_1916_);
v___x_1918_ = lean_box(0);
v_isShared_1919_ = v_isSharedCheck_1924_;
goto v_resetjp_1917_;
}
v_resetjp_1917_:
{
lean_object* v___x_1920_; lean_object* v___x_1922_; 
v___x_1920_ = lean_box_uint32(v___y_1857_);
if (v_isShared_1919_ == 0)
{
lean_ctor_set(v___x_1918_, 0, v___x_1920_);
v___x_1922_ = v___x_1918_;
goto v_reusejp_1921_;
}
else
{
lean_object* v_reuseFailAlloc_1923_; 
v_reuseFailAlloc_1923_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1923_, 0, v___x_1920_);
v___x_1922_ = v_reuseFailAlloc_1923_;
goto v_reusejp_1921_;
}
v_reusejp_1921_:
{
return v___x_1922_;
}
}
}
else
{
lean_object* v_a_1926_; lean_object* v___x_1928_; uint8_t v_isShared_1929_; uint8_t v_isSharedCheck_1933_; 
v_a_1926_ = lean_ctor_get(v___x_1916_, 0);
v_isSharedCheck_1933_ = !lean_is_exclusive(v___x_1916_);
if (v_isSharedCheck_1933_ == 0)
{
v___x_1928_ = v___x_1916_;
v_isShared_1929_ = v_isSharedCheck_1933_;
goto v_resetjp_1927_;
}
else
{
lean_inc(v_a_1926_);
lean_dec(v___x_1916_);
v___x_1928_ = lean_box(0);
v_isShared_1929_ = v_isSharedCheck_1933_;
goto v_resetjp_1927_;
}
v_resetjp_1927_:
{
lean_object* v___x_1931_; 
if (v_isShared_1929_ == 0)
{
v___x_1931_ = v___x_1928_;
goto v_reusejp_1930_;
}
else
{
lean_object* v_reuseFailAlloc_1932_; 
v_reuseFailAlloc_1932_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1932_, 0, v_a_1926_);
v___x_1931_ = v_reuseFailAlloc_1932_;
goto v_reusejp_1930_;
}
v_reusejp_1930_:
{
return v___x_1931_;
}
}
}
}
}
}
}
}
else
{
lean_object* v_a_1937_; lean_object* v___x_1939_; uint8_t v_isShared_1940_; uint8_t v_isSharedCheck_1944_; 
lean_dec_ref(v_targets_1858_);
lean_dec(v___y_1856_);
lean_dec_ref(v___y_1855_);
lean_dec(v_workers_1812_);
lean_del_object(v___x_1807_);
lean_del_object(v___x_1803_);
lean_del_object(v___x_1799_);
lean_dec(v_head_1797_);
lean_dec(v_head_1793_);
v_a_1937_ = lean_ctor_get(v___x_1862_, 0);
v_isSharedCheck_1944_ = !lean_is_exclusive(v___x_1862_);
if (v_isSharedCheck_1944_ == 0)
{
v___x_1939_ = v___x_1862_;
v_isShared_1940_ = v_isSharedCheck_1944_;
goto v_resetjp_1938_;
}
else
{
lean_inc(v_a_1937_);
lean_dec(v___x_1862_);
v___x_1939_ = lean_box(0);
v_isShared_1940_ = v_isSharedCheck_1944_;
goto v_resetjp_1938_;
}
v_resetjp_1938_:
{
lean_object* v___x_1942_; 
if (v_isShared_1940_ == 0)
{
v___x_1942_ = v___x_1939_;
goto v_reusejp_1941_;
}
else
{
lean_object* v_reuseFailAlloc_1943_; 
v_reuseFailAlloc_1943_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1943_, 0, v_a_1937_);
v___x_1942_ = v_reuseFailAlloc_1943_;
goto v_reusejp_1941_;
}
v_reusejp_1941_:
{
return v___x_1942_;
}
}
}
}
v___jp_1945_:
{
if (v___y_1951_ == 0)
{
lean_dec_ref(v___y_1946_);
v___y_1855_ = v___y_1948_;
v___y_1856_ = v___y_1949_;
v___y_1857_ = v___y_1950_;
v_targets_1858_ = v___y_1947_;
goto v___jp_1854_;
}
else
{
lean_object* v___x_1952_; size_t v_sz_1953_; size_t v___x_1954_; lean_object* v___x_1955_; lean_object* v_fst_1956_; 
v___x_1952_ = ((lean_object*)(l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__11___closed__1));
v_sz_1953_ = lean_array_size(v___y_1946_);
v___x_1954_ = ((size_t)0ULL);
v___x_1955_ = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__11(v___x_1853_, v___y_1946_, v_sz_1953_, v___x_1954_, v___x_1952_);
lean_dec_ref(v___y_1946_);
v_fst_1956_ = lean_ctor_get(v___x_1955_, 0);
lean_inc(v_fst_1956_);
lean_dec_ref(v___x_1955_);
if (lean_obj_tag(v_fst_1956_) == 0)
{
v___y_1855_ = v___y_1948_;
v___y_1856_ = v___y_1949_;
v___y_1857_ = v___y_1950_;
v_targets_1858_ = v___y_1947_;
goto v___jp_1854_;
}
else
{
lean_object* v_val_1957_; 
v_val_1957_ = lean_ctor_get(v_fst_1956_, 0);
lean_inc(v_val_1957_);
lean_dec_ref_known(v_fst_1956_, 1);
if (lean_obj_tag(v_val_1957_) == 1)
{
lean_object* v_val_1958_; lean_object* v___x_1959_; 
v_val_1958_ = lean_ctor_get(v_val_1957_, 0);
lean_inc(v_val_1958_);
lean_dec_ref_known(v_val_1957_, 1);
v___x_1959_ = lean_array_set(v___y_1947_, v___x_1809_, v_val_1958_);
v___y_1855_ = v___y_1948_;
v___y_1856_ = v___y_1949_;
v___y_1857_ = v___y_1950_;
v_targets_1858_ = v___x_1959_;
goto v___jp_1854_;
}
else
{
lean_dec(v_val_1957_);
v___y_1855_ = v___y_1948_;
v___y_1856_ = v___y_1949_;
v___y_1857_ = v___y_1950_;
v_targets_1858_ = v___y_1947_;
goto v___jp_1854_;
}
}
}
}
}
}
}
}
}
else
{
lean_dec(v_tail_1792_);
lean_dec_ref_known(v_tail_1791_, 2);
lean_dec_ref_known(v_tail_1790_, 2);
lean_dec_ref_known(v_tail_1789_, 2);
lean_dec_ref_known(v_args_1781_, 2);
goto v___jp_1783_;
}
}
else
{
lean_dec(v_tail_1791_);
lean_dec_ref_known(v_tail_1790_, 2);
lean_dec_ref_known(v_tail_1789_, 2);
lean_dec_ref_known(v_args_1781_, 2);
goto v___jp_1783_;
}
}
else
{
lean_dec_ref_known(v_tail_1789_, 2);
lean_dec(v_tail_1790_);
lean_dec_ref_known(v_args_1781_, 2);
goto v___jp_1783_;
}
}
else
{
lean_dec_ref_known(v_args_1781_, 2);
lean_dec(v_tail_1789_);
goto v___jp_1783_;
}
}
else
{
lean_dec(v_args_1781_);
goto v___jp_1783_;
}
v___jp_1783_:
{
lean_object* v___x_1784_; lean_object* v___x_1785_; 
v___x_1784_ = ((lean_object*)(l_main___closed__1));
v___x_1785_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_1785_, 0, v___x_1784_);
return v___x_1785_;
}
v___jp_1786_:
{
lean_object* v___x_1787_; lean_object* v___x_1788_; 
v___x_1787_ = l_main___boxed__const__1;
v___x_1788_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_1788_, 0, v___x_1787_);
return v___x_1788_;
}
}
}
LEAN_EXPORT lean_object* l_main___boxed(lean_object* v_args_2196_, lean_object* v_a_2197_){
_start:
{
lean_object* v_res_2198_; 
v_res_2198_ = _lean_main(v_args_2196_);
return v_res_2198_;
}
}
LEAN_EXPORT lean_object* l_List_forIn_x27_loop___at___00main_spec__2(lean_object* v_a_2199_, lean_object* v___x_2200_, uint8_t v___x_2201_, lean_object* v_head_2202_, lean_object* v_as_2203_, lean_object* v_as_x27_2204_, lean_object* v_b_2205_, lean_object* v_a_2206_){
_start:
{
lean_object* v___x_2208_; 
v___x_2208_ = l_List_forIn_x27_loop___at___00main_spec__2___redArg(v_a_2199_, v___x_2200_, v___x_2201_, v_head_2202_, v_as_2203_, v_as_x27_2204_, v_b_2205_);
return v___x_2208_;
}
}
LEAN_EXPORT lean_object* l_List_forIn_x27_loop___at___00main_spec__2___boxed(lean_object* v_a_2209_, lean_object* v___x_2210_, lean_object* v___x_2211_, lean_object* v_head_2212_, lean_object* v_as_2213_, lean_object* v_as_x27_2214_, lean_object* v_b_2215_, lean_object* v_a_2216_, lean_object* v___y_2217_){
_start:
{
uint8_t v___x_20418__boxed_2218_; lean_object* v_res_2219_; 
v___x_20418__boxed_2218_ = lean_unbox(v___x_2211_);
v_res_2219_ = l_List_forIn_x27_loop___at___00main_spec__2(v_a_2209_, v___x_2210_, v___x_20418__boxed_2218_, v_head_2212_, v_as_2213_, v_as_x27_2214_, v_b_2215_, v_a_2216_);
lean_dec(v_as_x27_2214_);
lean_dec(v_as_2213_);
lean_dec_ref(v_head_2212_);
lean_dec(v___x_2210_);
lean_dec_ref(v_a_2209_);
return v_res_2219_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__4(lean_object* v_workers_2220_, lean_object* v_a_2221_, lean_object* v_targets_2222_, lean_object* v___x_2223_, lean_object* v_range_2224_, lean_object* v_b_2225_, lean_object* v_i_2226_, lean_object* v_hs_2227_, lean_object* v_hl_2228_){
_start:
{
lean_object* v___x_2230_; 
v___x_2230_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__4___redArg(v_workers_2220_, v_a_2221_, v_targets_2222_, v___x_2223_, v_range_2224_, v_b_2225_, v_i_2226_);
return v___x_2230_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__4___boxed(lean_object* v_workers_2231_, lean_object* v_a_2232_, lean_object* v_targets_2233_, lean_object* v___x_2234_, lean_object* v_range_2235_, lean_object* v_b_2236_, lean_object* v_i_2237_, lean_object* v_hs_2238_, lean_object* v_hl_2239_, lean_object* v___y_2240_){
_start:
{
lean_object* v_res_2241_; 
v_res_2241_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__4(v_workers_2231_, v_a_2232_, v_targets_2233_, v___x_2234_, v_range_2235_, v_b_2236_, v_i_2237_, v_hs_2238_, v_hl_2239_);
lean_dec_ref(v_range_2235_);
lean_dec_ref(v_targets_2233_);
lean_dec(v_a_2232_);
lean_dec(v_workers_2231_);
return v_res_2241_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__5(lean_object* v_workers_2242_, lean_object* v_targets_2243_, lean_object* v___x_2244_, lean_object* v_val_2245_, lean_object* v_range_2246_, lean_object* v_b_2247_, lean_object* v_i_2248_, lean_object* v_hs_2249_, lean_object* v_hl_2250_){
_start:
{
lean_object* v___x_2252_; 
v___x_2252_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__5___redArg(v_workers_2242_, v_targets_2243_, v___x_2244_, v_val_2245_, v_range_2246_, v_b_2247_, v_i_2248_);
return v___x_2252_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__5___boxed(lean_object* v_workers_2253_, lean_object* v_targets_2254_, lean_object* v___x_2255_, lean_object* v_val_2256_, lean_object* v_range_2257_, lean_object* v_b_2258_, lean_object* v_i_2259_, lean_object* v_hs_2260_, lean_object* v_hl_2261_, lean_object* v___y_2262_){
_start:
{
lean_object* v_res_2263_; 
v_res_2263_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__5(v_workers_2253_, v_targets_2254_, v___x_2255_, v_val_2256_, v_range_2257_, v_b_2258_, v_i_2259_, v_hs_2260_, v_hl_2261_);
lean_dec_ref(v_range_2257_);
lean_dec(v_val_2256_);
return v_res_2263_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__8(lean_object* v_n_2264_, lean_object* v_as_2265_, lean_object* v_lo_2266_, lean_object* v_hi_2267_, lean_object* v_w_2268_, lean_object* v_hlo_2269_, lean_object* v_hhi_2270_){
_start:
{
lean_object* v___x_2271_; 
v___x_2271_ = l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__8___redArg(v_n_2264_, v_as_2265_, v_lo_2266_, v_hi_2267_);
return v___x_2271_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__8___boxed(lean_object* v_n_2272_, lean_object* v_as_2273_, lean_object* v_lo_2274_, lean_object* v_hi_2275_, lean_object* v_w_2276_, lean_object* v_hlo_2277_, lean_object* v_hhi_2278_){
_start:
{
lean_object* v_res_2279_; 
v_res_2279_ = l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__8(v_n_2272_, v_as_2273_, v_lo_2274_, v_hi_2275_, v_w_2276_, v_hlo_2277_, v_hhi_2278_);
lean_dec(v_hi_2275_);
lean_dec(v_n_2272_);
return v_res_2279_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__10(lean_object* v___x_2280_, lean_object* v___y_2281_, lean_object* v___y_2282_, lean_object* v_range_2283_, lean_object* v_b_2284_, lean_object* v_i_2285_, lean_object* v_hs_2286_, lean_object* v_hl_2287_){
_start:
{
lean_object* v___x_2289_; 
v___x_2289_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__10___redArg(v___x_2280_, v___y_2281_, v___y_2282_, v_range_2283_, v_b_2284_, v_i_2285_);
return v___x_2289_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__10___boxed(lean_object* v___x_2290_, lean_object* v___y_2291_, lean_object* v___y_2292_, lean_object* v_range_2293_, lean_object* v_b_2294_, lean_object* v_i_2295_, lean_object* v_hs_2296_, lean_object* v_hl_2297_, lean_object* v___y_2298_){
_start:
{
lean_object* v_res_2299_; 
v_res_2299_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__10(v___x_2290_, v___y_2291_, v___y_2292_, v_range_2293_, v_b_2294_, v_i_2295_, v_hs_2296_, v_hl_2297_);
lean_dec_ref(v_range_2293_);
lean_dec_ref(v___y_2292_);
lean_dec(v___y_2291_);
lean_dec(v___x_2290_);
return v_res_2299_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__12(uint8_t v___x_2300_, lean_object* v_n_2301_, lean_object* v_as_2302_, lean_object* v_lo_2303_, lean_object* v_hi_2304_, lean_object* v_w_2305_, lean_object* v_hlo_2306_, lean_object* v_hhi_2307_){
_start:
{
lean_object* v___x_2308_; 
v___x_2308_ = l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__12___redArg(v___x_2300_, v_n_2301_, v_as_2302_, v_lo_2303_, v_hi_2304_);
return v___x_2308_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__12___boxed(lean_object* v___x_2309_, lean_object* v_n_2310_, lean_object* v_as_2311_, lean_object* v_lo_2312_, lean_object* v_hi_2313_, lean_object* v_w_2314_, lean_object* v_hlo_2315_, lean_object* v_hhi_2316_){
_start:
{
uint8_t v___x_20471__boxed_2317_; lean_object* v_res_2318_; 
v___x_20471__boxed_2317_ = lean_unbox(v___x_2309_);
v_res_2318_ = l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__12(v___x_20471__boxed_2317_, v_n_2310_, v_as_2311_, v_lo_2312_, v_hi_2313_, v_w_2314_, v_hlo_2315_, v_hhi_2316_);
lean_dec(v_hi_2313_);
lean_dec(v_n_2310_);
return v_res_2318_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__13(lean_object* v_workers_2319_, lean_object* v_a_2320_, lean_object* v___x_2321_, lean_object* v___x_2322_, lean_object* v_fst_2323_, lean_object* v_snd_2324_, lean_object* v_head_2325_, lean_object* v_head_2326_, lean_object* v_range_2327_, lean_object* v_b_2328_, lean_object* v_i_2329_, lean_object* v_hs_2330_, lean_object* v_hl_2331_){
_start:
{
lean_object* v___x_2333_; 
v___x_2333_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__13___redArg(v_workers_2319_, v_a_2320_, v___x_2321_, v___x_2322_, v_fst_2323_, v_snd_2324_, v_head_2325_, v_head_2326_, v_range_2327_, v_b_2328_, v_i_2329_);
return v___x_2333_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__13___boxed(lean_object* v_workers_2334_, lean_object* v_a_2335_, lean_object* v___x_2336_, lean_object* v___x_2337_, lean_object* v_fst_2338_, lean_object* v_snd_2339_, lean_object* v_head_2340_, lean_object* v_head_2341_, lean_object* v_range_2342_, lean_object* v_b_2343_, lean_object* v_i_2344_, lean_object* v_hs_2345_, lean_object* v_hl_2346_, lean_object* v___y_2347_){
_start:
{
lean_object* v_res_2348_; 
v_res_2348_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__13(v_workers_2334_, v_a_2335_, v___x_2336_, v___x_2337_, v_fst_2338_, v_snd_2339_, v_head_2340_, v_head_2341_, v_range_2342_, v_b_2343_, v_i_2344_, v_hs_2345_, v_hl_2346_);
lean_dec_ref(v_range_2342_);
lean_dec_ref(v_snd_2339_);
lean_dec_ref(v___x_2337_);
lean_dec(v_a_2335_);
return v_res_2348_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__14(lean_object* v_workers_2349_, lean_object* v___x_2350_, lean_object* v___x_2351_, lean_object* v_fst_2352_, lean_object* v_snd_2353_, lean_object* v_head_2354_, lean_object* v_head_2355_, lean_object* v_val_2356_, lean_object* v_range_2357_, lean_object* v_b_2358_, lean_object* v_i_2359_, lean_object* v_hs_2360_, lean_object* v_hl_2361_){
_start:
{
lean_object* v___x_2363_; 
v___x_2363_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__14___redArg(v_workers_2349_, v___x_2350_, v___x_2351_, v_fst_2352_, v_snd_2353_, v_head_2354_, v_head_2355_, v_val_2356_, v_range_2357_, v_b_2358_, v_i_2359_);
return v___x_2363_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__14___boxed(lean_object* v_workers_2364_, lean_object* v___x_2365_, lean_object* v___x_2366_, lean_object* v_fst_2367_, lean_object* v_snd_2368_, lean_object* v_head_2369_, lean_object* v_head_2370_, lean_object* v_val_2371_, lean_object* v_range_2372_, lean_object* v_b_2373_, lean_object* v_i_2374_, lean_object* v_hs_2375_, lean_object* v_hl_2376_, lean_object* v___y_2377_){
_start:
{
lean_object* v_res_2378_; 
v_res_2378_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__14(v_workers_2364_, v___x_2365_, v___x_2366_, v_fst_2367_, v_snd_2368_, v_head_2369_, v_head_2370_, v_val_2371_, v_range_2372_, v_b_2373_, v_i_2374_, v_hs_2375_, v_hl_2376_);
lean_dec_ref(v_range_2372_);
lean_dec(v_val_2371_);
return v_res_2378_;
}
}
LEAN_EXPORT lean_object* l_List_forIn_x27_loop___at___00List_forIn_x27_loop___at___00main_spec__2_spec__2(lean_object* v_a_2379_, lean_object* v___x_2380_, uint8_t v___x_2381_, lean_object* v_head_2382_, lean_object* v_as_2383_, lean_object* v_as_x27_2384_, lean_object* v_b_2385_, lean_object* v_a_2386_){
_start:
{
lean_object* v___x_2388_; 
v___x_2388_ = l_List_forIn_x27_loop___at___00List_forIn_x27_loop___at___00main_spec__2_spec__2___redArg(v_a_2379_, v___x_2380_, v___x_2381_, v_head_2382_, v_as_x27_2384_, v_b_2385_);
return v___x_2388_;
}
}
LEAN_EXPORT lean_object* l_List_forIn_x27_loop___at___00List_forIn_x27_loop___at___00main_spec__2_spec__2___boxed(lean_object* v_a_2389_, lean_object* v___x_2390_, lean_object* v___x_2391_, lean_object* v_head_2392_, lean_object* v_as_2393_, lean_object* v_as_x27_2394_, lean_object* v_b_2395_, lean_object* v_a_2396_, lean_object* v___y_2397_){
_start:
{
uint8_t v___x_20527__boxed_2398_; lean_object* v_res_2399_; 
v___x_20527__boxed_2398_ = lean_unbox(v___x_2391_);
v_res_2399_ = l_List_forIn_x27_loop___at___00List_forIn_x27_loop___at___00main_spec__2_spec__2(v_a_2389_, v___x_2390_, v___x_20527__boxed_2398_, v_head_2392_, v_as_2393_, v_as_x27_2394_, v_b_2395_, v_a_2396_);
lean_dec(v_as_x27_2394_);
lean_dec(v_as_2393_);
lean_dec_ref(v_head_2392_);
lean_dec(v___x_2390_);
lean_dec_ref(v_a_2389_);
return v_res_2399_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__5_spec__6(lean_object* v_val_2400_, lean_object* v_targets_2401_, lean_object* v_workers_2402_, lean_object* v___x_2403_, lean_object* v_range_2404_, lean_object* v_b_2405_, lean_object* v_i_2406_, lean_object* v_hs_2407_, lean_object* v_hl_2408_){
_start:
{
lean_object* v___x_2410_; 
v___x_2410_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__5_spec__6___redArg(v_val_2400_, v_targets_2401_, v_workers_2402_, v___x_2403_, v_range_2404_, v_b_2405_, v_i_2406_);
return v___x_2410_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__5_spec__6___boxed(lean_object* v_val_2411_, lean_object* v_targets_2412_, lean_object* v_workers_2413_, lean_object* v___x_2414_, lean_object* v_range_2415_, lean_object* v_b_2416_, lean_object* v_i_2417_, lean_object* v_hs_2418_, lean_object* v_hl_2419_, lean_object* v___y_2420_){
_start:
{
lean_object* v_res_2421_; 
v_res_2421_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__5_spec__6(v_val_2411_, v_targets_2412_, v_workers_2413_, v___x_2414_, v_range_2415_, v_b_2416_, v_i_2417_, v_hs_2418_, v_hl_2419_);
lean_dec_ref(v_range_2415_);
lean_dec(v_val_2411_);
return v_res_2421_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_QSort_Basic_0__Array_qpartition_loop___at___00__private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__8_spec__10(lean_object* v_n_2422_, lean_object* v_lo_2423_, lean_object* v_hi_2424_, lean_object* v_hhi_2425_, lean_object* v_pivot_2426_, lean_object* v_as_2427_, lean_object* v_i_2428_, lean_object* v_k_2429_, lean_object* v_ilo_2430_, lean_object* v_ik_2431_, lean_object* v_w_2432_){
_start:
{
lean_object* v___x_2433_; 
v___x_2433_ = l___private_Init_Data_Array_QSort_Basic_0__Array_qpartition_loop___at___00__private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__8_spec__10___redArg(v_hi_2424_, v_pivot_2426_, v_as_2427_, v_i_2428_, v_k_2429_);
return v___x_2433_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_QSort_Basic_0__Array_qpartition_loop___at___00__private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__8_spec__10___boxed(lean_object* v_n_2434_, lean_object* v_lo_2435_, lean_object* v_hi_2436_, lean_object* v_hhi_2437_, lean_object* v_pivot_2438_, lean_object* v_as_2439_, lean_object* v_i_2440_, lean_object* v_k_2441_, lean_object* v_ilo_2442_, lean_object* v_ik_2443_, lean_object* v_w_2444_){
_start:
{
lean_object* v_res_2445_; 
v_res_2445_ = l___private_Init_Data_Array_QSort_Basic_0__Array_qpartition_loop___at___00__private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__8_spec__10(v_n_2434_, v_lo_2435_, v_hi_2436_, v_hhi_2437_, v_pivot_2438_, v_as_2439_, v_i_2440_, v_k_2441_, v_ilo_2442_, v_ik_2443_, v_w_2444_);
lean_dec_ref(v_pivot_2438_);
lean_dec(v_hi_2436_);
lean_dec(v_lo_2435_);
lean_dec(v_n_2434_);
return v_res_2445_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_QSort_Basic_0__Array_qpartition_loop___at___00__private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__12_spec__15(uint8_t v___x_2446_, lean_object* v_n_2447_, lean_object* v_lo_2448_, lean_object* v_hi_2449_, lean_object* v_hhi_2450_, lean_object* v_pivot_2451_, lean_object* v_as_2452_, lean_object* v_i_2453_, lean_object* v_k_2454_, lean_object* v_ilo_2455_, lean_object* v_ik_2456_, lean_object* v_w_2457_){
_start:
{
lean_object* v___x_2458_; 
v___x_2458_ = l___private_Init_Data_Array_QSort_Basic_0__Array_qpartition_loop___at___00__private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__12_spec__15___redArg(v___x_2446_, v_hi_2449_, v_pivot_2451_, v_as_2452_, v_i_2453_, v_k_2454_);
return v___x_2458_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_QSort_Basic_0__Array_qpartition_loop___at___00__private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__12_spec__15___boxed(lean_object* v___x_2459_, lean_object* v_n_2460_, lean_object* v_lo_2461_, lean_object* v_hi_2462_, lean_object* v_hhi_2463_, lean_object* v_pivot_2464_, lean_object* v_as_2465_, lean_object* v_i_2466_, lean_object* v_k_2467_, lean_object* v_ilo_2468_, lean_object* v_ik_2469_, lean_object* v_w_2470_){
_start:
{
uint8_t v___x_20558__boxed_2471_; lean_object* v_res_2472_; 
v___x_20558__boxed_2471_ = lean_unbox(v___x_2459_);
v_res_2472_ = l___private_Init_Data_Array_QSort_Basic_0__Array_qpartition_loop___at___00__private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__12_spec__15(v___x_20558__boxed_2471_, v_n_2460_, v_lo_2461_, v_hi_2462_, v_hhi_2463_, v_pivot_2464_, v_as_2465_, v_i_2466_, v_k_2467_, v_ilo_2468_, v_ik_2469_, v_w_2470_);
lean_dec(v_hi_2462_);
lean_dec(v_lo_2461_);
lean_dec(v_n_2460_);
return v_res_2472_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__14_spec__18(lean_object* v_val_2473_, lean_object* v_workers_2474_, lean_object* v___x_2475_, lean_object* v___x_2476_, lean_object* v_fst_2477_, lean_object* v_snd_2478_, lean_object* v_head_2479_, lean_object* v_head_2480_, lean_object* v_range_2481_, lean_object* v_b_2482_, lean_object* v_i_2483_, lean_object* v_hs_2484_, lean_object* v_hl_2485_){
_start:
{
lean_object* v___x_2487_; 
v___x_2487_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__14_spec__18___redArg(v_val_2473_, v_workers_2474_, v___x_2475_, v___x_2476_, v_fst_2477_, v_snd_2478_, v_head_2479_, v_head_2480_, v_range_2481_, v_b_2482_, v_i_2483_);
return v___x_2487_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__14_spec__18___boxed(lean_object* v_val_2488_, lean_object* v_workers_2489_, lean_object* v___x_2490_, lean_object* v___x_2491_, lean_object* v_fst_2492_, lean_object* v_snd_2493_, lean_object* v_head_2494_, lean_object* v_head_2495_, lean_object* v_range_2496_, lean_object* v_b_2497_, lean_object* v_i_2498_, lean_object* v_hs_2499_, lean_object* v_hl_2500_, lean_object* v___y_2501_){
_start:
{
lean_object* v_res_2502_; 
v_res_2502_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__14_spec__18(v_val_2488_, v_workers_2489_, v___x_2490_, v___x_2491_, v_fst_2492_, v_snd_2493_, v_head_2494_, v_head_2495_, v_range_2496_, v_b_2497_, v_i_2498_, v_hs_2499_, v_hl_2500_);
lean_dec_ref(v_range_2496_);
lean_dec(v_val_2488_);
return v_res_2502_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Lean(uint8_t builtin);
lean_object* initialize_Lean_Util_CollectAxioms(uint8_t builtin);
void lean_initialize();
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_ModuleProbe(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
lean_initialize();
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Lean(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Lean_Util_CollectAxioms(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
l_main___boxed__const__1 = _init_l_main___boxed__const__1();
lean_mark_persistent(l_main___boxed__const__1);
return lean_io_result_mk_ok(lean_box(0));
}
char ** lean_setup_args(int argc, char ** argv);
#if defined(WIN32) || defined(_WIN32)
#include <windows.h>
#endif
lean_object* run_main(int argc, char ** argv) {
    lean_object* in = lean_box(0);
    int i = argc;
    while (i > 1) {
      lean_object* n;
      i--;
      n = lean_alloc_ctor(1,2,0); lean_ctor_set(n, 0, lean_mk_string(argv[i])); lean_ctor_set(n, 1, in);
      in = n;
    }
    return _lean_main(in);
}
int main(int argc, char ** argv) {
#if defined(WIN32) || defined(_WIN32)
  SetErrorMode(SEM_FAILCRITICALERRORS);
  SetConsoleOutputCP(CP_UTF8);
#endif
  lean_object* res;
  argv = lean_setup_args(argc, argv);
  res = initialize_ModuleProbe(1 /* builtin */);
  lean_io_mark_end_initialization();
  if (lean_io_result_is_ok(res)) {
    lean_dec_ref(res);
    lean_init_task_manager();
    res = lean_run_main(&run_main, argc, argv);
  }
  lean_finalize_task_manager();
  if (lean_io_result_is_ok(res)) {
    int ret = lean_unbox_uint32(lean_io_result_get_value(res));
    lean_dec_ref(res);
    return ret;
  } else {
    lean_io_result_show_error(res);
    lean_dec_ref(res);
    return 1;
  }
}
#ifdef __cplusplus
}
#endif
