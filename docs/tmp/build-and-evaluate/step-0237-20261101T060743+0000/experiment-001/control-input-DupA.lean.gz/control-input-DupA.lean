prelude
import Init.Prelude
namespace Shared
theorem t : True := True.intro
end Shared
