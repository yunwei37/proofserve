from pathlib import Path
import subprocess,json,time,os,datetime
p=Path(__file__).resolve().parent
phases=['p12','p48','types','observer','placement','det24']
rows=[];state='partial';error=None
try:
 for phase in phases:
  if (p/(phase+'-launch.json')).exists():raise RuntimeError('phase already launched; inspect rather than duplicate')
  argv=['flock','/workspaces/.agent-state/gpu-smt-captures/pcore.lock','timeout','--signal=TERM','--kill-after=5','1740','taskset','-c','0-7','python3','-u',str(p/'attribution.py'),phase]
  with (p/(phase+'-controller.log')).open('w') as f:
   q=subprocess.Popen(argv,cwd=p,stdout=f,stderr=subprocess.STDOUT)
   birth=Path('/proc/'+str(q.pid)+'/stat').read_text().split(') ',1)[1].split()[19]
   launch=dict(pid=q.pid,birth=birth,argv=argv,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),foreground=True)
   (p/(phase+'-launch.json')).write_text(json.dumps(launch,indent=2))
   print('PHASE_STARTED',phase,q.pid,birth,flush=True)
   rc=q.wait();print('PHASE_RETURN',phase,rc,flush=True)
  term=json.loads((p/(phase+'-terminal.json')).read_text()) if (p/(phase+'-terminal.json')).exists() else None
  rows.append(dict(phase=phase,returncode=rc,state=term['state']if term else 'missing'))
  (p/'series-results.json').write_text(json.dumps(rows,indent=2))
  if rc or not term or term['state']!='complete' or not all(c['native_retired'] and c['cgroup_retired'] for c in term['cells']):
   raise RuntimeError('finite phase incomplete; retain raw and stop, no auto retry')
 state='complete'
except BaseException as ex:error=repr(ex);raise
finally:
 (p/'series-terminal.json').write_text(json.dumps(dict(state=state,error=error,phases=rows,utc=time.strftime('%FT%TZ',time.gmtime())),indent=2))
