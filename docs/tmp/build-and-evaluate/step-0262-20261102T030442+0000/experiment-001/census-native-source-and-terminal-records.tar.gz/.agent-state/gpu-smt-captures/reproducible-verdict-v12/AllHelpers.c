// Lean compiler output
// Module: AllHelpers
// Imports: public import Init public meta import Init public import Lean public import Lean.Util.CollectAxioms
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* l_Lean_JsonNumber_fromNat(lean_object*);
lean_object* lean_uint64_to_nat(uint64_t);
lean_object* l_Lean_bignumToJson(lean_object*);
lean_object* lean_mk_empty_array_with_capacity(lean_object*);
lean_object* l___private_Init_Data_List_Impl_0__List_flatMapTR_go___at___00Lean_Linter_CodeQuality_instToJsonEntry_toJson_spec__0(lean_object*, lean_object*);
lean_object* l_Lean_Json_mkObj(lean_object*);
lean_object* lean_array_fget(lean_object*, lean_object*);
uint8_t lean_nat_dec_lt(lean_object*, lean_object*);
lean_object* lean_array_fswap(lean_object*, lean_object*, lean_object*);
lean_object* lean_array_fget_borrowed(lean_object*, lean_object*);
lean_object* l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(lean_object*, uint8_t);
uint8_t lean_string_dec_lt(lean_object*, lean_object*);
lean_object* lean_nat_add(lean_object*, lean_object*);
uint8_t lean_nat_dec_le(lean_object*, lean_object*);
lean_object* lean_nat_shiftr(lean_object*, lean_object*);
lean_object* lean_nat_mod(lean_object*, lean_object*);
uint8_t lean_nat_dec_eq(lean_object*, lean_object*);
lean_object* l_Lean_Name_mkStr2(lean_object*, lean_object*);
lean_object* l_Lean_Name_mkStr1(lean_object*);
extern lean_object* l_Lean_Options_empty;
lean_object* l_Lean_Options_set___at___00Lean_Option_set___at___00__private_Lean_Shell_0__Lean_ShellOptions_process_spec__2_spec__3(lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Options_set___at___00Lean_Option_set___at___00__private_Lean_Shell_0__Lean_ShellOptions_process_spec__1_spec__1(lean_object*, lean_object*, uint8_t);
lean_object* l_Lean_Elab_Command_mkState(lean_object*, lean_object*, lean_object*);
lean_object* lean_st_mk_ref(lean_object*);
lean_object* l_Lean_Elab_Frontend_updateCmdPos___redArg(lean_object*);
lean_object* lean_st_ref_get(lean_object*);
extern lean_object* l_Lean_Elab_Command_instInhabitedScope_default;
lean_object* l_List_head_x21___redArg(lean_object*, lean_object*);
lean_object* l_Lean_Parser_parseCommand(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lean_st_ref_take(lean_object*);
lean_object* lean_array_push(lean_object*, lean_object*);
lean_object* lean_st_ref_set(lean_object*, lean_object*);
lean_object* l_Lean_Elab_Frontend_setParserState___redArg(lean_object*, lean_object*);
lean_object* l_Lean_Elab_Frontend_setMessages___redArg(lean_object*, lean_object*);
lean_object* lean_io_get_num_heartbeats();
lean_object* l_Lean_Elab_Frontend_elabCommandAtFrontend(lean_object*, lean_object*, lean_object*);
lean_object* lean_nat_sub(lean_object*, lean_object*);
uint64_t lean_uint64_sub(uint64_t, uint64_t);
lean_object* l_Lean_Syntax_getKind(lean_object*);
lean_object* l_Lean_MessageLog_toArray(lean_object*);
lean_object* l_Array_append___redArg(lean_object*, lean_object*);
uint8_t l_Lean_Parser_isTerminalCommand(lean_object*);
lean_object* l_Lean_Array_toJson___at___00Lean_Server_Test_Runner_Client_instToJsonHyp_toJson_spec__1(lean_object*);
lean_object* l_Lean_Array_toJson___at___00Lean_Server_FileWorker_handlePreRequestSpecialCases_x3f_spec__6(lean_object*);
size_t lean_array_size(lean_object*);
size_t lean_usize_add(size_t, size_t);
uint8_t lean_usize_dec_lt(size_t, size_t);
lean_object* lean_array_uget_borrowed(lean_object*, size_t);
uint8_t l_Lean_instBEqMessageSeverity_beq(uint8_t, uint8_t);
lean_object* l_Lean_MessageData_toString(lean_object*);
lean_object* l_Lean_Environment_constants(lean_object*);
lean_object* l_Lean_PersistentHashMap_toList___at___00__private_Lean_Linter_TacticTypeCheck_0__Lean_Linter_tacticCheckInstances_spec__6___redArg(lean_object*);
extern lean_object* l___private_Lean_Util_CollectAxioms_0__Lean_instInhabitedExportedAxiomsState;
lean_object* l_Lean_Environment_setExporting(lean_object*, uint8_t);
extern lean_object* l___private_Lean_Util_CollectAxioms_0__Lean_exportedAxiomsExt;
lean_object* l_Lean_PersistentEnvExtension_getState___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l___private_Lean_Util_CollectAxioms_0__Lean_ExportedAxiomsState_find_x3f___boxed(lean_object*, lean_object*, lean_object*);
lean_object* l___private_Lean_Util_CollectAxioms_0__Lean_CollectAxioms_collectAndGet___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l___private_Lean_Util_CollectAxioms_0__Lean_CollectAxioms_runM___redArg(lean_object*, lean_object*);
uint8_t l_Array_contains___at___00__private_Lean_Linter_CheckUnivs_0__Lean_Linter_CheckUnivs_badParams_spec__0(lean_object*, lean_object*);
lean_object* l_Lean_Kernel_enableDiag(lean_object*, uint8_t);
uint8_t l_Lean_Environment_contains(lean_object*, lean_object*, uint8_t);
lean_object* l_Lean_PersistentHashMap_mkEmptyEntriesArray(lean_object*, lean_object*);
extern lean_object* l_Lean_inheritedTraceOptions;
lean_object* l_Lean_Core_getMaxHeartbeats(lean_object*);
extern lean_object* l_Lean_diagnostics;
uint8_t l_Lean_Option_get___at___00Lean_Elab_addMacroStack___at___00Lean_throwError___at___00Lean_throwErrorAt___at___00Lean_throwUnknownIdentifierAt___at___00Lean_throwUnknownConstantAt___at___00Lean_throwUnknownConstant___at___00Lean_getConstVal___at___00Lean_mkConstWithLevelParams___at___00Lean_Elab_addConstInfo___at___00Lean_Elab_PostprocessTraces_elabStoreTraceAs_spec__3_spec__5_spec__6_spec__9_spec__12_spec__14_spec__16_spec__18_spec__20_spec__21(lean_object*, lean_object*);
uint8_t l_Lean_Kernel_isDiagnosticsEnabled(lean_object*);
lean_object* l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00__private_Lean_Elab_DocString_Builtin_0__Lean_Doc_validateCat_spec__3___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
uint64_t lean_io_get_tid();
lean_object* lean_array_get_size(lean_object*);
extern lean_object* l_Lean_instInhabitedTheoremVal_default;
lean_object* lean_array_get_borrowed(lean_object*, lean_object*, lean_object*);
lean_object* lean_io_mono_nanos_now();
lean_object* l_Nat_reprFast(lean_object*);
lean_object* lean_string_append(lean_object*, lean_object*);
lean_object* l_Lean_Name_str___override(lean_object*, lean_object*);
lean_object* lean_add_decl(lean_object*, size_t, size_t, lean_object*, lean_object*);
lean_object* l_Lean_Kernel_Exception_toMessageData(lean_object*, lean_object*);
lean_object* l_IO_Promise_result_x21___redArg(lean_object*);
lean_object* lean_io_wait(lean_object*);
lean_object* lean_io_as_task(lean_object*, lean_object*);
lean_object* l_Lean_Environment_getModuleIdxFor_x3f(lean_object*, lean_object*);
uint8_t lean_string_dec_eq(lean_object*, lean_object*);
lean_object* l_Lean_Expr_cleanupAnnotations(lean_object*);
lean_object* l_Lean_Expr_getAppFn(lean_object*);
uint8_t l_Lean_Expr_isConstOf(lean_object*, lean_object*);
uint8_t lean_usize_dec_eq(size_t, size_t);
uint8_t lean_name_eq(lean_object*, lean_object*);
uint8_t l_Lean_Expr_hasMVar(lean_object*);
uint8_t l_Lean_Expr_hasFVar(lean_object*);
uint8_t l_Lean_Expr_hasSorry(lean_object*);
lean_object* lean_nat_mul(lean_object*, lean_object*);
lean_object* lean_nat_div(lean_object*, lean_object*);
lean_object* l_Lean_Json_compress(lean_object*);
lean_object* l_IO_println___at___00__private_Lean_Shell_0__Lean_ShellOptions_process_spec__3(lean_object*);
lean_object* lean_string_utf8_byte_size(lean_object*);
lean_object* l_String_Slice_toNat_x21(lean_object*);
uint8_t l_List_elem___at___00Lean_Meta_Grind_Arith_Cutsat_checkElimEqs_spec__0(lean_object*, lean_object*);
lean_object* lean_io_promise_new();
lean_object* lean_elab_environment_to_kernel_env(lean_object*);
lean_object* lean_io_promise_resolve(lean_object*, lean_object*);
lean_object* lean_task_get_own(lean_object*);
lean_object* lean_array_uset(lean_object*, size_t, lean_object*);
size_t lean_usize_of_nat(lean_object*);
lean_object* l_Lean_findSysroot(lean_object*);
lean_object* l_Lean_initSearchPath(lean_object*, lean_object*);
lean_object* lean_enable_initializer_execution();
lean_object* l_String_toName(lean_object*);
uint8_t lean_string_memcmp(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_importModules(lean_object*, lean_object*, uint32_t, lean_object*, uint8_t, uint8_t, uint8_t, lean_object*);
lean_object* l_Lean_Environment_getModuleIdx_x3f(lean_object*, lean_object*);
lean_object* l_Lean_SMap_toList___at___00__private_Lean_Elab_DocString_Builtin_0__Lean_Doc_getQualified_spec__1___redArg(lean_object*);
lean_object* l_IO_FS_readFile(lean_object*);
lean_object* l_Lean_Parser_mkInputContext___redArg(lean_object*, lean_object*, uint8_t, lean_object*);
lean_object* l_Lean_Parser_parseHeader(lean_object*);
lean_object* l_Lean_Elab_HeaderSyntax_imports(lean_object*, uint8_t);
lean_object* l_Lean_Environment_setMainModule(lean_object*, lean_object*);
lean_object* rv_thread_cpu_ns();
LEAN_EXPORT lean_object* l_threadCpuNs___boxed(lean_object*);
static const lean_string_object l_instToJsonUnitRow_toJson___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 7, .m_capacity = 7, .m_length = 6, .m_data = "target"};
static const lean_object* l_instToJsonUnitRow_toJson___closed__0 = (const lean_object*)&l_instToJsonUnitRow_toJson___closed__0_value;
static const lean_string_object l_instToJsonUnitRow_toJson___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 6, .m_capacity = 6, .m_length = 5, .m_data = "rawHB"};
static const lean_object* l_instToJsonUnitRow_toJson___closed__1 = (const lean_object*)&l_instToJsonUnitRow_toJson___closed__1_value;
static const lean_string_object l_instToJsonUnitRow_toJson___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 6, .m_capacity = 6, .m_length = 5, .m_data = "cpuNS"};
static const lean_object* l_instToJsonUnitRow_toJson___closed__2 = (const lean_object*)&l_instToJsonUnitRow_toJson___closed__2_value;
static const lean_string_object l_instToJsonUnitRow_toJson___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 7, .m_capacity = 7, .m_length = 6, .m_data = "wallNS"};
static const lean_object* l_instToJsonUnitRow_toJson___closed__3 = (const lean_object*)&l_instToJsonUnitRow_toJson___closed__3_value;
static const lean_string_object l_instToJsonUnitRow_toJson___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 8, .m_capacity = 8, .m_length = 7, .m_data = "verdict"};
static const lean_object* l_instToJsonUnitRow_toJson___closed__4 = (const lean_object*)&l_instToJsonUnitRow_toJson___closed__4_value;
static const lean_string_object l_instToJsonUnitRow_toJson___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 6, .m_capacity = 6, .m_length = 5, .m_data = "error"};
static const lean_object* l_instToJsonUnitRow_toJson___closed__5 = (const lean_object*)&l_instToJsonUnitRow_toJson___closed__5_value;
static const lean_string_object l_instToJsonUnitRow_toJson___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 4, .m_capacity = 4, .m_length = 3, .m_data = "tid"};
static const lean_object* l_instToJsonUnitRow_toJson___closed__6 = (const lean_object*)&l_instToJsonUnitRow_toJson___closed__6_value;
static const lean_array_object l_instToJsonUnitRow_toJson___closed__7_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_array_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 246}, .m_size = 0, .m_capacity = 0, .m_data = {}};
static const lean_object* l_instToJsonUnitRow_toJson___closed__7 = (const lean_object*)&l_instToJsonUnitRow_toJson___closed__7_value;
LEAN_EXPORT lean_object* l_instToJsonUnitRow_toJson(lean_object*);
static const lean_closure_object l_instToJsonUnitRow___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_instToJsonUnitRow_toJson, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* l_instToJsonUnitRow___closed__0 = (const lean_object*)&l_instToJsonUnitRow___closed__0_value;
LEAN_EXPORT const lean_object* l_instToJsonUnitRow = (const lean_object*)&l_instToJsonUnitRow___closed__0_value;
static const lean_ctor_object l_checked___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* l_checked___closed__0 = (const lean_object*)&l_checked___closed__0_value;
LEAN_EXPORT lean_object* l_checked(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_checked___boxed(lean_object*, lean_object*, lean_object*);
static const lean_string_object l_one___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 12, .m_capacity = 12, .m_length = 11, .m_data = "ReproKernel"};
static const lean_object* l_one___closed__0 = (const lean_object*)&l_one___closed__0_value;
static const lean_ctor_object l_one___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&l_one___closed__0_value),LEAN_SCALAR_PTR_LITERAL(66, 164, 223, 236, 0, 168, 114, 232)}};
static const lean_object* l_one___closed__1 = (const lean_object*)&l_one___closed__1_value;
static const lean_string_object l_one___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "unit"};
static const lean_object* l_one___closed__2 = (const lean_object*)&l_one___closed__2_value;
static const lean_string_object l_one___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 13, .m_capacity = 13, .m_length = 12, .m_data = "kernel_error"};
static const lean_object* l_one___closed__3 = (const lean_object*)&l_one___closed__3_value;
static const lean_string_object l_one___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 9, .m_capacity = 9, .m_length = 8, .m_data = "accepted"};
static const lean_object* l_one___closed__4 = (const lean_object*)&l_one___closed__4_value;
static const lean_string_object l_one___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 1, .m_capacity = 1, .m_length = 0, .m_data = ""};
static const lean_object* l_one___closed__5 = (const lean_object*)&l_one___closed__5_value;
LEAN_EXPORT lean_object* l_one(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_one___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static lean_once_cell_t l_commands___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_commands___closed__0;
static lean_once_cell_t l_commands___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_commands___closed__1;
static lean_once_cell_t l_commands___closed__2_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_commands___closed__2;
static const lean_string_object l_commands___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 6, .m_capacity = 6, .m_length = 5, .m_data = "start"};
static const lean_object* l_commands___closed__3 = (const lean_object*)&l_commands___closed__3_value;
static const lean_string_object l_commands___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 4, .m_capacity = 4, .m_length = 3, .m_data = "end"};
static const lean_object* l_commands___closed__4 = (const lean_object*)&l_commands___closed__4_value;
static const lean_string_object l_commands___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "kind"};
static const lean_object* l_commands___closed__5 = (const lean_object*)&l_commands___closed__5_value;
LEAN_EXPORT lean_object* l_commands(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_commands___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Lean_collectAxioms___at___00elaborateOne_spec__1___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Lean_collectAxioms___at___00elaborateOne_spec__1___redArg___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Lean_collectAxioms___at___00elaborateOne_spec__1(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Lean_collectAxioms___at___00elaborateOne_spec__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00elaborateOne_spec__0(lean_object*, size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00elaborateOne_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_string_object l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 8, .m_capacity = 8, .m_length = 7, .m_data = "sorryAx"};
static const lean_object* l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__0 = (const lean_object*)&l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__0_value;
static const lean_ctor_object l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__0_value),LEAN_SCALAR_PTR_LITERAL(196, 190, 164, 146, 38, 179, 69, 72)}};
static const lean_object* l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__1 = (const lean_object*)&l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__1_value;
static lean_once_cell_t l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__2_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__2;
static lean_once_cell_t l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__3_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__3;
static lean_once_cell_t l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__4_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__4;
static const lean_string_object l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 6, .m_capacity = 6, .m_length = 5, .m_data = "_uniq"};
static const lean_object* l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__5 = (const lean_object*)&l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__5_value;
static const lean_ctor_object l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__5_value),LEAN_SCALAR_PTR_LITERAL(237, 141, 162, 170, 202, 74, 55, 55)}};
static const lean_object* l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__6 = (const lean_object*)&l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__6_value;
static const lean_ctor_object l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__7_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)&l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__6_value),((lean_object*)(((size_t)(1) << 1) | 1))}};
static const lean_object* l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__7 = (const lean_object*)&l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__7_value;
static const lean_ctor_object l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__8_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*3 + 0, .m_other = 3, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)(((size_t)(1) << 1) | 1)),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__8 = (const lean_object*)&l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__8_value;
static lean_once_cell_t l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__9_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__9;
static lean_once_cell_t l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__10_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__10;
static const lean_array_object l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__11_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_array_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 246}, .m_size = 0, .m_capacity = 0, .m_data = {}};
static const lean_object* l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__11 = (const lean_object*)&l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__11_value;
static lean_once_cell_t l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__12_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__12;
static lean_once_cell_t l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__13_once = LEAN_ONCE_CELL_INITIALIZER;
static uint8_t l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__13;
LEAN_EXPORT lean_object* l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_string_object l_elaborateOne___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 14, .m_capacity = 14, .m_length = 13, .m_data = "maxHeartbeats"};
static const lean_object* l_elaborateOne___closed__0 = (const lean_object*)&l_elaborateOne___closed__0_value;
static const lean_ctor_object l_elaborateOne___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&l_elaborateOne___closed__0_value),LEAN_SCALAR_PTR_LITERAL(163, 202, 216, 251, 148, 187, 135, 206)}};
static const lean_object* l_elaborateOne___closed__1 = (const lean_object*)&l_elaborateOne___closed__1_value;
static lean_once_cell_t l_elaborateOne___closed__2_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_elaborateOne___closed__2;
static const lean_string_object l_elaborateOne___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 12, .m_capacity = 12, .m_length = 11, .m_data = "maxRecDepth"};
static const lean_object* l_elaborateOne___closed__3 = (const lean_object*)&l_elaborateOne___closed__3_value;
static const lean_ctor_object l_elaborateOne___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&l_elaborateOne___closed__3_value),LEAN_SCALAR_PTR_LITERAL(213, 238, 178, 82, 0, 139, 185, 177)}};
static const lean_object* l_elaborateOne___closed__4 = (const lean_object*)&l_elaborateOne___closed__4_value;
static lean_once_cell_t l_elaborateOne___closed__5_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_elaborateOne___closed__5;
static const lean_string_object l_elaborateOne___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "Elab"};
static const lean_object* l_elaborateOne___closed__6 = (const lean_object*)&l_elaborateOne___closed__6_value;
static const lean_string_object l_elaborateOne___closed__7_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 6, .m_capacity = 6, .m_length = 5, .m_data = "async"};
static const lean_object* l_elaborateOne___closed__7 = (const lean_object*)&l_elaborateOne___closed__7_value;
static const lean_ctor_object l_elaborateOne___closed__8_value_aux_0 = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&l_elaborateOne___closed__6_value),LEAN_SCALAR_PTR_LITERAL(13, 84, 199, 228, 250, 36, 60, 178)}};
static const lean_ctor_object l_elaborateOne___closed__8_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&l_elaborateOne___closed__8_value_aux_0),((lean_object*)&l_elaborateOne___closed__7_value),LEAN_SCALAR_PTR_LITERAL(6, 0, 36, 68, 138, 2, 151, 20)}};
static const lean_object* l_elaborateOne___closed__8 = (const lean_object*)&l_elaborateOne___closed__8_value;
static lean_once_cell_t l_elaborateOne___closed__9_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* l_elaborateOne___closed__9;
static const lean_array_object l_elaborateOne___closed__10_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_array_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 246}, .m_size = 0, .m_capacity = 0, .m_data = {}};
static const lean_object* l_elaborateOne___closed__10 = (const lean_object*)&l_elaborateOne___closed__10_value;
static const lean_string_object l_elaborateOne___closed__11_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 9, .m_capacity = 9, .m_length = 8, .m_data = "commands"};
static const lean_object* l_elaborateOne___closed__11 = (const lean_object*)&l_elaborateOne___closed__11_value;
static const lean_string_object l_elaborateOne___closed__12_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 6, .m_capacity = 6, .m_length = 5, .m_data = "scope"};
static const lean_object* l_elaborateOne___closed__12 = (const lean_object*)&l_elaborateOne___closed__12_value;
static const lean_string_object l_elaborateOne___closed__13_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 105, .m_capacity = 105, .m_length = 104, .m_data = "synchronous full-source elaboration; command CPU includes tactics and kernel; not stock async task total"};
static const lean_object* l_elaborateOne___closed__13 = (const lean_object*)&l_elaborateOne___closed__13_value;
static const lean_ctor_object l_elaborateOne___closed__14_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&l_elaborateOne___closed__13_value)}};
static const lean_object* l_elaborateOne___closed__14 = (const lean_object*)&l_elaborateOne___closed__14_value;
static const lean_ctor_object l_elaborateOne___closed__15_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)&l_elaborateOne___closed__12_value),((lean_object*)&l_elaborateOne___closed__14_value)}};
static const lean_object* l_elaborateOne___closed__15 = (const lean_object*)&l_elaborateOne___closed__15_value;
static const lean_ctor_object l_elaborateOne___closed__16_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&l_elaborateOne___closed__15_value),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* l_elaborateOne___closed__16 = (const lean_object*)&l_elaborateOne___closed__16_value;
static const lean_ctor_object l_elaborateOne___closed__17_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)&l_elaborateOne___closed__10_value),((lean_object*)&l_elaborateOne___closed__10_value)}};
static const lean_object* l_elaborateOne___closed__17 = (const lean_object*)&l_elaborateOne___closed__17_value;
static const lean_ctor_object l_elaborateOne___closed__18_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)&l_elaborateOne___closed__10_value),((lean_object*)&l_elaborateOne___closed__17_value)}};
static const lean_object* l_elaborateOne___closed__18 = (const lean_object*)&l_elaborateOne___closed__18_value;
static const lean_string_object l_elaborateOne___closed__19_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 7, .m_capacity = 7, .m_length = 6, .m_data = "module"};
static const lean_object* l_elaborateOne___closed__19 = (const lean_object*)&l_elaborateOne___closed__19_value;
static const lean_string_object l_elaborateOne___closed__20_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 8, .m_capacity = 8, .m_length = 7, .m_data = "workers"};
static const lean_object* l_elaborateOne___closed__20 = (const lean_object*)&l_elaborateOne___closed__20_value;
static const lean_string_object l_elaborateOne___closed__21_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 6, .m_capacity = 6, .m_length = 5, .m_data = "index"};
static const lean_object* l_elaborateOne___closed__21 = (const lean_object*)&l_elaborateOne___closed__21_value;
static const lean_string_object l_elaborateOne___closed__22_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 7, .m_capacity = 7, .m_length = 6, .m_data = "errors"};
static const lean_object* l_elaborateOne___closed__22 = (const lean_object*)&l_elaborateOne___closed__22_value;
static const lean_string_object l_elaborateOne___closed__23_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 6, .m_capacity = 6, .m_length = 5, .m_data = "sorry"};
static const lean_object* l_elaborateOne___closed__23 = (const lean_object*)&l_elaborateOne___closed__23_value;
static const lean_string_object l_elaborateOne___closed__24_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 11, .m_capacity = 11, .m_length = 10, .m_data = "new_axioms"};
static const lean_object* l_elaborateOne___closed__24 = (const lean_object*)&l_elaborateOne___closed__24_value;
static const lean_string_object l_elaborateOne___closed__25_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 9, .m_capacity = 9, .m_length = 8, .m_data = "theorems"};
static const lean_object* l_elaborateOne___closed__25 = (const lean_object*)&l_elaborateOne___closed__25_value;
static const lean_string_object l_elaborateOne___closed__26_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 11, .m_capacity = 11, .m_length = 10, .m_data = "incomplete"};
static const lean_object* l_elaborateOne___closed__26 = (const lean_object*)&l_elaborateOne___closed__26_value;
static const lean_string_object l_elaborateOne___closed__27_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 11, .m_capacity = 11, .m_length = 10, .m_data = "lean_error"};
static const lean_object* l_elaborateOne___closed__27 = (const lean_object*)&l_elaborateOne___closed__27_value;
LEAN_EXPORT lean_object* l_elaborateOne(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_elaborateOne___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_forIn_x27_loop___at___00elaborateOne_spec__2(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_forIn_x27_loop___at___00elaborateOne_spec__2___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t l_Option_instBEq_beq___at___00main_spec__1(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Option_instBEq_beq___at___00main_spec__1___boxed(lean_object*, lean_object*);
static const lean_string_object l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__3___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 27, .m_capacity = 27, .m_length = 26, .m_data = "not a closed checked input"};
static const lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__3___closed__0 = (const lean_object*)&l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__3___closed__0_value;
static const lean_ctor_object l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__3___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__3___closed__0_value)}};
static const lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__3___closed__1 = (const lean_object*)&l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__3___closed__1_value;
static const lean_string_object l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__3___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 6, .m_capacity = 6, .m_length = 5, .m_data = "front"};
static const lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__3___closed__2 = (const lean_object*)&l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__3___closed__2_value;
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__3(lean_object*, lean_object*, size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__3___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_string_object l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__16___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 7, .m_capacity = 7, .m_length = 6, .m_data = "FRONT "};
static const lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__16___closed__0 = (const lean_object*)&l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__16___closed__0_value;
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__16(lean_object*, size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__16___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__17(lean_object*, size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__17___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00main_spec__12(lean_object*, lean_object*, size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00main_spec__12___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_QSort_Basic_0__Array_qpartition_loop___at___00__private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__8_spec__10___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_QSort_Basic_0__Array_qpartition_loop___at___00__private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__8_spec__10___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__8___redArg___lam__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__8___redArg___lam__0___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__8___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__8___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_string_object l_List_forIn_x27_loop___at___00List_forIn_x27_loop___at___00main_spec__2_spec__2___redArg___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 18, .m_capacity = 18, .m_length = 17, .m_data = "of_decide_eq_true"};
static const lean_object* l_List_forIn_x27_loop___at___00List_forIn_x27_loop___at___00main_spec__2_spec__2___redArg___closed__0 = (const lean_object*)&l_List_forIn_x27_loop___at___00List_forIn_x27_loop___at___00main_spec__2_spec__2___redArg___closed__0_value;
static const lean_ctor_object l_List_forIn_x27_loop___at___00List_forIn_x27_loop___at___00main_spec__2_spec__2___redArg___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&l_List_forIn_x27_loop___at___00List_forIn_x27_loop___at___00main_spec__2_spec__2___redArg___closed__0_value),LEAN_SCALAR_PTR_LITERAL(199, 143, 142, 104, 169, 34, 63, 25)}};
static const lean_object* l_List_forIn_x27_loop___at___00List_forIn_x27_loop___at___00main_spec__2_spec__2___redArg___closed__1 = (const lean_object*)&l_List_forIn_x27_loop___at___00List_forIn_x27_loop___at___00main_spec__2_spec__2___redArg___closed__1_value;
LEAN_EXPORT lean_object* l_List_forIn_x27_loop___at___00List_forIn_x27_loop___at___00main_spec__2_spec__2___redArg(lean_object*, lean_object*, uint8_t, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_forIn_x27_loop___at___00List_forIn_x27_loop___at___00main_spec__2_spec__2___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_forIn_x27_loop___at___00main_spec__2___redArg(lean_object*, lean_object*, uint8_t, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_forIn_x27_loop___at___00main_spec__2___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_string_object l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__7___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 8, .m_capacity = 8, .m_length = 7, .m_data = "KERNEL "};
static const lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__7___closed__0 = (const lean_object*)&l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__7___closed__0_value;
static const lean_string_object l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__7___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 9, .m_capacity = 9, .m_length = 8, .m_data = "eligible"};
static const lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__7___closed__1 = (const lean_object*)&l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__7___closed__1_value;
static const lean_string_object l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__7___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 9, .m_capacity = 9, .m_length = 8, .m_data = "selected"};
static const lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__7___closed__2 = (const lean_object*)&l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__7___closed__2_value;
static const lean_string_object l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__7___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 7, .m_capacity = 7, .m_length = 6, .m_data = "result"};
static const lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__7___closed__3 = (const lean_object*)&l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__7___closed__3_value;
static const lean_string_object l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__7___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 18, .m_capacity = 18, .m_length = 17, .m_data = "kernel_poll_count"};
static const lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__7___closed__4 = (const lean_object*)&l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__7___closed__4_value;
static const lean_ctor_object l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__7___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)&l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__7___closed__4_value),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__7___closed__5 = (const lean_object*)&l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__7___closed__5_value;
static const lean_ctor_object l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__7___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__7___closed__5_value),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__7___closed__6 = (const lean_object*)&l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__7___closed__6_value;
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__7(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__7___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_QSort_Basic_0__Array_qpartition_loop___at___00__private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__13_spec__16___redArg(uint8_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_QSort_Basic_0__Array_qpartition_loop___at___00__private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__13_spec__16___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__13___redArg___lam__0(uint8_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__13___redArg___lam__0___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__13___redArg(uint8_t, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__13___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__14___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__14___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__15___redArg___lam__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__15___redArg___lam__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__15_spec__19___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__15_spec__19___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__15___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__15___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00main_spec__9(uint8_t, size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00main_spec__9___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__4___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__4___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__5___redArg___lam__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__5___redArg___lam__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__5_spec__6___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__5_spec__6___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__5___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__5___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__10___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__10___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__6(lean_object*, size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__6___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_string_object l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__11___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 70, .m_capacity = 70, .m_length = 69, .m_data = "OAI.AtomicTriangular.FiniteCertificate.envelopeExpB16_calc._proof_1_1"};
static const lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__11___closed__0 = (const lean_object*)&l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__11___closed__0_value;
static const lean_ctor_object l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__11___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__11___closed__1 = (const lean_object*)&l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__11___closed__1_value;
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__11(uint8_t, lean_object*, size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__11___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t l_List_any___at___00main_spec__0(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_any___at___00main_spec__0___boxed(lean_object*, lean_object*, lean_object*);
static const lean_string_object l_main___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 56, .m_capacity = 56, .m_length = 55, .m_data = "usage: ModuleProbe (kernel|front) MODULE SOURCE WORKERS"};
static const lean_object* l_main___closed__0 = (const lean_object*)&l_main___closed__0_value;
static const lean_ctor_object l_main___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&l_main___closed__0_value)}};
static const lean_object* l_main___closed__1 = (const lean_object*)&l_main___closed__1_value;
static const lean_ctor_object l_main___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(8) << 1) | 1)),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* l_main___closed__2 = (const lean_object*)&l_main___closed__2_value;
static const lean_ctor_object l_main___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(4) << 1) | 1)),((lean_object*)&l_main___closed__2_value)}};
static const lean_object* l_main___closed__3 = (const lean_object*)&l_main___closed__3_value;
static const lean_ctor_object l_main___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(2) << 1) | 1)),((lean_object*)&l_main___closed__3_value)}};
static const lean_object* l_main___closed__4 = (const lean_object*)&l_main___closed__4_value;
static const lean_ctor_object l_main___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(1) << 1) | 1)),((lean_object*)&l_main___closed__4_value)}};
static const lean_object* l_main___closed__5 = (const lean_object*)&l_main___closed__5_value;
static const lean_string_object l_main___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 10, .m_capacity = 10, .m_length = 9, .m_data = "inventory"};
static const lean_object* l_main___closed__6 = (const lean_object*)&l_main___closed__6_value;
static const lean_array_object l_main___closed__7_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_array_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 246}, .m_size = 0, .m_capacity = 0, .m_data = {}};
static const lean_object* l_main___closed__7 = (const lean_object*)&l_main___closed__7_value;
static const lean_string_object l_main___closed__8_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 11, .m_capacity = 11, .m_length = 10, .m_data = "INVENTORY "};
static const lean_object* l_main___closed__8 = (const lean_object*)&l_main___closed__8_value;
static const lean_string_object l_main___closed__9_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 8, .m_capacity = 8, .m_length = 7, .m_data = "targets"};
static const lean_object* l_main___closed__9 = (const lean_object*)&l_main___closed__9_value;
static const lean_ctor_object l_main___closed__10_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&l_elaborateOne___closed__20_value)}};
static const lean_object* l_main___closed__10 = (const lean_object*)&l_main___closed__10_value;
static const lean_string_object l_main___closed__11_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "lean"};
static const lean_object* l_main___closed__11 = (const lean_object*)&l_main___closed__11_value;
static const lean_string_object l_main___closed__12_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 6, .m_capacity = 6, .m_length = 5, .m_data = "only "};
static const lean_object* l_main___closed__12 = (const lean_object*)&l_main___closed__12_value;
static const lean_string_object l_main___closed__13_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 19, .m_capacity = 19, .m_length = 18, .m_data = " eligible theorems"};
static const lean_object* l_main___closed__13 = (const lean_object*)&l_main___closed__13_value;
static const lean_string_object l_main___closed__14_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "mode"};
static const lean_object* l_main___closed__14 = (const lean_object*)&l_main___closed__14_value;
static const lean_ctor_object l_main___closed__15_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&l_main___closed__14_value)}};
static const lean_object* l_main___closed__15 = (const lean_object*)&l_main___closed__15_value;
static const lean_array_object l_main___closed__16_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_array_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 246}, .m_size = 0, .m_capacity = 0, .m_data = {}};
static const lean_object* l_main___closed__16 = (const lean_object*)&l_main___closed__16_value;
static const lean_string_object l_main___closed__17_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 10, .m_capacity = 10, .m_length = 9, .m_data = "UMoments9"};
static const lean_object* l_main___closed__17 = (const lean_object*)&l_main___closed__17_value;
static const lean_string_object l_main___closed__18_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 14, .m_capacity = 14, .m_length = 13, .m_data = "BarrierData41"};
static const lean_object* l_main___closed__18 = (const lean_object*)&l_main___closed__18_value;
static const lean_string_object l_main___closed__19_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 13, .m_capacity = 13, .m_length = 12, .m_data = "EnvelopePsiB"};
static const lean_object* l_main___closed__19 = (const lean_object*)&l_main___closed__19_value;
static const lean_string_object l_main___closed__20_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 14, .m_capacity = 14, .m_length = 13, .m_data = "module absent"};
static const lean_object* l_main___closed__20 = (const lean_object*)&l_main___closed__20_value;
static const lean_ctor_object l_main___closed__21_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&l_main___closed__20_value)}};
static const lean_object* l_main___closed__21 = (const lean_object*)&l_main___closed__21_value;
static const lean_string_object l_main___closed__22_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 7, .m_capacity = 7, .m_length = 6, .m_data = "kernel"};
static const lean_object* l_main___closed__22 = (const lean_object*)&l_main___closed__22_value;
LEAN_EXPORT lean_object* l_main___boxed__const__1;
LEAN_EXPORT lean_object* _lean_main(lean_object*);
LEAN_EXPORT lean_object* l_main___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_forIn_x27_loop___at___00main_spec__2(lean_object*, lean_object*, uint8_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_forIn_x27_loop___at___00main_spec__2___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__4(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__4___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__5(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__5___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__8(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__8___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__10(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__10___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__13(uint8_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__13___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__14(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__14___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__15(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__15___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_forIn_x27_loop___at___00List_forIn_x27_loop___at___00main_spec__2_spec__2(lean_object*, lean_object*, uint8_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_forIn_x27_loop___at___00List_forIn_x27_loop___at___00main_spec__2_spec__2___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__5_spec__6(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__5_spec__6___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_QSort_Basic_0__Array_qpartition_loop___at___00__private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__8_spec__10(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_QSort_Basic_0__Array_qpartition_loop___at___00__private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__8_spec__10___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_QSort_Basic_0__Array_qpartition_loop___at___00__private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__13_spec__16(uint8_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Array_QSort_Basic_0__Array_qpartition_loop___at___00__private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__13_spec__16___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__15_spec__19(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__15_spec__19___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_threadCpuNs___boxed(lean_object* v_a_00___x40___internal___hyg_2_){
_start:
{
lean_object* v_res_3_; 
v_res_3_ = rv_thread_cpu_ns();
return v_res_3_;
}
}
LEAN_EXPORT lean_object* l_instToJsonUnitRow_toJson(lean_object* v_x_13_){
_start:
{
lean_object* v_target_14_; lean_object* v_rawHB_15_; uint64_t v_cpuNS_16_; lean_object* v_wallNS_17_; lean_object* v_verdict_18_; lean_object* v_error_19_; uint64_t v_tid_20_; lean_object* v___x_21_; lean_object* v___x_22_; lean_object* v___x_23_; lean_object* v___x_24_; lean_object* v___x_25_; lean_object* v___x_26_; lean_object* v___x_27_; lean_object* v___x_28_; lean_object* v___x_29_; lean_object* v___x_30_; lean_object* v___x_31_; lean_object* v___x_32_; lean_object* v___x_33_; lean_object* v___x_34_; lean_object* v___x_35_; lean_object* v___x_36_; lean_object* v___x_37_; lean_object* v___x_38_; lean_object* v___x_39_; lean_object* v___x_40_; lean_object* v___x_41_; lean_object* v___x_42_; lean_object* v___x_43_; lean_object* v___x_44_; lean_object* v___x_45_; lean_object* v___x_46_; lean_object* v___x_47_; lean_object* v___x_48_; lean_object* v___x_49_; lean_object* v___x_50_; lean_object* v___x_51_; lean_object* v___x_52_; lean_object* v___x_53_; lean_object* v___x_54_; lean_object* v___x_55_; lean_object* v___x_56_; lean_object* v___x_57_; lean_object* v___x_58_; lean_object* v___x_59_; lean_object* v___x_60_; lean_object* v___x_61_; lean_object* v___x_62_; lean_object* v___x_63_; 
v_target_14_ = lean_ctor_get(v_x_13_, 0);
lean_inc_ref(v_target_14_);
v_rawHB_15_ = lean_ctor_get(v_x_13_, 1);
lean_inc(v_rawHB_15_);
v_cpuNS_16_ = lean_ctor_get_uint64(v_x_13_, sizeof(void*)*5);
v_wallNS_17_ = lean_ctor_get(v_x_13_, 2);
lean_inc(v_wallNS_17_);
v_verdict_18_ = lean_ctor_get(v_x_13_, 3);
lean_inc_ref(v_verdict_18_);
v_error_19_ = lean_ctor_get(v_x_13_, 4);
lean_inc_ref(v_error_19_);
v_tid_20_ = lean_ctor_get_uint64(v_x_13_, sizeof(void*)*5 + 8);
lean_dec_ref(v_x_13_);
v___x_21_ = ((lean_object*)(l_instToJsonUnitRow_toJson___closed__0));
v___x_22_ = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(v___x_22_, 0, v_target_14_);
v___x_23_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_23_, 0, v___x_21_);
lean_ctor_set(v___x_23_, 1, v___x_22_);
v___x_24_ = lean_box(0);
v___x_25_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_25_, 0, v___x_23_);
lean_ctor_set(v___x_25_, 1, v___x_24_);
v___x_26_ = ((lean_object*)(l_instToJsonUnitRow_toJson___closed__1));
v___x_27_ = l_Lean_JsonNumber_fromNat(v_rawHB_15_);
v___x_28_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_28_, 0, v___x_27_);
v___x_29_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_29_, 0, v___x_26_);
lean_ctor_set(v___x_29_, 1, v___x_28_);
v___x_30_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_30_, 0, v___x_29_);
lean_ctor_set(v___x_30_, 1, v___x_24_);
v___x_31_ = ((lean_object*)(l_instToJsonUnitRow_toJson___closed__2));
v___x_32_ = lean_uint64_to_nat(v_cpuNS_16_);
v___x_33_ = l_Lean_bignumToJson(v___x_32_);
v___x_34_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_34_, 0, v___x_31_);
lean_ctor_set(v___x_34_, 1, v___x_33_);
v___x_35_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_35_, 0, v___x_34_);
lean_ctor_set(v___x_35_, 1, v___x_24_);
v___x_36_ = ((lean_object*)(l_instToJsonUnitRow_toJson___closed__3));
v___x_37_ = l_Lean_JsonNumber_fromNat(v_wallNS_17_);
v___x_38_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_38_, 0, v___x_37_);
v___x_39_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_39_, 0, v___x_36_);
lean_ctor_set(v___x_39_, 1, v___x_38_);
v___x_40_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_40_, 0, v___x_39_);
lean_ctor_set(v___x_40_, 1, v___x_24_);
v___x_41_ = ((lean_object*)(l_instToJsonUnitRow_toJson___closed__4));
v___x_42_ = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(v___x_42_, 0, v_verdict_18_);
v___x_43_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_43_, 0, v___x_41_);
lean_ctor_set(v___x_43_, 1, v___x_42_);
v___x_44_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_44_, 0, v___x_43_);
lean_ctor_set(v___x_44_, 1, v___x_24_);
v___x_45_ = ((lean_object*)(l_instToJsonUnitRow_toJson___closed__5));
v___x_46_ = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(v___x_46_, 0, v_error_19_);
v___x_47_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_47_, 0, v___x_45_);
lean_ctor_set(v___x_47_, 1, v___x_46_);
v___x_48_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_48_, 0, v___x_47_);
lean_ctor_set(v___x_48_, 1, v___x_24_);
v___x_49_ = ((lean_object*)(l_instToJsonUnitRow_toJson___closed__6));
v___x_50_ = lean_uint64_to_nat(v_tid_20_);
v___x_51_ = l_Lean_bignumToJson(v___x_50_);
v___x_52_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_52_, 0, v___x_49_);
lean_ctor_set(v___x_52_, 1, v___x_51_);
v___x_53_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_53_, 0, v___x_52_);
lean_ctor_set(v___x_53_, 1, v___x_24_);
v___x_54_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_54_, 0, v___x_53_);
lean_ctor_set(v___x_54_, 1, v___x_24_);
v___x_55_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_55_, 0, v___x_48_);
lean_ctor_set(v___x_55_, 1, v___x_54_);
v___x_56_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_56_, 0, v___x_44_);
lean_ctor_set(v___x_56_, 1, v___x_55_);
v___x_57_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_57_, 0, v___x_40_);
lean_ctor_set(v___x_57_, 1, v___x_56_);
v___x_58_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_58_, 0, v___x_35_);
lean_ctor_set(v___x_58_, 1, v___x_57_);
v___x_59_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_59_, 0, v___x_30_);
lean_ctor_set(v___x_59_, 1, v___x_58_);
v___x_60_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_60_, 0, v___x_25_);
lean_ctor_set(v___x_60_, 1, v___x_59_);
v___x_61_ = ((lean_object*)(l_instToJsonUnitRow_toJson___closed__7));
v___x_62_ = l___private_Init_Data_List_Impl_0__List_flatMapTR_go___at___00Lean_Linter_CodeQuality_instToJsonEntry_toJson_spec__0(v___x_60_, v___x_61_);
v___x_63_ = l_Lean_Json_mkObj(v___x_62_);
lean_dec(v___x_62_);
return v___x_63_;
}
}
LEAN_EXPORT lean_object* l_checked(lean_object* v_base_68_, lean_object* v_decl_69_){
_start:
{
size_t v___x_71_; size_t v___x_72_; lean_object* v___x_73_; lean_object* v___x_74_; 
v___x_71_ = ((size_t)2000000000ULL);
v___x_72_ = ((size_t)20000ULL);
v___x_73_ = lean_box(0);
v___x_74_ = lean_add_decl(v_base_68_, v___x_71_, v___x_72_, v_decl_69_, v___x_73_);
if (lean_obj_tag(v___x_74_) == 0)
{
lean_object* v_a_75_; lean_object* v___x_77_; uint8_t v_isShared_78_; uint8_t v_isSharedCheck_83_; 
v_a_75_ = lean_ctor_get(v___x_74_, 0);
v_isSharedCheck_83_ = !lean_is_exclusive(v___x_74_);
if (v_isSharedCheck_83_ == 0)
{
v___x_77_ = v___x_74_;
v_isShared_78_ = v_isSharedCheck_83_;
goto v_resetjp_76_;
}
else
{
lean_inc(v_a_75_);
lean_dec(v___x_74_);
v___x_77_ = lean_box(0);
v_isShared_78_ = v_isSharedCheck_83_;
goto v_resetjp_76_;
}
v_resetjp_76_:
{
lean_object* v___x_80_; 
if (v_isShared_78_ == 0)
{
v___x_80_ = v___x_77_;
goto v_reusejp_79_;
}
else
{
lean_object* v_reuseFailAlloc_82_; 
v_reuseFailAlloc_82_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_82_, 0, v_a_75_);
v___x_80_ = v_reuseFailAlloc_82_;
goto v_reusejp_79_;
}
v_reusejp_79_:
{
lean_object* v___x_81_; 
v___x_81_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_81_, 0, v___x_80_);
return v___x_81_;
}
}
}
else
{
lean_object* v___x_84_; lean_object* v___x_85_; 
lean_dec_ref_known(v___x_74_, 1);
v___x_84_ = ((lean_object*)(l_checked___closed__0));
v___x_85_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_85_, 0, v___x_84_);
return v___x_85_;
}
}
}
LEAN_EXPORT lean_object* l_checked___boxed(lean_object* v_base_86_, lean_object* v_decl_87_, lean_object* v_a_88_){
_start:
{
lean_object* v_res_89_; 
v_res_89_ = l_checked(v_base_86_, v_decl_87_);
lean_dec(v_decl_87_);
return v_res_89_;
}
}
LEAN_EXPORT lean_object* l_one(lean_object* v_base_97_, lean_object* v_v_98_, lean_object* v_i_99_){
_start:
{
lean_object* v_toConstantVal_101_; lean_object* v_value_102_; lean_object* v___x_104_; uint8_t v_isShared_105_; uint8_t v_isSharedCheck_187_; 
v_toConstantVal_101_ = lean_ctor_get(v_v_98_, 0);
v_value_102_ = lean_ctor_get(v_v_98_, 1);
v_isSharedCheck_187_ = !lean_is_exclusive(v_v_98_);
if (v_isSharedCheck_187_ == 0)
{
lean_object* v_unused_188_; 
v_unused_188_ = lean_ctor_get(v_v_98_, 2);
lean_dec(v_unused_188_);
v___x_104_ = v_v_98_;
v_isShared_105_ = v_isSharedCheck_187_;
goto v_resetjp_103_;
}
else
{
lean_inc(v_value_102_);
lean_inc(v_toConstantVal_101_);
lean_dec(v_v_98_);
v___x_104_ = lean_box(0);
v_isShared_105_ = v_isSharedCheck_187_;
goto v_resetjp_103_;
}
v_resetjp_103_:
{
lean_object* v_name_106_; lean_object* v_levelParams_107_; lean_object* v_type_108_; lean_object* v___x_110_; uint8_t v_isShared_111_; uint8_t v_isSharedCheck_186_; 
v_name_106_ = lean_ctor_get(v_toConstantVal_101_, 0);
v_levelParams_107_ = lean_ctor_get(v_toConstantVal_101_, 1);
v_type_108_ = lean_ctor_get(v_toConstantVal_101_, 2);
v_isSharedCheck_186_ = !lean_is_exclusive(v_toConstantVal_101_);
if (v_isSharedCheck_186_ == 0)
{
v___x_110_ = v_toConstantVal_101_;
v_isShared_111_ = v_isSharedCheck_186_;
goto v_resetjp_109_;
}
else
{
lean_inc(v_type_108_);
lean_inc(v_levelParams_107_);
lean_inc(v_name_106_);
lean_dec(v_toConstantVal_101_);
v___x_110_ = lean_box(0);
v_isShared_111_ = v_isSharedCheck_186_;
goto v_resetjp_109_;
}
v_resetjp_109_:
{
uint64_t v___x_112_; lean_object* v___x_113_; lean_object* v___x_114_; 
v___x_112_ = lean_io_get_tid();
v___x_113_ = lean_io_mono_nanos_now();
v___x_114_ = rv_thread_cpu_ns();
if (lean_obj_tag(v___x_114_) == 0)
{
lean_object* v_a_115_; lean_object* v___x_116_; lean_object* v___x_117_; lean_object* v___x_118_; lean_object* v___x_119_; lean_object* v___x_120_; lean_object* v_n_121_; lean_object* v___x_123_; 
v_a_115_ = lean_ctor_get(v___x_114_, 0);
lean_inc(v_a_115_);
lean_dec_ref_known(v___x_114_, 1);
v___x_116_ = lean_io_get_num_heartbeats();
v___x_117_ = ((lean_object*)(l_one___closed__1));
v___x_118_ = ((lean_object*)(l_one___closed__2));
v___x_119_ = l_Nat_reprFast(v_i_99_);
v___x_120_ = lean_string_append(v___x_118_, v___x_119_);
lean_dec_ref(v___x_119_);
v_n_121_ = l_Lean_Name_str___override(v___x_117_, v___x_120_);
lean_inc(v_n_121_);
if (v_isShared_111_ == 0)
{
lean_ctor_set(v___x_110_, 0, v_n_121_);
v___x_123_ = v___x_110_;
goto v_reusejp_122_;
}
else
{
lean_object* v_reuseFailAlloc_177_; 
v_reuseFailAlloc_177_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v_reuseFailAlloc_177_, 0, v_n_121_);
lean_ctor_set(v_reuseFailAlloc_177_, 1, v_levelParams_107_);
lean_ctor_set(v_reuseFailAlloc_177_, 2, v_type_108_);
v___x_123_ = v_reuseFailAlloc_177_;
goto v_reusejp_122_;
}
v_reusejp_122_:
{
lean_object* v___x_124_; lean_object* v___x_125_; lean_object* v___x_127_; 
v___x_124_ = lean_box(0);
v___x_125_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_125_, 0, v_n_121_);
lean_ctor_set(v___x_125_, 1, v___x_124_);
if (v_isShared_105_ == 0)
{
lean_ctor_set(v___x_104_, 2, v___x_125_);
lean_ctor_set(v___x_104_, 0, v___x_123_);
v___x_127_ = v___x_104_;
goto v_reusejp_126_;
}
else
{
lean_object* v_reuseFailAlloc_176_; 
v_reuseFailAlloc_176_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v_reuseFailAlloc_176_, 0, v___x_123_);
lean_ctor_set(v_reuseFailAlloc_176_, 1, v_value_102_);
lean_ctor_set(v_reuseFailAlloc_176_, 2, v___x_125_);
v___x_127_ = v_reuseFailAlloc_176_;
goto v_reusejp_126_;
}
v_reusejp_126_:
{
lean_object* v_decl_128_; lean_object* v___x_129_; lean_object* v_a_130_; lean_object* v___x_131_; lean_object* v___x_132_; 
v_decl_128_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v_decl_128_, 0, v___x_127_);
v___x_129_ = l_checked(v_base_97_, v_decl_128_);
lean_dec_ref_known(v_decl_128_, 1);
v_a_130_ = lean_ctor_get(v___x_129_, 0);
lean_inc(v_a_130_);
lean_dec_ref(v___x_129_);
v___x_131_ = lean_io_get_num_heartbeats();
v___x_132_ = rv_thread_cpu_ns();
if (lean_obj_tag(v___x_132_) == 0)
{
lean_object* v_a_133_; lean_object* v___x_135_; uint8_t v_isShared_136_; uint8_t v_isSharedCheck_167_; 
v_a_133_ = lean_ctor_get(v___x_132_, 0);
v_isSharedCheck_167_ = !lean_is_exclusive(v___x_132_);
if (v_isSharedCheck_167_ == 0)
{
v___x_135_ = v___x_132_;
v_isShared_136_ = v_isSharedCheck_167_;
goto v_resetjp_134_;
}
else
{
lean_inc(v_a_133_);
lean_dec(v___x_132_);
v___x_135_ = lean_box(0);
v_isShared_136_ = v_isSharedCheck_167_;
goto v_resetjp_134_;
}
v_resetjp_134_:
{
lean_object* v___x_137_; 
v___x_137_ = lean_io_mono_nanos_now();
if (lean_obj_tag(v_a_130_) == 0)
{
lean_object* v_a_138_; lean_object* v___x_139_; lean_object* v___x_140_; lean_object* v___x_141_; uint8_t v___x_142_; lean_object* v___x_143_; lean_object* v___x_144_; uint64_t v___x_145_; uint64_t v___x_146_; uint64_t v___x_147_; lean_object* v___x_148_; lean_object* v___x_149_; lean_object* v___x_150_; lean_object* v___x_152_; 
v_a_138_ = lean_ctor_get(v_a_130_, 0);
lean_inc(v_a_138_);
lean_dec_ref_known(v_a_130_, 1);
v___x_139_ = l_Lean_Options_empty;
v___x_140_ = l_Lean_Kernel_Exception_toMessageData(v_a_138_, v___x_139_);
v___x_141_ = l_Lean_MessageData_toString(v___x_140_);
v___x_142_ = 1;
v___x_143_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v_name_106_, v___x_142_);
v___x_144_ = lean_nat_sub(v___x_131_, v___x_116_);
lean_dec(v___x_116_);
lean_dec(v___x_131_);
v___x_145_ = lean_unbox_uint64(v_a_133_);
lean_dec(v_a_133_);
v___x_146_ = lean_unbox_uint64(v_a_115_);
lean_dec(v_a_115_);
v___x_147_ = lean_uint64_sub(v___x_145_, v___x_146_);
v___x_148_ = lean_nat_sub(v___x_137_, v___x_113_);
lean_dec(v___x_113_);
lean_dec(v___x_137_);
v___x_149_ = ((lean_object*)(l_one___closed__3));
v___x_150_ = lean_alloc_ctor(0, 5, 16);
lean_ctor_set(v___x_150_, 0, v___x_143_);
lean_ctor_set(v___x_150_, 1, v___x_144_);
lean_ctor_set(v___x_150_, 2, v___x_148_);
lean_ctor_set(v___x_150_, 3, v___x_149_);
lean_ctor_set(v___x_150_, 4, v___x_141_);
lean_ctor_set_uint64(v___x_150_, sizeof(void*)*5, v___x_147_);
lean_ctor_set_uint64(v___x_150_, sizeof(void*)*5 + 8, v___x_112_);
if (v_isShared_136_ == 0)
{
lean_ctor_set(v___x_135_, 0, v___x_150_);
v___x_152_ = v___x_135_;
goto v_reusejp_151_;
}
else
{
lean_object* v_reuseFailAlloc_153_; 
v_reuseFailAlloc_153_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_153_, 0, v___x_150_);
v___x_152_ = v_reuseFailAlloc_153_;
goto v_reusejp_151_;
}
v_reusejp_151_:
{
return v___x_152_;
}
}
else
{
uint8_t v___x_154_; lean_object* v___x_155_; lean_object* v___x_156_; uint64_t v___x_157_; uint64_t v___x_158_; uint64_t v___x_159_; lean_object* v___x_160_; lean_object* v___x_161_; lean_object* v___x_162_; lean_object* v___x_163_; lean_object* v___x_165_; 
lean_dec_ref_known(v_a_130_, 1);
v___x_154_ = 1;
v___x_155_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v_name_106_, v___x_154_);
v___x_156_ = lean_nat_sub(v___x_131_, v___x_116_);
lean_dec(v___x_116_);
lean_dec(v___x_131_);
v___x_157_ = lean_unbox_uint64(v_a_133_);
lean_dec(v_a_133_);
v___x_158_ = lean_unbox_uint64(v_a_115_);
lean_dec(v_a_115_);
v___x_159_ = lean_uint64_sub(v___x_157_, v___x_158_);
v___x_160_ = lean_nat_sub(v___x_137_, v___x_113_);
lean_dec(v___x_113_);
lean_dec(v___x_137_);
v___x_161_ = ((lean_object*)(l_one___closed__4));
v___x_162_ = ((lean_object*)(l_one___closed__5));
v___x_163_ = lean_alloc_ctor(0, 5, 16);
lean_ctor_set(v___x_163_, 0, v___x_155_);
lean_ctor_set(v___x_163_, 1, v___x_156_);
lean_ctor_set(v___x_163_, 2, v___x_160_);
lean_ctor_set(v___x_163_, 3, v___x_161_);
lean_ctor_set(v___x_163_, 4, v___x_162_);
lean_ctor_set_uint64(v___x_163_, sizeof(void*)*5, v___x_159_);
lean_ctor_set_uint64(v___x_163_, sizeof(void*)*5 + 8, v___x_112_);
if (v_isShared_136_ == 0)
{
lean_ctor_set(v___x_135_, 0, v___x_163_);
v___x_165_ = v___x_135_;
goto v_reusejp_164_;
}
else
{
lean_object* v_reuseFailAlloc_166_; 
v_reuseFailAlloc_166_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_166_, 0, v___x_163_);
v___x_165_ = v_reuseFailAlloc_166_;
goto v_reusejp_164_;
}
v_reusejp_164_:
{
return v___x_165_;
}
}
}
}
else
{
lean_object* v_a_168_; lean_object* v___x_170_; uint8_t v_isShared_171_; uint8_t v_isSharedCheck_175_; 
lean_dec(v___x_131_);
lean_dec(v_a_130_);
lean_dec(v___x_116_);
lean_dec(v_a_115_);
lean_dec(v___x_113_);
lean_dec(v_name_106_);
v_a_168_ = lean_ctor_get(v___x_132_, 0);
v_isSharedCheck_175_ = !lean_is_exclusive(v___x_132_);
if (v_isSharedCheck_175_ == 0)
{
v___x_170_ = v___x_132_;
v_isShared_171_ = v_isSharedCheck_175_;
goto v_resetjp_169_;
}
else
{
lean_inc(v_a_168_);
lean_dec(v___x_132_);
v___x_170_ = lean_box(0);
v_isShared_171_ = v_isSharedCheck_175_;
goto v_resetjp_169_;
}
v_resetjp_169_:
{
lean_object* v___x_173_; 
if (v_isShared_171_ == 0)
{
v___x_173_ = v___x_170_;
goto v_reusejp_172_;
}
else
{
lean_object* v_reuseFailAlloc_174_; 
v_reuseFailAlloc_174_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_174_, 0, v_a_168_);
v___x_173_ = v_reuseFailAlloc_174_;
goto v_reusejp_172_;
}
v_reusejp_172_:
{
return v___x_173_;
}
}
}
}
}
}
else
{
lean_object* v_a_178_; lean_object* v___x_180_; uint8_t v_isShared_181_; uint8_t v_isSharedCheck_185_; 
lean_dec(v___x_113_);
lean_del_object(v___x_110_);
lean_dec_ref(v_type_108_);
lean_dec(v_levelParams_107_);
lean_dec(v_name_106_);
lean_del_object(v___x_104_);
lean_dec_ref(v_value_102_);
lean_dec(v_i_99_);
lean_dec_ref(v_base_97_);
v_a_178_ = lean_ctor_get(v___x_114_, 0);
v_isSharedCheck_185_ = !lean_is_exclusive(v___x_114_);
if (v_isSharedCheck_185_ == 0)
{
v___x_180_ = v___x_114_;
v_isShared_181_ = v_isSharedCheck_185_;
goto v_resetjp_179_;
}
else
{
lean_inc(v_a_178_);
lean_dec(v___x_114_);
v___x_180_ = lean_box(0);
v_isShared_181_ = v_isSharedCheck_185_;
goto v_resetjp_179_;
}
v_resetjp_179_:
{
lean_object* v___x_183_; 
if (v_isShared_181_ == 0)
{
v___x_183_ = v___x_180_;
goto v_reusejp_182_;
}
else
{
lean_object* v_reuseFailAlloc_184_; 
v_reuseFailAlloc_184_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_184_, 0, v_a_178_);
v___x_183_ = v_reuseFailAlloc_184_;
goto v_reusejp_182_;
}
v_reusejp_182_:
{
return v___x_183_;
}
}
}
}
}
}
}
LEAN_EXPORT lean_object* l_one___boxed(lean_object* v_base_189_, lean_object* v_v_190_, lean_object* v_i_191_, lean_object* v_a_192_){
_start:
{
lean_object* v_res_193_; 
v_res_193_ = l_one(v_base_189_, v_v_190_, v_i_191_);
return v_res_193_;
}
}
static lean_object* _init_l_commands___closed__0(void){
_start:
{
lean_object* v___x_194_; lean_object* v___x_195_; lean_object* v___x_196_; 
v___x_194_ = lean_unsigned_to_nat(32u);
v___x_195_ = lean_mk_empty_array_with_capacity(v___x_194_);
v___x_196_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_196_, 0, v___x_195_);
return v___x_196_;
}
}
static lean_object* _init_l_commands___closed__1(void){
_start:
{
size_t v___x_197_; lean_object* v___x_198_; lean_object* v___x_199_; lean_object* v___x_200_; lean_object* v___x_201_; lean_object* v___x_202_; 
v___x_197_ = ((size_t)5ULL);
v___x_198_ = lean_unsigned_to_nat(0u);
v___x_199_ = lean_unsigned_to_nat(32u);
v___x_200_ = lean_mk_empty_array_with_capacity(v___x_199_);
v___x_201_ = lean_obj_once(&l_commands___closed__0, &l_commands___closed__0_once, _init_l_commands___closed__0);
v___x_202_ = lean_alloc_ctor(0, 4, sizeof(size_t)*1);
lean_ctor_set(v___x_202_, 0, v___x_201_);
lean_ctor_set(v___x_202_, 1, v___x_200_);
lean_ctor_set(v___x_202_, 2, v___x_198_);
lean_ctor_set(v___x_202_, 3, v___x_198_);
lean_ctor_set_usize(v___x_202_, 4, v___x_197_);
return v___x_202_;
}
}
static lean_object* _init_l_commands___closed__2(void){
_start:
{
lean_object* v___x_203_; lean_object* v___x_204_; lean_object* v___x_205_; 
v___x_203_ = lean_box(1);
v___x_204_ = lean_obj_once(&l_commands___closed__1, &l_commands___closed__1_once, _init_l_commands___closed__1);
v___x_205_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_205_, 0, v___x_204_);
lean_ctor_set(v___x_205_, 1, v___x_204_);
lean_ctor_set(v___x_205_, 2, v___x_203_);
return v___x_205_;
}
}
LEAN_EXPORT lean_object* l_commands(lean_object* v_rows_209_, lean_object* v_messages_210_, lean_object* v_a_211_, lean_object* v_a_212_){
_start:
{
lean_object* v___x_214_; 
v___x_214_ = l_Lean_Elab_Frontend_updateCmdPos___redArg(v_a_212_);
if (lean_obj_tag(v___x_214_) == 0)
{
lean_object* v___x_215_; lean_object* v_commandState_216_; lean_object* v_parserState_217_; lean_object* v___x_219_; uint8_t v_isShared_220_; uint8_t v_isSharedCheck_365_; 
lean_dec_ref_known(v___x_214_, 1);
v___x_215_ = lean_st_ref_get(v_a_212_);
v_commandState_216_ = lean_ctor_get(v___x_215_, 0);
v_parserState_217_ = lean_ctor_get(v___x_215_, 1);
v_isSharedCheck_365_ = !lean_is_exclusive(v___x_215_);
if (v_isSharedCheck_365_ == 0)
{
lean_object* v_unused_366_; lean_object* v_unused_367_; 
v_unused_366_ = lean_ctor_get(v___x_215_, 3);
lean_dec(v_unused_366_);
v_unused_367_ = lean_ctor_get(v___x_215_, 2);
lean_dec(v_unused_367_);
v___x_219_ = v___x_215_;
v_isShared_220_ = v_isSharedCheck_365_;
goto v_resetjp_218_;
}
else
{
lean_inc(v_parserState_217_);
lean_inc(v_commandState_216_);
lean_dec(v___x_215_);
v___x_219_ = lean_box(0);
v_isShared_220_ = v_isSharedCheck_365_;
goto v_resetjp_218_;
}
v_resetjp_218_:
{
lean_object* v_env_221_; lean_object* v_scopes_222_; lean_object* v___x_223_; lean_object* v___x_224_; lean_object* v_opts_225_; lean_object* v_currNamespace_226_; lean_object* v_openDecls_227_; lean_object* v___x_229_; 
v_env_221_ = lean_ctor_get(v_commandState_216_, 0);
lean_inc_ref(v_env_221_);
v_scopes_222_ = lean_ctor_get(v_commandState_216_, 2);
lean_inc(v_scopes_222_);
lean_dec_ref(v_commandState_216_);
v___x_223_ = l_Lean_Elab_Command_instInhabitedScope_default;
v___x_224_ = l_List_head_x21___redArg(v___x_223_, v_scopes_222_);
lean_dec(v_scopes_222_);
v_opts_225_ = lean_ctor_get(v___x_224_, 1);
lean_inc_ref(v_opts_225_);
v_currNamespace_226_ = lean_ctor_get(v___x_224_, 2);
lean_inc(v_currNamespace_226_);
v_openDecls_227_ = lean_ctor_get(v___x_224_, 3);
lean_inc(v_openDecls_227_);
lean_dec(v___x_224_);
if (v_isShared_220_ == 0)
{
lean_ctor_set(v___x_219_, 3, v_openDecls_227_);
lean_ctor_set(v___x_219_, 2, v_currNamespace_226_);
lean_ctor_set(v___x_219_, 1, v_opts_225_);
lean_ctor_set(v___x_219_, 0, v_env_221_);
v___x_229_ = v___x_219_;
goto v_reusejp_228_;
}
else
{
lean_object* v_reuseFailAlloc_364_; 
v_reuseFailAlloc_364_ = lean_alloc_ctor(0, 4, 0);
lean_ctor_set(v_reuseFailAlloc_364_, 0, v_env_221_);
lean_ctor_set(v_reuseFailAlloc_364_, 1, v_opts_225_);
lean_ctor_set(v_reuseFailAlloc_364_, 2, v_currNamespace_226_);
lean_ctor_set(v_reuseFailAlloc_364_, 3, v_openDecls_227_);
v___x_229_ = v_reuseFailAlloc_364_;
goto v_reusejp_228_;
}
v_reusejp_228_:
{
lean_object* v___x_230_; lean_object* v___x_231_; lean_object* v_snd_232_; lean_object* v_fst_233_; lean_object* v___x_235_; uint8_t v_isShared_236_; uint8_t v_isSharedCheck_363_; 
v___x_230_ = lean_obj_once(&l_commands___closed__2, &l_commands___closed__2_once, _init_l_commands___closed__2);
lean_inc_ref(v_parserState_217_);
lean_inc_ref(v_a_211_);
v___x_231_ = l_Lean_Parser_parseCommand(v_a_211_, v___x_229_, v_parserState_217_, v___x_230_);
v_snd_232_ = lean_ctor_get(v___x_231_, 1);
v_fst_233_ = lean_ctor_get(v___x_231_, 0);
v_isSharedCheck_363_ = !lean_is_exclusive(v___x_231_);
if (v_isSharedCheck_363_ == 0)
{
v___x_235_ = v___x_231_;
v_isShared_236_ = v_isSharedCheck_363_;
goto v_resetjp_234_;
}
else
{
lean_inc(v_snd_232_);
lean_inc(v_fst_233_);
lean_dec(v___x_231_);
v___x_235_ = lean_box(0);
v_isShared_236_ = v_isSharedCheck_363_;
goto v_resetjp_234_;
}
v_resetjp_234_:
{
lean_object* v_fst_237_; lean_object* v_snd_238_; lean_object* v___x_240_; uint8_t v_isShared_241_; uint8_t v_isSharedCheck_362_; 
v_fst_237_ = lean_ctor_get(v_snd_232_, 0);
v_snd_238_ = lean_ctor_get(v_snd_232_, 1);
v_isSharedCheck_362_ = !lean_is_exclusive(v_snd_232_);
if (v_isSharedCheck_362_ == 0)
{
v___x_240_ = v_snd_232_;
v_isShared_241_ = v_isSharedCheck_362_;
goto v_resetjp_239_;
}
else
{
lean_inc(v_snd_238_);
lean_inc(v_fst_237_);
lean_dec(v_snd_232_);
v___x_240_ = lean_box(0);
v_isShared_241_ = v_isSharedCheck_362_;
goto v_resetjp_239_;
}
v_resetjp_239_:
{
lean_object* v___x_242_; lean_object* v_commandState_243_; lean_object* v_parserState_244_; lean_object* v_cmdPos_245_; lean_object* v_commands_246_; lean_object* v___x_248_; uint8_t v_isShared_249_; uint8_t v_isSharedCheck_361_; 
v___x_242_ = lean_st_ref_take(v_a_212_);
v_commandState_243_ = lean_ctor_get(v___x_242_, 0);
v_parserState_244_ = lean_ctor_get(v___x_242_, 1);
v_cmdPos_245_ = lean_ctor_get(v___x_242_, 2);
v_commands_246_ = lean_ctor_get(v___x_242_, 3);
v_isSharedCheck_361_ = !lean_is_exclusive(v___x_242_);
if (v_isSharedCheck_361_ == 0)
{
v___x_248_ = v___x_242_;
v_isShared_249_ = v_isSharedCheck_361_;
goto v_resetjp_247_;
}
else
{
lean_inc(v_commands_246_);
lean_inc(v_cmdPos_245_);
lean_inc(v_parserState_244_);
lean_inc(v_commandState_243_);
lean_dec(v___x_242_);
v___x_248_ = lean_box(0);
v_isShared_249_ = v_isSharedCheck_361_;
goto v_resetjp_247_;
}
v_resetjp_247_:
{
lean_object* v___x_250_; lean_object* v___x_252_; 
lean_inc(v_fst_233_);
v___x_250_ = lean_array_push(v_commands_246_, v_fst_233_);
if (v_isShared_249_ == 0)
{
lean_ctor_set(v___x_248_, 3, v___x_250_);
v___x_252_ = v___x_248_;
goto v_reusejp_251_;
}
else
{
lean_object* v_reuseFailAlloc_360_; 
v_reuseFailAlloc_360_ = lean_alloc_ctor(0, 4, 0);
lean_ctor_set(v_reuseFailAlloc_360_, 0, v_commandState_243_);
lean_ctor_set(v_reuseFailAlloc_360_, 1, v_parserState_244_);
lean_ctor_set(v_reuseFailAlloc_360_, 2, v_cmdPos_245_);
lean_ctor_set(v_reuseFailAlloc_360_, 3, v___x_250_);
v___x_252_ = v_reuseFailAlloc_360_;
goto v_reusejp_251_;
}
v_reusejp_251_:
{
lean_object* v___x_253_; lean_object* v___x_254_; 
v___x_253_ = lean_st_ref_set(v_a_212_, v___x_252_);
lean_inc(v_fst_237_);
v___x_254_ = l_Lean_Elab_Frontend_setParserState___redArg(v_fst_237_, v_a_212_);
if (lean_obj_tag(v___x_254_) == 0)
{
lean_object* v___x_255_; 
lean_dec_ref_known(v___x_254_, 1);
lean_inc(v_snd_238_);
v___x_255_ = l_Lean_Elab_Frontend_setMessages___redArg(v_snd_238_, v_a_212_);
if (lean_obj_tag(v___x_255_) == 0)
{
lean_object* v___x_256_; 
lean_dec_ref_known(v___x_255_, 1);
v___x_256_ = rv_thread_cpu_ns();
if (lean_obj_tag(v___x_256_) == 0)
{
lean_object* v_a_257_; lean_object* v___x_258_; lean_object* v___x_259_; 
v_a_257_ = lean_ctor_get(v___x_256_, 0);
lean_inc(v_a_257_);
lean_dec_ref_known(v___x_256_, 1);
v___x_258_ = lean_io_get_num_heartbeats();
lean_inc(v_fst_233_);
v___x_259_ = l_Lean_Elab_Frontend_elabCommandAtFrontend(v_fst_233_, v_a_211_, v_a_212_);
if (lean_obj_tag(v___x_259_) == 0)
{
lean_object* v___x_260_; lean_object* v___x_261_; 
lean_dec_ref_known(v___x_259_, 1);
v___x_260_ = lean_io_get_num_heartbeats();
v___x_261_ = rv_thread_cpu_ns();
if (lean_obj_tag(v___x_261_) == 0)
{
lean_object* v_a_262_; lean_object* v___x_264_; uint8_t v_isShared_265_; uint8_t v_isSharedCheck_319_; 
v_a_262_ = lean_ctor_get(v___x_261_, 0);
v_isSharedCheck_319_ = !lean_is_exclusive(v___x_261_);
if (v_isSharedCheck_319_ == 0)
{
v___x_264_ = v___x_261_;
v_isShared_265_ = v_isSharedCheck_319_;
goto v_resetjp_263_;
}
else
{
lean_inc(v_a_262_);
lean_dec(v___x_261_);
v___x_264_ = lean_box(0);
v_isShared_265_ = v_isSharedCheck_319_;
goto v_resetjp_263_;
}
v_resetjp_263_:
{
lean_object* v___x_266_; lean_object* v_commandState_267_; lean_object* v_pos_268_; lean_object* v_pos_269_; lean_object* v_messages_270_; lean_object* v___x_271_; lean_object* v___x_272_; lean_object* v___x_273_; lean_object* v___x_274_; lean_object* v___x_276_; 
v___x_266_ = lean_st_ref_get(v_a_212_);
v_commandState_267_ = lean_ctor_get(v___x_266_, 0);
lean_inc_ref(v_commandState_267_);
lean_dec(v___x_266_);
v_pos_268_ = lean_ctor_get(v_parserState_217_, 0);
lean_inc(v_pos_268_);
lean_dec_ref(v_parserState_217_);
v_pos_269_ = lean_ctor_get(v_fst_237_, 0);
lean_inc(v_pos_269_);
lean_dec(v_fst_237_);
v_messages_270_ = lean_ctor_get(v_commandState_267_, 1);
lean_inc_ref(v_messages_270_);
lean_dec_ref(v_commandState_267_);
v___x_271_ = ((lean_object*)(l_instToJsonUnitRow_toJson___closed__1));
v___x_272_ = lean_nat_sub(v___x_260_, v___x_258_);
lean_dec(v___x_258_);
lean_dec(v___x_260_);
v___x_273_ = l_Lean_JsonNumber_fromNat(v___x_272_);
v___x_274_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_274_, 0, v___x_273_);
if (v_isShared_241_ == 0)
{
lean_ctor_set(v___x_240_, 1, v___x_274_);
lean_ctor_set(v___x_240_, 0, v___x_271_);
v___x_276_ = v___x_240_;
goto v_reusejp_275_;
}
else
{
lean_object* v_reuseFailAlloc_318_; 
v_reuseFailAlloc_318_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_318_, 0, v___x_271_);
lean_ctor_set(v_reuseFailAlloc_318_, 1, v___x_274_);
v___x_276_ = v_reuseFailAlloc_318_;
goto v_reusejp_275_;
}
v_reusejp_275_:
{
lean_object* v___x_277_; uint64_t v___x_278_; uint64_t v___x_279_; uint64_t v___x_280_; lean_object* v___x_281_; lean_object* v___x_282_; lean_object* v___x_284_; 
v___x_277_ = ((lean_object*)(l_instToJsonUnitRow_toJson___closed__2));
v___x_278_ = lean_unbox_uint64(v_a_262_);
lean_dec(v_a_262_);
v___x_279_ = lean_unbox_uint64(v_a_257_);
lean_dec(v_a_257_);
v___x_280_ = lean_uint64_sub(v___x_278_, v___x_279_);
v___x_281_ = lean_uint64_to_nat(v___x_280_);
v___x_282_ = l_Lean_bignumToJson(v___x_281_);
if (v_isShared_236_ == 0)
{
lean_ctor_set(v___x_235_, 1, v___x_282_);
lean_ctor_set(v___x_235_, 0, v___x_277_);
v___x_284_ = v___x_235_;
goto v_reusejp_283_;
}
else
{
lean_object* v_reuseFailAlloc_317_; 
v_reuseFailAlloc_317_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_317_, 0, v___x_277_);
lean_ctor_set(v_reuseFailAlloc_317_, 1, v___x_282_);
v___x_284_ = v_reuseFailAlloc_317_;
goto v_reusejp_283_;
}
v_reusejp_283_:
{
lean_object* v___x_285_; lean_object* v___x_286_; lean_object* v___x_287_; lean_object* v___x_288_; lean_object* v___x_289_; lean_object* v___x_290_; lean_object* v___x_291_; lean_object* v___x_292_; lean_object* v___x_293_; lean_object* v___x_294_; uint8_t v___x_295_; lean_object* v___x_296_; lean_object* v___x_297_; lean_object* v___x_298_; lean_object* v___x_299_; lean_object* v___x_300_; lean_object* v___x_301_; lean_object* v___x_302_; lean_object* v___x_303_; lean_object* v___x_304_; lean_object* v___x_305_; lean_object* v___x_306_; lean_object* v___x_307_; lean_object* v___x_308_; lean_object* v___x_309_; lean_object* v___x_310_; uint8_t v___x_311_; 
v___x_285_ = ((lean_object*)(l_commands___closed__3));
v___x_286_ = l_Lean_JsonNumber_fromNat(v_pos_268_);
v___x_287_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_287_, 0, v___x_286_);
v___x_288_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_288_, 0, v___x_285_);
lean_ctor_set(v___x_288_, 1, v___x_287_);
v___x_289_ = ((lean_object*)(l_commands___closed__4));
v___x_290_ = l_Lean_JsonNumber_fromNat(v_pos_269_);
v___x_291_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_291_, 0, v___x_290_);
v___x_292_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_292_, 0, v___x_289_);
lean_ctor_set(v___x_292_, 1, v___x_291_);
v___x_293_ = ((lean_object*)(l_commands___closed__5));
lean_inc(v_fst_233_);
v___x_294_ = l_Lean_Syntax_getKind(v_fst_233_);
v___x_295_ = 1;
v___x_296_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v___x_294_, v___x_295_);
v___x_297_ = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(v___x_297_, 0, v___x_296_);
v___x_298_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_298_, 0, v___x_293_);
lean_ctor_set(v___x_298_, 1, v___x_297_);
v___x_299_ = lean_box(0);
v___x_300_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_300_, 0, v___x_298_);
lean_ctor_set(v___x_300_, 1, v___x_299_);
v___x_301_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_301_, 0, v___x_292_);
lean_ctor_set(v___x_301_, 1, v___x_300_);
v___x_302_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_302_, 0, v___x_288_);
lean_ctor_set(v___x_302_, 1, v___x_301_);
v___x_303_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_303_, 0, v___x_284_);
lean_ctor_set(v___x_303_, 1, v___x_302_);
v___x_304_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_304_, 0, v___x_276_);
lean_ctor_set(v___x_304_, 1, v___x_303_);
v___x_305_ = l_Lean_Json_mkObj(v___x_304_);
lean_dec_ref_known(v___x_304_, 2);
v___x_306_ = lean_array_push(v_rows_209_, v___x_305_);
v___x_307_ = l_Lean_MessageLog_toArray(v_snd_238_);
lean_dec(v_snd_238_);
v___x_308_ = l_Array_append___redArg(v_messages_210_, v___x_307_);
lean_dec_ref(v___x_307_);
v___x_309_ = l_Lean_MessageLog_toArray(v_messages_270_);
lean_dec_ref(v_messages_270_);
v___x_310_ = l_Array_append___redArg(v___x_308_, v___x_309_);
lean_dec_ref(v___x_309_);
v___x_311_ = l_Lean_Parser_isTerminalCommand(v_fst_233_);
if (v___x_311_ == 0)
{
lean_del_object(v___x_264_);
v_rows_209_ = v___x_306_;
v_messages_210_ = v___x_310_;
goto _start;
}
else
{
lean_object* v___x_313_; lean_object* v___x_315_; 
v___x_313_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_313_, 0, v___x_306_);
lean_ctor_set(v___x_313_, 1, v___x_310_);
if (v_isShared_265_ == 0)
{
lean_ctor_set(v___x_264_, 0, v___x_313_);
v___x_315_ = v___x_264_;
goto v_reusejp_314_;
}
else
{
lean_object* v_reuseFailAlloc_316_; 
v_reuseFailAlloc_316_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_316_, 0, v___x_313_);
v___x_315_ = v_reuseFailAlloc_316_;
goto v_reusejp_314_;
}
v_reusejp_314_:
{
return v___x_315_;
}
}
}
}
}
}
else
{
lean_object* v_a_320_; lean_object* v___x_322_; uint8_t v_isShared_323_; uint8_t v_isSharedCheck_327_; 
lean_dec(v___x_260_);
lean_dec(v___x_258_);
lean_dec(v_a_257_);
lean_del_object(v___x_240_);
lean_dec(v_snd_238_);
lean_dec(v_fst_237_);
lean_del_object(v___x_235_);
lean_dec(v_fst_233_);
lean_dec_ref(v_parserState_217_);
lean_dec_ref(v_messages_210_);
lean_dec_ref(v_rows_209_);
v_a_320_ = lean_ctor_get(v___x_261_, 0);
v_isSharedCheck_327_ = !lean_is_exclusive(v___x_261_);
if (v_isSharedCheck_327_ == 0)
{
v___x_322_ = v___x_261_;
v_isShared_323_ = v_isSharedCheck_327_;
goto v_resetjp_321_;
}
else
{
lean_inc(v_a_320_);
lean_dec(v___x_261_);
v___x_322_ = lean_box(0);
v_isShared_323_ = v_isSharedCheck_327_;
goto v_resetjp_321_;
}
v_resetjp_321_:
{
lean_object* v___x_325_; 
if (v_isShared_323_ == 0)
{
v___x_325_ = v___x_322_;
goto v_reusejp_324_;
}
else
{
lean_object* v_reuseFailAlloc_326_; 
v_reuseFailAlloc_326_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_326_, 0, v_a_320_);
v___x_325_ = v_reuseFailAlloc_326_;
goto v_reusejp_324_;
}
v_reusejp_324_:
{
return v___x_325_;
}
}
}
}
else
{
lean_object* v_a_328_; lean_object* v___x_330_; uint8_t v_isShared_331_; uint8_t v_isSharedCheck_335_; 
lean_dec(v___x_258_);
lean_dec(v_a_257_);
lean_del_object(v___x_240_);
lean_dec(v_snd_238_);
lean_dec(v_fst_237_);
lean_del_object(v___x_235_);
lean_dec(v_fst_233_);
lean_dec_ref(v_parserState_217_);
lean_dec_ref(v_messages_210_);
lean_dec_ref(v_rows_209_);
v_a_328_ = lean_ctor_get(v___x_259_, 0);
v_isSharedCheck_335_ = !lean_is_exclusive(v___x_259_);
if (v_isSharedCheck_335_ == 0)
{
v___x_330_ = v___x_259_;
v_isShared_331_ = v_isSharedCheck_335_;
goto v_resetjp_329_;
}
else
{
lean_inc(v_a_328_);
lean_dec(v___x_259_);
v___x_330_ = lean_box(0);
v_isShared_331_ = v_isSharedCheck_335_;
goto v_resetjp_329_;
}
v_resetjp_329_:
{
lean_object* v___x_333_; 
if (v_isShared_331_ == 0)
{
v___x_333_ = v___x_330_;
goto v_reusejp_332_;
}
else
{
lean_object* v_reuseFailAlloc_334_; 
v_reuseFailAlloc_334_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_334_, 0, v_a_328_);
v___x_333_ = v_reuseFailAlloc_334_;
goto v_reusejp_332_;
}
v_reusejp_332_:
{
return v___x_333_;
}
}
}
}
else
{
lean_object* v_a_336_; lean_object* v___x_338_; uint8_t v_isShared_339_; uint8_t v_isSharedCheck_343_; 
lean_del_object(v___x_240_);
lean_dec(v_snd_238_);
lean_dec(v_fst_237_);
lean_del_object(v___x_235_);
lean_dec(v_fst_233_);
lean_dec_ref(v_parserState_217_);
lean_dec_ref(v_messages_210_);
lean_dec_ref(v_rows_209_);
v_a_336_ = lean_ctor_get(v___x_256_, 0);
v_isSharedCheck_343_ = !lean_is_exclusive(v___x_256_);
if (v_isSharedCheck_343_ == 0)
{
v___x_338_ = v___x_256_;
v_isShared_339_ = v_isSharedCheck_343_;
goto v_resetjp_337_;
}
else
{
lean_inc(v_a_336_);
lean_dec(v___x_256_);
v___x_338_ = lean_box(0);
v_isShared_339_ = v_isSharedCheck_343_;
goto v_resetjp_337_;
}
v_resetjp_337_:
{
lean_object* v___x_341_; 
if (v_isShared_339_ == 0)
{
v___x_341_ = v___x_338_;
goto v_reusejp_340_;
}
else
{
lean_object* v_reuseFailAlloc_342_; 
v_reuseFailAlloc_342_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_342_, 0, v_a_336_);
v___x_341_ = v_reuseFailAlloc_342_;
goto v_reusejp_340_;
}
v_reusejp_340_:
{
return v___x_341_;
}
}
}
}
else
{
lean_object* v_a_344_; lean_object* v___x_346_; uint8_t v_isShared_347_; uint8_t v_isSharedCheck_351_; 
lean_del_object(v___x_240_);
lean_dec(v_snd_238_);
lean_dec(v_fst_237_);
lean_del_object(v___x_235_);
lean_dec(v_fst_233_);
lean_dec_ref(v_parserState_217_);
lean_dec_ref(v_messages_210_);
lean_dec_ref(v_rows_209_);
v_a_344_ = lean_ctor_get(v___x_255_, 0);
v_isSharedCheck_351_ = !lean_is_exclusive(v___x_255_);
if (v_isSharedCheck_351_ == 0)
{
v___x_346_ = v___x_255_;
v_isShared_347_ = v_isSharedCheck_351_;
goto v_resetjp_345_;
}
else
{
lean_inc(v_a_344_);
lean_dec(v___x_255_);
v___x_346_ = lean_box(0);
v_isShared_347_ = v_isSharedCheck_351_;
goto v_resetjp_345_;
}
v_resetjp_345_:
{
lean_object* v___x_349_; 
if (v_isShared_347_ == 0)
{
v___x_349_ = v___x_346_;
goto v_reusejp_348_;
}
else
{
lean_object* v_reuseFailAlloc_350_; 
v_reuseFailAlloc_350_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_350_, 0, v_a_344_);
v___x_349_ = v_reuseFailAlloc_350_;
goto v_reusejp_348_;
}
v_reusejp_348_:
{
return v___x_349_;
}
}
}
}
else
{
lean_object* v_a_352_; lean_object* v___x_354_; uint8_t v_isShared_355_; uint8_t v_isSharedCheck_359_; 
lean_del_object(v___x_240_);
lean_dec(v_snd_238_);
lean_dec(v_fst_237_);
lean_del_object(v___x_235_);
lean_dec(v_fst_233_);
lean_dec_ref(v_parserState_217_);
lean_dec_ref(v_messages_210_);
lean_dec_ref(v_rows_209_);
v_a_352_ = lean_ctor_get(v___x_254_, 0);
v_isSharedCheck_359_ = !lean_is_exclusive(v___x_254_);
if (v_isSharedCheck_359_ == 0)
{
v___x_354_ = v___x_254_;
v_isShared_355_ = v_isSharedCheck_359_;
goto v_resetjp_353_;
}
else
{
lean_inc(v_a_352_);
lean_dec(v___x_254_);
v___x_354_ = lean_box(0);
v_isShared_355_ = v_isSharedCheck_359_;
goto v_resetjp_353_;
}
v_resetjp_353_:
{
lean_object* v___x_357_; 
if (v_isShared_355_ == 0)
{
v___x_357_ = v___x_354_;
goto v_reusejp_356_;
}
else
{
lean_object* v_reuseFailAlloc_358_; 
v_reuseFailAlloc_358_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_358_, 0, v_a_352_);
v___x_357_ = v_reuseFailAlloc_358_;
goto v_reusejp_356_;
}
v_reusejp_356_:
{
return v___x_357_;
}
}
}
}
}
}
}
}
}
}
else
{
lean_object* v_a_368_; lean_object* v___x_370_; uint8_t v_isShared_371_; uint8_t v_isSharedCheck_375_; 
lean_dec_ref(v_messages_210_);
lean_dec_ref(v_rows_209_);
v_a_368_ = lean_ctor_get(v___x_214_, 0);
v_isSharedCheck_375_ = !lean_is_exclusive(v___x_214_);
if (v_isSharedCheck_375_ == 0)
{
v___x_370_ = v___x_214_;
v_isShared_371_ = v_isSharedCheck_375_;
goto v_resetjp_369_;
}
else
{
lean_inc(v_a_368_);
lean_dec(v___x_214_);
v___x_370_ = lean_box(0);
v_isShared_371_ = v_isSharedCheck_375_;
goto v_resetjp_369_;
}
v_resetjp_369_:
{
lean_object* v___x_373_; 
if (v_isShared_371_ == 0)
{
v___x_373_ = v___x_370_;
goto v_reusejp_372_;
}
else
{
lean_object* v_reuseFailAlloc_374_; 
v_reuseFailAlloc_374_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_374_, 0, v_a_368_);
v___x_373_ = v_reuseFailAlloc_374_;
goto v_reusejp_372_;
}
v_reusejp_372_:
{
return v___x_373_;
}
}
}
}
}
LEAN_EXPORT lean_object* l_commands___boxed(lean_object* v_rows_376_, lean_object* v_messages_377_, lean_object* v_a_378_, lean_object* v_a_379_, lean_object* v_a_380_){
_start:
{
lean_object* v_res_381_; 
v_res_381_ = l_commands(v_rows_376_, v_messages_377_, v_a_378_, v_a_379_);
lean_dec(v_a_379_);
lean_dec_ref(v_a_378_);
return v_res_381_;
}
}
LEAN_EXPORT lean_object* l_Lean_collectAxioms___at___00elaborateOne_spec__1___redArg(lean_object* v_constName_382_, lean_object* v___y_383_){
_start:
{
lean_object* v___x_385_; lean_object* v_env_386_; lean_object* v___x_387_; uint8_t v___x_388_; lean_object* v_privateEnv_389_; lean_object* v___x_390_; lean_object* v___x_391_; lean_object* v___x_392_; lean_object* v_s_393_; lean_object* v___x_394_; lean_object* v___x_395_; lean_object* v___x_396_; lean_object* v___x_397_; 
v___x_385_ = lean_st_ref_get(v___y_383_);
v_env_386_ = lean_ctor_get(v___x_385_, 0);
lean_inc_ref_n(v_env_386_, 2);
lean_dec(v___x_385_);
v___x_387_ = l___private_Lean_Util_CollectAxioms_0__Lean_instInhabitedExportedAxiomsState;
v___x_388_ = 0;
v_privateEnv_389_ = l_Lean_Environment_setExporting(v_env_386_, v___x_388_);
v___x_390_ = l___private_Lean_Util_CollectAxioms_0__Lean_exportedAxiomsExt;
v___x_391_ = lean_box(2);
v___x_392_ = lean_box(0);
v_s_393_ = l_Lean_PersistentEnvExtension_getState___redArg(v___x_387_, v___x_390_, v_env_386_, v___x_391_, v___x_392_);
v___x_394_ = lean_alloc_closure((void*)(l___private_Lean_Util_CollectAxioms_0__Lean_ExportedAxiomsState_find_x3f___boxed), 3, 1);
lean_closure_set(v___x_394_, 0, v_s_393_);
v___x_395_ = lean_alloc_closure((void*)(l___private_Lean_Util_CollectAxioms_0__Lean_CollectAxioms_collectAndGet___boxed), 4, 2);
lean_closure_set(v___x_395_, 0, v___x_394_);
lean_closure_set(v___x_395_, 1, v_constName_382_);
v___x_396_ = l___private_Lean_Util_CollectAxioms_0__Lean_CollectAxioms_runM___redArg(v_privateEnv_389_, v___x_395_);
v___x_397_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_397_, 0, v___x_396_);
return v___x_397_;
}
}
LEAN_EXPORT lean_object* l_Lean_collectAxioms___at___00elaborateOne_spec__1___redArg___boxed(lean_object* v_constName_398_, lean_object* v___y_399_, lean_object* v___y_400_){
_start:
{
lean_object* v_res_401_; 
v_res_401_ = l_Lean_collectAxioms___at___00elaborateOne_spec__1___redArg(v_constName_398_, v___y_399_);
lean_dec(v___y_399_);
return v_res_401_;
}
}
LEAN_EXPORT lean_object* l_Lean_collectAxioms___at___00elaborateOne_spec__1(lean_object* v_constName_402_, lean_object* v___y_403_, lean_object* v___y_404_){
_start:
{
lean_object* v___x_406_; 
v___x_406_ = l_Lean_collectAxioms___at___00elaborateOne_spec__1___redArg(v_constName_402_, v___y_404_);
return v___x_406_;
}
}
LEAN_EXPORT lean_object* l_Lean_collectAxioms___at___00elaborateOne_spec__1___boxed(lean_object* v_constName_407_, lean_object* v___y_408_, lean_object* v___y_409_, lean_object* v___y_410_){
_start:
{
lean_object* v_res_411_; 
v_res_411_ = l_Lean_collectAxioms___at___00elaborateOne_spec__1(v_constName_407_, v___y_408_, v___y_409_);
lean_dec(v___y_409_);
lean_dec_ref(v___y_408_);
return v_res_411_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00elaborateOne_spec__0(lean_object* v_as_412_, size_t v_sz_413_, size_t v_i_414_, lean_object* v_b_415_){
_start:
{
lean_object* v_a_418_; uint8_t v___x_422_; 
v___x_422_ = lean_usize_dec_lt(v_i_414_, v_sz_413_);
if (v___x_422_ == 0)
{
lean_object* v___x_423_; 
v___x_423_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_423_, 0, v_b_415_);
return v___x_423_;
}
else
{
lean_object* v_a_424_; uint8_t v_severity_425_; lean_object* v_data_426_; uint8_t v___x_427_; uint8_t v___x_428_; 
v_a_424_ = lean_array_uget_borrowed(v_as_412_, v_i_414_);
v_severity_425_ = lean_ctor_get_uint8(v_a_424_, sizeof(void*)*5 + 1);
v_data_426_ = lean_ctor_get(v_a_424_, 4);
v___x_427_ = 2;
v___x_428_ = l_Lean_instBEqMessageSeverity_beq(v_severity_425_, v___x_427_);
if (v___x_428_ == 0)
{
v_a_418_ = v_b_415_;
goto v___jp_417_;
}
else
{
lean_object* v___x_429_; lean_object* v___x_430_; 
lean_inc(v_data_426_);
v___x_429_ = l_Lean_MessageData_toString(v_data_426_);
v___x_430_ = lean_array_push(v_b_415_, v___x_429_);
v_a_418_ = v___x_430_;
goto v___jp_417_;
}
}
v___jp_417_:
{
size_t v___x_419_; size_t v___x_420_; 
v___x_419_ = ((size_t)1ULL);
v___x_420_ = lean_usize_add(v_i_414_, v___x_419_);
v_i_414_ = v___x_420_;
v_b_415_ = v_a_418_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00elaborateOne_spec__0___boxed(lean_object* v_as_431_, lean_object* v_sz_432_, lean_object* v_i_433_, lean_object* v_b_434_, lean_object* v___y_435_){
_start:
{
size_t v_sz_boxed_436_; size_t v_i_boxed_437_; lean_object* v_res_438_; 
v_sz_boxed_436_ = lean_unbox_usize(v_sz_432_);
lean_dec(v_sz_432_);
v_i_boxed_437_ = lean_unbox_usize(v_i_433_);
lean_dec(v_i_433_);
v_res_438_ = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00elaborateOne_spec__0(v_as_431_, v_sz_boxed_436_, v_i_boxed_437_, v_b_434_);
lean_dec_ref(v_as_431_);
return v_res_438_;
}
}
static lean_object* _init_l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__2(void){
_start:
{
lean_object* v___x_442_; 
v___x_442_ = l_Lean_PersistentHashMap_mkEmptyEntriesArray(lean_box(0), lean_box(0));
return v___x_442_;
}
}
static lean_object* _init_l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__3(void){
_start:
{
lean_object* v___x_443_; lean_object* v___x_444_; 
v___x_443_ = lean_obj_once(&l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__2, &l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__2_once, _init_l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__2);
v___x_444_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_444_, 0, v___x_443_);
return v___x_444_;
}
}
static lean_object* _init_l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__4(void){
_start:
{
lean_object* v___x_445_; lean_object* v___x_446_; 
v___x_445_ = lean_obj_once(&l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__3, &l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__3_once, _init_l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__3);
v___x_446_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_446_, 0, v___x_445_);
lean_ctor_set(v___x_446_, 1, v___x_445_);
return v___x_446_;
}
}
static lean_object* _init_l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__9(void){
_start:
{
lean_object* v___x_457_; uint64_t v___x_458_; lean_object* v___x_459_; 
v___x_457_ = lean_obj_once(&l_commands___closed__1, &l_commands___closed__1_once, _init_l_commands___closed__1);
v___x_458_ = 0ULL;
v___x_459_ = lean_alloc_ctor(0, 1, 8);
lean_ctor_set(v___x_459_, 0, v___x_457_);
lean_ctor_set_uint64(v___x_459_, sizeof(void*)*1, v___x_458_);
return v___x_459_;
}
}
static lean_object* _init_l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__10(void){
_start:
{
lean_object* v___x_460_; lean_object* v___x_461_; uint8_t v___x_462_; lean_object* v___x_463_; 
v___x_460_ = lean_obj_once(&l_commands___closed__1, &l_commands___closed__1_once, _init_l_commands___closed__1);
v___x_461_ = lean_obj_once(&l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__3, &l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__3_once, _init_l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__3);
v___x_462_ = 1;
v___x_463_ = lean_alloc_ctor(0, 3, 1);
lean_ctor_set(v___x_463_, 0, v___x_461_);
lean_ctor_set(v___x_463_, 1, v___x_461_);
lean_ctor_set(v___x_463_, 2, v___x_460_);
lean_ctor_set_uint8(v___x_463_, sizeof(void*)*3, v___x_462_);
return v___x_463_;
}
}
static lean_object* _init_l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__12(void){
_start:
{
lean_object* v___x_466_; lean_object* v___x_467_; 
v___x_466_ = l_Lean_Options_empty;
v___x_467_ = l_Lean_Core_getMaxHeartbeats(v___x_466_);
return v___x_467_;
}
}
static uint8_t _init_l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__13(void){
_start:
{
lean_object* v___x_468_; lean_object* v___x_469_; uint8_t v___x_470_; 
v___x_468_ = l_Lean_diagnostics;
v___x_469_ = l_Lean_Options_empty;
v___x_470_ = l_Lean_Option_get___at___00Lean_Elab_addMacroStack___at___00Lean_throwError___at___00Lean_throwErrorAt___at___00Lean_throwUnknownIdentifierAt___at___00Lean_throwUnknownConstantAt___at___00Lean_throwUnknownConstant___at___00Lean_getConstVal___at___00Lean_mkConstWithLevelParams___at___00Lean_Elab_addConstInfo___at___00Lean_Elab_PostprocessTraces_elabStoreTraceAs_spec__3_spec__5_spec__6_spec__9_spec__12_spec__14_spec__16_spec__18_spec__20_spec__21(v___x_469_, v___x_468_);
return v___x_470_;
}
}
LEAN_EXPORT lean_object* l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg(lean_object* v___x_471_, lean_object* v_ctx_472_, lean_object* v_file_473_, lean_object* v_base_474_, lean_object* v_as_x27_475_, lean_object* v_b_476_){
_start:
{
lean_object* v___x_478_; lean_object* v___x_479_; 
v___x_478_ = lean_unsigned_to_nat(0u);
v___x_479_ = lean_obj_once(&l_commands___closed__2, &l_commands___closed__2_once, _init_l_commands___closed__2);
if (lean_obj_tag(v_as_x27_475_) == 0)
{
lean_object* v___x_480_; 
lean_dec_ref(v_base_474_);
lean_dec_ref(v_file_473_);
lean_dec_ref(v___x_471_);
v___x_480_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_480_, 0, v_b_476_);
return v___x_480_;
}
else
{
lean_object* v_head_481_; lean_object* v_snd_482_; lean_object* v_tail_483_; lean_object* v_fst_484_; lean_object* v_snd_485_; lean_object* v_fst_486_; lean_object* v___x_488_; uint8_t v_isShared_489_; uint8_t v_isSharedCheck_592_; 
v_head_481_ = lean_ctor_get(v_as_x27_475_, 0);
v_snd_482_ = lean_ctor_get(v_b_476_, 1);
lean_inc(v_snd_482_);
v_tail_483_ = lean_ctor_get(v_as_x27_475_, 1);
v_fst_484_ = lean_ctor_get(v_head_481_, 0);
v_snd_485_ = lean_ctor_get(v_head_481_, 1);
v_fst_486_ = lean_ctor_get(v_b_476_, 0);
v_isSharedCheck_592_ = !lean_is_exclusive(v_b_476_);
if (v_isSharedCheck_592_ == 0)
{
lean_object* v_unused_593_; 
v_unused_593_ = lean_ctor_get(v_b_476_, 1);
lean_dec(v_unused_593_);
v___x_488_ = v_b_476_;
v_isShared_489_ = v_isSharedCheck_592_;
goto v_resetjp_487_;
}
else
{
lean_inc(v_fst_486_);
lean_dec(v_b_476_);
v___x_488_ = lean_box(0);
v_isShared_489_ = v_isSharedCheck_592_;
goto v_resetjp_487_;
}
v_resetjp_487_:
{
lean_object* v_fst_490_; lean_object* v_snd_491_; lean_object* v___x_493_; uint8_t v_isShared_494_; uint8_t v_isSharedCheck_591_; 
v_fst_490_ = lean_ctor_get(v_snd_482_, 0);
v_snd_491_ = lean_ctor_get(v_snd_482_, 1);
v_isSharedCheck_591_ = !lean_is_exclusive(v_snd_482_);
if (v_isSharedCheck_591_ == 0)
{
v___x_493_ = v_snd_482_;
v_isShared_494_ = v_isSharedCheck_591_;
goto v_resetjp_492_;
}
else
{
lean_inc(v_snd_491_);
lean_inc(v_fst_490_);
lean_dec(v_snd_482_);
v___x_493_ = lean_box(0);
v_isShared_494_ = v_isSharedCheck_591_;
goto v_resetjp_492_;
}
v_resetjp_492_:
{
uint8_t v___x_495_; uint8_t v___y_497_; lean_object* v___y_498_; lean_object* v___y_499_; lean_object* v___y_500_; lean_object* v___y_501_; lean_object* v___y_502_; lean_object* v___y_503_; uint8_t v___y_525_; lean_object* v___y_526_; lean_object* v___y_527_; lean_object* v___y_528_; lean_object* v___y_529_; lean_object* v___y_530_; lean_object* v___y_531_; uint8_t v___y_532_; uint8_t v___x_552_; 
v___x_495_ = 1;
lean_inc(v_fst_484_);
lean_inc_ref(v_base_474_);
v___x_552_ = l_Lean_Environment_contains(v_base_474_, v_fst_484_, v___x_495_);
if (v___x_552_ == 0)
{
lean_object* v___x_553_; lean_object* v_newAxioms_555_; 
v___x_553_ = l_Lean_Options_empty;
if (lean_obj_tag(v_snd_485_) == 0)
{
lean_object* v___x_586_; lean_object* v___x_587_; 
lean_inc(v_fst_484_);
v___x_586_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v_fst_484_, v___x_495_);
v___x_587_ = lean_array_push(v_snd_491_, v___x_586_);
v_newAxioms_555_ = v___x_587_;
goto v___jp_554_;
}
else
{
v_newAxioms_555_ = v_snd_491_;
goto v___jp_554_;
}
v___jp_554_:
{
if (lean_obj_tag(v_snd_485_) == 2)
{
lean_object* v___x_556_; lean_object* v___x_557_; lean_object* v___x_558_; lean_object* v___x_559_; lean_object* v___x_560_; lean_object* v___x_561_; lean_object* v___x_562_; lean_object* v___x_563_; lean_object* v___x_564_; lean_object* v___x_565_; lean_object* v___x_566_; lean_object* v___x_567_; lean_object* v___x_568_; lean_object* v___x_569_; lean_object* v___x_570_; lean_object* v___x_571_; lean_object* v___x_572_; lean_object* v_fileMap_573_; lean_object* v___x_574_; lean_object* v___x_575_; lean_object* v___x_576_; lean_object* v___x_577_; lean_object* v___x_578_; lean_object* v_env_579_; lean_object* v___x_580_; uint8_t v___x_581_; uint8_t v___x_582_; 
v___x_556_ = lean_obj_once(&l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__4, &l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__4_once, _init_l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__4);
v___x_557_ = lean_io_get_num_heartbeats();
lean_inc(v_fst_484_);
v___x_558_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v_fst_484_, v___x_495_);
v___x_559_ = lean_unsigned_to_nat(1u);
v___x_560_ = ((lean_object*)(l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__7));
v___x_561_ = lean_box(0);
v___x_562_ = lean_unsigned_to_nat(2u);
v___x_563_ = lean_box(0);
v___x_564_ = ((lean_object*)(l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__8));
v___x_565_ = lean_obj_once(&l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__9, &l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__9_once, _init_l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__9);
v___x_566_ = lean_obj_once(&l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__10, &l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__10_once, _init_l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__10);
v___x_567_ = ((lean_object*)(l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__11));
lean_inc_ref(v___x_471_);
v___x_568_ = lean_alloc_ctor(0, 9, 0);
lean_ctor_set(v___x_568_, 0, v___x_471_);
lean_ctor_set(v___x_568_, 1, v___x_562_);
lean_ctor_set(v___x_568_, 2, v___x_560_);
lean_ctor_set(v___x_568_, 3, v___x_564_);
lean_ctor_set(v___x_568_, 4, v___x_565_);
lean_ctor_set(v___x_568_, 5, v___x_556_);
lean_ctor_set(v___x_568_, 6, v___x_479_);
lean_ctor_set(v___x_568_, 7, v___x_566_);
lean_ctor_set(v___x_568_, 8, v___x_567_);
v___x_569_ = lean_st_mk_ref(v___x_568_);
v___x_570_ = l_Lean_inheritedTraceOptions;
v___x_571_ = lean_st_ref_get(v___x_570_);
v___x_572_ = lean_st_ref_get(v___x_569_);
v_fileMap_573_ = lean_ctor_get(v_ctx_472_, 2);
v___x_574_ = lean_unsigned_to_nat(1000u);
v___x_575_ = lean_box(0);
v___x_576_ = lean_obj_once(&l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__12, &l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__12_once, _init_l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__12);
v___x_577_ = lean_box(0);
lean_inc_ref(v_fileMap_573_);
lean_inc_ref(v_file_473_);
v___x_578_ = lean_alloc_ctor(0, 14, 2);
lean_ctor_set(v___x_578_, 0, v_file_473_);
lean_ctor_set(v___x_578_, 1, v_fileMap_573_);
lean_ctor_set(v___x_578_, 2, v___x_553_);
lean_ctor_set(v___x_578_, 3, v___x_478_);
lean_ctor_set(v___x_578_, 4, v___x_574_);
lean_ctor_set(v___x_578_, 5, v___x_575_);
lean_ctor_set(v___x_578_, 6, v___x_561_);
lean_ctor_set(v___x_578_, 7, v___x_563_);
lean_ctor_set(v___x_578_, 8, v___x_557_);
lean_ctor_set(v___x_578_, 9, v___x_576_);
lean_ctor_set(v___x_578_, 10, v___x_561_);
lean_ctor_set(v___x_578_, 11, v___x_559_);
lean_ctor_set(v___x_578_, 12, v___x_577_);
lean_ctor_set(v___x_578_, 13, v___x_571_);
lean_ctor_set_uint8(v___x_578_, sizeof(void*)*14, v___x_552_);
lean_ctor_set_uint8(v___x_578_, sizeof(void*)*14 + 1, v___x_552_);
v_env_579_ = lean_ctor_get(v___x_572_, 0);
lean_inc_ref(v_env_579_);
lean_dec(v___x_572_);
lean_inc_ref(v___x_558_);
v___x_580_ = lean_array_push(v_fst_486_, v___x_558_);
v___x_581_ = lean_uint8_once(&l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__13, &l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__13_once, _init_l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__13);
v___x_582_ = l_Lean_Kernel_isDiagnosticsEnabled(v_env_579_);
lean_dec_ref(v_env_579_);
if (v___x_582_ == 0)
{
if (v___x_581_ == 0)
{
lean_inc(v___x_569_);
v___y_497_ = v___x_581_;
v___y_498_ = v___x_580_;
v___y_499_ = v___x_569_;
v___y_500_ = v_newAxioms_555_;
v___y_501_ = v___x_558_;
v___y_502_ = v___x_578_;
v___y_503_ = v___x_569_;
goto v___jp_496_;
}
else
{
v___y_525_ = v___x_581_;
v___y_526_ = v___x_580_;
v___y_527_ = v___x_569_;
v___y_528_ = v___x_578_;
v___y_529_ = v___x_556_;
v___y_530_ = v_newAxioms_555_;
v___y_531_ = v___x_558_;
v___y_532_ = v___x_582_;
goto v___jp_524_;
}
}
else
{
v___y_525_ = v___x_581_;
v___y_526_ = v___x_580_;
v___y_527_ = v___x_569_;
v___y_528_ = v___x_578_;
v___y_529_ = v___x_556_;
v___y_530_ = v_newAxioms_555_;
v___y_531_ = v___x_558_;
v___y_532_ = v___x_581_;
goto v___jp_524_;
}
}
else
{
lean_object* v___x_583_; lean_object* v___x_584_; 
lean_del_object(v___x_493_);
lean_del_object(v___x_488_);
v___x_583_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_583_, 0, v_fst_490_);
lean_ctor_set(v___x_583_, 1, v_newAxioms_555_);
v___x_584_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_584_, 0, v_fst_486_);
lean_ctor_set(v___x_584_, 1, v___x_583_);
v_as_x27_475_ = v_tail_483_;
v_b_476_ = v___x_584_;
goto _start;
}
}
}
else
{
lean_object* v___x_588_; lean_object* v___x_589_; 
lean_del_object(v___x_493_);
lean_del_object(v___x_488_);
v___x_588_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_588_, 0, v_fst_490_);
lean_ctor_set(v___x_588_, 1, v_snd_491_);
v___x_589_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_589_, 0, v_fst_486_);
lean_ctor_set(v___x_589_, 1, v___x_588_);
v_as_x27_475_ = v_tail_483_;
v_b_476_ = v___x_589_;
goto _start;
}
v___jp_496_:
{
lean_object* v___x_504_; lean_object* v_a_505_; lean_object* v___x_506_; lean_object* v___x_507_; uint8_t v___x_508_; 
lean_dec_ref(v___y_502_);
lean_inc(v_fst_484_);
v___x_504_ = l_Lean_collectAxioms___at___00elaborateOne_spec__1___redArg(v_fst_484_, v___y_503_);
lean_dec(v___y_503_);
v_a_505_ = lean_ctor_get(v___x_504_, 0);
lean_inc(v_a_505_);
lean_dec_ref(v___x_504_);
v___x_506_ = lean_st_ref_get(v___y_499_);
lean_dec(v___y_499_);
lean_dec(v___x_506_);
v___x_507_ = ((lean_object*)(l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___closed__1));
v___x_508_ = l_Array_contains___at___00__private_Lean_Linter_CheckUnivs_0__Lean_Linter_CheckUnivs_badParams_spec__0(v_a_505_, v___x_507_);
lean_dec(v_a_505_);
if (v___x_508_ == 0)
{
lean_object* v___x_510_; 
lean_dec_ref(v___y_501_);
if (v_isShared_494_ == 0)
{
lean_ctor_set(v___x_493_, 1, v___y_500_);
v___x_510_ = v___x_493_;
goto v_reusejp_509_;
}
else
{
lean_object* v_reuseFailAlloc_515_; 
v_reuseFailAlloc_515_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_515_, 0, v_fst_490_);
lean_ctor_set(v_reuseFailAlloc_515_, 1, v___y_500_);
v___x_510_ = v_reuseFailAlloc_515_;
goto v_reusejp_509_;
}
v_reusejp_509_:
{
lean_object* v___x_512_; 
if (v_isShared_489_ == 0)
{
lean_ctor_set(v___x_488_, 1, v___x_510_);
lean_ctor_set(v___x_488_, 0, v___y_498_);
v___x_512_ = v___x_488_;
goto v_reusejp_511_;
}
else
{
lean_object* v_reuseFailAlloc_514_; 
v_reuseFailAlloc_514_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_514_, 0, v___y_498_);
lean_ctor_set(v_reuseFailAlloc_514_, 1, v___x_510_);
v___x_512_ = v_reuseFailAlloc_514_;
goto v_reusejp_511_;
}
v_reusejp_511_:
{
v_as_x27_475_ = v_tail_483_;
v_b_476_ = v___x_512_;
goto _start;
}
}
}
else
{
lean_object* v___x_516_; lean_object* v___x_518_; 
v___x_516_ = lean_array_push(v_fst_490_, v___y_501_);
if (v_isShared_494_ == 0)
{
lean_ctor_set(v___x_493_, 1, v___y_500_);
lean_ctor_set(v___x_493_, 0, v___x_516_);
v___x_518_ = v___x_493_;
goto v_reusejp_517_;
}
else
{
lean_object* v_reuseFailAlloc_523_; 
v_reuseFailAlloc_523_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_523_, 0, v___x_516_);
lean_ctor_set(v_reuseFailAlloc_523_, 1, v___y_500_);
v___x_518_ = v_reuseFailAlloc_523_;
goto v_reusejp_517_;
}
v_reusejp_517_:
{
lean_object* v___x_520_; 
if (v_isShared_489_ == 0)
{
lean_ctor_set(v___x_488_, 1, v___x_518_);
lean_ctor_set(v___x_488_, 0, v___y_498_);
v___x_520_ = v___x_488_;
goto v_reusejp_519_;
}
else
{
lean_object* v_reuseFailAlloc_522_; 
v_reuseFailAlloc_522_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_522_, 0, v___y_498_);
lean_ctor_set(v_reuseFailAlloc_522_, 1, v___x_518_);
v___x_520_ = v_reuseFailAlloc_522_;
goto v_reusejp_519_;
}
v_reusejp_519_:
{
v_as_x27_475_ = v_tail_483_;
v_b_476_ = v___x_520_;
goto _start;
}
}
}
}
v___jp_524_:
{
if (v___y_532_ == 0)
{
lean_object* v___x_533_; lean_object* v_env_534_; lean_object* v_nextMacroScope_535_; lean_object* v_ngen_536_; lean_object* v_auxDeclNGen_537_; lean_object* v_traceState_538_; lean_object* v_messages_539_; lean_object* v_infoState_540_; lean_object* v_snapshotTasks_541_; lean_object* v___x_543_; uint8_t v_isShared_544_; uint8_t v_isSharedCheck_550_; 
v___x_533_ = lean_st_ref_take(v___y_527_);
v_env_534_ = lean_ctor_get(v___x_533_, 0);
v_nextMacroScope_535_ = lean_ctor_get(v___x_533_, 1);
v_ngen_536_ = lean_ctor_get(v___x_533_, 2);
v_auxDeclNGen_537_ = lean_ctor_get(v___x_533_, 3);
v_traceState_538_ = lean_ctor_get(v___x_533_, 4);
v_messages_539_ = lean_ctor_get(v___x_533_, 6);
v_infoState_540_ = lean_ctor_get(v___x_533_, 7);
v_snapshotTasks_541_ = lean_ctor_get(v___x_533_, 8);
v_isSharedCheck_550_ = !lean_is_exclusive(v___x_533_);
if (v_isSharedCheck_550_ == 0)
{
lean_object* v_unused_551_; 
v_unused_551_ = lean_ctor_get(v___x_533_, 5);
lean_dec(v_unused_551_);
v___x_543_ = v___x_533_;
v_isShared_544_ = v_isSharedCheck_550_;
goto v_resetjp_542_;
}
else
{
lean_inc(v_snapshotTasks_541_);
lean_inc(v_infoState_540_);
lean_inc(v_messages_539_);
lean_inc(v_traceState_538_);
lean_inc(v_auxDeclNGen_537_);
lean_inc(v_ngen_536_);
lean_inc(v_nextMacroScope_535_);
lean_inc(v_env_534_);
lean_dec(v___x_533_);
v___x_543_ = lean_box(0);
v_isShared_544_ = v_isSharedCheck_550_;
goto v_resetjp_542_;
}
v_resetjp_542_:
{
lean_object* v___x_545_; lean_object* v___x_547_; 
v___x_545_ = l_Lean_Kernel_enableDiag(v_env_534_, v___y_525_);
lean_inc_ref(v___y_529_);
if (v_isShared_544_ == 0)
{
lean_ctor_set(v___x_543_, 5, v___y_529_);
lean_ctor_set(v___x_543_, 0, v___x_545_);
v___x_547_ = v___x_543_;
goto v_reusejp_546_;
}
else
{
lean_object* v_reuseFailAlloc_549_; 
v_reuseFailAlloc_549_ = lean_alloc_ctor(0, 9, 0);
lean_ctor_set(v_reuseFailAlloc_549_, 0, v___x_545_);
lean_ctor_set(v_reuseFailAlloc_549_, 1, v_nextMacroScope_535_);
lean_ctor_set(v_reuseFailAlloc_549_, 2, v_ngen_536_);
lean_ctor_set(v_reuseFailAlloc_549_, 3, v_auxDeclNGen_537_);
lean_ctor_set(v_reuseFailAlloc_549_, 4, v_traceState_538_);
lean_ctor_set(v_reuseFailAlloc_549_, 5, v___y_529_);
lean_ctor_set(v_reuseFailAlloc_549_, 6, v_messages_539_);
lean_ctor_set(v_reuseFailAlloc_549_, 7, v_infoState_540_);
lean_ctor_set(v_reuseFailAlloc_549_, 8, v_snapshotTasks_541_);
v___x_547_ = v_reuseFailAlloc_549_;
goto v_reusejp_546_;
}
v_reusejp_546_:
{
lean_object* v___x_548_; 
v___x_548_ = lean_st_ref_set(v___y_527_, v___x_547_);
lean_inc(v___y_527_);
v___y_497_ = v___y_525_;
v___y_498_ = v___y_526_;
v___y_499_ = v___y_527_;
v___y_500_ = v___y_530_;
v___y_501_ = v___y_531_;
v___y_502_ = v___y_528_;
v___y_503_ = v___y_527_;
goto v___jp_496_;
}
}
}
else
{
lean_inc(v___y_527_);
v___y_497_ = v___y_525_;
v___y_498_ = v___y_526_;
v___y_499_ = v___y_527_;
v___y_500_ = v___y_530_;
v___y_501_ = v___y_531_;
v___y_502_ = v___y_528_;
v___y_503_ = v___y_527_;
goto v___jp_496_;
}
}
}
}
}
}
}
LEAN_EXPORT lean_object* l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg___boxed(lean_object* v___x_594_, lean_object* v_ctx_595_, lean_object* v_file_596_, lean_object* v_base_597_, lean_object* v_as_x27_598_, lean_object* v_b_599_, lean_object* v___y_600_){
_start:
{
lean_object* v_res_601_; 
v_res_601_ = l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg(v___x_594_, v_ctx_595_, v_file_596_, v_base_597_, v_as_x27_598_, v_b_599_);
lean_dec(v_as_x27_598_);
lean_dec_ref(v_ctx_595_);
return v_res_601_;
}
}
static lean_object* _init_l_elaborateOne___closed__2(void){
_start:
{
lean_object* v___x_605_; lean_object* v___x_606_; lean_object* v___x_607_; lean_object* v___x_608_; 
v___x_605_ = lean_unsigned_to_nat(2000000u);
v___x_606_ = ((lean_object*)(l_elaborateOne___closed__1));
v___x_607_ = l_Lean_Options_empty;
v___x_608_ = l_Lean_Options_set___at___00Lean_Option_set___at___00__private_Lean_Shell_0__Lean_ShellOptions_process_spec__2_spec__3(v___x_607_, v___x_606_, v___x_605_);
return v___x_608_;
}
}
static lean_object* _init_l_elaborateOne___closed__5(void){
_start:
{
lean_object* v___x_612_; lean_object* v___x_613_; lean_object* v___x_614_; lean_object* v___x_615_; 
v___x_612_ = lean_unsigned_to_nat(20000u);
v___x_613_ = ((lean_object*)(l_elaborateOne___closed__4));
v___x_614_ = lean_obj_once(&l_elaborateOne___closed__2, &l_elaborateOne___closed__2_once, _init_l_elaborateOne___closed__2);
v___x_615_ = l_Lean_Options_set___at___00Lean_Option_set___at___00__private_Lean_Shell_0__Lean_ShellOptions_process_spec__2_spec__3(v___x_614_, v___x_613_, v___x_612_);
return v___x_615_;
}
}
static lean_object* _init_l_elaborateOne___closed__9(void){
_start:
{
uint8_t v___x_621_; lean_object* v___x_622_; lean_object* v___x_623_; lean_object* v_opts_624_; 
v___x_621_ = 0;
v___x_622_ = ((lean_object*)(l_elaborateOne___closed__8));
v___x_623_ = lean_obj_once(&l_elaborateOne___closed__5, &l_elaborateOne___closed__5_once, _init_l_elaborateOne___closed__5);
v_opts_624_ = l_Lean_Options_set___at___00Lean_Option_set___at___00__private_Lean_Shell_0__Lean_ShellOptions_process_spec__1_spec__1(v___x_623_, v___x_622_, v___x_621_);
return v_opts_624_;
}
}
LEAN_EXPORT lean_object* l_elaborateOne(lean_object* v_base_652_, lean_object* v_ctx_653_, lean_object* v_ps_654_, lean_object* v_headerMsgs_655_, lean_object* v_file_656_, lean_object* v_moduleText_657_, lean_object* v_workers_658_, lean_object* v_index_659_){
_start:
{
lean_object* v___x_661_; lean_object* v___x_662_; lean_object* v_pos_663_; lean_object* v_opts_664_; lean_object* v___x_665_; lean_object* v___x_666_; lean_object* v___x_667_; lean_object* v___x_668_; lean_object* v___x_669_; 
v___x_661_ = lean_unsigned_to_nat(0u);
v___x_662_ = lean_obj_once(&l_commands___closed__2, &l_commands___closed__2_once, _init_l_commands___closed__2);
v_pos_663_ = lean_ctor_get(v_ps_654_, 0);
lean_inc(v_pos_663_);
v_opts_664_ = lean_obj_once(&l_elaborateOne___closed__9, &l_elaborateOne___closed__9_once, _init_l_elaborateOne___closed__9);
lean_inc_ref(v_base_652_);
v___x_665_ = l_Lean_Elab_Command_mkState(v_base_652_, v___x_662_, v_opts_664_);
v___x_666_ = ((lean_object*)(l_elaborateOne___closed__10));
v___x_667_ = lean_alloc_ctor(0, 4, 0);
lean_ctor_set(v___x_667_, 0, v___x_665_);
lean_ctor_set(v___x_667_, 1, v_ps_654_);
lean_ctor_set(v___x_667_, 2, v_pos_663_);
lean_ctor_set(v___x_667_, 3, v___x_666_);
v___x_668_ = lean_st_mk_ref(v___x_667_);
v___x_669_ = l_commands(v___x_666_, v___x_666_, v_ctx_653_, v___x_668_);
if (lean_obj_tag(v___x_669_) == 0)
{
lean_object* v_a_670_; lean_object* v___x_672_; uint8_t v_isShared_673_; uint8_t v_isSharedCheck_834_; 
v_a_670_ = lean_ctor_get(v___x_669_, 0);
v_isSharedCheck_834_ = !lean_is_exclusive(v___x_669_);
if (v_isSharedCheck_834_ == 0)
{
v___x_672_ = v___x_669_;
v_isShared_673_ = v_isSharedCheck_834_;
goto v_resetjp_671_;
}
else
{
lean_inc(v_a_670_);
lean_dec(v___x_669_);
v___x_672_ = lean_box(0);
v_isShared_673_ = v_isSharedCheck_834_;
goto v_resetjp_671_;
}
v_resetjp_671_:
{
lean_object* v___x_674_; lean_object* v_fst_675_; lean_object* v_snd_676_; lean_object* v___x_678_; uint8_t v_isShared_679_; uint8_t v_isSharedCheck_833_; 
v___x_674_ = lean_st_ref_get(v___x_668_);
lean_dec(v___x_668_);
v_fst_675_ = lean_ctor_get(v_a_670_, 0);
v_snd_676_ = lean_ctor_get(v_a_670_, 1);
v_isSharedCheck_833_ = !lean_is_exclusive(v_a_670_);
if (v_isSharedCheck_833_ == 0)
{
v___x_678_ = v_a_670_;
v_isShared_679_ = v_isSharedCheck_833_;
goto v_resetjp_677_;
}
else
{
lean_inc(v_snd_676_);
lean_inc(v_fst_675_);
lean_dec(v_a_670_);
v___x_678_ = lean_box(0);
v_isShared_679_ = v_isSharedCheck_833_;
goto v_resetjp_677_;
}
v_resetjp_677_:
{
lean_object* v___y_681_; lean_object* v___y_682_; lean_object* v___y_683_; lean_object* v___y_684_; lean_object* v___y_685_; lean_object* v___y_686_; lean_object* v___y_687_; lean_object* v___y_688_; lean_object* v___y_689_; lean_object* v___y_690_; lean_object* v___x_713_; lean_object* v___x_714_; size_t v_sz_715_; size_t v___x_716_; lean_object* v___x_717_; 
v___x_713_ = l_Lean_MessageLog_toArray(v_headerMsgs_655_);
v___x_714_ = l_Array_append___redArg(v___x_713_, v_snd_676_);
lean_dec(v_snd_676_);
v_sz_715_ = lean_array_size(v___x_714_);
v___x_716_ = ((size_t)0ULL);
v___x_717_ = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00elaborateOne_spec__0(v___x_714_, v_sz_715_, v___x_716_, v___x_666_);
lean_dec_ref(v___x_714_);
if (lean_obj_tag(v___x_717_) == 0)
{
lean_object* v_commandState_718_; lean_object* v_a_719_; lean_object* v_env_720_; lean_object* v___x_721_; lean_object* v_map_u2082_722_; lean_object* v___x_723_; lean_object* v___x_724_; lean_object* v___x_725_; 
v_commandState_718_ = lean_ctor_get(v___x_674_, 0);
lean_inc_ref(v_commandState_718_);
lean_dec(v___x_674_);
v_a_719_ = lean_ctor_get(v___x_717_, 0);
lean_inc(v_a_719_);
lean_dec_ref_known(v___x_717_, 1);
v_env_720_ = lean_ctor_get(v_commandState_718_, 0);
lean_inc_ref_n(v_env_720_, 2);
lean_dec_ref(v_commandState_718_);
v___x_721_ = l_Lean_Environment_constants(v_env_720_);
v_map_u2082_722_ = lean_ctor_get(v___x_721_, 1);
lean_inc_ref(v_map_u2082_722_);
lean_dec_ref(v___x_721_);
v___x_723_ = l_Lean_PersistentHashMap_toList___at___00__private_Lean_Linter_TacticTypeCheck_0__Lean_Linter_tacticCheckInstances_spec__6___redArg(v_map_u2082_722_);
lean_dec_ref(v_map_u2082_722_);
v___x_724_ = ((lean_object*)(l_elaborateOne___closed__18));
v___x_725_ = l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg(v_env_720_, v_ctx_653_, v_file_656_, v_base_652_, v___x_723_, v___x_724_);
lean_dec(v___x_723_);
if (lean_obj_tag(v___x_725_) == 0)
{
lean_object* v_a_726_; lean_object* v_fst_727_; lean_object* v_snd_728_; lean_object* v___x_730_; uint8_t v_isShared_731_; uint8_t v_isSharedCheck_816_; 
v_a_726_ = lean_ctor_get(v___x_725_, 0);
lean_inc(v_a_726_);
lean_dec_ref_known(v___x_725_, 1);
v_fst_727_ = lean_ctor_get(v_a_726_, 0);
v_snd_728_ = lean_ctor_get(v_a_726_, 1);
v_isSharedCheck_816_ = !lean_is_exclusive(v_a_726_);
if (v_isSharedCheck_816_ == 0)
{
v___x_730_ = v_a_726_;
v_isShared_731_ = v_isSharedCheck_816_;
goto v_resetjp_729_;
}
else
{
lean_inc(v_snd_728_);
lean_inc(v_fst_727_);
lean_dec(v_a_726_);
v___x_730_ = lean_box(0);
v_isShared_731_ = v_isSharedCheck_816_;
goto v_resetjp_729_;
}
v_resetjp_729_:
{
lean_object* v___y_733_; lean_object* v___y_734_; lean_object* v___y_735_; lean_object* v___y_736_; lean_object* v___y_737_; lean_object* v___y_738_; lean_object* v___y_739_; lean_object* v___y_740_; lean_object* v___y_741_; lean_object* v___y_742_; lean_object* v___y_743_; lean_object* v___y_744_; lean_object* v___y_747_; lean_object* v___y_748_; lean_object* v___y_749_; lean_object* v___y_750_; lean_object* v___y_751_; lean_object* v___y_752_; lean_object* v___y_753_; lean_object* v___y_754_; lean_object* v___y_755_; lean_object* v___y_756_; lean_object* v___y_757_; lean_object* v___y_758_; lean_object* v_fst_760_; lean_object* v_snd_761_; lean_object* v___x_763_; uint8_t v_isShared_764_; uint8_t v_isSharedCheck_815_; 
v_fst_760_ = lean_ctor_get(v_snd_728_, 0);
v_snd_761_ = lean_ctor_get(v_snd_728_, 1);
v_isSharedCheck_815_ = !lean_is_exclusive(v_snd_728_);
if (v_isSharedCheck_815_ == 0)
{
v___x_763_ = v_snd_728_;
v_isShared_764_ = v_isSharedCheck_815_;
goto v_resetjp_762_;
}
else
{
lean_inc(v_snd_761_);
lean_inc(v_fst_760_);
lean_dec(v_snd_728_);
v___x_763_ = lean_box(0);
v_isShared_764_ = v_isSharedCheck_815_;
goto v_resetjp_762_;
}
v___jp_732_:
{
lean_object* v___x_745_; 
v___x_745_ = l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00__private_Lean_Elab_DocString_Builtin_0__Lean_Doc_validateCat_spec__3___redArg(v___y_738_, v_fst_727_, v___y_736_, v___y_744_);
lean_dec(v___y_744_);
lean_dec(v___y_738_);
v___y_681_ = v___y_733_;
v___y_682_ = v___y_734_;
v___y_683_ = v___y_735_;
v___y_684_ = v___y_737_;
v___y_685_ = v___y_740_;
v___y_686_ = v___y_739_;
v___y_687_ = v___y_741_;
v___y_688_ = v___y_743_;
v___y_689_ = v___y_742_;
v___y_690_ = v___x_745_;
goto v___jp_680_;
}
v___jp_746_:
{
uint8_t v___x_759_; 
v___x_759_ = lean_nat_dec_le(v___y_758_, v___y_748_);
if (v___x_759_ == 0)
{
lean_dec(v___y_748_);
lean_inc(v___y_758_);
v___y_733_ = v___y_747_;
v___y_734_ = v___y_749_;
v___y_735_ = v___y_750_;
v___y_736_ = v___y_758_;
v___y_737_ = v___y_752_;
v___y_738_ = v___y_751_;
v___y_739_ = v___y_754_;
v___y_740_ = v___y_753_;
v___y_741_ = v___y_755_;
v___y_742_ = v___y_757_;
v___y_743_ = v___y_756_;
v___y_744_ = v___y_758_;
goto v___jp_732_;
}
else
{
v___y_733_ = v___y_747_;
v___y_734_ = v___y_749_;
v___y_735_ = v___y_750_;
v___y_736_ = v___y_758_;
v___y_737_ = v___y_752_;
v___y_738_ = v___y_751_;
v___y_739_ = v___y_754_;
v___y_740_ = v___y_753_;
v___y_741_ = v___y_755_;
v___y_742_ = v___y_757_;
v___y_743_ = v___y_756_;
v___y_744_ = v___y_748_;
goto v___jp_732_;
}
}
v_resetjp_762_:
{
lean_object* v___y_766_; lean_object* v___x_807_; uint8_t v___x_808_; 
v___x_807_ = lean_array_get_size(v_a_719_);
v___x_808_ = lean_nat_dec_eq(v___x_807_, v___x_661_);
if (v___x_808_ == 0)
{
lean_object* v___x_809_; 
v___x_809_ = ((lean_object*)(l_elaborateOne___closed__27));
v___y_766_ = v___x_809_;
goto v___jp_765_;
}
else
{
lean_object* v___x_810_; uint8_t v___x_811_; 
v___x_810_ = lean_array_get_size(v_fst_760_);
v___x_811_ = lean_nat_dec_eq(v___x_810_, v___x_661_);
if (v___x_811_ == 0)
{
goto v___jp_805_;
}
else
{
lean_object* v___x_812_; uint8_t v___x_813_; 
v___x_812_ = lean_array_get_size(v_snd_761_);
v___x_813_ = lean_nat_dec_eq(v___x_812_, v___x_661_);
if (v___x_813_ == 0)
{
goto v___jp_805_;
}
else
{
lean_object* v___x_814_; 
v___x_814_ = ((lean_object*)(l_one___closed__4));
v___y_766_ = v___x_814_;
goto v___jp_765_;
}
}
}
v___jp_765_:
{
uint64_t v___x_767_; lean_object* v___x_768_; lean_object* v___x_769_; lean_object* v___x_771_; 
v___x_767_ = lean_io_get_tid();
v___x_768_ = ((lean_object*)(l_elaborateOne___closed__19));
v___x_769_ = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(v___x_769_, 0, v_moduleText_657_);
if (v_isShared_764_ == 0)
{
lean_ctor_set(v___x_763_, 1, v___x_769_);
lean_ctor_set(v___x_763_, 0, v___x_768_);
v___x_771_ = v___x_763_;
goto v_reusejp_770_;
}
else
{
lean_object* v_reuseFailAlloc_804_; 
v_reuseFailAlloc_804_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_804_, 0, v___x_768_);
lean_ctor_set(v_reuseFailAlloc_804_, 1, v___x_769_);
v___x_771_ = v_reuseFailAlloc_804_;
goto v_reusejp_770_;
}
v_reusejp_770_:
{
lean_object* v___x_772_; lean_object* v___x_773_; lean_object* v___x_774_; lean_object* v___x_776_; 
v___x_772_ = ((lean_object*)(l_elaborateOne___closed__20));
v___x_773_ = l_Lean_JsonNumber_fromNat(v_workers_658_);
v___x_774_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_774_, 0, v___x_773_);
if (v_isShared_731_ == 0)
{
lean_ctor_set(v___x_730_, 1, v___x_774_);
lean_ctor_set(v___x_730_, 0, v___x_772_);
v___x_776_ = v___x_730_;
goto v_reusejp_775_;
}
else
{
lean_object* v_reuseFailAlloc_803_; 
v_reuseFailAlloc_803_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_803_, 0, v___x_772_);
lean_ctor_set(v_reuseFailAlloc_803_, 1, v___x_774_);
v___x_776_ = v_reuseFailAlloc_803_;
goto v_reusejp_775_;
}
v_reusejp_775_:
{
lean_object* v___x_777_; lean_object* v___x_778_; lean_object* v___x_779_; lean_object* v___x_780_; lean_object* v___x_781_; lean_object* v___x_782_; lean_object* v___x_783_; lean_object* v___x_784_; lean_object* v___x_785_; lean_object* v___x_786_; lean_object* v___x_787_; lean_object* v___x_788_; lean_object* v___x_789_; lean_object* v___x_790_; lean_object* v___x_791_; lean_object* v___x_792_; lean_object* v___x_793_; lean_object* v___x_794_; lean_object* v___x_795_; lean_object* v___x_796_; lean_object* v___x_797_; lean_object* v___x_798_; uint8_t v___x_799_; 
v___x_777_ = ((lean_object*)(l_elaborateOne___closed__21));
v___x_778_ = l_Lean_JsonNumber_fromNat(v_index_659_);
v___x_779_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_779_, 0, v___x_778_);
v___x_780_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_780_, 0, v___x_777_);
lean_ctor_set(v___x_780_, 1, v___x_779_);
v___x_781_ = ((lean_object*)(l_instToJsonUnitRow_toJson___closed__6));
v___x_782_ = lean_uint64_to_nat(v___x_767_);
v___x_783_ = l_Lean_bignumToJson(v___x_782_);
v___x_784_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_784_, 0, v___x_781_);
lean_ctor_set(v___x_784_, 1, v___x_783_);
v___x_785_ = ((lean_object*)(l_instToJsonUnitRow_toJson___closed__4));
lean_inc_ref(v___y_766_);
v___x_786_ = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(v___x_786_, 0, v___y_766_);
v___x_787_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_787_, 0, v___x_785_);
lean_ctor_set(v___x_787_, 1, v___x_786_);
v___x_788_ = ((lean_object*)(l_elaborateOne___closed__22));
v___x_789_ = l_Lean_Array_toJson___at___00Lean_Server_Test_Runner_Client_instToJsonHyp_toJson_spec__1(v_a_719_);
v___x_790_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_790_, 0, v___x_788_);
lean_ctor_set(v___x_790_, 1, v___x_789_);
v___x_791_ = ((lean_object*)(l_elaborateOne___closed__23));
v___x_792_ = l_Lean_Array_toJson___at___00Lean_Server_Test_Runner_Client_instToJsonHyp_toJson_spec__1(v_fst_760_);
v___x_793_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_793_, 0, v___x_791_);
lean_ctor_set(v___x_793_, 1, v___x_792_);
v___x_794_ = ((lean_object*)(l_elaborateOne___closed__24));
v___x_795_ = l_Lean_Array_toJson___at___00Lean_Server_Test_Runner_Client_instToJsonHyp_toJson_spec__1(v_snd_761_);
v___x_796_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_796_, 0, v___x_794_);
lean_ctor_set(v___x_796_, 1, v___x_795_);
v___x_797_ = ((lean_object*)(l_elaborateOne___closed__25));
v___x_798_ = lean_array_get_size(v_fst_727_);
v___x_799_ = lean_nat_dec_eq(v___x_798_, v___x_661_);
if (v___x_799_ == 0)
{
lean_object* v___x_800_; lean_object* v___x_801_; uint8_t v___x_802_; 
v___x_800_ = lean_unsigned_to_nat(1u);
v___x_801_ = lean_nat_sub(v___x_798_, v___x_800_);
v___x_802_ = lean_nat_dec_le(v___x_661_, v___x_801_);
if (v___x_802_ == 0)
{
lean_inc(v___x_801_);
v___y_747_ = v___x_771_;
v___y_748_ = v___x_801_;
v___y_749_ = v___x_796_;
v___y_750_ = v___x_793_;
v___y_751_ = v___x_798_;
v___y_752_ = v___x_787_;
v___y_753_ = v___x_790_;
v___y_754_ = v___x_797_;
v___y_755_ = v___x_780_;
v___y_756_ = v___x_776_;
v___y_757_ = v___x_784_;
v___y_758_ = v___x_801_;
goto v___jp_746_;
}
else
{
v___y_747_ = v___x_771_;
v___y_748_ = v___x_801_;
v___y_749_ = v___x_796_;
v___y_750_ = v___x_793_;
v___y_751_ = v___x_798_;
v___y_752_ = v___x_787_;
v___y_753_ = v___x_790_;
v___y_754_ = v___x_797_;
v___y_755_ = v___x_780_;
v___y_756_ = v___x_776_;
v___y_757_ = v___x_784_;
v___y_758_ = v___x_661_;
goto v___jp_746_;
}
}
else
{
v___y_681_ = v___x_771_;
v___y_682_ = v___x_796_;
v___y_683_ = v___x_793_;
v___y_684_ = v___x_787_;
v___y_685_ = v___x_790_;
v___y_686_ = v___x_797_;
v___y_687_ = v___x_780_;
v___y_688_ = v___x_776_;
v___y_689_ = v___x_784_;
v___y_690_ = v_fst_727_;
goto v___jp_680_;
}
}
}
}
v___jp_805_:
{
lean_object* v___x_806_; 
v___x_806_ = ((lean_object*)(l_elaborateOne___closed__26));
v___y_766_ = v___x_806_;
goto v___jp_765_;
}
}
}
}
else
{
lean_object* v_a_817_; lean_object* v___x_819_; uint8_t v_isShared_820_; uint8_t v_isSharedCheck_824_; 
lean_dec(v_a_719_);
lean_del_object(v___x_678_);
lean_dec(v_fst_675_);
lean_del_object(v___x_672_);
lean_dec(v_index_659_);
lean_dec(v_workers_658_);
lean_dec_ref(v_moduleText_657_);
v_a_817_ = lean_ctor_get(v___x_725_, 0);
v_isSharedCheck_824_ = !lean_is_exclusive(v___x_725_);
if (v_isSharedCheck_824_ == 0)
{
v___x_819_ = v___x_725_;
v_isShared_820_ = v_isSharedCheck_824_;
goto v_resetjp_818_;
}
else
{
lean_inc(v_a_817_);
lean_dec(v___x_725_);
v___x_819_ = lean_box(0);
v_isShared_820_ = v_isSharedCheck_824_;
goto v_resetjp_818_;
}
v_resetjp_818_:
{
lean_object* v___x_822_; 
if (v_isShared_820_ == 0)
{
v___x_822_ = v___x_819_;
goto v_reusejp_821_;
}
else
{
lean_object* v_reuseFailAlloc_823_; 
v_reuseFailAlloc_823_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_823_, 0, v_a_817_);
v___x_822_ = v_reuseFailAlloc_823_;
goto v_reusejp_821_;
}
v_reusejp_821_:
{
return v___x_822_;
}
}
}
}
else
{
lean_object* v_a_825_; lean_object* v___x_827_; uint8_t v_isShared_828_; uint8_t v_isSharedCheck_832_; 
lean_del_object(v___x_678_);
lean_dec(v_fst_675_);
lean_dec(v___x_674_);
lean_del_object(v___x_672_);
lean_dec(v_index_659_);
lean_dec(v_workers_658_);
lean_dec_ref(v_moduleText_657_);
lean_dec_ref(v_file_656_);
lean_dec_ref(v_base_652_);
v_a_825_ = lean_ctor_get(v___x_717_, 0);
v_isSharedCheck_832_ = !lean_is_exclusive(v___x_717_);
if (v_isSharedCheck_832_ == 0)
{
v___x_827_ = v___x_717_;
v_isShared_828_ = v_isSharedCheck_832_;
goto v_resetjp_826_;
}
else
{
lean_inc(v_a_825_);
lean_dec(v___x_717_);
v___x_827_ = lean_box(0);
v_isShared_828_ = v_isSharedCheck_832_;
goto v_resetjp_826_;
}
v_resetjp_826_:
{
lean_object* v___x_830_; 
if (v_isShared_828_ == 0)
{
v___x_830_ = v___x_827_;
goto v_reusejp_829_;
}
else
{
lean_object* v_reuseFailAlloc_831_; 
v_reuseFailAlloc_831_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_831_, 0, v_a_825_);
v___x_830_ = v_reuseFailAlloc_831_;
goto v_reusejp_829_;
}
v_reusejp_829_:
{
return v___x_830_;
}
}
}
v___jp_680_:
{
lean_object* v___x_691_; lean_object* v___x_693_; 
v___x_691_ = l_Lean_Array_toJson___at___00Lean_Server_Test_Runner_Client_instToJsonHyp_toJson_spec__1(v___y_690_);
lean_inc_ref(v___y_686_);
if (v_isShared_679_ == 0)
{
lean_ctor_set(v___x_678_, 1, v___x_691_);
lean_ctor_set(v___x_678_, 0, v___y_686_);
v___x_693_ = v___x_678_;
goto v_reusejp_692_;
}
else
{
lean_object* v_reuseFailAlloc_712_; 
v_reuseFailAlloc_712_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_712_, 0, v___y_686_);
lean_ctor_set(v_reuseFailAlloc_712_, 1, v___x_691_);
v___x_693_ = v_reuseFailAlloc_712_;
goto v_reusejp_692_;
}
v_reusejp_692_:
{
lean_object* v___x_694_; lean_object* v___x_695_; lean_object* v___x_696_; lean_object* v___x_697_; lean_object* v___x_698_; lean_object* v___x_699_; lean_object* v___x_700_; lean_object* v___x_701_; lean_object* v___x_702_; lean_object* v___x_703_; lean_object* v___x_704_; lean_object* v___x_705_; lean_object* v___x_706_; lean_object* v___x_707_; lean_object* v___x_708_; lean_object* v___x_710_; 
v___x_694_ = ((lean_object*)(l_elaborateOne___closed__11));
v___x_695_ = l_Lean_Array_toJson___at___00Lean_Server_FileWorker_handlePreRequestSpecialCases_x3f_spec__6(v_fst_675_);
v___x_696_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_696_, 0, v___x_694_);
lean_ctor_set(v___x_696_, 1, v___x_695_);
v___x_697_ = ((lean_object*)(l_elaborateOne___closed__16));
v___x_698_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_698_, 0, v___x_696_);
lean_ctor_set(v___x_698_, 1, v___x_697_);
v___x_699_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_699_, 0, v___x_693_);
lean_ctor_set(v___x_699_, 1, v___x_698_);
v___x_700_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_700_, 0, v___y_682_);
lean_ctor_set(v___x_700_, 1, v___x_699_);
v___x_701_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_701_, 0, v___y_683_);
lean_ctor_set(v___x_701_, 1, v___x_700_);
v___x_702_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_702_, 0, v___y_685_);
lean_ctor_set(v___x_702_, 1, v___x_701_);
v___x_703_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_703_, 0, v___y_684_);
lean_ctor_set(v___x_703_, 1, v___x_702_);
v___x_704_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_704_, 0, v___y_689_);
lean_ctor_set(v___x_704_, 1, v___x_703_);
v___x_705_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_705_, 0, v___y_687_);
lean_ctor_set(v___x_705_, 1, v___x_704_);
v___x_706_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_706_, 0, v___y_688_);
lean_ctor_set(v___x_706_, 1, v___x_705_);
v___x_707_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_707_, 0, v___y_681_);
lean_ctor_set(v___x_707_, 1, v___x_706_);
v___x_708_ = l_Lean_Json_mkObj(v___x_707_);
lean_dec_ref_known(v___x_707_, 2);
if (v_isShared_673_ == 0)
{
lean_ctor_set(v___x_672_, 0, v___x_708_);
v___x_710_ = v___x_672_;
goto v_reusejp_709_;
}
else
{
lean_object* v_reuseFailAlloc_711_; 
v_reuseFailAlloc_711_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_711_, 0, v___x_708_);
v___x_710_ = v_reuseFailAlloc_711_;
goto v_reusejp_709_;
}
v_reusejp_709_:
{
return v___x_710_;
}
}
}
}
}
}
else
{
lean_object* v_a_835_; lean_object* v___x_837_; uint8_t v_isShared_838_; uint8_t v_isSharedCheck_842_; 
lean_dec(v___x_668_);
lean_dec(v_index_659_);
lean_dec(v_workers_658_);
lean_dec_ref(v_moduleText_657_);
lean_dec_ref(v_file_656_);
lean_dec_ref(v_base_652_);
v_a_835_ = lean_ctor_get(v___x_669_, 0);
v_isSharedCheck_842_ = !lean_is_exclusive(v___x_669_);
if (v_isSharedCheck_842_ == 0)
{
v___x_837_ = v___x_669_;
v_isShared_838_ = v_isSharedCheck_842_;
goto v_resetjp_836_;
}
else
{
lean_inc(v_a_835_);
lean_dec(v___x_669_);
v___x_837_ = lean_box(0);
v_isShared_838_ = v_isSharedCheck_842_;
goto v_resetjp_836_;
}
v_resetjp_836_:
{
lean_object* v___x_840_; 
if (v_isShared_838_ == 0)
{
v___x_840_ = v___x_837_;
goto v_reusejp_839_;
}
else
{
lean_object* v_reuseFailAlloc_841_; 
v_reuseFailAlloc_841_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_841_, 0, v_a_835_);
v___x_840_ = v_reuseFailAlloc_841_;
goto v_reusejp_839_;
}
v_reusejp_839_:
{
return v___x_840_;
}
}
}
}
}
LEAN_EXPORT lean_object* l_elaborateOne___boxed(lean_object* v_base_843_, lean_object* v_ctx_844_, lean_object* v_ps_845_, lean_object* v_headerMsgs_846_, lean_object* v_file_847_, lean_object* v_moduleText_848_, lean_object* v_workers_849_, lean_object* v_index_850_, lean_object* v_a_851_){
_start:
{
lean_object* v_res_852_; 
v_res_852_ = l_elaborateOne(v_base_843_, v_ctx_844_, v_ps_845_, v_headerMsgs_846_, v_file_847_, v_moduleText_848_, v_workers_849_, v_index_850_);
lean_dec_ref(v_headerMsgs_846_);
lean_dec_ref(v_ctx_844_);
return v_res_852_;
}
}
LEAN_EXPORT lean_object* l_List_forIn_x27_loop___at___00elaborateOne_spec__2(lean_object* v___x_853_, lean_object* v_ctx_854_, lean_object* v_file_855_, lean_object* v_base_856_, lean_object* v_as_857_, lean_object* v_as_x27_858_, lean_object* v_b_859_, lean_object* v_a_860_){
_start:
{
lean_object* v___x_862_; 
v___x_862_ = l_List_forIn_x27_loop___at___00elaborateOne_spec__2___redArg(v___x_853_, v_ctx_854_, v_file_855_, v_base_856_, v_as_x27_858_, v_b_859_);
return v___x_862_;
}
}
LEAN_EXPORT lean_object* l_List_forIn_x27_loop___at___00elaborateOne_spec__2___boxed(lean_object* v___x_863_, lean_object* v_ctx_864_, lean_object* v_file_865_, lean_object* v_base_866_, lean_object* v_as_867_, lean_object* v_as_x27_868_, lean_object* v_b_869_, lean_object* v_a_870_, lean_object* v___y_871_){
_start:
{
lean_object* v_res_872_; 
v_res_872_ = l_List_forIn_x27_loop___at___00elaborateOne_spec__2(v___x_863_, v_ctx_864_, v_file_865_, v_base_866_, v_as_867_, v_as_x27_868_, v_b_869_, v_a_870_);
lean_dec(v_as_x27_868_);
lean_dec(v_as_867_);
lean_dec_ref(v_ctx_864_);
return v_res_872_;
}
}
LEAN_EXPORT uint8_t l_Option_instBEq_beq___at___00main_spec__1(lean_object* v_x_873_, lean_object* v_x_874_){
_start:
{
if (lean_obj_tag(v_x_873_) == 0)
{
if (lean_obj_tag(v_x_874_) == 0)
{
uint8_t v___x_875_; 
v___x_875_ = 1;
return v___x_875_;
}
else
{
uint8_t v___x_876_; 
v___x_876_ = 0;
return v___x_876_;
}
}
else
{
if (lean_obj_tag(v_x_874_) == 0)
{
uint8_t v___x_877_; 
v___x_877_ = 0;
return v___x_877_;
}
else
{
lean_object* v_val_878_; lean_object* v_val_879_; uint8_t v___x_880_; 
v_val_878_ = lean_ctor_get(v_x_873_, 0);
v_val_879_ = lean_ctor_get(v_x_874_, 0);
v___x_880_ = lean_nat_dec_eq(v_val_878_, v_val_879_);
return v___x_880_;
}
}
}
}
LEAN_EXPORT lean_object* l_Option_instBEq_beq___at___00main_spec__1___boxed(lean_object* v_x_881_, lean_object* v_x_882_){
_start:
{
uint8_t v_res_883_; lean_object* v_r_884_; 
v_res_883_ = l_Option_instBEq_beq___at___00main_spec__1(v_x_881_, v_x_882_);
lean_dec(v_x_882_);
lean_dec(v_x_881_);
v_r_884_ = lean_box(v_res_883_);
return v_r_884_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__3(lean_object* v_head_889_, lean_object* v_as_890_, size_t v_sz_891_, size_t v_i_892_, lean_object* v_b_893_){
_start:
{
lean_object* v_a_896_; uint8_t v___x_900_; 
v___x_900_ = lean_usize_dec_lt(v_i_892_, v_sz_891_);
if (v___x_900_ == 0)
{
lean_object* v___x_901_; 
v___x_901_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_901_, 0, v_b_893_);
return v___x_901_;
}
else
{
lean_object* v_a_902_; lean_object* v_value_903_; lean_object* v___x_904_; uint8_t v___y_906_; lean_object* v___x_909_; uint8_t v___x_910_; uint8_t v___x_918_; 
v_a_902_ = lean_array_uget_borrowed(v_as_890_, v_i_892_);
v_value_903_ = lean_ctor_get(v_a_902_, 1);
v___x_904_ = lean_box(0);
v___x_909_ = ((lean_object*)(l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__3___closed__2));
v___x_910_ = lean_string_dec_eq(v_head_889_, v___x_909_);
v___x_918_ = l_Lean_Expr_hasSorry(v_value_903_);
if (v___x_918_ == 0)
{
goto v___jp_915_;
}
else
{
if (v___x_910_ == 0)
{
goto v___jp_914_;
}
else
{
goto v___jp_915_;
}
}
v___jp_905_:
{
if (v___y_906_ == 0)
{
lean_object* v___x_907_; lean_object* v___x_908_; 
v___x_907_ = ((lean_object*)(l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__3___closed__1));
v___x_908_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_908_, 0, v___x_907_);
return v___x_908_;
}
else
{
v_a_896_ = v___x_904_;
goto v___jp_895_;
}
}
v___jp_911_:
{
lean_object* v_value_912_; uint8_t v___x_913_; 
v_value_912_ = lean_ctor_get(v_a_902_, 1);
v___x_913_ = l_Lean_Expr_hasMVar(v_value_912_);
if (v___x_913_ == 0)
{
v_a_896_ = v___x_904_;
goto v___jp_895_;
}
else
{
v___y_906_ = v___x_910_;
goto v___jp_905_;
}
}
v___jp_914_:
{
if (v___x_910_ == 0)
{
v___y_906_ = v___x_910_;
goto v___jp_905_;
}
else
{
goto v___jp_911_;
}
}
v___jp_915_:
{
lean_object* v_value_916_; uint8_t v___x_917_; 
v_value_916_ = lean_ctor_get(v_a_902_, 1);
v___x_917_ = l_Lean_Expr_hasFVar(v_value_916_);
if (v___x_917_ == 0)
{
goto v___jp_911_;
}
else
{
goto v___jp_914_;
}
}
}
v___jp_895_:
{
size_t v___x_897_; size_t v___x_898_; 
v___x_897_ = ((size_t)1ULL);
v___x_898_ = lean_usize_add(v_i_892_, v___x_897_);
v_i_892_ = v___x_898_;
v_b_893_ = v_a_896_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__3___boxed(lean_object* v_head_919_, lean_object* v_as_920_, lean_object* v_sz_921_, lean_object* v_i_922_, lean_object* v_b_923_, lean_object* v___y_924_){
_start:
{
size_t v_sz_boxed_925_; size_t v_i_boxed_926_; lean_object* v_res_927_; 
v_sz_boxed_925_ = lean_unbox_usize(v_sz_921_);
lean_dec(v_sz_921_);
v_i_boxed_926_ = lean_unbox_usize(v_i_922_);
lean_dec(v_i_922_);
v_res_927_ = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__3(v_head_919_, v_as_920_, v_sz_boxed_925_, v_i_boxed_926_, v_b_923_);
lean_dec_ref(v_as_920_);
lean_dec_ref(v_head_919_);
return v_res_927_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__16(lean_object* v_as_929_, size_t v_sz_930_, size_t v_i_931_, lean_object* v_b_932_){
_start:
{
uint8_t v___x_934_; 
v___x_934_ = lean_usize_dec_lt(v_i_931_, v_sz_930_);
if (v___x_934_ == 0)
{
lean_object* v___x_935_; 
v___x_935_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_935_, 0, v_b_932_);
return v___x_935_;
}
else
{
lean_object* v_a_936_; lean_object* v___x_937_; lean_object* v___x_938_; lean_object* v___x_939_; lean_object* v___x_940_; 
v_a_936_ = lean_array_uget_borrowed(v_as_929_, v_i_931_);
v___x_937_ = ((lean_object*)(l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__16___closed__0));
lean_inc(v_a_936_);
v___x_938_ = l_Lean_Json_compress(v_a_936_);
v___x_939_ = lean_string_append(v___x_937_, v___x_938_);
lean_dec_ref(v___x_938_);
v___x_940_ = l_IO_println___at___00__private_Lean_Shell_0__Lean_ShellOptions_process_spec__3(v___x_939_);
if (lean_obj_tag(v___x_940_) == 0)
{
lean_object* v___x_941_; size_t v___x_942_; size_t v___x_943_; 
lean_dec_ref_known(v___x_940_, 1);
v___x_941_ = lean_box(0);
v___x_942_ = ((size_t)1ULL);
v___x_943_ = lean_usize_add(v_i_931_, v___x_942_);
v_i_931_ = v___x_943_;
v_b_932_ = v___x_941_;
goto _start;
}
else
{
return v___x_940_;
}
}
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__16___boxed(lean_object* v_as_945_, lean_object* v_sz_946_, lean_object* v_i_947_, lean_object* v_b_948_, lean_object* v___y_949_){
_start:
{
size_t v_sz_boxed_950_; size_t v_i_boxed_951_; lean_object* v_res_952_; 
v_sz_boxed_950_ = lean_unbox_usize(v_sz_946_);
lean_dec(v_sz_946_);
v_i_boxed_951_ = lean_unbox_usize(v_i_947_);
lean_dec(v_i_947_);
v_res_952_ = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__16(v_as_945_, v_sz_boxed_950_, v_i_boxed_951_, v_b_948_);
lean_dec_ref(v_as_945_);
return v_res_952_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__17(lean_object* v_as_953_, size_t v_sz_954_, size_t v_i_955_, lean_object* v_b_956_){
_start:
{
uint8_t v___x_958_; 
v___x_958_ = lean_usize_dec_lt(v_i_955_, v_sz_954_);
if (v___x_958_ == 0)
{
lean_object* v___x_959_; 
v___x_959_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_959_, 0, v_b_956_);
return v___x_959_;
}
else
{
lean_object* v_a_960_; lean_object* v___x_961_; 
v_a_960_ = lean_array_uget_borrowed(v_as_953_, v_i_955_);
lean_inc(v_a_960_);
v___x_961_ = lean_task_get_own(v_a_960_);
if (lean_obj_tag(v___x_961_) == 0)
{
lean_object* v_a_962_; lean_object* v___x_964_; uint8_t v_isShared_965_; uint8_t v_isSharedCheck_969_; 
v_a_962_ = lean_ctor_get(v___x_961_, 0);
v_isSharedCheck_969_ = !lean_is_exclusive(v___x_961_);
if (v_isSharedCheck_969_ == 0)
{
v___x_964_ = v___x_961_;
v_isShared_965_ = v_isSharedCheck_969_;
goto v_resetjp_963_;
}
else
{
lean_inc(v_a_962_);
lean_dec(v___x_961_);
v___x_964_ = lean_box(0);
v_isShared_965_ = v_isSharedCheck_969_;
goto v_resetjp_963_;
}
v_resetjp_963_:
{
lean_object* v___x_967_; 
if (v_isShared_965_ == 0)
{
lean_ctor_set_tag(v___x_964_, 1);
v___x_967_ = v___x_964_;
goto v_reusejp_966_;
}
else
{
lean_object* v_reuseFailAlloc_968_; 
v_reuseFailAlloc_968_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_968_, 0, v_a_962_);
v___x_967_ = v_reuseFailAlloc_968_;
goto v_reusejp_966_;
}
v_reusejp_966_:
{
return v___x_967_;
}
}
}
else
{
lean_object* v_a_970_; lean_object* v___x_971_; size_t v_sz_972_; size_t v___x_973_; lean_object* v___x_974_; 
v_a_970_ = lean_ctor_get(v___x_961_, 0);
lean_inc(v_a_970_);
lean_dec_ref_known(v___x_961_, 1);
v___x_971_ = lean_box(0);
v_sz_972_ = lean_array_size(v_a_970_);
v___x_973_ = ((size_t)0ULL);
v___x_974_ = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__16(v_a_970_, v_sz_972_, v___x_973_, v___x_971_);
lean_dec(v_a_970_);
if (lean_obj_tag(v___x_974_) == 0)
{
size_t v___x_975_; size_t v___x_976_; 
lean_dec_ref_known(v___x_974_, 1);
v___x_975_ = ((size_t)1ULL);
v___x_976_ = lean_usize_add(v_i_955_, v___x_975_);
v_i_955_ = v___x_976_;
v_b_956_ = v___x_971_;
goto _start;
}
else
{
return v___x_974_;
}
}
}
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__17___boxed(lean_object* v_as_978_, lean_object* v_sz_979_, lean_object* v_i_980_, lean_object* v_b_981_, lean_object* v___y_982_){
_start:
{
size_t v_sz_boxed_983_; size_t v_i_boxed_984_; lean_object* v_res_985_; 
v_sz_boxed_983_ = lean_unbox_usize(v_sz_979_);
lean_dec(v_sz_979_);
v_i_boxed_984_ = lean_unbox_usize(v_i_980_);
lean_dec(v_i_980_);
v_res_985_ = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__17(v_as_978_, v_sz_boxed_983_, v_i_boxed_984_, v_b_981_);
lean_dec_ref(v_as_978_);
return v_res_985_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00main_spec__12(lean_object* v_val_986_, lean_object* v_as_987_, size_t v_i_988_, size_t v_stop_989_, lean_object* v_b_990_){
_start:
{
lean_object* v___y_992_; uint8_t v___x_996_; 
v___x_996_ = lean_usize_dec_eq(v_i_988_, v_stop_989_);
if (v___x_996_ == 0)
{
lean_object* v___x_997_; lean_object* v_toConstantVal_998_; lean_object* v_toConstantVal_999_; lean_object* v_name_1000_; lean_object* v_name_1001_; uint8_t v___x_1002_; 
v___x_997_ = lean_array_uget_borrowed(v_as_987_, v_i_988_);
v_toConstantVal_998_ = lean_ctor_get(v___x_997_, 0);
v_toConstantVal_999_ = lean_ctor_get(v_val_986_, 0);
v_name_1000_ = lean_ctor_get(v_toConstantVal_998_, 0);
v_name_1001_ = lean_ctor_get(v_toConstantVal_999_, 0);
v___x_1002_ = lean_name_eq(v_name_1000_, v_name_1001_);
if (v___x_1002_ == 0)
{
lean_object* v___x_1003_; 
lean_inc(v___x_997_);
v___x_1003_ = lean_array_push(v_b_990_, v___x_997_);
v___y_992_ = v___x_1003_;
goto v___jp_991_;
}
else
{
v___y_992_ = v_b_990_;
goto v___jp_991_;
}
}
else
{
return v_b_990_;
}
v___jp_991_:
{
size_t v___x_993_; size_t v___x_994_; 
v___x_993_ = ((size_t)1ULL);
v___x_994_ = lean_usize_add(v_i_988_, v___x_993_);
v_i_988_ = v___x_994_;
v_b_990_ = v___y_992_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00main_spec__12___boxed(lean_object* v_val_1004_, lean_object* v_as_1005_, lean_object* v_i_1006_, lean_object* v_stop_1007_, lean_object* v_b_1008_){
_start:
{
size_t v_i_boxed_1009_; size_t v_stop_boxed_1010_; lean_object* v_res_1011_; 
v_i_boxed_1009_ = lean_unbox_usize(v_i_1006_);
lean_dec(v_i_1006_);
v_stop_boxed_1010_ = lean_unbox_usize(v_stop_1007_);
lean_dec(v_stop_1007_);
v_res_1011_ = l___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00main_spec__12(v_val_1004_, v_as_1005_, v_i_boxed_1009_, v_stop_boxed_1010_, v_b_1008_);
lean_dec_ref(v_as_1005_);
lean_dec_ref(v_val_1004_);
return v_res_1011_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_QSort_Basic_0__Array_qpartition_loop___at___00__private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__8_spec__10___redArg(lean_object* v_hi_1012_, lean_object* v_pivot_1013_, lean_object* v_as_1014_, lean_object* v_i_1015_, lean_object* v_k_1016_){
_start:
{
uint8_t v___x_1017_; 
v___x_1017_ = lean_nat_dec_lt(v_k_1016_, v_hi_1012_);
if (v___x_1017_ == 0)
{
lean_object* v___x_1018_; lean_object* v___x_1019_; 
lean_dec(v_k_1016_);
v___x_1018_ = lean_array_fswap(v_as_1014_, v_i_1015_, v_hi_1012_);
v___x_1019_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1019_, 0, v_i_1015_);
lean_ctor_set(v___x_1019_, 1, v___x_1018_);
return v___x_1019_;
}
else
{
lean_object* v___x_1020_; lean_object* v_target_1021_; lean_object* v_target_1022_; uint8_t v___x_1023_; 
v___x_1020_ = lean_array_fget_borrowed(v_as_1014_, v_k_1016_);
v_target_1021_ = lean_ctor_get(v___x_1020_, 0);
v_target_1022_ = lean_ctor_get(v_pivot_1013_, 0);
v___x_1023_ = lean_string_dec_lt(v_target_1021_, v_target_1022_);
if (v___x_1023_ == 0)
{
lean_object* v___x_1024_; lean_object* v___x_1025_; 
v___x_1024_ = lean_unsigned_to_nat(1u);
v___x_1025_ = lean_nat_add(v_k_1016_, v___x_1024_);
lean_dec(v_k_1016_);
v_k_1016_ = v___x_1025_;
goto _start;
}
else
{
lean_object* v___x_1027_; lean_object* v___x_1028_; lean_object* v___x_1029_; lean_object* v___x_1030_; 
v___x_1027_ = lean_array_fswap(v_as_1014_, v_i_1015_, v_k_1016_);
v___x_1028_ = lean_unsigned_to_nat(1u);
v___x_1029_ = lean_nat_add(v_i_1015_, v___x_1028_);
lean_dec(v_i_1015_);
v___x_1030_ = lean_nat_add(v_k_1016_, v___x_1028_);
lean_dec(v_k_1016_);
v_as_1014_ = v___x_1027_;
v_i_1015_ = v___x_1029_;
v_k_1016_ = v___x_1030_;
goto _start;
}
}
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_QSort_Basic_0__Array_qpartition_loop___at___00__private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__8_spec__10___redArg___boxed(lean_object* v_hi_1032_, lean_object* v_pivot_1033_, lean_object* v_as_1034_, lean_object* v_i_1035_, lean_object* v_k_1036_){
_start:
{
lean_object* v_res_1037_; 
v_res_1037_ = l___private_Init_Data_Array_QSort_Basic_0__Array_qpartition_loop___at___00__private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__8_spec__10___redArg(v_hi_1032_, v_pivot_1033_, v_as_1034_, v_i_1035_, v_k_1036_);
lean_dec_ref(v_pivot_1033_);
lean_dec(v_hi_1032_);
return v_res_1037_;
}
}
LEAN_EXPORT uint8_t l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__8___redArg___lam__0(lean_object* v_a_1038_, lean_object* v_b_1039_){
_start:
{
lean_object* v_target_1040_; lean_object* v_target_1041_; uint8_t v___x_1042_; 
v_target_1040_ = lean_ctor_get(v_a_1038_, 0);
v_target_1041_ = lean_ctor_get(v_b_1039_, 0);
v___x_1042_ = lean_string_dec_lt(v_target_1040_, v_target_1041_);
return v___x_1042_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__8___redArg___lam__0___boxed(lean_object* v_a_1043_, lean_object* v_b_1044_){
_start:
{
uint8_t v_res_1045_; lean_object* v_r_1046_; 
v_res_1045_ = l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__8___redArg___lam__0(v_a_1043_, v_b_1044_);
lean_dec_ref(v_b_1044_);
lean_dec_ref(v_a_1043_);
v_r_1046_ = lean_box(v_res_1045_);
return v_r_1046_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__8___redArg(lean_object* v_n_1047_, lean_object* v_as_1048_, lean_object* v_lo_1049_, lean_object* v_hi_1050_){
_start:
{
lean_object* v___y_1052_; uint8_t v___x_1062_; 
v___x_1062_ = lean_nat_dec_lt(v_lo_1049_, v_hi_1050_);
if (v___x_1062_ == 0)
{
lean_dec(v_lo_1049_);
return v_as_1048_;
}
else
{
lean_object* v___x_1063_; lean_object* v___x_1064_; lean_object* v_mid_1065_; lean_object* v___y_1067_; lean_object* v___y_1073_; lean_object* v___x_1078_; lean_object* v___x_1079_; uint8_t v___x_1080_; 
v___x_1063_ = lean_nat_add(v_lo_1049_, v_hi_1050_);
v___x_1064_ = lean_unsigned_to_nat(1u);
v_mid_1065_ = lean_nat_shiftr(v___x_1063_, v___x_1064_);
lean_dec(v___x_1063_);
v___x_1078_ = lean_array_fget_borrowed(v_as_1048_, v_mid_1065_);
v___x_1079_ = lean_array_fget_borrowed(v_as_1048_, v_lo_1049_);
v___x_1080_ = l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__8___redArg___lam__0(v___x_1078_, v___x_1079_);
if (v___x_1080_ == 0)
{
v___y_1073_ = v_as_1048_;
goto v___jp_1072_;
}
else
{
lean_object* v___x_1081_; 
v___x_1081_ = lean_array_fswap(v_as_1048_, v_lo_1049_, v_mid_1065_);
v___y_1073_ = v___x_1081_;
goto v___jp_1072_;
}
v___jp_1066_:
{
lean_object* v___x_1068_; lean_object* v___x_1069_; uint8_t v___x_1070_; 
v___x_1068_ = lean_array_fget_borrowed(v___y_1067_, v_mid_1065_);
v___x_1069_ = lean_array_fget_borrowed(v___y_1067_, v_hi_1050_);
v___x_1070_ = l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__8___redArg___lam__0(v___x_1068_, v___x_1069_);
if (v___x_1070_ == 0)
{
lean_dec(v_mid_1065_);
v___y_1052_ = v___y_1067_;
goto v___jp_1051_;
}
else
{
lean_object* v___x_1071_; 
v___x_1071_ = lean_array_fswap(v___y_1067_, v_mid_1065_, v_hi_1050_);
lean_dec(v_mid_1065_);
v___y_1052_ = v___x_1071_;
goto v___jp_1051_;
}
}
v___jp_1072_:
{
lean_object* v___x_1074_; lean_object* v___x_1075_; uint8_t v___x_1076_; 
v___x_1074_ = lean_array_fget_borrowed(v___y_1073_, v_hi_1050_);
v___x_1075_ = lean_array_fget_borrowed(v___y_1073_, v_lo_1049_);
v___x_1076_ = l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__8___redArg___lam__0(v___x_1074_, v___x_1075_);
if (v___x_1076_ == 0)
{
v___y_1067_ = v___y_1073_;
goto v___jp_1066_;
}
else
{
lean_object* v___x_1077_; 
v___x_1077_ = lean_array_fswap(v___y_1073_, v_lo_1049_, v_hi_1050_);
v___y_1067_ = v___x_1077_;
goto v___jp_1066_;
}
}
}
v___jp_1051_:
{
lean_object* v_pivot_1053_; lean_object* v___x_1054_; lean_object* v_fst_1055_; lean_object* v_snd_1056_; uint8_t v___x_1057_; 
v_pivot_1053_ = lean_array_fget(v___y_1052_, v_hi_1050_);
lean_inc_n(v_lo_1049_, 2);
v___x_1054_ = l___private_Init_Data_Array_QSort_Basic_0__Array_qpartition_loop___at___00__private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__8_spec__10___redArg(v_hi_1050_, v_pivot_1053_, v___y_1052_, v_lo_1049_, v_lo_1049_);
lean_dec(v_pivot_1053_);
v_fst_1055_ = lean_ctor_get(v___x_1054_, 0);
lean_inc(v_fst_1055_);
v_snd_1056_ = lean_ctor_get(v___x_1054_, 1);
lean_inc(v_snd_1056_);
lean_dec_ref(v___x_1054_);
v___x_1057_ = lean_nat_dec_le(v_hi_1050_, v_fst_1055_);
if (v___x_1057_ == 0)
{
lean_object* v___x_1058_; lean_object* v___x_1059_; lean_object* v___x_1060_; 
v___x_1058_ = l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__8___redArg(v_n_1047_, v_snd_1056_, v_lo_1049_, v_fst_1055_);
v___x_1059_ = lean_unsigned_to_nat(1u);
v___x_1060_ = lean_nat_add(v_fst_1055_, v___x_1059_);
lean_dec(v_fst_1055_);
v_as_1048_ = v___x_1058_;
v_lo_1049_ = v___x_1060_;
goto _start;
}
else
{
lean_dec(v_fst_1055_);
lean_dec(v_lo_1049_);
return v_snd_1056_;
}
}
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__8___redArg___boxed(lean_object* v_n_1082_, lean_object* v_as_1083_, lean_object* v_lo_1084_, lean_object* v_hi_1085_){
_start:
{
lean_object* v_res_1086_; 
v_res_1086_ = l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__8___redArg(v_n_1082_, v_as_1083_, v_lo_1084_, v_hi_1085_);
lean_dec(v_hi_1085_);
lean_dec(v_n_1082_);
return v_res_1086_;
}
}
LEAN_EXPORT lean_object* l_List_forIn_x27_loop___at___00List_forIn_x27_loop___at___00main_spec__2_spec__2___redArg(lean_object* v_a_1090_, lean_object* v___x_1091_, uint8_t v___x_1092_, lean_object* v_head_1093_, lean_object* v_as_x27_1094_, lean_object* v_b_1095_){
_start:
{
if (lean_obj_tag(v_as_x27_1094_) == 0)
{
lean_object* v___x_1097_; 
v___x_1097_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_1097_, 0, v_b_1095_);
return v___x_1097_;
}
else
{
lean_object* v_head_1098_; lean_object* v_tail_1099_; lean_object* v_fst_1100_; lean_object* v_snd_1101_; lean_object* v___x_1102_; uint8_t v___x_1103_; 
v_head_1098_ = lean_ctor_get(v_as_x27_1094_, 0);
v_tail_1099_ = lean_ctor_get(v_as_x27_1094_, 1);
v_fst_1100_ = lean_ctor_get(v_head_1098_, 0);
v_snd_1101_ = lean_ctor_get(v_head_1098_, 1);
v___x_1102_ = l_Lean_Environment_getModuleIdxFor_x3f(v_a_1090_, v_fst_1100_);
v___x_1103_ = l_Option_instBEq_beq___at___00main_spec__1(v___x_1102_, v___x_1091_);
lean_dec(v___x_1102_);
if (v___x_1103_ == 0)
{
v_as_x27_1094_ = v_tail_1099_;
goto _start;
}
else
{
if (lean_obj_tag(v_snd_1101_) == 2)
{
lean_object* v_val_1105_; lean_object* v___x_1106_; uint8_t v___x_1107_; 
v_val_1105_ = lean_ctor_get(v_snd_1101_, 0);
v___x_1106_ = ((lean_object*)(l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__3___closed__2));
v___x_1107_ = lean_string_dec_eq(v_head_1093_, v___x_1106_);
if (v___x_1092_ == 0)
{
goto v___jp_1108_;
}
else
{
lean_object* v_value_1112_; lean_object* v___x_1113_; lean_object* v___x_1114_; lean_object* v___x_1115_; uint8_t v___x_1116_; 
v_value_1112_ = lean_ctor_get(v_val_1105_, 1);
lean_inc_ref(v_value_1112_);
v___x_1113_ = l_Lean_Expr_cleanupAnnotations(v_value_1112_);
v___x_1114_ = l_Lean_Expr_getAppFn(v___x_1113_);
lean_dec_ref(v___x_1113_);
v___x_1115_ = ((lean_object*)(l_List_forIn_x27_loop___at___00List_forIn_x27_loop___at___00main_spec__2_spec__2___redArg___closed__1));
v___x_1116_ = l_Lean_Expr_isConstOf(v___x_1114_, v___x_1115_);
lean_dec_ref(v___x_1114_);
if (v___x_1116_ == 0)
{
v_as_x27_1094_ = v_tail_1099_;
goto _start;
}
else
{
goto v___jp_1108_;
}
}
v___jp_1108_:
{
if (v___x_1107_ == 0)
{
lean_object* v___x_1109_; 
lean_inc_ref(v_val_1105_);
v___x_1109_ = lean_array_push(v_b_1095_, v_val_1105_);
v_as_x27_1094_ = v_tail_1099_;
v_b_1095_ = v___x_1109_;
goto _start;
}
else
{
v_as_x27_1094_ = v_tail_1099_;
goto _start;
}
}
}
else
{
v_as_x27_1094_ = v_tail_1099_;
goto _start;
}
}
}
}
}
LEAN_EXPORT lean_object* l_List_forIn_x27_loop___at___00List_forIn_x27_loop___at___00main_spec__2_spec__2___redArg___boxed(lean_object* v_a_1119_, lean_object* v___x_1120_, lean_object* v___x_1121_, lean_object* v_head_1122_, lean_object* v_as_x27_1123_, lean_object* v_b_1124_, lean_object* v___y_1125_){
_start:
{
uint8_t v___x_19406__boxed_1126_; lean_object* v_res_1127_; 
v___x_19406__boxed_1126_ = lean_unbox(v___x_1121_);
v_res_1127_ = l_List_forIn_x27_loop___at___00List_forIn_x27_loop___at___00main_spec__2_spec__2___redArg(v_a_1119_, v___x_1120_, v___x_19406__boxed_1126_, v_head_1122_, v_as_x27_1123_, v_b_1124_);
lean_dec(v_as_x27_1123_);
lean_dec_ref(v_head_1122_);
lean_dec(v___x_1120_);
lean_dec_ref(v_a_1119_);
return v_res_1127_;
}
}
LEAN_EXPORT lean_object* l_List_forIn_x27_loop___at___00main_spec__2___redArg(lean_object* v_a_1128_, lean_object* v___x_1129_, uint8_t v___x_1130_, lean_object* v_head_1131_, lean_object* v_as_1132_, lean_object* v_as_x27_1133_, lean_object* v_b_1134_){
_start:
{
if (lean_obj_tag(v_as_x27_1133_) == 0)
{
lean_object* v___x_1136_; 
v___x_1136_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_1136_, 0, v_b_1134_);
return v___x_1136_;
}
else
{
lean_object* v_head_1137_; lean_object* v_tail_1138_; lean_object* v_fst_1139_; lean_object* v_snd_1140_; lean_object* v___x_1141_; uint8_t v___x_1142_; 
v_head_1137_ = lean_ctor_get(v_as_x27_1133_, 0);
v_tail_1138_ = lean_ctor_get(v_as_x27_1133_, 1);
v_fst_1139_ = lean_ctor_get(v_head_1137_, 0);
v_snd_1140_ = lean_ctor_get(v_head_1137_, 1);
v___x_1141_ = l_Lean_Environment_getModuleIdxFor_x3f(v_a_1128_, v_fst_1139_);
v___x_1142_ = l_Option_instBEq_beq___at___00main_spec__1(v___x_1141_, v___x_1129_);
lean_dec(v___x_1141_);
if (v___x_1142_ == 0)
{
lean_object* v___x_1143_; 
v___x_1143_ = l_List_forIn_x27_loop___at___00List_forIn_x27_loop___at___00main_spec__2_spec__2___redArg(v_a_1128_, v___x_1129_, v___x_1130_, v_head_1131_, v_tail_1138_, v_b_1134_);
return v___x_1143_;
}
else
{
if (lean_obj_tag(v_snd_1140_) == 2)
{
lean_object* v_val_1144_; lean_object* v___x_1145_; uint8_t v___x_1146_; 
v_val_1144_ = lean_ctor_get(v_snd_1140_, 0);
v___x_1145_ = ((lean_object*)(l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__3___closed__2));
v___x_1146_ = lean_string_dec_eq(v_head_1131_, v___x_1145_);
if (v___x_1130_ == 0)
{
goto v___jp_1147_;
}
else
{
lean_object* v_value_1151_; lean_object* v___x_1152_; lean_object* v___x_1153_; lean_object* v___x_1154_; uint8_t v___x_1155_; 
v_value_1151_ = lean_ctor_get(v_val_1144_, 1);
lean_inc_ref(v_value_1151_);
v___x_1152_ = l_Lean_Expr_cleanupAnnotations(v_value_1151_);
v___x_1153_ = l_Lean_Expr_getAppFn(v___x_1152_);
lean_dec_ref(v___x_1152_);
v___x_1154_ = ((lean_object*)(l_List_forIn_x27_loop___at___00List_forIn_x27_loop___at___00main_spec__2_spec__2___redArg___closed__1));
v___x_1155_ = l_Lean_Expr_isConstOf(v___x_1153_, v___x_1154_);
lean_dec_ref(v___x_1153_);
if (v___x_1155_ == 0)
{
lean_object* v___x_1156_; 
v___x_1156_ = l_List_forIn_x27_loop___at___00List_forIn_x27_loop___at___00main_spec__2_spec__2___redArg(v_a_1128_, v___x_1129_, v___x_1130_, v_head_1131_, v_tail_1138_, v_b_1134_);
return v___x_1156_;
}
else
{
goto v___jp_1147_;
}
}
v___jp_1147_:
{
if (v___x_1146_ == 0)
{
lean_object* v___x_1148_; lean_object* v___x_1149_; 
lean_inc_ref(v_val_1144_);
v___x_1148_ = lean_array_push(v_b_1134_, v_val_1144_);
v___x_1149_ = l_List_forIn_x27_loop___at___00List_forIn_x27_loop___at___00main_spec__2_spec__2___redArg(v_a_1128_, v___x_1129_, v___x_1130_, v_head_1131_, v_tail_1138_, v___x_1148_);
return v___x_1149_;
}
else
{
lean_object* v___x_1150_; 
v___x_1150_ = l_List_forIn_x27_loop___at___00List_forIn_x27_loop___at___00main_spec__2_spec__2___redArg(v_a_1128_, v___x_1129_, v___x_1130_, v_head_1131_, v_tail_1138_, v_b_1134_);
return v___x_1150_;
}
}
}
else
{
lean_object* v___x_1157_; 
v___x_1157_ = l_List_forIn_x27_loop___at___00List_forIn_x27_loop___at___00main_spec__2_spec__2___redArg(v_a_1128_, v___x_1129_, v___x_1130_, v_head_1131_, v_tail_1138_, v_b_1134_);
return v___x_1157_;
}
}
}
}
}
LEAN_EXPORT lean_object* l_List_forIn_x27_loop___at___00main_spec__2___redArg___boxed(lean_object* v_a_1158_, lean_object* v___x_1159_, lean_object* v___x_1160_, lean_object* v_head_1161_, lean_object* v_as_1162_, lean_object* v_as_x27_1163_, lean_object* v_b_1164_, lean_object* v___y_1165_){
_start:
{
uint8_t v___x_19470__boxed_1166_; lean_object* v_res_1167_; 
v___x_19470__boxed_1166_ = lean_unbox(v___x_1160_);
v_res_1167_ = l_List_forIn_x27_loop___at___00main_spec__2___redArg(v_a_1158_, v___x_1159_, v___x_19470__boxed_1166_, v_head_1161_, v_as_1162_, v_as_x27_1163_, v_b_1164_);
lean_dec(v_as_x27_1163_);
lean_dec(v_as_1162_);
lean_dec_ref(v_head_1161_);
lean_dec(v___x_1159_);
lean_dec_ref(v_a_1158_);
return v_res_1167_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__7(lean_object* v_head_1179_, lean_object* v_workers_1180_, lean_object* v___x_1181_, lean_object* v_targets_1182_, lean_object* v_as_1183_, size_t v_sz_1184_, size_t v_i_1185_, lean_object* v_b_1186_){
_start:
{
uint8_t v___x_1188_; 
v___x_1188_ = lean_usize_dec_lt(v_i_1185_, v_sz_1184_);
if (v___x_1188_ == 0)
{
lean_object* v___x_1189_; 
lean_dec(v___x_1181_);
lean_dec(v_workers_1180_);
lean_dec_ref(v_head_1179_);
v___x_1189_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_1189_, 0, v_b_1186_);
return v___x_1189_;
}
else
{
lean_object* v_a_1190_; lean_object* v___x_1191_; lean_object* v___x_1192_; lean_object* v___x_1193_; lean_object* v___x_1194_; lean_object* v___x_1195_; lean_object* v___x_1196_; lean_object* v___x_1197_; lean_object* v___x_1198_; lean_object* v___x_1199_; lean_object* v___x_1200_; lean_object* v___x_1201_; lean_object* v___x_1202_; lean_object* v___x_1203_; lean_object* v___x_1204_; lean_object* v___x_1205_; lean_object* v___x_1206_; lean_object* v___x_1207_; lean_object* v___x_1208_; lean_object* v___x_1209_; lean_object* v___x_1210_; lean_object* v___x_1211_; lean_object* v___x_1212_; lean_object* v___x_1213_; lean_object* v___x_1214_; lean_object* v___x_1215_; lean_object* v___x_1216_; lean_object* v___x_1217_; lean_object* v___x_1218_; lean_object* v___x_1219_; lean_object* v___x_1220_; 
v_a_1190_ = lean_array_uget_borrowed(v_as_1183_, v_i_1185_);
v___x_1191_ = ((lean_object*)(l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__7___closed__0));
v___x_1192_ = ((lean_object*)(l_elaborateOne___closed__19));
lean_inc_ref(v_head_1179_);
v___x_1193_ = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(v___x_1193_, 0, v_head_1179_);
v___x_1194_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1194_, 0, v___x_1192_);
lean_ctor_set(v___x_1194_, 1, v___x_1193_);
v___x_1195_ = ((lean_object*)(l_elaborateOne___closed__20));
lean_inc(v_workers_1180_);
v___x_1196_ = l_Lean_JsonNumber_fromNat(v_workers_1180_);
v___x_1197_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_1197_, 0, v___x_1196_);
v___x_1198_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1198_, 0, v___x_1195_);
lean_ctor_set(v___x_1198_, 1, v___x_1197_);
v___x_1199_ = ((lean_object*)(l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__7___closed__1));
lean_inc(v___x_1181_);
v___x_1200_ = l_Lean_JsonNumber_fromNat(v___x_1181_);
v___x_1201_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_1201_, 0, v___x_1200_);
v___x_1202_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1202_, 0, v___x_1199_);
lean_ctor_set(v___x_1202_, 1, v___x_1201_);
v___x_1203_ = ((lean_object*)(l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__7___closed__2));
v___x_1204_ = lean_array_get_size(v_targets_1182_);
v___x_1205_ = l_Lean_JsonNumber_fromNat(v___x_1204_);
v___x_1206_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_1206_, 0, v___x_1205_);
v___x_1207_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1207_, 0, v___x_1203_);
lean_ctor_set(v___x_1207_, 1, v___x_1206_);
v___x_1208_ = ((lean_object*)(l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__7___closed__3));
lean_inc(v_a_1190_);
v___x_1209_ = l_instToJsonUnitRow_toJson(v_a_1190_);
v___x_1210_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1210_, 0, v___x_1208_);
lean_ctor_set(v___x_1210_, 1, v___x_1209_);
v___x_1211_ = ((lean_object*)(l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__7___closed__6));
v___x_1212_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_1212_, 0, v___x_1210_);
lean_ctor_set(v___x_1212_, 1, v___x_1211_);
v___x_1213_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_1213_, 0, v___x_1207_);
lean_ctor_set(v___x_1213_, 1, v___x_1212_);
v___x_1214_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_1214_, 0, v___x_1202_);
lean_ctor_set(v___x_1214_, 1, v___x_1213_);
v___x_1215_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_1215_, 0, v___x_1198_);
lean_ctor_set(v___x_1215_, 1, v___x_1214_);
v___x_1216_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_1216_, 0, v___x_1194_);
lean_ctor_set(v___x_1216_, 1, v___x_1215_);
v___x_1217_ = l_Lean_Json_mkObj(v___x_1216_);
lean_dec_ref_known(v___x_1216_, 2);
v___x_1218_ = l_Lean_Json_compress(v___x_1217_);
v___x_1219_ = lean_string_append(v___x_1191_, v___x_1218_);
lean_dec_ref(v___x_1218_);
v___x_1220_ = l_IO_println___at___00__private_Lean_Shell_0__Lean_ShellOptions_process_spec__3(v___x_1219_);
if (lean_obj_tag(v___x_1220_) == 0)
{
lean_object* v___x_1221_; size_t v___x_1222_; size_t v___x_1223_; 
lean_dec_ref_known(v___x_1220_, 1);
v___x_1221_ = lean_box(0);
v___x_1222_ = ((size_t)1ULL);
v___x_1223_ = lean_usize_add(v_i_1185_, v___x_1222_);
v_i_1185_ = v___x_1223_;
v_b_1186_ = v___x_1221_;
goto _start;
}
else
{
lean_dec(v___x_1181_);
lean_dec(v_workers_1180_);
lean_dec_ref(v_head_1179_);
return v___x_1220_;
}
}
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__7___boxed(lean_object* v_head_1225_, lean_object* v_workers_1226_, lean_object* v___x_1227_, lean_object* v_targets_1228_, lean_object* v_as_1229_, lean_object* v_sz_1230_, lean_object* v_i_1231_, lean_object* v_b_1232_, lean_object* v___y_1233_){
_start:
{
size_t v_sz_boxed_1234_; size_t v_i_boxed_1235_; lean_object* v_res_1236_; 
v_sz_boxed_1234_ = lean_unbox_usize(v_sz_1230_);
lean_dec(v_sz_1230_);
v_i_boxed_1235_ = lean_unbox_usize(v_i_1231_);
lean_dec(v_i_1231_);
v_res_1236_ = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__7(v_head_1225_, v_workers_1226_, v___x_1227_, v_targets_1228_, v_as_1229_, v_sz_boxed_1234_, v_i_boxed_1235_, v_b_1232_);
lean_dec_ref(v_as_1229_);
lean_dec_ref(v_targets_1228_);
return v_res_1236_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_QSort_Basic_0__Array_qpartition_loop___at___00__private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__13_spec__16___redArg(uint8_t v___x_1237_, lean_object* v_hi_1238_, lean_object* v_pivot_1239_, lean_object* v_as_1240_, lean_object* v_i_1241_, lean_object* v_k_1242_){
_start:
{
uint8_t v___x_1243_; 
v___x_1243_ = lean_nat_dec_lt(v_k_1242_, v_hi_1238_);
if (v___x_1243_ == 0)
{
lean_object* v___x_1244_; lean_object* v___x_1245_; 
lean_dec(v_k_1242_);
lean_dec_ref(v_pivot_1239_);
v___x_1244_ = lean_array_fswap(v_as_1240_, v_i_1241_, v_hi_1238_);
v___x_1245_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1245_, 0, v_i_1241_);
lean_ctor_set(v___x_1245_, 1, v___x_1244_);
return v___x_1245_;
}
else
{
lean_object* v___x_1246_; lean_object* v_toConstantVal_1247_; lean_object* v_toConstantVal_1248_; lean_object* v_name_1249_; lean_object* v_name_1250_; lean_object* v___x_1251_; lean_object* v___x_1252_; uint8_t v___x_1253_; 
v___x_1246_ = lean_array_fget_borrowed(v_as_1240_, v_k_1242_);
v_toConstantVal_1247_ = lean_ctor_get(v___x_1246_, 0);
v_toConstantVal_1248_ = lean_ctor_get(v_pivot_1239_, 0);
v_name_1249_ = lean_ctor_get(v_toConstantVal_1247_, 0);
v_name_1250_ = lean_ctor_get(v_toConstantVal_1248_, 0);
lean_inc(v_name_1249_);
v___x_1251_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v_name_1249_, v___x_1237_);
lean_inc(v_name_1250_);
v___x_1252_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v_name_1250_, v___x_1237_);
v___x_1253_ = lean_string_dec_lt(v___x_1251_, v___x_1252_);
lean_dec_ref(v___x_1252_);
lean_dec_ref(v___x_1251_);
if (v___x_1253_ == 0)
{
lean_object* v___x_1254_; lean_object* v___x_1255_; 
v___x_1254_ = lean_unsigned_to_nat(1u);
v___x_1255_ = lean_nat_add(v_k_1242_, v___x_1254_);
lean_dec(v_k_1242_);
v_k_1242_ = v___x_1255_;
goto _start;
}
else
{
lean_object* v___x_1257_; lean_object* v___x_1258_; lean_object* v___x_1259_; lean_object* v___x_1260_; 
v___x_1257_ = lean_array_fswap(v_as_1240_, v_i_1241_, v_k_1242_);
v___x_1258_ = lean_unsigned_to_nat(1u);
v___x_1259_ = lean_nat_add(v_i_1241_, v___x_1258_);
lean_dec(v_i_1241_);
v___x_1260_ = lean_nat_add(v_k_1242_, v___x_1258_);
lean_dec(v_k_1242_);
v_as_1240_ = v___x_1257_;
v_i_1241_ = v___x_1259_;
v_k_1242_ = v___x_1260_;
goto _start;
}
}
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_QSort_Basic_0__Array_qpartition_loop___at___00__private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__13_spec__16___redArg___boxed(lean_object* v___x_1262_, lean_object* v_hi_1263_, lean_object* v_pivot_1264_, lean_object* v_as_1265_, lean_object* v_i_1266_, lean_object* v_k_1267_){
_start:
{
uint8_t v___x_19644__boxed_1268_; lean_object* v_res_1269_; 
v___x_19644__boxed_1268_ = lean_unbox(v___x_1262_);
v_res_1269_ = l___private_Init_Data_Array_QSort_Basic_0__Array_qpartition_loop___at___00__private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__13_spec__16___redArg(v___x_19644__boxed_1268_, v_hi_1263_, v_pivot_1264_, v_as_1265_, v_i_1266_, v_k_1267_);
lean_dec(v_hi_1263_);
return v_res_1269_;
}
}
LEAN_EXPORT uint8_t l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__13___redArg___lam__0(uint8_t v___x_1270_, lean_object* v_a_1271_, lean_object* v_b_1272_){
_start:
{
lean_object* v_toConstantVal_1273_; lean_object* v_toConstantVal_1274_; lean_object* v_name_1275_; lean_object* v_name_1276_; lean_object* v___x_1277_; lean_object* v___x_1278_; uint8_t v___x_1279_; 
v_toConstantVal_1273_ = lean_ctor_get(v_a_1271_, 0);
lean_inc_ref(v_toConstantVal_1273_);
lean_dec_ref(v_a_1271_);
v_toConstantVal_1274_ = lean_ctor_get(v_b_1272_, 0);
lean_inc_ref(v_toConstantVal_1274_);
lean_dec_ref(v_b_1272_);
v_name_1275_ = lean_ctor_get(v_toConstantVal_1273_, 0);
lean_inc(v_name_1275_);
lean_dec_ref(v_toConstantVal_1273_);
v_name_1276_ = lean_ctor_get(v_toConstantVal_1274_, 0);
lean_inc(v_name_1276_);
lean_dec_ref(v_toConstantVal_1274_);
v___x_1277_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v_name_1275_, v___x_1270_);
v___x_1278_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v_name_1276_, v___x_1270_);
v___x_1279_ = lean_string_dec_lt(v___x_1277_, v___x_1278_);
lean_dec_ref(v___x_1278_);
lean_dec_ref(v___x_1277_);
return v___x_1279_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__13___redArg___lam__0___boxed(lean_object* v___x_1280_, lean_object* v_a_1281_, lean_object* v_b_1282_){
_start:
{
uint8_t v___x_19677__boxed_1283_; uint8_t v_res_1284_; lean_object* v_r_1285_; 
v___x_19677__boxed_1283_ = lean_unbox(v___x_1280_);
v_res_1284_ = l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__13___redArg___lam__0(v___x_19677__boxed_1283_, v_a_1281_, v_b_1282_);
v_r_1285_ = lean_box(v_res_1284_);
return v_r_1285_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__13___redArg(uint8_t v___x_1286_, lean_object* v_n_1287_, lean_object* v_as_1288_, lean_object* v_lo_1289_, lean_object* v_hi_1290_){
_start:
{
lean_object* v___y_1292_; uint8_t v___x_1302_; 
v___x_1302_ = lean_nat_dec_lt(v_lo_1289_, v_hi_1290_);
if (v___x_1302_ == 0)
{
lean_dec(v_lo_1289_);
return v_as_1288_;
}
else
{
lean_object* v___x_1303_; lean_object* v___x_1304_; lean_object* v_mid_1305_; lean_object* v___y_1307_; lean_object* v___y_1313_; lean_object* v___x_1318_; lean_object* v___x_1319_; uint8_t v___x_1320_; 
v___x_1303_ = lean_nat_add(v_lo_1289_, v_hi_1290_);
v___x_1304_ = lean_unsigned_to_nat(1u);
v_mid_1305_ = lean_nat_shiftr(v___x_1303_, v___x_1304_);
lean_dec(v___x_1303_);
v___x_1318_ = lean_array_fget_borrowed(v_as_1288_, v_mid_1305_);
v___x_1319_ = lean_array_fget_borrowed(v_as_1288_, v_lo_1289_);
lean_inc(v___x_1319_);
lean_inc(v___x_1318_);
v___x_1320_ = l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__13___redArg___lam__0(v___x_1286_, v___x_1318_, v___x_1319_);
if (v___x_1320_ == 0)
{
v___y_1313_ = v_as_1288_;
goto v___jp_1312_;
}
else
{
lean_object* v___x_1321_; 
v___x_1321_ = lean_array_fswap(v_as_1288_, v_lo_1289_, v_mid_1305_);
v___y_1313_ = v___x_1321_;
goto v___jp_1312_;
}
v___jp_1306_:
{
lean_object* v___x_1308_; lean_object* v___x_1309_; uint8_t v___x_1310_; 
v___x_1308_ = lean_array_fget_borrowed(v___y_1307_, v_mid_1305_);
v___x_1309_ = lean_array_fget_borrowed(v___y_1307_, v_hi_1290_);
lean_inc(v___x_1309_);
lean_inc(v___x_1308_);
v___x_1310_ = l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__13___redArg___lam__0(v___x_1286_, v___x_1308_, v___x_1309_);
if (v___x_1310_ == 0)
{
lean_dec(v_mid_1305_);
v___y_1292_ = v___y_1307_;
goto v___jp_1291_;
}
else
{
lean_object* v___x_1311_; 
v___x_1311_ = lean_array_fswap(v___y_1307_, v_mid_1305_, v_hi_1290_);
lean_dec(v_mid_1305_);
v___y_1292_ = v___x_1311_;
goto v___jp_1291_;
}
}
v___jp_1312_:
{
lean_object* v___x_1314_; lean_object* v___x_1315_; uint8_t v___x_1316_; 
v___x_1314_ = lean_array_fget_borrowed(v___y_1313_, v_hi_1290_);
v___x_1315_ = lean_array_fget_borrowed(v___y_1313_, v_lo_1289_);
lean_inc(v___x_1315_);
lean_inc(v___x_1314_);
v___x_1316_ = l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__13___redArg___lam__0(v___x_1286_, v___x_1314_, v___x_1315_);
if (v___x_1316_ == 0)
{
v___y_1307_ = v___y_1313_;
goto v___jp_1306_;
}
else
{
lean_object* v___x_1317_; 
v___x_1317_ = lean_array_fswap(v___y_1313_, v_lo_1289_, v_hi_1290_);
v___y_1307_ = v___x_1317_;
goto v___jp_1306_;
}
}
}
v___jp_1291_:
{
lean_object* v_pivot_1293_; lean_object* v___x_1294_; lean_object* v_fst_1295_; lean_object* v_snd_1296_; uint8_t v___x_1297_; 
v_pivot_1293_ = lean_array_fget(v___y_1292_, v_hi_1290_);
lean_inc_n(v_lo_1289_, 2);
v___x_1294_ = l___private_Init_Data_Array_QSort_Basic_0__Array_qpartition_loop___at___00__private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__13_spec__16___redArg(v___x_1286_, v_hi_1290_, v_pivot_1293_, v___y_1292_, v_lo_1289_, v_lo_1289_);
v_fst_1295_ = lean_ctor_get(v___x_1294_, 0);
lean_inc(v_fst_1295_);
v_snd_1296_ = lean_ctor_get(v___x_1294_, 1);
lean_inc(v_snd_1296_);
lean_dec_ref(v___x_1294_);
v___x_1297_ = lean_nat_dec_le(v_hi_1290_, v_fst_1295_);
if (v___x_1297_ == 0)
{
lean_object* v___x_1298_; lean_object* v___x_1299_; lean_object* v___x_1300_; 
v___x_1298_ = l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__13___redArg(v___x_1286_, v_n_1287_, v_snd_1296_, v_lo_1289_, v_fst_1295_);
v___x_1299_ = lean_unsigned_to_nat(1u);
v___x_1300_ = lean_nat_add(v_fst_1295_, v___x_1299_);
lean_dec(v_fst_1295_);
v_as_1288_ = v___x_1298_;
v_lo_1289_ = v___x_1300_;
goto _start;
}
else
{
lean_dec(v_fst_1295_);
lean_dec(v_lo_1289_);
return v_snd_1296_;
}
}
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__13___redArg___boxed(lean_object* v___x_1322_, lean_object* v_n_1323_, lean_object* v_as_1324_, lean_object* v_lo_1325_, lean_object* v_hi_1326_){
_start:
{
uint8_t v___x_19686__boxed_1327_; lean_object* v_res_1328_; 
v___x_19686__boxed_1327_ = lean_unbox(v___x_1322_);
v_res_1328_ = l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__13___redArg(v___x_19686__boxed_1327_, v_n_1323_, v_as_1324_, v_lo_1325_, v_hi_1326_);
lean_dec(v_hi_1326_);
lean_dec(v_n_1323_);
return v_res_1328_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__14___redArg(lean_object* v_workers_1329_, lean_object* v_a_1330_, lean_object* v___x_1331_, lean_object* v___x_1332_, lean_object* v_fst_1333_, lean_object* v_snd_1334_, lean_object* v_head_1335_, lean_object* v_head_1336_, lean_object* v_range_1337_, lean_object* v_b_1338_, lean_object* v_i_1339_){
_start:
{
lean_object* v_stop_1341_; lean_object* v_step_1342_; lean_object* v_a_1344_; uint8_t v___x_1347_; 
v_stop_1341_ = lean_ctor_get(v_range_1337_, 1);
v_step_1342_ = lean_ctor_get(v_range_1337_, 2);
v___x_1347_ = lean_nat_dec_lt(v_i_1339_, v_stop_1341_);
if (v___x_1347_ == 0)
{
lean_object* v___x_1348_; 
lean_dec(v_i_1339_);
lean_dec_ref(v_head_1336_);
lean_dec_ref(v_head_1335_);
lean_dec_ref(v_fst_1333_);
lean_dec_ref(v___x_1331_);
lean_dec(v_workers_1329_);
v___x_1348_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_1348_, 0, v_b_1338_);
return v___x_1348_;
}
else
{
lean_object* v___x_1349_; uint8_t v___x_1350_; 
v___x_1349_ = lean_nat_mod(v_i_1339_, v_workers_1329_);
v___x_1350_ = lean_nat_dec_eq(v___x_1349_, v_a_1330_);
lean_dec(v___x_1349_);
if (v___x_1350_ == 0)
{
v_a_1344_ = v_b_1338_;
goto v___jp_1343_;
}
else
{
lean_object* v___x_1351_; 
lean_inc(v_i_1339_);
lean_inc(v_workers_1329_);
lean_inc_ref(v_head_1336_);
lean_inc_ref(v_head_1335_);
lean_inc_ref(v_fst_1333_);
lean_inc_ref(v___x_1331_);
v___x_1351_ = l_elaborateOne(v___x_1331_, v___x_1332_, v_fst_1333_, v_snd_1334_, v_head_1335_, v_head_1336_, v_workers_1329_, v_i_1339_);
if (lean_obj_tag(v___x_1351_) == 0)
{
lean_object* v_a_1352_; lean_object* v___x_1353_; 
v_a_1352_ = lean_ctor_get(v___x_1351_, 0);
lean_inc(v_a_1352_);
lean_dec_ref_known(v___x_1351_, 1);
v___x_1353_ = lean_array_push(v_b_1338_, v_a_1352_);
v_a_1344_ = v___x_1353_;
goto v___jp_1343_;
}
else
{
lean_object* v_a_1354_; lean_object* v___x_1356_; uint8_t v_isShared_1357_; uint8_t v_isSharedCheck_1361_; 
lean_dec(v_i_1339_);
lean_dec_ref(v_b_1338_);
lean_dec_ref(v_head_1336_);
lean_dec_ref(v_head_1335_);
lean_dec_ref(v_fst_1333_);
lean_dec_ref(v___x_1331_);
lean_dec(v_workers_1329_);
v_a_1354_ = lean_ctor_get(v___x_1351_, 0);
v_isSharedCheck_1361_ = !lean_is_exclusive(v___x_1351_);
if (v_isSharedCheck_1361_ == 0)
{
v___x_1356_ = v___x_1351_;
v_isShared_1357_ = v_isSharedCheck_1361_;
goto v_resetjp_1355_;
}
else
{
lean_inc(v_a_1354_);
lean_dec(v___x_1351_);
v___x_1356_ = lean_box(0);
v_isShared_1357_ = v_isSharedCheck_1361_;
goto v_resetjp_1355_;
}
v_resetjp_1355_:
{
lean_object* v___x_1359_; 
if (v_isShared_1357_ == 0)
{
v___x_1359_ = v___x_1356_;
goto v_reusejp_1358_;
}
else
{
lean_object* v_reuseFailAlloc_1360_; 
v_reuseFailAlloc_1360_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1360_, 0, v_a_1354_);
v___x_1359_ = v_reuseFailAlloc_1360_;
goto v_reusejp_1358_;
}
v_reusejp_1358_:
{
return v___x_1359_;
}
}
}
}
}
v___jp_1343_:
{
lean_object* v___x_1345_; 
v___x_1345_ = lean_nat_add(v_i_1339_, v_step_1342_);
lean_dec(v_i_1339_);
v_b_1338_ = v_a_1344_;
v_i_1339_ = v___x_1345_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__14___redArg___boxed(lean_object* v_workers_1362_, lean_object* v_a_1363_, lean_object* v___x_1364_, lean_object* v___x_1365_, lean_object* v_fst_1366_, lean_object* v_snd_1367_, lean_object* v_head_1368_, lean_object* v_head_1369_, lean_object* v_range_1370_, lean_object* v_b_1371_, lean_object* v_i_1372_, lean_object* v___y_1373_){
_start:
{
lean_object* v_res_1374_; 
v_res_1374_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__14___redArg(v_workers_1362_, v_a_1363_, v___x_1364_, v___x_1365_, v_fst_1366_, v_snd_1367_, v_head_1368_, v_head_1369_, v_range_1370_, v_b_1371_, v_i_1372_);
lean_dec_ref(v_range_1370_);
lean_dec_ref(v_snd_1367_);
lean_dec_ref(v___x_1365_);
lean_dec(v_a_1363_);
return v_res_1374_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__15___redArg___lam__0(lean_object* v___x_1375_, lean_object* v___x_1376_, lean_object* v___x_1377_, lean_object* v_workers_1378_, lean_object* v_i_1379_, lean_object* v___x_1380_, lean_object* v___x_1381_, lean_object* v_fst_1382_, lean_object* v_snd_1383_, lean_object* v_head_1384_, lean_object* v_head_1385_){
_start:
{
lean_object* v___x_1387_; lean_object* v___x_1388_; lean_object* v___x_1389_; lean_object* v___x_1390_; lean_object* v___x_1391_; 
v___x_1387_ = lean_io_wait(v___x_1375_);
lean_dec(v___x_1387_);
v___x_1388_ = lean_mk_empty_array_with_capacity(v___x_1376_);
v___x_1389_ = lean_unsigned_to_nat(8u);
lean_inc(v___x_1376_);
v___x_1390_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_1390_, 0, v___x_1376_);
lean_ctor_set(v___x_1390_, 1, v___x_1389_);
lean_ctor_set(v___x_1390_, 2, v___x_1377_);
v___x_1391_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__14___redArg(v_workers_1378_, v_i_1379_, v___x_1380_, v___x_1381_, v_fst_1382_, v_snd_1383_, v_head_1384_, v_head_1385_, v___x_1390_, v___x_1388_, v___x_1376_);
lean_dec_ref_known(v___x_1390_, 3);
if (lean_obj_tag(v___x_1391_) == 0)
{
lean_object* v_a_1392_; lean_object* v___x_1394_; uint8_t v_isShared_1395_; uint8_t v_isSharedCheck_1399_; 
v_a_1392_ = lean_ctor_get(v___x_1391_, 0);
v_isSharedCheck_1399_ = !lean_is_exclusive(v___x_1391_);
if (v_isSharedCheck_1399_ == 0)
{
v___x_1394_ = v___x_1391_;
v_isShared_1395_ = v_isSharedCheck_1399_;
goto v_resetjp_1393_;
}
else
{
lean_inc(v_a_1392_);
lean_dec(v___x_1391_);
v___x_1394_ = lean_box(0);
v_isShared_1395_ = v_isSharedCheck_1399_;
goto v_resetjp_1393_;
}
v_resetjp_1393_:
{
lean_object* v___x_1397_; 
if (v_isShared_1395_ == 0)
{
lean_ctor_set_tag(v___x_1394_, 1);
v___x_1397_ = v___x_1394_;
goto v_reusejp_1396_;
}
else
{
lean_object* v_reuseFailAlloc_1398_; 
v_reuseFailAlloc_1398_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1398_, 0, v_a_1392_);
v___x_1397_ = v_reuseFailAlloc_1398_;
goto v_reusejp_1396_;
}
v_reusejp_1396_:
{
return v___x_1397_;
}
}
}
else
{
lean_object* v_a_1400_; lean_object* v___x_1402_; uint8_t v_isShared_1403_; uint8_t v_isSharedCheck_1407_; 
v_a_1400_ = lean_ctor_get(v___x_1391_, 0);
v_isSharedCheck_1407_ = !lean_is_exclusive(v___x_1391_);
if (v_isSharedCheck_1407_ == 0)
{
v___x_1402_ = v___x_1391_;
v_isShared_1403_ = v_isSharedCheck_1407_;
goto v_resetjp_1401_;
}
else
{
lean_inc(v_a_1400_);
lean_dec(v___x_1391_);
v___x_1402_ = lean_box(0);
v_isShared_1403_ = v_isSharedCheck_1407_;
goto v_resetjp_1401_;
}
v_resetjp_1401_:
{
lean_object* v___x_1405_; 
if (v_isShared_1403_ == 0)
{
lean_ctor_set_tag(v___x_1402_, 0);
v___x_1405_ = v___x_1402_;
goto v_reusejp_1404_;
}
else
{
lean_object* v_reuseFailAlloc_1406_; 
v_reuseFailAlloc_1406_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1406_, 0, v_a_1400_);
v___x_1405_ = v_reuseFailAlloc_1406_;
goto v_reusejp_1404_;
}
v_reusejp_1404_:
{
return v___x_1405_;
}
}
}
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__15___redArg___lam__0___boxed(lean_object* v___x_1408_, lean_object* v___x_1409_, lean_object* v___x_1410_, lean_object* v_workers_1411_, lean_object* v_i_1412_, lean_object* v___x_1413_, lean_object* v___x_1414_, lean_object* v_fst_1415_, lean_object* v_snd_1416_, lean_object* v_head_1417_, lean_object* v_head_1418_, lean_object* v___y_1419_){
_start:
{
lean_object* v_res_1420_; 
v_res_1420_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__15___redArg___lam__0(v___x_1408_, v___x_1409_, v___x_1410_, v_workers_1411_, v_i_1412_, v___x_1413_, v___x_1414_, v_fst_1415_, v_snd_1416_, v_head_1417_, v_head_1418_);
lean_dec_ref(v_snd_1416_);
lean_dec_ref(v___x_1414_);
lean_dec(v_i_1412_);
return v_res_1420_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__15_spec__19___redArg(lean_object* v_val_1421_, lean_object* v_workers_1422_, lean_object* v___x_1423_, lean_object* v___x_1424_, lean_object* v_fst_1425_, lean_object* v_snd_1426_, lean_object* v_head_1427_, lean_object* v_head_1428_, lean_object* v_range_1429_, lean_object* v_b_1430_, lean_object* v_i_1431_){
_start:
{
lean_object* v_stop_1433_; lean_object* v_step_1434_; uint8_t v___x_1435_; 
v_stop_1433_ = lean_ctor_get(v_range_1429_, 1);
v_step_1434_ = lean_ctor_get(v_range_1429_, 2);
v___x_1435_ = lean_nat_dec_lt(v_i_1431_, v_stop_1433_);
if (v___x_1435_ == 0)
{
lean_object* v___x_1436_; 
lean_dec(v_i_1431_);
lean_dec_ref(v_head_1428_);
lean_dec_ref(v_head_1427_);
lean_dec_ref(v_snd_1426_);
lean_dec_ref(v_fst_1425_);
lean_dec_ref(v___x_1424_);
lean_dec_ref(v___x_1423_);
lean_dec(v_workers_1422_);
v___x_1436_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_1436_, 0, v_b_1430_);
return v___x_1436_;
}
else
{
lean_object* v___x_1437_; lean_object* v___x_1438_; lean_object* v___x_1439_; lean_object* v___f_1440_; lean_object* v___x_1441_; lean_object* v___x_1442_; lean_object* v___x_1443_; 
v___x_1437_ = lean_unsigned_to_nat(0u);
v___x_1438_ = lean_unsigned_to_nat(1u);
v___x_1439_ = l_IO_Promise_result_x21___redArg(v_val_1421_);
lean_inc_ref(v_head_1428_);
lean_inc_ref(v_head_1427_);
lean_inc_ref(v_snd_1426_);
lean_inc_ref(v_fst_1425_);
lean_inc_ref(v___x_1424_);
lean_inc_ref(v___x_1423_);
lean_inc(v_i_1431_);
lean_inc(v_workers_1422_);
v___f_1440_ = lean_alloc_closure((void*)(l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__15___redArg___lam__0___boxed), 12, 11);
lean_closure_set(v___f_1440_, 0, v___x_1439_);
lean_closure_set(v___f_1440_, 1, v___x_1437_);
lean_closure_set(v___f_1440_, 2, v___x_1438_);
lean_closure_set(v___f_1440_, 3, v_workers_1422_);
lean_closure_set(v___f_1440_, 4, v_i_1431_);
lean_closure_set(v___f_1440_, 5, v___x_1423_);
lean_closure_set(v___f_1440_, 6, v___x_1424_);
lean_closure_set(v___f_1440_, 7, v_fst_1425_);
lean_closure_set(v___f_1440_, 8, v_snd_1426_);
lean_closure_set(v___f_1440_, 9, v_head_1427_);
lean_closure_set(v___f_1440_, 10, v_head_1428_);
v___x_1441_ = lean_io_as_task(v___f_1440_, v___x_1437_);
v___x_1442_ = lean_array_push(v_b_1430_, v___x_1441_);
v___x_1443_ = lean_nat_add(v_i_1431_, v_step_1434_);
lean_dec(v_i_1431_);
v_b_1430_ = v___x_1442_;
v_i_1431_ = v___x_1443_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__15_spec__19___redArg___boxed(lean_object* v_val_1445_, lean_object* v_workers_1446_, lean_object* v___x_1447_, lean_object* v___x_1448_, lean_object* v_fst_1449_, lean_object* v_snd_1450_, lean_object* v_head_1451_, lean_object* v_head_1452_, lean_object* v_range_1453_, lean_object* v_b_1454_, lean_object* v_i_1455_, lean_object* v___y_1456_){
_start:
{
lean_object* v_res_1457_; 
v_res_1457_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__15_spec__19___redArg(v_val_1445_, v_workers_1446_, v___x_1447_, v___x_1448_, v_fst_1449_, v_snd_1450_, v_head_1451_, v_head_1452_, v_range_1453_, v_b_1454_, v_i_1455_);
lean_dec_ref(v_range_1453_);
lean_dec(v_val_1445_);
return v_res_1457_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__15___redArg(lean_object* v_workers_1458_, lean_object* v___x_1459_, lean_object* v___x_1460_, lean_object* v_fst_1461_, lean_object* v_snd_1462_, lean_object* v_head_1463_, lean_object* v_head_1464_, lean_object* v_val_1465_, lean_object* v_range_1466_, lean_object* v_b_1467_, lean_object* v_i_1468_){
_start:
{
lean_object* v_stop_1470_; lean_object* v_step_1471_; uint8_t v___x_1472_; 
v_stop_1470_ = lean_ctor_get(v_range_1466_, 1);
v_step_1471_ = lean_ctor_get(v_range_1466_, 2);
v___x_1472_ = lean_nat_dec_lt(v_i_1468_, v_stop_1470_);
if (v___x_1472_ == 0)
{
lean_object* v___x_1473_; 
lean_dec(v_i_1468_);
lean_dec_ref(v_head_1464_);
lean_dec_ref(v_head_1463_);
lean_dec_ref(v_snd_1462_);
lean_dec_ref(v_fst_1461_);
lean_dec_ref(v___x_1460_);
lean_dec_ref(v___x_1459_);
lean_dec(v_workers_1458_);
v___x_1473_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_1473_, 0, v_b_1467_);
return v___x_1473_;
}
else
{
lean_object* v___x_1474_; lean_object* v___x_1475_; lean_object* v___x_1476_; lean_object* v___f_1477_; lean_object* v___x_1478_; lean_object* v___x_1479_; lean_object* v___x_1480_; lean_object* v___x_1481_; 
v___x_1474_ = lean_unsigned_to_nat(0u);
v___x_1475_ = lean_unsigned_to_nat(1u);
v___x_1476_ = l_IO_Promise_result_x21___redArg(v_val_1465_);
lean_inc_ref(v_head_1464_);
lean_inc_ref(v_head_1463_);
lean_inc_ref(v_snd_1462_);
lean_inc_ref(v_fst_1461_);
lean_inc_ref(v___x_1460_);
lean_inc_ref(v___x_1459_);
lean_inc(v_i_1468_);
lean_inc(v_workers_1458_);
v___f_1477_ = lean_alloc_closure((void*)(l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__15___redArg___lam__0___boxed), 12, 11);
lean_closure_set(v___f_1477_, 0, v___x_1476_);
lean_closure_set(v___f_1477_, 1, v___x_1474_);
lean_closure_set(v___f_1477_, 2, v___x_1475_);
lean_closure_set(v___f_1477_, 3, v_workers_1458_);
lean_closure_set(v___f_1477_, 4, v_i_1468_);
lean_closure_set(v___f_1477_, 5, v___x_1459_);
lean_closure_set(v___f_1477_, 6, v___x_1460_);
lean_closure_set(v___f_1477_, 7, v_fst_1461_);
lean_closure_set(v___f_1477_, 8, v_snd_1462_);
lean_closure_set(v___f_1477_, 9, v_head_1463_);
lean_closure_set(v___f_1477_, 10, v_head_1464_);
v___x_1478_ = lean_io_as_task(v___f_1477_, v___x_1474_);
v___x_1479_ = lean_array_push(v_b_1467_, v___x_1478_);
v___x_1480_ = lean_nat_add(v_i_1468_, v_step_1471_);
lean_dec(v_i_1468_);
v___x_1481_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__15_spec__19___redArg(v_val_1465_, v_workers_1458_, v___x_1459_, v___x_1460_, v_fst_1461_, v_snd_1462_, v_head_1463_, v_head_1464_, v_range_1466_, v___x_1479_, v___x_1480_);
return v___x_1481_;
}
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__15___redArg___boxed(lean_object* v_workers_1482_, lean_object* v___x_1483_, lean_object* v___x_1484_, lean_object* v_fst_1485_, lean_object* v_snd_1486_, lean_object* v_head_1487_, lean_object* v_head_1488_, lean_object* v_val_1489_, lean_object* v_range_1490_, lean_object* v_b_1491_, lean_object* v_i_1492_, lean_object* v___y_1493_){
_start:
{
lean_object* v_res_1494_; 
v_res_1494_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__15___redArg(v_workers_1482_, v___x_1483_, v___x_1484_, v_fst_1485_, v_snd_1486_, v_head_1487_, v_head_1488_, v_val_1489_, v_range_1490_, v_b_1491_, v_i_1492_);
lean_dec_ref(v_range_1490_);
lean_dec(v_val_1489_);
return v_res_1494_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00main_spec__9(uint8_t v___x_1495_, size_t v_sz_1496_, size_t v_i_1497_, lean_object* v_bs_1498_){
_start:
{
uint8_t v___x_1499_; 
v___x_1499_ = lean_usize_dec_lt(v_i_1497_, v_sz_1496_);
if (v___x_1499_ == 0)
{
return v_bs_1498_;
}
else
{
lean_object* v_v_1500_; lean_object* v_toConstantVal_1501_; lean_object* v_name_1502_; lean_object* v___x_1503_; lean_object* v_bs_x27_1504_; lean_object* v___x_1505_; size_t v___x_1506_; size_t v___x_1507_; lean_object* v___x_1508_; 
v_v_1500_ = lean_array_uget_borrowed(v_bs_1498_, v_i_1497_);
v_toConstantVal_1501_ = lean_ctor_get(v_v_1500_, 0);
v_name_1502_ = lean_ctor_get(v_toConstantVal_1501_, 0);
lean_inc(v_name_1502_);
v___x_1503_ = lean_unsigned_to_nat(0u);
v_bs_x27_1504_ = lean_array_uset(v_bs_1498_, v_i_1497_, v___x_1503_);
v___x_1505_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v_name_1502_, v___x_1495_);
v___x_1506_ = ((size_t)1ULL);
v___x_1507_ = lean_usize_add(v_i_1497_, v___x_1506_);
v___x_1508_ = lean_array_uset(v_bs_x27_1504_, v_i_1497_, v___x_1505_);
v_i_1497_ = v___x_1507_;
v_bs_1498_ = v___x_1508_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00main_spec__9___boxed(lean_object* v___x_1510_, lean_object* v_sz_1511_, lean_object* v_i_1512_, lean_object* v_bs_1513_){
_start:
{
uint8_t v___x_19966__boxed_1514_; size_t v_sz_boxed_1515_; size_t v_i_boxed_1516_; lean_object* v_res_1517_; 
v___x_19966__boxed_1514_ = lean_unbox(v___x_1510_);
v_sz_boxed_1515_ = lean_unbox_usize(v_sz_1511_);
lean_dec(v_sz_1511_);
v_i_boxed_1516_ = lean_unbox_usize(v_i_1512_);
lean_dec(v_i_1512_);
v_res_1517_ = l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00main_spec__9(v___x_19966__boxed_1514_, v_sz_boxed_1515_, v_i_boxed_1516_, v_bs_1513_);
return v_res_1517_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__4___redArg(lean_object* v_workers_1518_, lean_object* v_a_1519_, lean_object* v_targets_1520_, lean_object* v___x_1521_, lean_object* v_range_1522_, lean_object* v_b_1523_, lean_object* v_i_1524_){
_start:
{
lean_object* v_stop_1526_; lean_object* v_step_1527_; lean_object* v_a_1529_; uint8_t v___x_1532_; 
v_stop_1526_ = lean_ctor_get(v_range_1522_, 1);
v_step_1527_ = lean_ctor_get(v_range_1522_, 2);
v___x_1532_ = lean_nat_dec_lt(v_i_1524_, v_stop_1526_);
if (v___x_1532_ == 0)
{
lean_object* v___x_1533_; 
lean_dec(v_i_1524_);
lean_dec_ref(v___x_1521_);
v___x_1533_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_1533_, 0, v_b_1523_);
return v___x_1533_;
}
else
{
lean_object* v___x_1534_; uint8_t v___x_1535_; 
v___x_1534_ = lean_nat_mod(v_i_1524_, v_workers_1518_);
v___x_1535_ = lean_nat_dec_eq(v___x_1534_, v_a_1519_);
lean_dec(v___x_1534_);
if (v___x_1535_ == 0)
{
v_a_1529_ = v_b_1523_;
goto v___jp_1528_;
}
else
{
lean_object* v___x_1536_; lean_object* v___x_1537_; lean_object* v___x_1538_; 
v___x_1536_ = l_Lean_instInhabitedTheoremVal_default;
v___x_1537_ = lean_array_get_borrowed(v___x_1536_, v_targets_1520_, v_i_1524_);
lean_inc(v_i_1524_);
lean_inc(v___x_1537_);
lean_inc_ref(v___x_1521_);
v___x_1538_ = l_one(v___x_1521_, v___x_1537_, v_i_1524_);
if (lean_obj_tag(v___x_1538_) == 0)
{
lean_object* v_a_1539_; lean_object* v___x_1540_; 
v_a_1539_ = lean_ctor_get(v___x_1538_, 0);
lean_inc(v_a_1539_);
lean_dec_ref_known(v___x_1538_, 1);
v___x_1540_ = lean_array_push(v_b_1523_, v_a_1539_);
v_a_1529_ = v___x_1540_;
goto v___jp_1528_;
}
else
{
lean_object* v_a_1541_; lean_object* v___x_1543_; uint8_t v_isShared_1544_; uint8_t v_isSharedCheck_1548_; 
lean_dec(v_i_1524_);
lean_dec_ref(v_b_1523_);
lean_dec_ref(v___x_1521_);
v_a_1541_ = lean_ctor_get(v___x_1538_, 0);
v_isSharedCheck_1548_ = !lean_is_exclusive(v___x_1538_);
if (v_isSharedCheck_1548_ == 0)
{
v___x_1543_ = v___x_1538_;
v_isShared_1544_ = v_isSharedCheck_1548_;
goto v_resetjp_1542_;
}
else
{
lean_inc(v_a_1541_);
lean_dec(v___x_1538_);
v___x_1543_ = lean_box(0);
v_isShared_1544_ = v_isSharedCheck_1548_;
goto v_resetjp_1542_;
}
v_resetjp_1542_:
{
lean_object* v___x_1546_; 
if (v_isShared_1544_ == 0)
{
v___x_1546_ = v___x_1543_;
goto v_reusejp_1545_;
}
else
{
lean_object* v_reuseFailAlloc_1547_; 
v_reuseFailAlloc_1547_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1547_, 0, v_a_1541_);
v___x_1546_ = v_reuseFailAlloc_1547_;
goto v_reusejp_1545_;
}
v_reusejp_1545_:
{
return v___x_1546_;
}
}
}
}
}
v___jp_1528_:
{
lean_object* v___x_1530_; 
v___x_1530_ = lean_nat_add(v_i_1524_, v_step_1527_);
lean_dec(v_i_1524_);
v_b_1523_ = v_a_1529_;
v_i_1524_ = v___x_1530_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__4___redArg___boxed(lean_object* v_workers_1549_, lean_object* v_a_1550_, lean_object* v_targets_1551_, lean_object* v___x_1552_, lean_object* v_range_1553_, lean_object* v_b_1554_, lean_object* v_i_1555_, lean_object* v___y_1556_){
_start:
{
lean_object* v_res_1557_; 
v_res_1557_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__4___redArg(v_workers_1549_, v_a_1550_, v_targets_1551_, v___x_1552_, v_range_1553_, v_b_1554_, v_i_1555_);
lean_dec_ref(v_range_1553_);
lean_dec_ref(v_targets_1551_);
lean_dec(v_a_1550_);
lean_dec(v_workers_1549_);
return v_res_1557_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__5___redArg___lam__0(lean_object* v___x_1558_, lean_object* v___x_1559_, lean_object* v_targets_1560_, lean_object* v___x_1561_, lean_object* v_workers_1562_, lean_object* v_i_1563_, lean_object* v___x_1564_){
_start:
{
lean_object* v___x_1566_; lean_object* v___x_1567_; lean_object* v___x_1568_; lean_object* v___x_1569_; lean_object* v___x_1570_; 
v___x_1566_ = lean_io_wait(v___x_1558_);
lean_dec(v___x_1566_);
v___x_1567_ = lean_mk_empty_array_with_capacity(v___x_1559_);
v___x_1568_ = lean_array_get_size(v_targets_1560_);
lean_inc(v___x_1559_);
v___x_1569_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_1569_, 0, v___x_1559_);
lean_ctor_set(v___x_1569_, 1, v___x_1568_);
lean_ctor_set(v___x_1569_, 2, v___x_1561_);
v___x_1570_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__4___redArg(v_workers_1562_, v_i_1563_, v_targets_1560_, v___x_1564_, v___x_1569_, v___x_1567_, v___x_1559_);
lean_dec_ref_known(v___x_1569_, 3);
if (lean_obj_tag(v___x_1570_) == 0)
{
lean_object* v_a_1571_; lean_object* v___x_1573_; uint8_t v_isShared_1574_; uint8_t v_isSharedCheck_1578_; 
v_a_1571_ = lean_ctor_get(v___x_1570_, 0);
v_isSharedCheck_1578_ = !lean_is_exclusive(v___x_1570_);
if (v_isSharedCheck_1578_ == 0)
{
v___x_1573_ = v___x_1570_;
v_isShared_1574_ = v_isSharedCheck_1578_;
goto v_resetjp_1572_;
}
else
{
lean_inc(v_a_1571_);
lean_dec(v___x_1570_);
v___x_1573_ = lean_box(0);
v_isShared_1574_ = v_isSharedCheck_1578_;
goto v_resetjp_1572_;
}
v_resetjp_1572_:
{
lean_object* v___x_1576_; 
if (v_isShared_1574_ == 0)
{
lean_ctor_set_tag(v___x_1573_, 1);
v___x_1576_ = v___x_1573_;
goto v_reusejp_1575_;
}
else
{
lean_object* v_reuseFailAlloc_1577_; 
v_reuseFailAlloc_1577_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1577_, 0, v_a_1571_);
v___x_1576_ = v_reuseFailAlloc_1577_;
goto v_reusejp_1575_;
}
v_reusejp_1575_:
{
return v___x_1576_;
}
}
}
else
{
lean_object* v_a_1579_; lean_object* v___x_1581_; uint8_t v_isShared_1582_; uint8_t v_isSharedCheck_1586_; 
v_a_1579_ = lean_ctor_get(v___x_1570_, 0);
v_isSharedCheck_1586_ = !lean_is_exclusive(v___x_1570_);
if (v_isSharedCheck_1586_ == 0)
{
v___x_1581_ = v___x_1570_;
v_isShared_1582_ = v_isSharedCheck_1586_;
goto v_resetjp_1580_;
}
else
{
lean_inc(v_a_1579_);
lean_dec(v___x_1570_);
v___x_1581_ = lean_box(0);
v_isShared_1582_ = v_isSharedCheck_1586_;
goto v_resetjp_1580_;
}
v_resetjp_1580_:
{
lean_object* v___x_1584_; 
if (v_isShared_1582_ == 0)
{
lean_ctor_set_tag(v___x_1581_, 0);
v___x_1584_ = v___x_1581_;
goto v_reusejp_1583_;
}
else
{
lean_object* v_reuseFailAlloc_1585_; 
v_reuseFailAlloc_1585_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1585_, 0, v_a_1579_);
v___x_1584_ = v_reuseFailAlloc_1585_;
goto v_reusejp_1583_;
}
v_reusejp_1583_:
{
return v___x_1584_;
}
}
}
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__5___redArg___lam__0___boxed(lean_object* v___x_1587_, lean_object* v___x_1588_, lean_object* v_targets_1589_, lean_object* v___x_1590_, lean_object* v_workers_1591_, lean_object* v_i_1592_, lean_object* v___x_1593_, lean_object* v___y_1594_){
_start:
{
lean_object* v_res_1595_; 
v_res_1595_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__5___redArg___lam__0(v___x_1587_, v___x_1588_, v_targets_1589_, v___x_1590_, v_workers_1591_, v_i_1592_, v___x_1593_);
lean_dec(v_i_1592_);
lean_dec(v_workers_1591_);
lean_dec_ref(v_targets_1589_);
return v_res_1595_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__5_spec__6___redArg(lean_object* v_val_1596_, lean_object* v_targets_1597_, lean_object* v_workers_1598_, lean_object* v___x_1599_, lean_object* v_range_1600_, lean_object* v_b_1601_, lean_object* v_i_1602_){
_start:
{
lean_object* v_stop_1604_; lean_object* v_step_1605_; uint8_t v___x_1606_; 
v_stop_1604_ = lean_ctor_get(v_range_1600_, 1);
v_step_1605_ = lean_ctor_get(v_range_1600_, 2);
v___x_1606_ = lean_nat_dec_lt(v_i_1602_, v_stop_1604_);
if (v___x_1606_ == 0)
{
lean_object* v___x_1607_; 
lean_dec(v_i_1602_);
lean_dec_ref(v___x_1599_);
lean_dec(v_workers_1598_);
lean_dec_ref(v_targets_1597_);
v___x_1607_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_1607_, 0, v_b_1601_);
return v___x_1607_;
}
else
{
lean_object* v___x_1608_; lean_object* v___x_1609_; lean_object* v___x_1610_; lean_object* v___f_1611_; lean_object* v___x_1612_; lean_object* v___x_1613_; lean_object* v___x_1614_; 
v___x_1608_ = lean_unsigned_to_nat(0u);
v___x_1609_ = lean_unsigned_to_nat(1u);
v___x_1610_ = l_IO_Promise_result_x21___redArg(v_val_1596_);
lean_inc_ref(v___x_1599_);
lean_inc(v_i_1602_);
lean_inc(v_workers_1598_);
lean_inc_ref(v_targets_1597_);
v___f_1611_ = lean_alloc_closure((void*)(l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__5___redArg___lam__0___boxed), 8, 7);
lean_closure_set(v___f_1611_, 0, v___x_1610_);
lean_closure_set(v___f_1611_, 1, v___x_1608_);
lean_closure_set(v___f_1611_, 2, v_targets_1597_);
lean_closure_set(v___f_1611_, 3, v___x_1609_);
lean_closure_set(v___f_1611_, 4, v_workers_1598_);
lean_closure_set(v___f_1611_, 5, v_i_1602_);
lean_closure_set(v___f_1611_, 6, v___x_1599_);
v___x_1612_ = lean_io_as_task(v___f_1611_, v___x_1608_);
v___x_1613_ = lean_array_push(v_b_1601_, v___x_1612_);
v___x_1614_ = lean_nat_add(v_i_1602_, v_step_1605_);
lean_dec(v_i_1602_);
v_b_1601_ = v___x_1613_;
v_i_1602_ = v___x_1614_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__5_spec__6___redArg___boxed(lean_object* v_val_1616_, lean_object* v_targets_1617_, lean_object* v_workers_1618_, lean_object* v___x_1619_, lean_object* v_range_1620_, lean_object* v_b_1621_, lean_object* v_i_1622_, lean_object* v___y_1623_){
_start:
{
lean_object* v_res_1624_; 
v_res_1624_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__5_spec__6___redArg(v_val_1616_, v_targets_1617_, v_workers_1618_, v___x_1619_, v_range_1620_, v_b_1621_, v_i_1622_);
lean_dec_ref(v_range_1620_);
lean_dec(v_val_1616_);
return v_res_1624_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__5___redArg(lean_object* v_workers_1625_, lean_object* v_targets_1626_, lean_object* v___x_1627_, lean_object* v_val_1628_, lean_object* v_range_1629_, lean_object* v_b_1630_, lean_object* v_i_1631_){
_start:
{
lean_object* v_stop_1633_; lean_object* v_step_1634_; uint8_t v___x_1635_; 
v_stop_1633_ = lean_ctor_get(v_range_1629_, 1);
v_step_1634_ = lean_ctor_get(v_range_1629_, 2);
v___x_1635_ = lean_nat_dec_lt(v_i_1631_, v_stop_1633_);
if (v___x_1635_ == 0)
{
lean_object* v___x_1636_; 
lean_dec(v_i_1631_);
lean_dec_ref(v___x_1627_);
lean_dec_ref(v_targets_1626_);
lean_dec(v_workers_1625_);
v___x_1636_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_1636_, 0, v_b_1630_);
return v___x_1636_;
}
else
{
lean_object* v___x_1637_; lean_object* v___x_1638_; lean_object* v___x_1639_; lean_object* v___f_1640_; lean_object* v___x_1641_; lean_object* v___x_1642_; lean_object* v___x_1643_; lean_object* v___x_1644_; 
v___x_1637_ = lean_unsigned_to_nat(0u);
v___x_1638_ = lean_unsigned_to_nat(1u);
v___x_1639_ = l_IO_Promise_result_x21___redArg(v_val_1628_);
lean_inc_ref(v___x_1627_);
lean_inc(v_i_1631_);
lean_inc(v_workers_1625_);
lean_inc_ref(v_targets_1626_);
v___f_1640_ = lean_alloc_closure((void*)(l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__5___redArg___lam__0___boxed), 8, 7);
lean_closure_set(v___f_1640_, 0, v___x_1639_);
lean_closure_set(v___f_1640_, 1, v___x_1637_);
lean_closure_set(v___f_1640_, 2, v_targets_1626_);
lean_closure_set(v___f_1640_, 3, v___x_1638_);
lean_closure_set(v___f_1640_, 4, v_workers_1625_);
lean_closure_set(v___f_1640_, 5, v_i_1631_);
lean_closure_set(v___f_1640_, 6, v___x_1627_);
v___x_1641_ = lean_io_as_task(v___f_1640_, v___x_1637_);
v___x_1642_ = lean_array_push(v_b_1630_, v___x_1641_);
v___x_1643_ = lean_nat_add(v_i_1631_, v_step_1634_);
lean_dec(v_i_1631_);
v___x_1644_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__5_spec__6___redArg(v_val_1628_, v_targets_1626_, v_workers_1625_, v___x_1627_, v_range_1629_, v___x_1642_, v___x_1643_);
return v___x_1644_;
}
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__5___redArg___boxed(lean_object* v_workers_1645_, lean_object* v_targets_1646_, lean_object* v___x_1647_, lean_object* v_val_1648_, lean_object* v_range_1649_, lean_object* v_b_1650_, lean_object* v_i_1651_, lean_object* v___y_1652_){
_start:
{
lean_object* v_res_1653_; 
v_res_1653_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__5___redArg(v_workers_1645_, v_targets_1646_, v___x_1647_, v_val_1648_, v_range_1649_, v_b_1650_, v_i_1651_);
lean_dec_ref(v_range_1649_);
lean_dec(v_val_1648_);
return v_res_1653_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__10___redArg(lean_object* v___x_1654_, lean_object* v___y_1655_, lean_object* v_range_1656_, lean_object* v_b_1657_, lean_object* v_i_1658_){
_start:
{
lean_object* v_stop_1660_; lean_object* v_step_1661_; uint8_t v___x_1662_; 
v_stop_1660_ = lean_ctor_get(v_range_1656_, 1);
v_step_1661_ = lean_ctor_get(v_range_1656_, 2);
v___x_1662_ = lean_nat_dec_lt(v_i_1658_, v_stop_1660_);
if (v___x_1662_ == 0)
{
lean_object* v___x_1663_; 
lean_dec(v_i_1658_);
v___x_1663_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_1663_, 0, v_b_1657_);
return v___x_1663_;
}
else
{
lean_object* v___x_1664_; lean_object* v___x_1665_; lean_object* v___x_1666_; lean_object* v___x_1667_; lean_object* v___x_1668_; lean_object* v___x_1669_; lean_object* v___x_1670_; lean_object* v___x_1671_; 
v___x_1664_ = lean_unsigned_to_nat(1u);
v___x_1665_ = l_Lean_instInhabitedTheoremVal_default;
v___x_1666_ = lean_nat_sub(v___x_1654_, v___x_1664_);
v___x_1667_ = lean_nat_mul(v_i_1658_, v___x_1666_);
v___x_1668_ = lean_nat_div(v___x_1667_, v___x_1666_);
lean_dec(v___x_1666_);
lean_dec(v___x_1667_);
v___x_1669_ = lean_array_get_borrowed(v___x_1665_, v___y_1655_, v___x_1668_);
lean_dec(v___x_1668_);
lean_inc(v___x_1669_);
v___x_1670_ = lean_array_push(v_b_1657_, v___x_1669_);
v___x_1671_ = lean_nat_add(v_i_1658_, v_step_1661_);
lean_dec(v_i_1658_);
v_b_1657_ = v___x_1670_;
v_i_1658_ = v___x_1671_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__10___redArg___boxed(lean_object* v___x_1673_, lean_object* v___y_1674_, lean_object* v_range_1675_, lean_object* v_b_1676_, lean_object* v_i_1677_, lean_object* v___y_1678_){
_start:
{
lean_object* v_res_1679_; 
v_res_1679_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__10___redArg(v___x_1673_, v___y_1674_, v_range_1675_, v_b_1676_, v_i_1677_);
lean_dec_ref(v_range_1675_);
lean_dec_ref(v___y_1674_);
lean_dec(v___x_1673_);
return v_res_1679_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__6(lean_object* v_as_1680_, size_t v_sz_1681_, size_t v_i_1682_, lean_object* v_b_1683_){
_start:
{
uint8_t v___x_1685_; 
v___x_1685_ = lean_usize_dec_lt(v_i_1682_, v_sz_1681_);
if (v___x_1685_ == 0)
{
lean_object* v___x_1686_; 
v___x_1686_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_1686_, 0, v_b_1683_);
return v___x_1686_;
}
else
{
lean_object* v_a_1687_; lean_object* v___x_1688_; 
v_a_1687_ = lean_array_uget_borrowed(v_as_1680_, v_i_1682_);
lean_inc(v_a_1687_);
v___x_1688_ = lean_task_get_own(v_a_1687_);
if (lean_obj_tag(v___x_1688_) == 0)
{
lean_object* v_a_1689_; lean_object* v___x_1691_; uint8_t v_isShared_1692_; uint8_t v_isSharedCheck_1696_; 
lean_dec_ref(v_b_1683_);
v_a_1689_ = lean_ctor_get(v___x_1688_, 0);
v_isSharedCheck_1696_ = !lean_is_exclusive(v___x_1688_);
if (v_isSharedCheck_1696_ == 0)
{
v___x_1691_ = v___x_1688_;
v_isShared_1692_ = v_isSharedCheck_1696_;
goto v_resetjp_1690_;
}
else
{
lean_inc(v_a_1689_);
lean_dec(v___x_1688_);
v___x_1691_ = lean_box(0);
v_isShared_1692_ = v_isSharedCheck_1696_;
goto v_resetjp_1690_;
}
v_resetjp_1690_:
{
lean_object* v___x_1694_; 
if (v_isShared_1692_ == 0)
{
lean_ctor_set_tag(v___x_1691_, 1);
v___x_1694_ = v___x_1691_;
goto v_reusejp_1693_;
}
else
{
lean_object* v_reuseFailAlloc_1695_; 
v_reuseFailAlloc_1695_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1695_, 0, v_a_1689_);
v___x_1694_ = v_reuseFailAlloc_1695_;
goto v_reusejp_1693_;
}
v_reusejp_1693_:
{
return v___x_1694_;
}
}
}
else
{
lean_object* v_a_1697_; lean_object* v___x_1698_; size_t v___x_1699_; size_t v___x_1700_; 
v_a_1697_ = lean_ctor_get(v___x_1688_, 0);
lean_inc(v_a_1697_);
lean_dec_ref_known(v___x_1688_, 1);
v___x_1698_ = l_Array_append___redArg(v_b_1683_, v_a_1697_);
lean_dec(v_a_1697_);
v___x_1699_ = ((size_t)1ULL);
v___x_1700_ = lean_usize_add(v_i_1682_, v___x_1699_);
v_i_1682_ = v___x_1700_;
v_b_1683_ = v___x_1698_;
goto _start;
}
}
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__6___boxed(lean_object* v_as_1702_, lean_object* v_sz_1703_, lean_object* v_i_1704_, lean_object* v_b_1705_, lean_object* v___y_1706_){
_start:
{
size_t v_sz_boxed_1707_; size_t v_i_boxed_1708_; lean_object* v_res_1709_; 
v_sz_boxed_1707_ = lean_unbox_usize(v_sz_1703_);
lean_dec(v_sz_1703_);
v_i_boxed_1708_ = lean_unbox_usize(v_i_1704_);
lean_dec(v_i_1704_);
v_res_1709_ = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__6(v_as_1702_, v_sz_boxed_1707_, v_i_boxed_1708_, v_b_1705_);
lean_dec_ref(v_as_1702_);
return v_res_1709_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__11(uint8_t v___x_1714_, lean_object* v_as_1715_, size_t v_sz_1716_, size_t v_i_1717_, lean_object* v_b_1718_){
_start:
{
uint8_t v___x_1719_; 
v___x_1719_ = lean_usize_dec_lt(v_i_1717_, v_sz_1716_);
if (v___x_1719_ == 0)
{
lean_inc_ref(v_b_1718_);
return v_b_1718_;
}
else
{
lean_object* v_a_1720_; lean_object* v_toConstantVal_1721_; lean_object* v_name_1722_; lean_object* v___x_1723_; lean_object* v___x_1724_; lean_object* v___x_1725_; uint8_t v___x_1726_; 
v_a_1720_ = lean_array_uget_borrowed(v_as_1715_, v_i_1717_);
v_toConstantVal_1721_ = lean_ctor_get(v_a_1720_, 0);
v_name_1722_ = lean_ctor_get(v_toConstantVal_1721_, 0);
v___x_1723_ = ((lean_object*)(l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__11___closed__0));
v___x_1724_ = lean_box(0);
lean_inc(v_name_1722_);
v___x_1725_ = l_Lean_Name_toStringWithToken___at___00Lean_Name_toString_spec__0(v_name_1722_, v___x_1714_);
v___x_1726_ = lean_string_dec_eq(v___x_1725_, v___x_1723_);
lean_dec_ref(v___x_1725_);
if (v___x_1726_ == 0)
{
lean_object* v___x_1727_; size_t v___x_1728_; size_t v___x_1729_; 
v___x_1727_ = ((lean_object*)(l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__11___closed__1));
v___x_1728_ = ((size_t)1ULL);
v___x_1729_ = lean_usize_add(v_i_1717_, v___x_1728_);
v_i_1717_ = v___x_1729_;
v_b_1718_ = v___x_1727_;
goto _start;
}
else
{
lean_object* v___x_1731_; lean_object* v___x_1732_; lean_object* v___x_1733_; 
lean_inc(v_a_1720_);
v___x_1731_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_1731_, 0, v_a_1720_);
v___x_1732_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_1732_, 0, v___x_1731_);
v___x_1733_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1733_, 0, v___x_1732_);
lean_ctor_set(v___x_1733_, 1, v___x_1724_);
return v___x_1733_;
}
}
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__11___boxed(lean_object* v___x_1734_, lean_object* v_as_1735_, lean_object* v_sz_1736_, lean_object* v_i_1737_, lean_object* v_b_1738_){
_start:
{
uint8_t v___x_20220__boxed_1739_; size_t v_sz_boxed_1740_; size_t v_i_boxed_1741_; lean_object* v_res_1742_; 
v___x_20220__boxed_1739_ = lean_unbox(v___x_1734_);
v_sz_boxed_1740_ = lean_unbox_usize(v_sz_1736_);
lean_dec(v_sz_1736_);
v_i_boxed_1741_ = lean_unbox_usize(v_i_1737_);
lean_dec(v_i_1737_);
v_res_1742_ = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__11(v___x_20220__boxed_1739_, v_as_1735_, v_sz_boxed_1740_, v_i_boxed_1741_, v_b_1738_);
lean_dec_ref(v_b_1738_);
lean_dec_ref(v_as_1735_);
return v_res_1742_;
}
}
LEAN_EXPORT uint8_t l_List_any___at___00main_spec__0(lean_object* v_head_1743_, lean_object* v_head_1744_, lean_object* v_x_1745_){
_start:
{
if (lean_obj_tag(v_x_1745_) == 0)
{
uint8_t v___x_1746_; 
v___x_1746_ = 0;
return v___x_1746_;
}
else
{
lean_object* v_head_1747_; lean_object* v_tail_1748_; uint8_t v___y_1750_; lean_object* v___x_1752_; lean_object* v___x_1753_; uint8_t v___x_1754_; 
v_head_1747_ = lean_ctor_get(v_x_1745_, 0);
v_tail_1748_ = lean_ctor_get(v_x_1745_, 1);
v___x_1752_ = lean_string_utf8_byte_size(v_head_1743_);
v___x_1753_ = lean_string_utf8_byte_size(v_head_1747_);
v___x_1754_ = lean_nat_dec_le(v___x_1753_, v___x_1752_);
if (v___x_1754_ == 0)
{
lean_object* v___x_1755_; uint8_t v___x_1756_; 
v___x_1755_ = ((lean_object*)(l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__3___closed__2));
v___x_1756_ = lean_string_dec_eq(v_head_1744_, v___x_1755_);
v___y_1750_ = v___x_1756_;
goto v___jp_1749_;
}
else
{
lean_object* v___x_1757_; lean_object* v___x_1758_; uint8_t v___x_1759_; 
v___x_1757_ = lean_unsigned_to_nat(0u);
v___x_1758_ = lean_nat_sub(v___x_1752_, v___x_1753_);
v___x_1759_ = lean_string_memcmp(v_head_1743_, v_head_1747_, v___x_1758_, v___x_1757_, v___x_1753_);
lean_dec(v___x_1758_);
v___y_1750_ = v___x_1759_;
goto v___jp_1749_;
}
v___jp_1749_:
{
if (v___y_1750_ == 0)
{
v_x_1745_ = v_tail_1748_;
goto _start;
}
else
{
return v___y_1750_;
}
}
}
}
}
LEAN_EXPORT lean_object* l_List_any___at___00main_spec__0___boxed(lean_object* v_head_1760_, lean_object* v_head_1761_, lean_object* v_x_1762_){
_start:
{
uint8_t v_res_1763_; lean_object* v_r_1764_; 
v_res_1763_ = l_List_any___at___00main_spec__0(v_head_1760_, v_head_1761_, v_x_1762_);
lean_dec(v_x_1762_);
lean_dec_ref(v_head_1761_);
lean_dec_ref(v_head_1760_);
v_r_1764_ = lean_box(v_res_1763_);
return v_r_1764_;
}
}
static lean_object* _init_l_main___boxed__const__1(void){
_start:
{
uint32_t v___x_1802_; lean_object* v___x_1803_; 
v___x_1802_ = 0;
v___x_1803_ = lean_box_uint32(v___x_1802_);
return v___x_1803_;
}
}
LEAN_EXPORT lean_object* _lean_main(lean_object* v_args_1804_){
_start:
{
if (lean_obj_tag(v_args_1804_) == 1)
{
lean_object* v_tail_1812_; 
v_tail_1812_ = lean_ctor_get(v_args_1804_, 1);
lean_inc(v_tail_1812_);
if (lean_obj_tag(v_tail_1812_) == 1)
{
lean_object* v_tail_1813_; 
v_tail_1813_ = lean_ctor_get(v_tail_1812_, 1);
lean_inc(v_tail_1813_);
if (lean_obj_tag(v_tail_1813_) == 1)
{
lean_object* v_tail_1814_; 
v_tail_1814_ = lean_ctor_get(v_tail_1813_, 1);
lean_inc(v_tail_1814_);
if (lean_obj_tag(v_tail_1814_) == 1)
{
lean_object* v_tail_1815_; 
v_tail_1815_ = lean_ctor_get(v_tail_1814_, 1);
lean_inc(v_tail_1815_);
if (lean_obj_tag(v_tail_1815_) == 0)
{
lean_object* v_head_1816_; lean_object* v___x_1818_; uint8_t v_isShared_1819_; uint8_t v_isSharedCheck_2219_; 
v_head_1816_ = lean_ctor_get(v_args_1804_, 0);
v_isSharedCheck_2219_ = !lean_is_exclusive(v_args_1804_);
if (v_isSharedCheck_2219_ == 0)
{
lean_object* v_unused_2220_; 
v_unused_2220_ = lean_ctor_get(v_args_1804_, 1);
lean_dec(v_unused_2220_);
v___x_1818_ = v_args_1804_;
v_isShared_1819_ = v_isSharedCheck_2219_;
goto v_resetjp_1817_;
}
else
{
lean_inc(v_head_1816_);
lean_dec(v_args_1804_);
v___x_1818_ = lean_box(0);
v_isShared_1819_ = v_isSharedCheck_2219_;
goto v_resetjp_1817_;
}
v_resetjp_1817_:
{
lean_object* v_head_1820_; lean_object* v___x_1822_; uint8_t v_isShared_1823_; uint8_t v_isSharedCheck_2217_; 
v_head_1820_ = lean_ctor_get(v_tail_1812_, 0);
v_isSharedCheck_2217_ = !lean_is_exclusive(v_tail_1812_);
if (v_isSharedCheck_2217_ == 0)
{
lean_object* v_unused_2218_; 
v_unused_2218_ = lean_ctor_get(v_tail_1812_, 1);
lean_dec(v_unused_2218_);
v___x_1822_ = v_tail_1812_;
v_isShared_1823_ = v_isSharedCheck_2217_;
goto v_resetjp_1821_;
}
else
{
lean_inc(v_head_1820_);
lean_dec(v_tail_1812_);
v___x_1822_ = lean_box(0);
v_isShared_1823_ = v_isSharedCheck_2217_;
goto v_resetjp_1821_;
}
v_resetjp_1821_:
{
lean_object* v_head_1824_; lean_object* v___x_1826_; uint8_t v_isShared_1827_; uint8_t v_isSharedCheck_2215_; 
v_head_1824_ = lean_ctor_get(v_tail_1813_, 0);
v_isSharedCheck_2215_ = !lean_is_exclusive(v_tail_1813_);
if (v_isSharedCheck_2215_ == 0)
{
lean_object* v_unused_2216_; 
v_unused_2216_ = lean_ctor_get(v_tail_1813_, 1);
lean_dec(v_unused_2216_);
v___x_1826_ = v_tail_1813_;
v_isShared_1827_ = v_isSharedCheck_2215_;
goto v_resetjp_1825_;
}
else
{
lean_inc(v_head_1824_);
lean_dec(v_tail_1813_);
v___x_1826_ = lean_box(0);
v_isShared_1827_ = v_isSharedCheck_2215_;
goto v_resetjp_1825_;
}
v_resetjp_1825_:
{
lean_object* v_head_1828_; lean_object* v___x_1830_; uint8_t v_isShared_1831_; uint8_t v_isSharedCheck_2213_; 
v_head_1828_ = lean_ctor_get(v_tail_1814_, 0);
v_isSharedCheck_2213_ = !lean_is_exclusive(v_tail_1814_);
if (v_isSharedCheck_2213_ == 0)
{
lean_object* v_unused_2214_; 
v_unused_2214_ = lean_ctor_get(v_tail_1814_, 1);
lean_dec(v_unused_2214_);
v___x_1830_ = v_tail_1814_;
v_isShared_1831_ = v_isSharedCheck_2213_;
goto v_resetjp_1829_;
}
else
{
lean_inc(v_head_1828_);
lean_dec(v_tail_1814_);
v___x_1830_ = lean_box(0);
v_isShared_1831_ = v_isSharedCheck_2213_;
goto v_resetjp_1829_;
}
v_resetjp_1829_:
{
lean_object* v___x_1832_; lean_object* v___x_1833_; lean_object* v___x_1834_; lean_object* v_workers_1835_; lean_object* v___y_1837_; lean_object* v___y_1838_; lean_object* v___y_1839_; size_t v___y_1840_; lean_object* v___y_1841_; lean_object* v___y_1853_; lean_object* v___y_1854_; lean_object* v___y_1855_; size_t v___y_1856_; lean_object* v___y_1857_; lean_object* v___y_1858_; lean_object* v___y_1859_; lean_object* v___y_1860_; lean_object* v___y_1863_; lean_object* v___y_1864_; lean_object* v___y_1865_; lean_object* v___y_1866_; size_t v___y_1867_; lean_object* v___y_1868_; lean_object* v___y_1869_; lean_object* v___y_1870_; lean_object* v___x_1872_; lean_object* v___x_1873_; lean_object* v___x_1874_; uint8_t v___x_1875_; lean_object* v___y_1877_; lean_object* v___y_1878_; uint32_t v___y_1879_; lean_object* v_targets_1880_; lean_object* v___y_1968_; lean_object* v___y_1969_; uint32_t v___y_1970_; lean_object* v___y_1971_; lean_object* v___y_1972_; lean_object* v___y_1975_; lean_object* v___y_1976_; uint32_t v___y_1977_; lean_object* v___y_1978_; uint8_t v___y_1979_; lean_object* v___y_1980_; lean_object* v___y_1981_; uint8_t v___y_1982_; 
v___x_1832_ = lean_unsigned_to_nat(0u);
v___x_1833_ = lean_string_utf8_byte_size(v_head_1828_);
v___x_1834_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_1834_, 0, v_head_1828_);
lean_ctor_set(v___x_1834_, 1, v___x_1832_);
lean_ctor_set(v___x_1834_, 2, v___x_1833_);
v_workers_1835_ = l_String_Slice_toNat_x21(v___x_1834_);
lean_dec_ref_known(v___x_1834_, 3);
v___x_1872_ = lean_unsigned_to_nat(1u);
v___x_1873_ = lean_box(0);
v___x_1874_ = ((lean_object*)(l_main___closed__5));
v___x_1875_ = l_List_elem___at___00Lean_Meta_Grind_Arith_Cutsat_checkElimEqs_spec__0(v_workers_1835_, v___x_1874_);
if (v___x_1875_ == 0)
{
lean_object* v___x_1994_; lean_object* v___x_1995_; 
lean_dec(v_workers_1835_);
lean_del_object(v___x_1830_);
lean_del_object(v___x_1826_);
lean_dec(v_head_1824_);
lean_del_object(v___x_1822_);
lean_dec(v_head_1820_);
lean_del_object(v___x_1818_);
lean_dec(v_head_1816_);
v___x_1994_ = ((lean_object*)(l_main___closed__10));
v___x_1995_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_1995_, 0, v___x_1994_);
return v___x_1995_;
}
else
{
lean_object* v___x_1996_; lean_object* v___x_1997_; 
v___x_1996_ = ((lean_object*)(l_main___closed__11));
v___x_1997_ = l_Lean_findSysroot(v___x_1996_);
if (lean_obj_tag(v___x_1997_) == 0)
{
lean_object* v_a_1998_; lean_object* v___x_2000_; uint8_t v_isShared_2001_; uint8_t v_isSharedCheck_2204_; 
v_a_1998_ = lean_ctor_get(v___x_1997_, 0);
v_isSharedCheck_2204_ = !lean_is_exclusive(v___x_1997_);
if (v_isSharedCheck_2204_ == 0)
{
v___x_2000_ = v___x_1997_;
v_isShared_2001_ = v_isSharedCheck_2204_;
goto v_resetjp_1999_;
}
else
{
lean_inc(v_a_1998_);
lean_dec(v___x_1997_);
v___x_2000_ = lean_box(0);
v_isShared_2001_ = v_isSharedCheck_2204_;
goto v_resetjp_1999_;
}
v_resetjp_1999_:
{
lean_object* v___x_2002_; 
v___x_2002_ = l_Lean_initSearchPath(v_a_1998_, v___x_1873_);
if (lean_obj_tag(v___x_2002_) == 0)
{
lean_object* v___x_2004_; uint8_t v_isShared_2005_; uint8_t v_isSharedCheck_2194_; 
v_isSharedCheck_2194_ = !lean_is_exclusive(v___x_2002_);
if (v_isSharedCheck_2194_ == 0)
{
lean_object* v_unused_2195_; 
v_unused_2195_ = lean_ctor_get(v___x_2002_, 0);
lean_dec(v_unused_2195_);
v___x_2004_ = v___x_2002_;
v_isShared_2005_ = v_isSharedCheck_2194_;
goto v_resetjp_2003_;
}
else
{
lean_dec(v___x_2002_);
v___x_2004_ = lean_box(0);
v_isShared_2005_ = v_isSharedCheck_2194_;
goto v_resetjp_2003_;
}
v_resetjp_2003_:
{
lean_object* v___x_2006_; lean_object* v___x_2007_; lean_object* v___x_2008_; uint8_t v___x_2009_; lean_object* v___y_2011_; lean_object* v___y_2012_; uint32_t v___y_2013_; lean_object* v___y_2014_; lean_object* v___y_2015_; lean_object* v___y_2044_; lean_object* v___y_2045_; lean_object* v___y_2046_; lean_object* v___y_2047_; uint32_t v___y_2048_; lean_object* v___y_2049_; lean_object* v___y_2050_; lean_object* v___y_2051_; lean_object* v___y_2054_; lean_object* v___y_2055_; lean_object* v___y_2056_; uint32_t v___y_2057_; lean_object* v___y_2058_; lean_object* v___y_2059_; lean_object* v___y_2060_; lean_object* v___y_2061_; uint8_t v___y_2064_; 
v___x_2006_ = lean_enable_initializer_execution();
lean_inc(v_head_1820_);
v___x_2007_ = l_String_toName(v_head_1820_);
v___x_2008_ = ((lean_object*)(l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__3___closed__2));
v___x_2009_ = lean_string_dec_eq(v_head_1816_, v___x_2008_);
if (v___x_2009_ == 0)
{
lean_object* v___x_2121_; uint8_t v___x_2122_; 
lean_dec(v_head_1824_);
v___x_2121_ = ((lean_object*)(l_main___closed__22));
v___x_2122_ = lean_string_dec_eq(v_head_1816_, v___x_2121_);
if (v___x_2122_ == 0)
{
lean_object* v___x_2123_; uint8_t v___x_2124_; 
v___x_2123_ = ((lean_object*)(l_main___closed__6));
v___x_2124_ = lean_string_dec_eq(v_head_1816_, v___x_2123_);
v___y_2064_ = v___x_2124_;
goto v___jp_2063_;
}
else
{
v___y_2064_ = v___x_1875_;
goto v___jp_2063_;
}
}
else
{
lean_object* v___x_2125_; 
lean_del_object(v___x_2004_);
lean_del_object(v___x_2000_);
lean_del_object(v___x_1830_);
lean_del_object(v___x_1826_);
lean_del_object(v___x_1822_);
lean_del_object(v___x_1818_);
lean_dec(v_head_1816_);
v___x_2125_ = l_IO_FS_readFile(v_head_1824_);
if (lean_obj_tag(v___x_2125_) == 0)
{
lean_object* v_a_2126_; lean_object* v___x_2127_; lean_object* v___x_2128_; lean_object* v___x_2129_; 
v_a_2126_ = lean_ctor_get(v___x_2125_, 0);
lean_inc(v_a_2126_);
lean_dec_ref_known(v___x_2125_, 1);
v___x_2127_ = lean_string_utf8_byte_size(v_a_2126_);
lean_inc(v_head_1824_);
v___x_2128_ = l_Lean_Parser_mkInputContext___redArg(v_a_2126_, v_head_1824_, v___x_1875_, v___x_2127_);
lean_inc_ref(v___x_2128_);
v___x_2129_ = l_Lean_Parser_parseHeader(v___x_2128_);
if (lean_obj_tag(v___x_2129_) == 0)
{
lean_object* v_a_2130_; lean_object* v_snd_2131_; lean_object* v_fst_2132_; lean_object* v_fst_2133_; lean_object* v_snd_2134_; lean_object* v___x_2135_; lean_object* v___x_2136_; uint32_t v___x_2137_; lean_object* v___x_2138_; uint8_t v___x_2139_; uint8_t v___x_2140_; lean_object* v___x_2141_; lean_object* v___x_2142_; 
v_a_2130_ = lean_ctor_get(v___x_2129_, 0);
lean_inc(v_a_2130_);
lean_dec_ref_known(v___x_2129_, 1);
v_snd_2131_ = lean_ctor_get(v_a_2130_, 1);
lean_inc(v_snd_2131_);
v_fst_2132_ = lean_ctor_get(v_a_2130_, 0);
lean_inc(v_fst_2132_);
lean_dec(v_a_2130_);
v_fst_2133_ = lean_ctor_get(v_snd_2131_, 0);
lean_inc(v_fst_2133_);
v_snd_2134_ = lean_ctor_get(v_snd_2131_, 1);
lean_inc(v_snd_2134_);
lean_dec(v_snd_2131_);
v___x_2135_ = l_Lean_Elab_HeaderSyntax_imports(v_fst_2132_, v___x_1875_);
v___x_2136_ = l_Lean_Options_empty;
v___x_2137_ = 0;
v___x_2138_ = ((lean_object*)(l_main___closed__16));
v___x_2139_ = 0;
v___x_2140_ = 2;
v___x_2141_ = lean_box(1);
v___x_2142_ = l_Lean_importModules(v___x_2135_, v___x_2136_, v___x_2137_, v___x_2138_, v___x_2139_, v___x_1875_, v___x_2140_, v___x_2141_);
if (lean_obj_tag(v___x_2142_) == 0)
{
lean_object* v_a_2143_; lean_object* v___x_2144_; lean_object* v___x_2145_; lean_object* v___x_2146_; lean_object* v___x_2147_; 
v_a_2143_ = lean_ctor_get(v___x_2142_, 0);
lean_inc(v_a_2143_);
lean_dec_ref_known(v___x_2142_, 1);
v___x_2144_ = lean_io_promise_new();
v___x_2145_ = l_Lean_Environment_setMainModule(v_a_2143_, v___x_2007_);
lean_inc(v_workers_1835_);
v___x_2146_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_2146_, 0, v___x_1832_);
lean_ctor_set(v___x_2146_, 1, v_workers_1835_);
lean_ctor_set(v___x_2146_, 2, v___x_1872_);
v___x_2147_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__15___redArg(v_workers_1835_, v___x_2145_, v___x_2128_, v_fst_2133_, v_snd_2134_, v_head_1824_, v_head_1820_, v___x_2144_, v___x_2146_, v___x_2138_, v___x_1832_);
lean_dec_ref_known(v___x_2146_, 3);
if (lean_obj_tag(v___x_2147_) == 0)
{
lean_object* v_a_2148_; lean_object* v___x_2149_; lean_object* v___x_2150_; size_t v_sz_2151_; size_t v___x_2152_; lean_object* v___x_2153_; 
v_a_2148_ = lean_ctor_get(v___x_2147_, 0);
lean_inc(v_a_2148_);
lean_dec_ref_known(v___x_2147_, 1);
v___x_2149_ = lean_box(0);
v___x_2150_ = lean_io_promise_resolve(v___x_2149_, v___x_2144_);
lean_dec(v___x_2144_);
v_sz_2151_ = lean_array_size(v_a_2148_);
v___x_2152_ = ((size_t)0ULL);
v___x_2153_ = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__17(v_a_2148_, v_sz_2151_, v___x_2152_, v___x_2149_);
lean_dec(v_a_2148_);
if (lean_obj_tag(v___x_2153_) == 0)
{
lean_dec_ref_known(v___x_2153_, 1);
goto v___jp_1809_;
}
else
{
lean_object* v_a_2154_; lean_object* v___x_2156_; uint8_t v_isShared_2157_; uint8_t v_isSharedCheck_2161_; 
v_a_2154_ = lean_ctor_get(v___x_2153_, 0);
v_isSharedCheck_2161_ = !lean_is_exclusive(v___x_2153_);
if (v_isSharedCheck_2161_ == 0)
{
v___x_2156_ = v___x_2153_;
v_isShared_2157_ = v_isSharedCheck_2161_;
goto v_resetjp_2155_;
}
else
{
lean_inc(v_a_2154_);
lean_dec(v___x_2153_);
v___x_2156_ = lean_box(0);
v_isShared_2157_ = v_isSharedCheck_2161_;
goto v_resetjp_2155_;
}
v_resetjp_2155_:
{
lean_object* v___x_2159_; 
if (v_isShared_2157_ == 0)
{
v___x_2159_ = v___x_2156_;
goto v_reusejp_2158_;
}
else
{
lean_object* v_reuseFailAlloc_2160_; 
v_reuseFailAlloc_2160_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2160_, 0, v_a_2154_);
v___x_2159_ = v_reuseFailAlloc_2160_;
goto v_reusejp_2158_;
}
v_reusejp_2158_:
{
return v___x_2159_;
}
}
}
}
else
{
lean_object* v_a_2162_; lean_object* v___x_2164_; uint8_t v_isShared_2165_; uint8_t v_isSharedCheck_2169_; 
lean_dec(v___x_2144_);
v_a_2162_ = lean_ctor_get(v___x_2147_, 0);
v_isSharedCheck_2169_ = !lean_is_exclusive(v___x_2147_);
if (v_isSharedCheck_2169_ == 0)
{
v___x_2164_ = v___x_2147_;
v_isShared_2165_ = v_isSharedCheck_2169_;
goto v_resetjp_2163_;
}
else
{
lean_inc(v_a_2162_);
lean_dec(v___x_2147_);
v___x_2164_ = lean_box(0);
v_isShared_2165_ = v_isSharedCheck_2169_;
goto v_resetjp_2163_;
}
v_resetjp_2163_:
{
lean_object* v___x_2167_; 
if (v_isShared_2165_ == 0)
{
v___x_2167_ = v___x_2164_;
goto v_reusejp_2166_;
}
else
{
lean_object* v_reuseFailAlloc_2168_; 
v_reuseFailAlloc_2168_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2168_, 0, v_a_2162_);
v___x_2167_ = v_reuseFailAlloc_2168_;
goto v_reusejp_2166_;
}
v_reusejp_2166_:
{
return v___x_2167_;
}
}
}
}
else
{
lean_object* v_a_2170_; lean_object* v___x_2172_; uint8_t v_isShared_2173_; uint8_t v_isSharedCheck_2177_; 
lean_dec(v_snd_2134_);
lean_dec(v_fst_2133_);
lean_dec_ref(v___x_2128_);
lean_dec(v___x_2007_);
lean_dec(v_workers_1835_);
lean_dec(v_head_1824_);
lean_dec(v_head_1820_);
v_a_2170_ = lean_ctor_get(v___x_2142_, 0);
v_isSharedCheck_2177_ = !lean_is_exclusive(v___x_2142_);
if (v_isSharedCheck_2177_ == 0)
{
v___x_2172_ = v___x_2142_;
v_isShared_2173_ = v_isSharedCheck_2177_;
goto v_resetjp_2171_;
}
else
{
lean_inc(v_a_2170_);
lean_dec(v___x_2142_);
v___x_2172_ = lean_box(0);
v_isShared_2173_ = v_isSharedCheck_2177_;
goto v_resetjp_2171_;
}
v_resetjp_2171_:
{
lean_object* v___x_2175_; 
if (v_isShared_2173_ == 0)
{
v___x_2175_ = v___x_2172_;
goto v_reusejp_2174_;
}
else
{
lean_object* v_reuseFailAlloc_2176_; 
v_reuseFailAlloc_2176_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2176_, 0, v_a_2170_);
v___x_2175_ = v_reuseFailAlloc_2176_;
goto v_reusejp_2174_;
}
v_reusejp_2174_:
{
return v___x_2175_;
}
}
}
}
else
{
lean_object* v_a_2178_; lean_object* v___x_2180_; uint8_t v_isShared_2181_; uint8_t v_isSharedCheck_2185_; 
lean_dec_ref(v___x_2128_);
lean_dec(v___x_2007_);
lean_dec(v_workers_1835_);
lean_dec(v_head_1824_);
lean_dec(v_head_1820_);
v_a_2178_ = lean_ctor_get(v___x_2129_, 0);
v_isSharedCheck_2185_ = !lean_is_exclusive(v___x_2129_);
if (v_isSharedCheck_2185_ == 0)
{
v___x_2180_ = v___x_2129_;
v_isShared_2181_ = v_isSharedCheck_2185_;
goto v_resetjp_2179_;
}
else
{
lean_inc(v_a_2178_);
lean_dec(v___x_2129_);
v___x_2180_ = lean_box(0);
v_isShared_2181_ = v_isSharedCheck_2185_;
goto v_resetjp_2179_;
}
v_resetjp_2179_:
{
lean_object* v___x_2183_; 
if (v_isShared_2181_ == 0)
{
v___x_2183_ = v___x_2180_;
goto v_reusejp_2182_;
}
else
{
lean_object* v_reuseFailAlloc_2184_; 
v_reuseFailAlloc_2184_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2184_, 0, v_a_2178_);
v___x_2183_ = v_reuseFailAlloc_2184_;
goto v_reusejp_2182_;
}
v_reusejp_2182_:
{
return v___x_2183_;
}
}
}
}
else
{
lean_object* v_a_2186_; lean_object* v___x_2188_; uint8_t v_isShared_2189_; uint8_t v_isSharedCheck_2193_; 
lean_dec(v___x_2007_);
lean_dec(v_workers_1835_);
lean_dec(v_head_1824_);
lean_dec(v_head_1820_);
v_a_2186_ = lean_ctor_get(v___x_2125_, 0);
v_isSharedCheck_2193_ = !lean_is_exclusive(v___x_2125_);
if (v_isSharedCheck_2193_ == 0)
{
v___x_2188_ = v___x_2125_;
v_isShared_2189_ = v_isSharedCheck_2193_;
goto v_resetjp_2187_;
}
else
{
lean_inc(v_a_2186_);
lean_dec(v___x_2125_);
v___x_2188_ = lean_box(0);
v_isShared_2189_ = v_isSharedCheck_2193_;
goto v_resetjp_2187_;
}
v_resetjp_2187_:
{
lean_object* v___x_2191_; 
if (v_isShared_2189_ == 0)
{
v___x_2191_ = v___x_2188_;
goto v_reusejp_2190_;
}
else
{
lean_object* v_reuseFailAlloc_2192_; 
v_reuseFailAlloc_2192_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2192_, 0, v_a_2186_);
v___x_2191_ = v_reuseFailAlloc_2192_;
goto v_reusejp_2190_;
}
v_reusejp_2190_:
{
return v___x_2191_;
}
}
}
}
v___jp_2010_:
{
lean_object* v___x_2016_; uint8_t v___x_2017_; 
v___x_2016_ = lean_array_get_size(v___y_2015_);
v___x_2017_ = lean_nat_dec_lt(v___x_1832_, v___x_2016_);
if (v___x_2017_ == 0)
{
lean_object* v___x_2018_; lean_object* v___x_2019_; lean_object* v___x_2020_; lean_object* v___x_2021_; lean_object* v___x_2022_; lean_object* v___x_2023_; lean_object* v___x_2025_; 
lean_dec_ref(v___y_2015_);
lean_dec_ref(v___y_2014_);
lean_dec_ref(v___y_2012_);
lean_dec(v_workers_1835_);
lean_del_object(v___x_1830_);
lean_del_object(v___x_1826_);
lean_del_object(v___x_1822_);
lean_dec(v_head_1820_);
lean_dec(v_head_1816_);
v___x_2018_ = ((lean_object*)(l_main___closed__12));
v___x_2019_ = l_Nat_reprFast(v___x_2016_);
v___x_2020_ = lean_string_append(v___x_2018_, v___x_2019_);
lean_dec_ref(v___x_2019_);
v___x_2021_ = ((lean_object*)(l_main___closed__13));
v___x_2022_ = lean_string_append(v___x_2020_, v___x_2021_);
v___x_2023_ = lean_alloc_ctor(18, 1, 0);
lean_ctor_set(v___x_2023_, 0, v___x_2022_);
if (v_isShared_2005_ == 0)
{
lean_ctor_set_tag(v___x_2004_, 1);
lean_ctor_set(v___x_2004_, 0, v___x_2023_);
v___x_2025_ = v___x_2004_;
goto v_reusejp_2024_;
}
else
{
lean_object* v_reuseFailAlloc_2026_; 
v_reuseFailAlloc_2026_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2026_, 0, v___x_2023_);
v___x_2025_ = v_reuseFailAlloc_2026_;
goto v_reusejp_2024_;
}
v_reusejp_2024_:
{
return v___x_2025_;
}
}
else
{
lean_object* v___x_2027_; lean_object* v___x_2028_; 
lean_del_object(v___x_2004_);
v___x_2027_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_2027_, 0, v___x_1832_);
lean_ctor_set(v___x_2027_, 1, v___x_2016_);
lean_ctor_set(v___x_2027_, 2, v___x_1872_);
lean_inc_ref(v___y_2014_);
v___x_2028_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__10___redArg(v___x_2016_, v___y_2015_, v___x_2027_, v___y_2014_, v___x_1832_);
lean_dec_ref_known(v___x_2027_, 3);
if (lean_obj_tag(v___x_2028_) == 0)
{
lean_object* v_a_2029_; lean_object* v___x_2030_; lean_object* v___x_2031_; uint8_t v___x_2032_; 
v_a_2029_ = lean_ctor_get(v___x_2028_, 0);
lean_inc(v_a_2029_);
lean_dec_ref_known(v___x_2028_, 1);
v___x_2030_ = lean_string_utf8_byte_size(v_head_1820_);
v___x_2031_ = lean_string_utf8_byte_size(v___y_2011_);
v___x_2032_ = lean_nat_dec_le(v___x_2031_, v___x_2030_);
if (v___x_2032_ == 0)
{
v___y_1975_ = v___x_2016_;
v___y_1976_ = v___y_2012_;
v___y_1977_ = v___y_2013_;
v___y_1978_ = v___y_2015_;
v___y_1979_ = v___x_2017_;
v___y_1980_ = v___y_2014_;
v___y_1981_ = v_a_2029_;
v___y_1982_ = v___x_2009_;
goto v___jp_1974_;
}
else
{
lean_object* v___x_2033_; uint8_t v___x_2034_; 
v___x_2033_ = lean_nat_sub(v___x_2030_, v___x_2031_);
v___x_2034_ = lean_string_memcmp(v_head_1820_, v___y_2011_, v___x_2033_, v___x_1832_, v___x_2031_);
lean_dec(v___x_2033_);
v___y_1975_ = v___x_2016_;
v___y_1976_ = v___y_2012_;
v___y_1977_ = v___y_2013_;
v___y_1978_ = v___y_2015_;
v___y_1979_ = v___x_2017_;
v___y_1980_ = v___y_2014_;
v___y_1981_ = v_a_2029_;
v___y_1982_ = v___x_2034_;
goto v___jp_1974_;
}
}
else
{
lean_object* v_a_2035_; lean_object* v___x_2037_; uint8_t v_isShared_2038_; uint8_t v_isSharedCheck_2042_; 
lean_dec_ref(v___y_2015_);
lean_dec_ref(v___y_2014_);
lean_dec_ref(v___y_2012_);
lean_dec(v_workers_1835_);
lean_del_object(v___x_1830_);
lean_del_object(v___x_1826_);
lean_del_object(v___x_1822_);
lean_dec(v_head_1820_);
lean_dec(v_head_1816_);
v_a_2035_ = lean_ctor_get(v___x_2028_, 0);
v_isSharedCheck_2042_ = !lean_is_exclusive(v___x_2028_);
if (v_isSharedCheck_2042_ == 0)
{
v___x_2037_ = v___x_2028_;
v_isShared_2038_ = v_isSharedCheck_2042_;
goto v_resetjp_2036_;
}
else
{
lean_inc(v_a_2035_);
lean_dec(v___x_2028_);
v___x_2037_ = lean_box(0);
v_isShared_2038_ = v_isSharedCheck_2042_;
goto v_resetjp_2036_;
}
v_resetjp_2036_:
{
lean_object* v___x_2040_; 
if (v_isShared_2038_ == 0)
{
v___x_2040_ = v___x_2037_;
goto v_reusejp_2039_;
}
else
{
lean_object* v_reuseFailAlloc_2041_; 
v_reuseFailAlloc_2041_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2041_, 0, v_a_2035_);
v___x_2040_ = v_reuseFailAlloc_2041_;
goto v_reusejp_2039_;
}
v_reusejp_2039_:
{
return v___x_2040_;
}
}
}
}
}
v___jp_2043_:
{
lean_object* v___x_2052_; 
v___x_2052_ = l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__13___redArg(v___x_1875_, v___y_2046_, v___y_2050_, v___y_2044_, v___y_2051_);
lean_dec(v___y_2051_);
lean_dec(v___y_2046_);
v___y_2011_ = v___y_2045_;
v___y_2012_ = v___y_2047_;
v___y_2013_ = v___y_2048_;
v___y_2014_ = v___y_2049_;
v___y_2015_ = v___x_2052_;
goto v___jp_2010_;
}
v___jp_2053_:
{
uint8_t v___x_2062_; 
v___x_2062_ = lean_nat_dec_le(v___y_2061_, v___y_2058_);
if (v___x_2062_ == 0)
{
lean_dec(v___y_2058_);
lean_inc(v___y_2061_);
v___y_2044_ = v___y_2061_;
v___y_2045_ = v___y_2055_;
v___y_2046_ = v___y_2054_;
v___y_2047_ = v___y_2056_;
v___y_2048_ = v___y_2057_;
v___y_2049_ = v___y_2059_;
v___y_2050_ = v___y_2060_;
v___y_2051_ = v___y_2061_;
goto v___jp_2043_;
}
else
{
v___y_2044_ = v___y_2061_;
v___y_2045_ = v___y_2055_;
v___y_2046_ = v___y_2054_;
v___y_2047_ = v___y_2056_;
v___y_2048_ = v___y_2057_;
v___y_2049_ = v___y_2059_;
v___y_2050_ = v___y_2060_;
v___y_2051_ = v___y_2058_;
goto v___jp_2043_;
}
}
v___jp_2063_:
{
if (v___y_2064_ == 0)
{
lean_object* v___x_2065_; lean_object* v___x_2067_; 
lean_dec(v___x_2007_);
lean_del_object(v___x_2004_);
lean_dec(v_workers_1835_);
lean_del_object(v___x_1830_);
lean_del_object(v___x_1826_);
lean_del_object(v___x_1822_);
lean_dec(v_head_1820_);
lean_del_object(v___x_1818_);
lean_dec(v_head_1816_);
v___x_2065_ = ((lean_object*)(l_main___closed__15));
if (v_isShared_2001_ == 0)
{
lean_ctor_set_tag(v___x_2000_, 1);
lean_ctor_set(v___x_2000_, 0, v___x_2065_);
v___x_2067_ = v___x_2000_;
goto v_reusejp_2066_;
}
else
{
lean_object* v_reuseFailAlloc_2068_; 
v_reuseFailAlloc_2068_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2068_, 0, v___x_2065_);
v___x_2067_ = v_reuseFailAlloc_2068_;
goto v_reusejp_2066_;
}
v_reusejp_2066_:
{
return v___x_2067_;
}
}
else
{
lean_object* v___x_2069_; lean_object* v___x_2070_; lean_object* v___x_2071_; lean_object* v___x_2072_; uint32_t v___x_2073_; lean_object* v___x_2074_; uint8_t v___x_2075_; lean_object* v___x_2076_; lean_object* v___x_2077_; 
lean_del_object(v___x_2000_);
lean_inc(v___x_2007_);
v___x_2069_ = lean_alloc_ctor(0, 1, 3);
lean_ctor_set(v___x_2069_, 0, v___x_2007_);
lean_ctor_set_uint8(v___x_2069_, sizeof(void*)*1, v___x_2009_);
lean_ctor_set_uint8(v___x_2069_, sizeof(void*)*1 + 1, v___x_1875_);
lean_ctor_set_uint8(v___x_2069_, sizeof(void*)*1 + 2, v___x_2009_);
v___x_2070_ = lean_mk_empty_array_with_capacity(v___x_1872_);
v___x_2071_ = lean_array_push(v___x_2070_, v___x_2069_);
v___x_2072_ = l_Lean_Options_empty;
v___x_2073_ = 0;
v___x_2074_ = ((lean_object*)(l_main___closed__16));
v___x_2075_ = 2;
v___x_2076_ = lean_box(1);
v___x_2077_ = l_Lean_importModules(v___x_2071_, v___x_2072_, v___x_2073_, v___x_2074_, v___x_2009_, v___x_1875_, v___x_2075_, v___x_2076_);
if (lean_obj_tag(v___x_2077_) == 0)
{
lean_object* v_a_2078_; lean_object* v___x_2080_; uint8_t v_isShared_2081_; uint8_t v_isSharedCheck_2112_; 
v_a_2078_ = lean_ctor_get(v___x_2077_, 0);
v_isSharedCheck_2112_ = !lean_is_exclusive(v___x_2077_);
if (v_isSharedCheck_2112_ == 0)
{
v___x_2080_ = v___x_2077_;
v_isShared_2081_ = v_isSharedCheck_2112_;
goto v_resetjp_2079_;
}
else
{
lean_inc(v_a_2078_);
lean_dec(v___x_2077_);
v___x_2080_ = lean_box(0);
v_isShared_2081_ = v_isSharedCheck_2112_;
goto v_resetjp_2079_;
}
v_resetjp_2079_:
{
lean_object* v___x_2082_; 
v___x_2082_ = l_Lean_Environment_getModuleIdx_x3f(v_a_2078_, v___x_2007_);
lean_dec(v___x_2007_);
if (lean_obj_tag(v___x_2082_) == 1)
{
lean_object* v___x_2083_; lean_object* v___x_2084_; lean_object* v___x_2085_; lean_object* v___x_2087_; 
lean_del_object(v___x_2080_);
v___x_2083_ = ((lean_object*)(l_main___closed__17));
v___x_2084_ = ((lean_object*)(l_main___closed__18));
v___x_2085_ = ((lean_object*)(l_main___closed__19));
if (v_isShared_1819_ == 0)
{
lean_ctor_set(v___x_1818_, 1, v_tail_1815_);
lean_ctor_set(v___x_1818_, 0, v___x_2085_);
v___x_2087_ = v___x_1818_;
goto v_reusejp_2086_;
}
else
{
lean_object* v_reuseFailAlloc_2107_; 
v_reuseFailAlloc_2107_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_2107_, 0, v___x_2085_);
lean_ctor_set(v_reuseFailAlloc_2107_, 1, v_tail_1815_);
v___x_2087_ = v_reuseFailAlloc_2107_;
goto v_reusejp_2086_;
}
v_reusejp_2086_:
{
lean_object* v___x_2088_; lean_object* v___x_2089_; uint8_t v___x_2090_; lean_object* v___x_2091_; lean_object* v___x_2092_; lean_object* v___x_2093_; 
v___x_2088_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_2088_, 0, v___x_2084_);
lean_ctor_set(v___x_2088_, 1, v___x_2087_);
v___x_2089_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_2089_, 0, v___x_2083_);
lean_ctor_set(v___x_2089_, 1, v___x_2088_);
v___x_2090_ = l_List_any___at___00main_spec__0(v_head_1820_, v_head_1816_, v___x_2089_);
lean_dec_ref_known(v___x_2089_, 2);
lean_inc(v_a_2078_);
v___x_2091_ = l_Lean_Environment_constants(v_a_2078_);
v___x_2092_ = l_Lean_SMap_toList___at___00__private_Lean_Elab_DocString_Builtin_0__Lean_Doc_getQualified_spec__1___redArg(v___x_2091_);
lean_dec_ref(v___x_2091_);
v___x_2093_ = l_List_forIn_x27_loop___at___00main_spec__2___redArg(v_a_2078_, v___x_2082_, v___x_2090_, v_head_1816_, v___x_2092_, v___x_2092_, v___x_2074_);
lean_dec(v___x_2092_);
lean_dec_ref_known(v___x_2082_, 1);
if (lean_obj_tag(v___x_2093_) == 0)
{
lean_object* v_a_2094_; lean_object* v___x_2095_; uint8_t v___x_2096_; 
v_a_2094_ = lean_ctor_get(v___x_2093_, 0);
lean_inc(v_a_2094_);
lean_dec_ref_known(v___x_2093_, 1);
v___x_2095_ = lean_array_get_size(v_a_2094_);
v___x_2096_ = lean_nat_dec_eq(v___x_2095_, v___x_1832_);
if (v___x_2096_ == 0)
{
lean_object* v___x_2097_; uint8_t v___x_2098_; 
v___x_2097_ = lean_nat_sub(v___x_2095_, v___x_1872_);
v___x_2098_ = lean_nat_dec_le(v___x_1832_, v___x_2097_);
if (v___x_2098_ == 0)
{
lean_inc(v___x_2097_);
v___y_2054_ = v___x_2095_;
v___y_2055_ = v___x_2085_;
v___y_2056_ = v_a_2078_;
v___y_2057_ = v___x_2073_;
v___y_2058_ = v___x_2097_;
v___y_2059_ = v___x_2074_;
v___y_2060_ = v_a_2094_;
v___y_2061_ = v___x_2097_;
goto v___jp_2053_;
}
else
{
v___y_2054_ = v___x_2095_;
v___y_2055_ = v___x_2085_;
v___y_2056_ = v_a_2078_;
v___y_2057_ = v___x_2073_;
v___y_2058_ = v___x_2097_;
v___y_2059_ = v___x_2074_;
v___y_2060_ = v_a_2094_;
v___y_2061_ = v___x_1832_;
goto v___jp_2053_;
}
}
else
{
v___y_2011_ = v___x_2085_;
v___y_2012_ = v_a_2078_;
v___y_2013_ = v___x_2073_;
v___y_2014_ = v___x_2074_;
v___y_2015_ = v_a_2094_;
goto v___jp_2010_;
}
}
else
{
lean_object* v_a_2099_; lean_object* v___x_2101_; uint8_t v_isShared_2102_; uint8_t v_isSharedCheck_2106_; 
lean_dec(v_a_2078_);
lean_del_object(v___x_2004_);
lean_dec(v_workers_1835_);
lean_del_object(v___x_1830_);
lean_del_object(v___x_1826_);
lean_del_object(v___x_1822_);
lean_dec(v_head_1820_);
lean_dec(v_head_1816_);
v_a_2099_ = lean_ctor_get(v___x_2093_, 0);
v_isSharedCheck_2106_ = !lean_is_exclusive(v___x_2093_);
if (v_isSharedCheck_2106_ == 0)
{
v___x_2101_ = v___x_2093_;
v_isShared_2102_ = v_isSharedCheck_2106_;
goto v_resetjp_2100_;
}
else
{
lean_inc(v_a_2099_);
lean_dec(v___x_2093_);
v___x_2101_ = lean_box(0);
v_isShared_2102_ = v_isSharedCheck_2106_;
goto v_resetjp_2100_;
}
v_resetjp_2100_:
{
lean_object* v___x_2104_; 
if (v_isShared_2102_ == 0)
{
v___x_2104_ = v___x_2101_;
goto v_reusejp_2103_;
}
else
{
lean_object* v_reuseFailAlloc_2105_; 
v_reuseFailAlloc_2105_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2105_, 0, v_a_2099_);
v___x_2104_ = v_reuseFailAlloc_2105_;
goto v_reusejp_2103_;
}
v_reusejp_2103_:
{
return v___x_2104_;
}
}
}
}
}
else
{
lean_object* v___x_2108_; lean_object* v___x_2110_; 
lean_dec(v___x_2082_);
lean_dec(v_a_2078_);
lean_del_object(v___x_2004_);
lean_dec(v_workers_1835_);
lean_del_object(v___x_1830_);
lean_del_object(v___x_1826_);
lean_del_object(v___x_1822_);
lean_dec(v_head_1820_);
lean_del_object(v___x_1818_);
lean_dec(v_head_1816_);
v___x_2108_ = ((lean_object*)(l_main___closed__21));
if (v_isShared_2081_ == 0)
{
lean_ctor_set_tag(v___x_2080_, 1);
lean_ctor_set(v___x_2080_, 0, v___x_2108_);
v___x_2110_ = v___x_2080_;
goto v_reusejp_2109_;
}
else
{
lean_object* v_reuseFailAlloc_2111_; 
v_reuseFailAlloc_2111_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2111_, 0, v___x_2108_);
v___x_2110_ = v_reuseFailAlloc_2111_;
goto v_reusejp_2109_;
}
v_reusejp_2109_:
{
return v___x_2110_;
}
}
}
}
else
{
lean_object* v_a_2113_; lean_object* v___x_2115_; uint8_t v_isShared_2116_; uint8_t v_isSharedCheck_2120_; 
lean_dec(v___x_2007_);
lean_del_object(v___x_2004_);
lean_dec(v_workers_1835_);
lean_del_object(v___x_1830_);
lean_del_object(v___x_1826_);
lean_del_object(v___x_1822_);
lean_dec(v_head_1820_);
lean_del_object(v___x_1818_);
lean_dec(v_head_1816_);
v_a_2113_ = lean_ctor_get(v___x_2077_, 0);
v_isSharedCheck_2120_ = !lean_is_exclusive(v___x_2077_);
if (v_isSharedCheck_2120_ == 0)
{
v___x_2115_ = v___x_2077_;
v_isShared_2116_ = v_isSharedCheck_2120_;
goto v_resetjp_2114_;
}
else
{
lean_inc(v_a_2113_);
lean_dec(v___x_2077_);
v___x_2115_ = lean_box(0);
v_isShared_2116_ = v_isSharedCheck_2120_;
goto v_resetjp_2114_;
}
v_resetjp_2114_:
{
lean_object* v___x_2118_; 
if (v_isShared_2116_ == 0)
{
v___x_2118_ = v___x_2115_;
goto v_reusejp_2117_;
}
else
{
lean_object* v_reuseFailAlloc_2119_; 
v_reuseFailAlloc_2119_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2119_, 0, v_a_2113_);
v___x_2118_ = v_reuseFailAlloc_2119_;
goto v_reusejp_2117_;
}
v_reusejp_2117_:
{
return v___x_2118_;
}
}
}
}
}
}
}
else
{
lean_object* v_a_2196_; lean_object* v___x_2198_; uint8_t v_isShared_2199_; uint8_t v_isSharedCheck_2203_; 
lean_del_object(v___x_2000_);
lean_dec(v_workers_1835_);
lean_del_object(v___x_1830_);
lean_del_object(v___x_1826_);
lean_dec(v_head_1824_);
lean_del_object(v___x_1822_);
lean_dec(v_head_1820_);
lean_del_object(v___x_1818_);
lean_dec(v_head_1816_);
v_a_2196_ = lean_ctor_get(v___x_2002_, 0);
v_isSharedCheck_2203_ = !lean_is_exclusive(v___x_2002_);
if (v_isSharedCheck_2203_ == 0)
{
v___x_2198_ = v___x_2002_;
v_isShared_2199_ = v_isSharedCheck_2203_;
goto v_resetjp_2197_;
}
else
{
lean_inc(v_a_2196_);
lean_dec(v___x_2002_);
v___x_2198_ = lean_box(0);
v_isShared_2199_ = v_isSharedCheck_2203_;
goto v_resetjp_2197_;
}
v_resetjp_2197_:
{
lean_object* v___x_2201_; 
if (v_isShared_2199_ == 0)
{
v___x_2201_ = v___x_2198_;
goto v_reusejp_2200_;
}
else
{
lean_object* v_reuseFailAlloc_2202_; 
v_reuseFailAlloc_2202_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2202_, 0, v_a_2196_);
v___x_2201_ = v_reuseFailAlloc_2202_;
goto v_reusejp_2200_;
}
v_reusejp_2200_:
{
return v___x_2201_;
}
}
}
}
}
else
{
lean_object* v_a_2205_; lean_object* v___x_2207_; uint8_t v_isShared_2208_; uint8_t v_isSharedCheck_2212_; 
lean_dec(v_workers_1835_);
lean_del_object(v___x_1830_);
lean_del_object(v___x_1826_);
lean_dec(v_head_1824_);
lean_del_object(v___x_1822_);
lean_dec(v_head_1820_);
lean_del_object(v___x_1818_);
lean_dec(v_head_1816_);
v_a_2205_ = lean_ctor_get(v___x_1997_, 0);
v_isSharedCheck_2212_ = !lean_is_exclusive(v___x_1997_);
if (v_isSharedCheck_2212_ == 0)
{
v___x_2207_ = v___x_1997_;
v_isShared_2208_ = v_isSharedCheck_2212_;
goto v_resetjp_2206_;
}
else
{
lean_inc(v_a_2205_);
lean_dec(v___x_1997_);
v___x_2207_ = lean_box(0);
v_isShared_2208_ = v_isSharedCheck_2212_;
goto v_resetjp_2206_;
}
v_resetjp_2206_:
{
lean_object* v___x_2210_; 
if (v_isShared_2208_ == 0)
{
v___x_2210_ = v___x_2207_;
goto v_reusejp_2209_;
}
else
{
lean_object* v_reuseFailAlloc_2211_; 
v_reuseFailAlloc_2211_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2211_, 0, v_a_2205_);
v___x_2210_ = v_reuseFailAlloc_2211_;
goto v_reusejp_2209_;
}
v_reusejp_2209_:
{
return v___x_2210_;
}
}
}
}
v___jp_1836_:
{
size_t v_sz_1842_; lean_object* v___x_1843_; 
v_sz_1842_ = lean_array_size(v___y_1841_);
v___x_1843_ = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__7(v_head_1820_, v_workers_1835_, v___y_1837_, v___y_1839_, v___y_1841_, v_sz_1842_, v___y_1840_, v___y_1838_);
lean_dec_ref(v___y_1841_);
lean_dec_ref(v___y_1839_);
if (lean_obj_tag(v___x_1843_) == 0)
{
lean_dec_ref_known(v___x_1843_, 1);
goto v___jp_1809_;
}
else
{
lean_object* v_a_1844_; lean_object* v___x_1846_; uint8_t v_isShared_1847_; uint8_t v_isSharedCheck_1851_; 
v_a_1844_ = lean_ctor_get(v___x_1843_, 0);
v_isSharedCheck_1851_ = !lean_is_exclusive(v___x_1843_);
if (v_isSharedCheck_1851_ == 0)
{
v___x_1846_ = v___x_1843_;
v_isShared_1847_ = v_isSharedCheck_1851_;
goto v_resetjp_1845_;
}
else
{
lean_inc(v_a_1844_);
lean_dec(v___x_1843_);
v___x_1846_ = lean_box(0);
v_isShared_1847_ = v_isSharedCheck_1851_;
goto v_resetjp_1845_;
}
v_resetjp_1845_:
{
lean_object* v___x_1849_; 
if (v_isShared_1847_ == 0)
{
v___x_1849_ = v___x_1846_;
goto v_reusejp_1848_;
}
else
{
lean_object* v_reuseFailAlloc_1850_; 
v_reuseFailAlloc_1850_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1850_, 0, v_a_1844_);
v___x_1849_ = v_reuseFailAlloc_1850_;
goto v_reusejp_1848_;
}
v_reusejp_1848_:
{
return v___x_1849_;
}
}
}
}
v___jp_1852_:
{
lean_object* v___x_1861_; 
v___x_1861_ = l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__8___redArg(v___y_1858_, v___y_1859_, v___y_1857_, v___y_1860_);
lean_dec(v___y_1860_);
lean_dec(v___y_1858_);
v___y_1837_ = v___y_1853_;
v___y_1838_ = v___y_1855_;
v___y_1839_ = v___y_1854_;
v___y_1840_ = v___y_1856_;
v___y_1841_ = v___x_1861_;
goto v___jp_1836_;
}
v___jp_1862_:
{
uint8_t v___x_1871_; 
v___x_1871_ = lean_nat_dec_le(v___y_1870_, v___y_1863_);
if (v___x_1871_ == 0)
{
lean_dec(v___y_1863_);
lean_inc(v___y_1870_);
v___y_1853_ = v___y_1864_;
v___y_1854_ = v___y_1866_;
v___y_1855_ = v___y_1865_;
v___y_1856_ = v___y_1867_;
v___y_1857_ = v___y_1870_;
v___y_1858_ = v___y_1868_;
v___y_1859_ = v___y_1869_;
v___y_1860_ = v___y_1870_;
goto v___jp_1852_;
}
else
{
v___y_1853_ = v___y_1864_;
v___y_1854_ = v___y_1866_;
v___y_1855_ = v___y_1865_;
v___y_1856_ = v___y_1867_;
v___y_1857_ = v___y_1870_;
v___y_1858_ = v___y_1868_;
v___y_1859_ = v___y_1869_;
v___y_1860_ = v___y_1863_;
goto v___jp_1852_;
}
}
v___jp_1876_:
{
lean_object* v___x_1881_; size_t v_sz_1882_; size_t v___x_1883_; lean_object* v___x_1884_; 
v___x_1881_ = lean_box(0);
v_sz_1882_ = lean_array_size(v_targets_1880_);
v___x_1883_ = ((size_t)0ULL);
v___x_1884_ = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__3(v_head_1816_, v_targets_1880_, v_sz_1882_, v___x_1883_, v___x_1881_);
if (lean_obj_tag(v___x_1884_) == 0)
{
lean_object* v___x_1885_; uint8_t v___x_1886_; 
lean_dec_ref_known(v___x_1884_, 1);
v___x_1885_ = ((lean_object*)(l_main___closed__6));
v___x_1886_ = lean_string_dec_eq(v_head_1816_, v___x_1885_);
lean_dec(v_head_1816_);
if (v___x_1886_ == 0)
{
lean_object* v___x_1887_; lean_object* v___x_1888_; lean_object* v___x_1889_; lean_object* v___x_1890_; lean_object* v___x_1891_; 
lean_del_object(v___x_1830_);
lean_del_object(v___x_1826_);
lean_del_object(v___x_1822_);
v___x_1887_ = lean_io_promise_new();
v___x_1888_ = ((lean_object*)(l_main___closed__7));
v___x_1889_ = lean_elab_environment_to_kernel_env(v___y_1878_);
lean_inc_n(v_workers_1835_, 2);
v___x_1890_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_1890_, 0, v___x_1832_);
lean_ctor_set(v___x_1890_, 1, v_workers_1835_);
lean_ctor_set(v___x_1890_, 2, v___x_1872_);
lean_inc_ref(v_targets_1880_);
v___x_1891_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__5___redArg(v_workers_1835_, v_targets_1880_, v___x_1889_, v___x_1887_, v___x_1890_, v___x_1888_, v___x_1832_);
lean_dec_ref_known(v___x_1890_, 3);
if (lean_obj_tag(v___x_1891_) == 0)
{
lean_object* v_a_1892_; lean_object* v___x_1893_; size_t v_sz_1894_; lean_object* v___x_1895_; 
v_a_1892_ = lean_ctor_get(v___x_1891_, 0);
lean_inc(v_a_1892_);
lean_dec_ref_known(v___x_1891_, 1);
v___x_1893_ = lean_io_promise_resolve(v___x_1881_, v___x_1887_);
lean_dec(v___x_1887_);
v_sz_1894_ = lean_array_size(v_a_1892_);
v___x_1895_ = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__6(v_a_1892_, v_sz_1894_, v___x_1883_, v___x_1888_);
lean_dec(v_a_1892_);
if (lean_obj_tag(v___x_1895_) == 0)
{
lean_object* v_a_1896_; lean_object* v___x_1897_; uint8_t v___x_1898_; 
v_a_1896_ = lean_ctor_get(v___x_1895_, 0);
lean_inc(v_a_1896_);
lean_dec_ref_known(v___x_1895_, 1);
v___x_1897_ = lean_array_get_size(v_a_1896_);
v___x_1898_ = lean_nat_dec_eq(v___x_1897_, v___x_1832_);
if (v___x_1898_ == 0)
{
lean_object* v___x_1899_; uint8_t v___x_1900_; 
v___x_1899_ = lean_nat_sub(v___x_1897_, v___x_1872_);
v___x_1900_ = lean_nat_dec_le(v___x_1832_, v___x_1899_);
if (v___x_1900_ == 0)
{
lean_inc(v___x_1899_);
v___y_1863_ = v___x_1899_;
v___y_1864_ = v___y_1877_;
v___y_1865_ = v___x_1881_;
v___y_1866_ = v_targets_1880_;
v___y_1867_ = v___x_1883_;
v___y_1868_ = v___x_1897_;
v___y_1869_ = v_a_1896_;
v___y_1870_ = v___x_1899_;
goto v___jp_1862_;
}
else
{
v___y_1863_ = v___x_1899_;
v___y_1864_ = v___y_1877_;
v___y_1865_ = v___x_1881_;
v___y_1866_ = v_targets_1880_;
v___y_1867_ = v___x_1883_;
v___y_1868_ = v___x_1897_;
v___y_1869_ = v_a_1896_;
v___y_1870_ = v___x_1832_;
goto v___jp_1862_;
}
}
else
{
v___y_1837_ = v___y_1877_;
v___y_1838_ = v___x_1881_;
v___y_1839_ = v_targets_1880_;
v___y_1840_ = v___x_1883_;
v___y_1841_ = v_a_1896_;
goto v___jp_1836_;
}
}
else
{
lean_object* v_a_1901_; lean_object* v___x_1903_; uint8_t v_isShared_1904_; uint8_t v_isSharedCheck_1908_; 
lean_dec_ref(v_targets_1880_);
lean_dec(v___y_1877_);
lean_dec(v_workers_1835_);
lean_dec(v_head_1820_);
v_a_1901_ = lean_ctor_get(v___x_1895_, 0);
v_isSharedCheck_1908_ = !lean_is_exclusive(v___x_1895_);
if (v_isSharedCheck_1908_ == 0)
{
v___x_1903_ = v___x_1895_;
v_isShared_1904_ = v_isSharedCheck_1908_;
goto v_resetjp_1902_;
}
else
{
lean_inc(v_a_1901_);
lean_dec(v___x_1895_);
v___x_1903_ = lean_box(0);
v_isShared_1904_ = v_isSharedCheck_1908_;
goto v_resetjp_1902_;
}
v_resetjp_1902_:
{
lean_object* v___x_1906_; 
if (v_isShared_1904_ == 0)
{
v___x_1906_ = v___x_1903_;
goto v_reusejp_1905_;
}
else
{
lean_object* v_reuseFailAlloc_1907_; 
v_reuseFailAlloc_1907_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1907_, 0, v_a_1901_);
v___x_1906_ = v_reuseFailAlloc_1907_;
goto v_reusejp_1905_;
}
v_reusejp_1905_:
{
return v___x_1906_;
}
}
}
}
else
{
lean_object* v_a_1909_; lean_object* v___x_1911_; uint8_t v_isShared_1912_; uint8_t v_isSharedCheck_1916_; 
lean_dec(v___x_1887_);
lean_dec_ref(v_targets_1880_);
lean_dec(v___y_1877_);
lean_dec(v_workers_1835_);
lean_dec(v_head_1820_);
v_a_1909_ = lean_ctor_get(v___x_1891_, 0);
v_isSharedCheck_1916_ = !lean_is_exclusive(v___x_1891_);
if (v_isSharedCheck_1916_ == 0)
{
v___x_1911_ = v___x_1891_;
v_isShared_1912_ = v_isSharedCheck_1916_;
goto v_resetjp_1910_;
}
else
{
lean_inc(v_a_1909_);
lean_dec(v___x_1891_);
v___x_1911_ = lean_box(0);
v_isShared_1912_ = v_isSharedCheck_1916_;
goto v_resetjp_1910_;
}
v_resetjp_1910_:
{
lean_object* v___x_1914_; 
if (v_isShared_1912_ == 0)
{
v___x_1914_ = v___x_1911_;
goto v_reusejp_1913_;
}
else
{
lean_object* v_reuseFailAlloc_1915_; 
v_reuseFailAlloc_1915_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1915_, 0, v_a_1909_);
v___x_1914_ = v_reuseFailAlloc_1915_;
goto v_reusejp_1913_;
}
v_reusejp_1913_:
{
return v___x_1914_;
}
}
}
}
else
{
lean_object* v___x_1917_; lean_object* v___x_1918_; lean_object* v___x_1919_; lean_object* v___x_1920_; lean_object* v___x_1921_; lean_object* v___x_1922_; lean_object* v___x_1923_; lean_object* v___x_1924_; lean_object* v___x_1925_; lean_object* v___x_1926_; lean_object* v___x_1927_; lean_object* v___x_1928_; lean_object* v___x_1930_; 
lean_dec_ref(v___y_1878_);
lean_dec(v_workers_1835_);
v___x_1917_ = ((lean_object*)(l_main___closed__8));
v___x_1918_ = ((lean_object*)(l_elaborateOne___closed__19));
v___x_1919_ = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(v___x_1919_, 0, v_head_1820_);
v___x_1920_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1920_, 0, v___x_1918_);
lean_ctor_set(v___x_1920_, 1, v___x_1919_);
v___x_1921_ = ((lean_object*)(l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__7___closed__1));
v___x_1922_ = l_Lean_JsonNumber_fromNat(v___y_1877_);
v___x_1923_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_1923_, 0, v___x_1922_);
v___x_1924_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1924_, 0, v___x_1921_);
lean_ctor_set(v___x_1924_, 1, v___x_1923_);
v___x_1925_ = ((lean_object*)(l_main___closed__9));
v___x_1926_ = l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00main_spec__9(v___x_1875_, v_sz_1882_, v___x_1883_, v_targets_1880_);
v___x_1927_ = l_Lean_Array_toJson___at___00Lean_Server_Test_Runner_Client_instToJsonHyp_toJson_spec__1(v___x_1926_);
v___x_1928_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1928_, 0, v___x_1925_);
lean_ctor_set(v___x_1928_, 1, v___x_1927_);
if (v_isShared_1831_ == 0)
{
lean_ctor_set(v___x_1830_, 1, v___x_1873_);
lean_ctor_set(v___x_1830_, 0, v___x_1928_);
v___x_1930_ = v___x_1830_;
goto v_reusejp_1929_;
}
else
{
lean_object* v_reuseFailAlloc_1958_; 
v_reuseFailAlloc_1958_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1958_, 0, v___x_1928_);
lean_ctor_set(v_reuseFailAlloc_1958_, 1, v___x_1873_);
v___x_1930_ = v_reuseFailAlloc_1958_;
goto v_reusejp_1929_;
}
v_reusejp_1929_:
{
lean_object* v___x_1932_; 
if (v_isShared_1827_ == 0)
{
lean_ctor_set(v___x_1826_, 1, v___x_1930_);
lean_ctor_set(v___x_1826_, 0, v___x_1924_);
v___x_1932_ = v___x_1826_;
goto v_reusejp_1931_;
}
else
{
lean_object* v_reuseFailAlloc_1957_; 
v_reuseFailAlloc_1957_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1957_, 0, v___x_1924_);
lean_ctor_set(v_reuseFailAlloc_1957_, 1, v___x_1930_);
v___x_1932_ = v_reuseFailAlloc_1957_;
goto v_reusejp_1931_;
}
v_reusejp_1931_:
{
lean_object* v___x_1934_; 
if (v_isShared_1823_ == 0)
{
lean_ctor_set(v___x_1822_, 1, v___x_1932_);
lean_ctor_set(v___x_1822_, 0, v___x_1920_);
v___x_1934_ = v___x_1822_;
goto v_reusejp_1933_;
}
else
{
lean_object* v_reuseFailAlloc_1956_; 
v_reuseFailAlloc_1956_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1956_, 0, v___x_1920_);
lean_ctor_set(v_reuseFailAlloc_1956_, 1, v___x_1932_);
v___x_1934_ = v_reuseFailAlloc_1956_;
goto v_reusejp_1933_;
}
v_reusejp_1933_:
{
lean_object* v___x_1935_; lean_object* v___x_1936_; lean_object* v___x_1937_; lean_object* v___x_1938_; 
v___x_1935_ = l_Lean_Json_mkObj(v___x_1934_);
lean_dec_ref(v___x_1934_);
v___x_1936_ = l_Lean_Json_compress(v___x_1935_);
v___x_1937_ = lean_string_append(v___x_1917_, v___x_1936_);
lean_dec_ref(v___x_1936_);
v___x_1938_ = l_IO_println___at___00__private_Lean_Shell_0__Lean_ShellOptions_process_spec__3(v___x_1937_);
if (lean_obj_tag(v___x_1938_) == 0)
{
lean_object* v___x_1940_; uint8_t v_isShared_1941_; uint8_t v_isSharedCheck_1946_; 
v_isSharedCheck_1946_ = !lean_is_exclusive(v___x_1938_);
if (v_isSharedCheck_1946_ == 0)
{
lean_object* v_unused_1947_; 
v_unused_1947_ = lean_ctor_get(v___x_1938_, 0);
lean_dec(v_unused_1947_);
v___x_1940_ = v___x_1938_;
v_isShared_1941_ = v_isSharedCheck_1946_;
goto v_resetjp_1939_;
}
else
{
lean_dec(v___x_1938_);
v___x_1940_ = lean_box(0);
v_isShared_1941_ = v_isSharedCheck_1946_;
goto v_resetjp_1939_;
}
v_resetjp_1939_:
{
lean_object* v___x_1942_; lean_object* v___x_1944_; 
v___x_1942_ = lean_box_uint32(v___y_1879_);
if (v_isShared_1941_ == 0)
{
lean_ctor_set(v___x_1940_, 0, v___x_1942_);
v___x_1944_ = v___x_1940_;
goto v_reusejp_1943_;
}
else
{
lean_object* v_reuseFailAlloc_1945_; 
v_reuseFailAlloc_1945_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1945_, 0, v___x_1942_);
v___x_1944_ = v_reuseFailAlloc_1945_;
goto v_reusejp_1943_;
}
v_reusejp_1943_:
{
return v___x_1944_;
}
}
}
else
{
lean_object* v_a_1948_; lean_object* v___x_1950_; uint8_t v_isShared_1951_; uint8_t v_isSharedCheck_1955_; 
v_a_1948_ = lean_ctor_get(v___x_1938_, 0);
v_isSharedCheck_1955_ = !lean_is_exclusive(v___x_1938_);
if (v_isSharedCheck_1955_ == 0)
{
v___x_1950_ = v___x_1938_;
v_isShared_1951_ = v_isSharedCheck_1955_;
goto v_resetjp_1949_;
}
else
{
lean_inc(v_a_1948_);
lean_dec(v___x_1938_);
v___x_1950_ = lean_box(0);
v_isShared_1951_ = v_isSharedCheck_1955_;
goto v_resetjp_1949_;
}
v_resetjp_1949_:
{
lean_object* v___x_1953_; 
if (v_isShared_1951_ == 0)
{
v___x_1953_ = v___x_1950_;
goto v_reusejp_1952_;
}
else
{
lean_object* v_reuseFailAlloc_1954_; 
v_reuseFailAlloc_1954_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1954_, 0, v_a_1948_);
v___x_1953_ = v_reuseFailAlloc_1954_;
goto v_reusejp_1952_;
}
v_reusejp_1952_:
{
return v___x_1953_;
}
}
}
}
}
}
}
}
else
{
lean_object* v_a_1959_; lean_object* v___x_1961_; uint8_t v_isShared_1962_; uint8_t v_isSharedCheck_1966_; 
lean_dec_ref(v_targets_1880_);
lean_dec_ref(v___y_1878_);
lean_dec(v___y_1877_);
lean_dec(v_workers_1835_);
lean_del_object(v___x_1830_);
lean_del_object(v___x_1826_);
lean_del_object(v___x_1822_);
lean_dec(v_head_1820_);
lean_dec(v_head_1816_);
v_a_1959_ = lean_ctor_get(v___x_1884_, 0);
v_isSharedCheck_1966_ = !lean_is_exclusive(v___x_1884_);
if (v_isSharedCheck_1966_ == 0)
{
v___x_1961_ = v___x_1884_;
v_isShared_1962_ = v_isSharedCheck_1966_;
goto v_resetjp_1960_;
}
else
{
lean_inc(v_a_1959_);
lean_dec(v___x_1884_);
v___x_1961_ = lean_box(0);
v_isShared_1962_ = v_isSharedCheck_1966_;
goto v_resetjp_1960_;
}
v_resetjp_1960_:
{
lean_object* v___x_1964_; 
if (v_isShared_1962_ == 0)
{
v___x_1964_ = v___x_1961_;
goto v_reusejp_1963_;
}
else
{
lean_object* v_reuseFailAlloc_1965_; 
v_reuseFailAlloc_1965_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1965_, 0, v_a_1959_);
v___x_1964_ = v_reuseFailAlloc_1965_;
goto v_reusejp_1963_;
}
v_reusejp_1963_:
{
return v___x_1964_;
}
}
}
}
v___jp_1967_:
{
lean_object* v___x_1973_; 
v___x_1973_ = l_Array_append___redArg(v___y_1971_, v___y_1972_);
lean_dec_ref(v___y_1972_);
v___y_1877_ = v___y_1968_;
v___y_1878_ = v___y_1969_;
v___y_1879_ = v___y_1970_;
v_targets_1880_ = v___x_1973_;
goto v___jp_1876_;
}
v___jp_1974_:
{
if (v___y_1982_ == 0)
{
lean_dec_ref(v___y_1980_);
lean_dec_ref(v___y_1978_);
v___y_1877_ = v___y_1975_;
v___y_1878_ = v___y_1976_;
v___y_1879_ = v___y_1977_;
v_targets_1880_ = v___y_1981_;
goto v___jp_1876_;
}
else
{
lean_object* v___x_1983_; size_t v_sz_1984_; size_t v___x_1985_; lean_object* v___x_1986_; lean_object* v_fst_1987_; 
v___x_1983_ = ((lean_object*)(l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__11___closed__1));
v_sz_1984_ = lean_array_size(v___y_1978_);
v___x_1985_ = ((size_t)0ULL);
v___x_1986_ = l___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00main_spec__11(v___x_1875_, v___y_1978_, v_sz_1984_, v___x_1985_, v___x_1983_);
v_fst_1987_ = lean_ctor_get(v___x_1986_, 0);
lean_inc(v_fst_1987_);
lean_dec_ref(v___x_1986_);
if (lean_obj_tag(v_fst_1987_) == 0)
{
lean_dec_ref(v___y_1980_);
lean_dec_ref(v___y_1978_);
v___y_1877_ = v___y_1975_;
v___y_1878_ = v___y_1976_;
v___y_1879_ = v___y_1977_;
v_targets_1880_ = v___y_1981_;
goto v___jp_1876_;
}
else
{
lean_object* v_val_1988_; 
v_val_1988_ = lean_ctor_get(v_fst_1987_, 0);
lean_inc(v_val_1988_);
lean_dec_ref_known(v_fst_1987_, 1);
if (lean_obj_tag(v_val_1988_) == 1)
{
lean_object* v_val_1989_; lean_object* v___x_1990_; lean_object* v___x_1991_; 
lean_dec_ref(v___y_1981_);
v_val_1989_ = lean_ctor_get(v_val_1988_, 0);
lean_inc_n(v_val_1989_, 2);
lean_dec_ref_known(v_val_1988_, 1);
v___x_1990_ = lean_mk_empty_array_with_capacity(v___x_1872_);
v___x_1991_ = lean_array_push(v___x_1990_, v_val_1989_);
if (v___y_1979_ == 0)
{
lean_dec(v_val_1989_);
lean_dec_ref(v___y_1978_);
v___y_1968_ = v___y_1975_;
v___y_1969_ = v___y_1976_;
v___y_1970_ = v___y_1977_;
v___y_1971_ = v___x_1991_;
v___y_1972_ = v___y_1980_;
goto v___jp_1967_;
}
else
{
size_t v___x_1992_; lean_object* v___x_1993_; 
v___x_1992_ = lean_usize_of_nat(v___y_1975_);
v___x_1993_ = l___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00main_spec__12(v_val_1989_, v___y_1978_, v___x_1985_, v___x_1992_, v___y_1980_);
lean_dec_ref(v___y_1978_);
lean_dec(v_val_1989_);
v___y_1968_ = v___y_1975_;
v___y_1969_ = v___y_1976_;
v___y_1970_ = v___y_1977_;
v___y_1971_ = v___x_1991_;
v___y_1972_ = v___x_1993_;
goto v___jp_1967_;
}
}
else
{
lean_dec(v_val_1988_);
lean_dec_ref(v___y_1980_);
lean_dec_ref(v___y_1978_);
v___y_1877_ = v___y_1975_;
v___y_1878_ = v___y_1976_;
v___y_1879_ = v___y_1977_;
v_targets_1880_ = v___y_1981_;
goto v___jp_1876_;
}
}
}
}
}
}
}
}
}
else
{
lean_dec_ref_known(v_tail_1814_, 2);
lean_dec(v_tail_1815_);
lean_dec_ref_known(v_tail_1813_, 2);
lean_dec_ref_known(v_tail_1812_, 2);
lean_dec_ref_known(v_args_1804_, 2);
goto v___jp_1806_;
}
}
else
{
lean_dec_ref_known(v_tail_1813_, 2);
lean_dec(v_tail_1814_);
lean_dec_ref_known(v_tail_1812_, 2);
lean_dec_ref_known(v_args_1804_, 2);
goto v___jp_1806_;
}
}
else
{
lean_dec_ref_known(v_tail_1812_, 2);
lean_dec(v_tail_1813_);
lean_dec_ref_known(v_args_1804_, 2);
goto v___jp_1806_;
}
}
else
{
lean_dec_ref_known(v_args_1804_, 2);
lean_dec(v_tail_1812_);
goto v___jp_1806_;
}
}
else
{
lean_dec(v_args_1804_);
goto v___jp_1806_;
}
v___jp_1806_:
{
lean_object* v___x_1807_; lean_object* v___x_1808_; 
v___x_1807_ = ((lean_object*)(l_main___closed__1));
v___x_1808_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_1808_, 0, v___x_1807_);
return v___x_1808_;
}
v___jp_1809_:
{
lean_object* v___x_1810_; lean_object* v___x_1811_; 
v___x_1810_ = l_main___boxed__const__1;
v___x_1811_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_1811_, 0, v___x_1810_);
return v___x_1811_;
}
}
}
LEAN_EXPORT lean_object* l_main___boxed(lean_object* v_args_2221_, lean_object* v_a_2222_){
_start:
{
lean_object* v_res_2223_; 
v_res_2223_ = _lean_main(v_args_2221_);
return v_res_2223_;
}
}
LEAN_EXPORT lean_object* l_List_forIn_x27_loop___at___00main_spec__2(lean_object* v_a_2224_, lean_object* v___x_2225_, uint8_t v___x_2226_, lean_object* v_head_2227_, lean_object* v_as_2228_, lean_object* v_as_x27_2229_, lean_object* v_b_2230_, lean_object* v_a_2231_){
_start:
{
lean_object* v___x_2233_; 
v___x_2233_ = l_List_forIn_x27_loop___at___00main_spec__2___redArg(v_a_2224_, v___x_2225_, v___x_2226_, v_head_2227_, v_as_2228_, v_as_x27_2229_, v_b_2230_);
return v___x_2233_;
}
}
LEAN_EXPORT lean_object* l_List_forIn_x27_loop___at___00main_spec__2___boxed(lean_object* v_a_2234_, lean_object* v___x_2235_, lean_object* v___x_2236_, lean_object* v_head_2237_, lean_object* v_as_2238_, lean_object* v_as_x27_2239_, lean_object* v_b_2240_, lean_object* v_a_2241_, lean_object* v___y_2242_){
_start:
{
uint8_t v___x_21240__boxed_2243_; lean_object* v_res_2244_; 
v___x_21240__boxed_2243_ = lean_unbox(v___x_2236_);
v_res_2244_ = l_List_forIn_x27_loop___at___00main_spec__2(v_a_2234_, v___x_2235_, v___x_21240__boxed_2243_, v_head_2237_, v_as_2238_, v_as_x27_2239_, v_b_2240_, v_a_2241_);
lean_dec(v_as_x27_2239_);
lean_dec(v_as_2238_);
lean_dec_ref(v_head_2237_);
lean_dec(v___x_2235_);
lean_dec_ref(v_a_2234_);
return v_res_2244_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__4(lean_object* v_workers_2245_, lean_object* v_a_2246_, lean_object* v_targets_2247_, lean_object* v___x_2248_, lean_object* v_range_2249_, lean_object* v_b_2250_, lean_object* v_i_2251_, lean_object* v_hs_2252_, lean_object* v_hl_2253_){
_start:
{
lean_object* v___x_2255_; 
v___x_2255_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__4___redArg(v_workers_2245_, v_a_2246_, v_targets_2247_, v___x_2248_, v_range_2249_, v_b_2250_, v_i_2251_);
return v___x_2255_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__4___boxed(lean_object* v_workers_2256_, lean_object* v_a_2257_, lean_object* v_targets_2258_, lean_object* v___x_2259_, lean_object* v_range_2260_, lean_object* v_b_2261_, lean_object* v_i_2262_, lean_object* v_hs_2263_, lean_object* v_hl_2264_, lean_object* v___y_2265_){
_start:
{
lean_object* v_res_2266_; 
v_res_2266_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__4(v_workers_2256_, v_a_2257_, v_targets_2258_, v___x_2259_, v_range_2260_, v_b_2261_, v_i_2262_, v_hs_2263_, v_hl_2264_);
lean_dec_ref(v_range_2260_);
lean_dec_ref(v_targets_2258_);
lean_dec(v_a_2257_);
lean_dec(v_workers_2256_);
return v_res_2266_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__5(lean_object* v_workers_2267_, lean_object* v_targets_2268_, lean_object* v___x_2269_, lean_object* v_val_2270_, lean_object* v_range_2271_, lean_object* v_b_2272_, lean_object* v_i_2273_, lean_object* v_hs_2274_, lean_object* v_hl_2275_){
_start:
{
lean_object* v___x_2277_; 
v___x_2277_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__5___redArg(v_workers_2267_, v_targets_2268_, v___x_2269_, v_val_2270_, v_range_2271_, v_b_2272_, v_i_2273_);
return v___x_2277_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__5___boxed(lean_object* v_workers_2278_, lean_object* v_targets_2279_, lean_object* v___x_2280_, lean_object* v_val_2281_, lean_object* v_range_2282_, lean_object* v_b_2283_, lean_object* v_i_2284_, lean_object* v_hs_2285_, lean_object* v_hl_2286_, lean_object* v___y_2287_){
_start:
{
lean_object* v_res_2288_; 
v_res_2288_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__5(v_workers_2278_, v_targets_2279_, v___x_2280_, v_val_2281_, v_range_2282_, v_b_2283_, v_i_2284_, v_hs_2285_, v_hl_2286_);
lean_dec_ref(v_range_2282_);
lean_dec(v_val_2281_);
return v_res_2288_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__8(lean_object* v_n_2289_, lean_object* v_as_2290_, lean_object* v_lo_2291_, lean_object* v_hi_2292_, lean_object* v_w_2293_, lean_object* v_hlo_2294_, lean_object* v_hhi_2295_){
_start:
{
lean_object* v___x_2296_; 
v___x_2296_ = l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__8___redArg(v_n_2289_, v_as_2290_, v_lo_2291_, v_hi_2292_);
return v___x_2296_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__8___boxed(lean_object* v_n_2297_, lean_object* v_as_2298_, lean_object* v_lo_2299_, lean_object* v_hi_2300_, lean_object* v_w_2301_, lean_object* v_hlo_2302_, lean_object* v_hhi_2303_){
_start:
{
lean_object* v_res_2304_; 
v_res_2304_ = l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__8(v_n_2297_, v_as_2298_, v_lo_2299_, v_hi_2300_, v_w_2301_, v_hlo_2302_, v_hhi_2303_);
lean_dec(v_hi_2300_);
lean_dec(v_n_2297_);
return v_res_2304_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__10(lean_object* v___x_2305_, lean_object* v___y_2306_, lean_object* v_range_2307_, lean_object* v_b_2308_, lean_object* v_i_2309_, lean_object* v_hs_2310_, lean_object* v_hl_2311_){
_start:
{
lean_object* v___x_2313_; 
v___x_2313_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__10___redArg(v___x_2305_, v___y_2306_, v_range_2307_, v_b_2308_, v_i_2309_);
return v___x_2313_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__10___boxed(lean_object* v___x_2314_, lean_object* v___y_2315_, lean_object* v_range_2316_, lean_object* v_b_2317_, lean_object* v_i_2318_, lean_object* v_hs_2319_, lean_object* v_hl_2320_, lean_object* v___y_2321_){
_start:
{
lean_object* v_res_2322_; 
v_res_2322_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__10(v___x_2314_, v___y_2315_, v_range_2316_, v_b_2317_, v_i_2318_, v_hs_2319_, v_hl_2320_);
lean_dec_ref(v_range_2316_);
lean_dec_ref(v___y_2315_);
lean_dec(v___x_2314_);
return v_res_2322_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__13(uint8_t v___x_2323_, lean_object* v_n_2324_, lean_object* v_as_2325_, lean_object* v_lo_2326_, lean_object* v_hi_2327_, lean_object* v_w_2328_, lean_object* v_hlo_2329_, lean_object* v_hhi_2330_){
_start:
{
lean_object* v___x_2331_; 
v___x_2331_ = l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__13___redArg(v___x_2323_, v_n_2324_, v_as_2325_, v_lo_2326_, v_hi_2327_);
return v___x_2331_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__13___boxed(lean_object* v___x_2332_, lean_object* v_n_2333_, lean_object* v_as_2334_, lean_object* v_lo_2335_, lean_object* v_hi_2336_, lean_object* v_w_2337_, lean_object* v_hlo_2338_, lean_object* v_hhi_2339_){
_start:
{
uint8_t v___x_21290__boxed_2340_; lean_object* v_res_2341_; 
v___x_21290__boxed_2340_ = lean_unbox(v___x_2332_);
v_res_2341_ = l___private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__13(v___x_21290__boxed_2340_, v_n_2333_, v_as_2334_, v_lo_2335_, v_hi_2336_, v_w_2337_, v_hlo_2338_, v_hhi_2339_);
lean_dec(v_hi_2336_);
lean_dec(v_n_2333_);
return v_res_2341_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__14(lean_object* v_workers_2342_, lean_object* v_a_2343_, lean_object* v___x_2344_, lean_object* v___x_2345_, lean_object* v_fst_2346_, lean_object* v_snd_2347_, lean_object* v_head_2348_, lean_object* v_head_2349_, lean_object* v_range_2350_, lean_object* v_b_2351_, lean_object* v_i_2352_, lean_object* v_hs_2353_, lean_object* v_hl_2354_){
_start:
{
lean_object* v___x_2356_; 
v___x_2356_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__14___redArg(v_workers_2342_, v_a_2343_, v___x_2344_, v___x_2345_, v_fst_2346_, v_snd_2347_, v_head_2348_, v_head_2349_, v_range_2350_, v_b_2351_, v_i_2352_);
return v___x_2356_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__14___boxed(lean_object* v_workers_2357_, lean_object* v_a_2358_, lean_object* v___x_2359_, lean_object* v___x_2360_, lean_object* v_fst_2361_, lean_object* v_snd_2362_, lean_object* v_head_2363_, lean_object* v_head_2364_, lean_object* v_range_2365_, lean_object* v_b_2366_, lean_object* v_i_2367_, lean_object* v_hs_2368_, lean_object* v_hl_2369_, lean_object* v___y_2370_){
_start:
{
lean_object* v_res_2371_; 
v_res_2371_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__14(v_workers_2357_, v_a_2358_, v___x_2359_, v___x_2360_, v_fst_2361_, v_snd_2362_, v_head_2363_, v_head_2364_, v_range_2365_, v_b_2366_, v_i_2367_, v_hs_2368_, v_hl_2369_);
lean_dec_ref(v_range_2365_);
lean_dec_ref(v_snd_2362_);
lean_dec_ref(v___x_2360_);
lean_dec(v_a_2358_);
return v_res_2371_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__15(lean_object* v_workers_2372_, lean_object* v___x_2373_, lean_object* v___x_2374_, lean_object* v_fst_2375_, lean_object* v_snd_2376_, lean_object* v_head_2377_, lean_object* v_head_2378_, lean_object* v_val_2379_, lean_object* v_range_2380_, lean_object* v_b_2381_, lean_object* v_i_2382_, lean_object* v_hs_2383_, lean_object* v_hl_2384_){
_start:
{
lean_object* v___x_2386_; 
v___x_2386_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__15___redArg(v_workers_2372_, v___x_2373_, v___x_2374_, v_fst_2375_, v_snd_2376_, v_head_2377_, v_head_2378_, v_val_2379_, v_range_2380_, v_b_2381_, v_i_2382_);
return v___x_2386_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__15___boxed(lean_object* v_workers_2387_, lean_object* v___x_2388_, lean_object* v___x_2389_, lean_object* v_fst_2390_, lean_object* v_snd_2391_, lean_object* v_head_2392_, lean_object* v_head_2393_, lean_object* v_val_2394_, lean_object* v_range_2395_, lean_object* v_b_2396_, lean_object* v_i_2397_, lean_object* v_hs_2398_, lean_object* v_hl_2399_, lean_object* v___y_2400_){
_start:
{
lean_object* v_res_2401_; 
v_res_2401_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__15(v_workers_2387_, v___x_2388_, v___x_2389_, v_fst_2390_, v_snd_2391_, v_head_2392_, v_head_2393_, v_val_2394_, v_range_2395_, v_b_2396_, v_i_2397_, v_hs_2398_, v_hl_2399_);
lean_dec_ref(v_range_2395_);
lean_dec(v_val_2394_);
return v_res_2401_;
}
}
LEAN_EXPORT lean_object* l_List_forIn_x27_loop___at___00List_forIn_x27_loop___at___00main_spec__2_spec__2(lean_object* v_a_2402_, lean_object* v___x_2403_, uint8_t v___x_2404_, lean_object* v_head_2405_, lean_object* v_as_2406_, lean_object* v_as_x27_2407_, lean_object* v_b_2408_, lean_object* v_a_2409_){
_start:
{
lean_object* v___x_2411_; 
v___x_2411_ = l_List_forIn_x27_loop___at___00List_forIn_x27_loop___at___00main_spec__2_spec__2___redArg(v_a_2402_, v___x_2403_, v___x_2404_, v_head_2405_, v_as_x27_2407_, v_b_2408_);
return v___x_2411_;
}
}
LEAN_EXPORT lean_object* l_List_forIn_x27_loop___at___00List_forIn_x27_loop___at___00main_spec__2_spec__2___boxed(lean_object* v_a_2412_, lean_object* v___x_2413_, lean_object* v___x_2414_, lean_object* v_head_2415_, lean_object* v_as_2416_, lean_object* v_as_x27_2417_, lean_object* v_b_2418_, lean_object* v_a_2419_, lean_object* v___y_2420_){
_start:
{
uint8_t v___x_21346__boxed_2421_; lean_object* v_res_2422_; 
v___x_21346__boxed_2421_ = lean_unbox(v___x_2414_);
v_res_2422_ = l_List_forIn_x27_loop___at___00List_forIn_x27_loop___at___00main_spec__2_spec__2(v_a_2412_, v___x_2413_, v___x_21346__boxed_2421_, v_head_2415_, v_as_2416_, v_as_x27_2417_, v_b_2418_, v_a_2419_);
lean_dec(v_as_x27_2417_);
lean_dec(v_as_2416_);
lean_dec_ref(v_head_2415_);
lean_dec(v___x_2413_);
lean_dec_ref(v_a_2412_);
return v_res_2422_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__5_spec__6(lean_object* v_val_2423_, lean_object* v_targets_2424_, lean_object* v_workers_2425_, lean_object* v___x_2426_, lean_object* v_range_2427_, lean_object* v_b_2428_, lean_object* v_i_2429_, lean_object* v_hs_2430_, lean_object* v_hl_2431_){
_start:
{
lean_object* v___x_2433_; 
v___x_2433_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__5_spec__6___redArg(v_val_2423_, v_targets_2424_, v_workers_2425_, v___x_2426_, v_range_2427_, v_b_2428_, v_i_2429_);
return v___x_2433_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__5_spec__6___boxed(lean_object* v_val_2434_, lean_object* v_targets_2435_, lean_object* v_workers_2436_, lean_object* v___x_2437_, lean_object* v_range_2438_, lean_object* v_b_2439_, lean_object* v_i_2440_, lean_object* v_hs_2441_, lean_object* v_hl_2442_, lean_object* v___y_2443_){
_start:
{
lean_object* v_res_2444_; 
v_res_2444_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__5_spec__6(v_val_2434_, v_targets_2435_, v_workers_2436_, v___x_2437_, v_range_2438_, v_b_2439_, v_i_2440_, v_hs_2441_, v_hl_2442_);
lean_dec_ref(v_range_2438_);
lean_dec(v_val_2434_);
return v_res_2444_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_QSort_Basic_0__Array_qpartition_loop___at___00__private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__8_spec__10(lean_object* v_n_2445_, lean_object* v_lo_2446_, lean_object* v_hi_2447_, lean_object* v_hhi_2448_, lean_object* v_pivot_2449_, lean_object* v_as_2450_, lean_object* v_i_2451_, lean_object* v_k_2452_, lean_object* v_ilo_2453_, lean_object* v_ik_2454_, lean_object* v_w_2455_){
_start:
{
lean_object* v___x_2456_; 
v___x_2456_ = l___private_Init_Data_Array_QSort_Basic_0__Array_qpartition_loop___at___00__private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__8_spec__10___redArg(v_hi_2447_, v_pivot_2449_, v_as_2450_, v_i_2451_, v_k_2452_);
return v___x_2456_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_QSort_Basic_0__Array_qpartition_loop___at___00__private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__8_spec__10___boxed(lean_object* v_n_2457_, lean_object* v_lo_2458_, lean_object* v_hi_2459_, lean_object* v_hhi_2460_, lean_object* v_pivot_2461_, lean_object* v_as_2462_, lean_object* v_i_2463_, lean_object* v_k_2464_, lean_object* v_ilo_2465_, lean_object* v_ik_2466_, lean_object* v_w_2467_){
_start:
{
lean_object* v_res_2468_; 
v_res_2468_ = l___private_Init_Data_Array_QSort_Basic_0__Array_qpartition_loop___at___00__private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__8_spec__10(v_n_2457_, v_lo_2458_, v_hi_2459_, v_hhi_2460_, v_pivot_2461_, v_as_2462_, v_i_2463_, v_k_2464_, v_ilo_2465_, v_ik_2466_, v_w_2467_);
lean_dec_ref(v_pivot_2461_);
lean_dec(v_hi_2459_);
lean_dec(v_lo_2458_);
lean_dec(v_n_2457_);
return v_res_2468_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_QSort_Basic_0__Array_qpartition_loop___at___00__private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__13_spec__16(uint8_t v___x_2469_, lean_object* v_n_2470_, lean_object* v_lo_2471_, lean_object* v_hi_2472_, lean_object* v_hhi_2473_, lean_object* v_pivot_2474_, lean_object* v_as_2475_, lean_object* v_i_2476_, lean_object* v_k_2477_, lean_object* v_ilo_2478_, lean_object* v_ik_2479_, lean_object* v_w_2480_){
_start:
{
lean_object* v___x_2481_; 
v___x_2481_ = l___private_Init_Data_Array_QSort_Basic_0__Array_qpartition_loop___at___00__private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__13_spec__16___redArg(v___x_2469_, v_hi_2472_, v_pivot_2474_, v_as_2475_, v_i_2476_, v_k_2477_);
return v___x_2481_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Array_QSort_Basic_0__Array_qpartition_loop___at___00__private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__13_spec__16___boxed(lean_object* v___x_2482_, lean_object* v_n_2483_, lean_object* v_lo_2484_, lean_object* v_hi_2485_, lean_object* v_hhi_2486_, lean_object* v_pivot_2487_, lean_object* v_as_2488_, lean_object* v_i_2489_, lean_object* v_k_2490_, lean_object* v_ilo_2491_, lean_object* v_ik_2492_, lean_object* v_w_2493_){
_start:
{
uint8_t v___x_21377__boxed_2494_; lean_object* v_res_2495_; 
v___x_21377__boxed_2494_ = lean_unbox(v___x_2482_);
v_res_2495_ = l___private_Init_Data_Array_QSort_Basic_0__Array_qpartition_loop___at___00__private_Init_Data_Array_QSort_Basic_0__Array_qsort_sort___at___00main_spec__13_spec__16(v___x_21377__boxed_2494_, v_n_2483_, v_lo_2484_, v_hi_2485_, v_hhi_2486_, v_pivot_2487_, v_as_2488_, v_i_2489_, v_k_2490_, v_ilo_2491_, v_ik_2492_, v_w_2493_);
lean_dec(v_hi_2485_);
lean_dec(v_lo_2484_);
lean_dec(v_n_2483_);
return v_res_2495_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__15_spec__19(lean_object* v_val_2496_, lean_object* v_workers_2497_, lean_object* v___x_2498_, lean_object* v___x_2499_, lean_object* v_fst_2500_, lean_object* v_snd_2501_, lean_object* v_head_2502_, lean_object* v_head_2503_, lean_object* v_range_2504_, lean_object* v_b_2505_, lean_object* v_i_2506_, lean_object* v_hs_2507_, lean_object* v_hl_2508_){
_start:
{
lean_object* v___x_2510_; 
v___x_2510_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__15_spec__19___redArg(v_val_2496_, v_workers_2497_, v___x_2498_, v___x_2499_, v_fst_2500_, v_snd_2501_, v_head_2502_, v_head_2503_, v_range_2504_, v_b_2505_, v_i_2506_);
return v___x_2510_;
}
}
LEAN_EXPORT lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__15_spec__19___boxed(lean_object* v_val_2511_, lean_object* v_workers_2512_, lean_object* v___x_2513_, lean_object* v___x_2514_, lean_object* v_fst_2515_, lean_object* v_snd_2516_, lean_object* v_head_2517_, lean_object* v_head_2518_, lean_object* v_range_2519_, lean_object* v_b_2520_, lean_object* v_i_2521_, lean_object* v_hs_2522_, lean_object* v_hl_2523_, lean_object* v___y_2524_){
_start:
{
lean_object* v_res_2525_; 
v_res_2525_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__15_spec__19(v_val_2511_, v_workers_2512_, v___x_2513_, v___x_2514_, v_fst_2515_, v_snd_2516_, v_head_2517_, v_head_2518_, v_range_2519_, v_b_2520_, v_i_2521_, v_hs_2522_, v_hl_2523_);
lean_dec_ref(v_range_2519_);
lean_dec(v_val_2511_);
return v_res_2525_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Lean(uint8_t builtin);
lean_object* initialize_Lean_Util_CollectAxioms(uint8_t builtin);
void lean_initialize();
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_AllHelpers(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
lean_initialize();
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Lean(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Lean_Util_CollectAxioms(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
l_main___boxed__const__1 = _init_l_main___boxed__const__1();
lean_mark_persistent(l_main___boxed__const__1);
return lean_io_result_mk_ok(lean_box(0));
}
char ** lean_setup_args(int argc, char ** argv);
#if defined(WIN32) || defined(_WIN32)
#include <windows.h>
#endif
lean_object* run_main(int argc, char ** argv) {
    lean_object* in = lean_box(0);
    int i = argc;
    while (i > 1) {
      lean_object* n;
      i--;
      n = lean_alloc_ctor(1,2,0); lean_ctor_set(n, 0, lean_mk_string(argv[i])); lean_ctor_set(n, 1, in);
      in = n;
    }
    return _lean_main(in);
}
int main(int argc, char ** argv) {
#if defined(WIN32) || defined(_WIN32)
  SetErrorMode(SEM_FAILCRITICALERRORS);
  SetConsoleOutputCP(CP_UTF8);
#endif
  lean_object* res;
  argv = lean_setup_args(argc, argv);
  res = initialize_AllHelpers(1 /* builtin */);
  lean_io_mark_end_initialization();
  if (lean_io_result_is_ok(res)) {
    lean_dec_ref(res);
    lean_init_task_manager();
    res = lean_run_main(&run_main, argc, argv);
  }
  lean_finalize_task_manager();
  if (lean_io_result_is_ok(res)) {
    int ret = lean_unbox_uint32(lean_io_result_get_value(res));
    lean_dec_ref(res);
    return ret;
  } else {
    lean_io_result_show_error(res);
    lean_dec_ref(res);
    return 1;
  }
}
#ifdef __cplusplus
}
#endif
