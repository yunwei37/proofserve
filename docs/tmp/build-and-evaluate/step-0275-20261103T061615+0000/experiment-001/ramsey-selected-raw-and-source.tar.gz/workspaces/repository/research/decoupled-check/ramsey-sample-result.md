# Ramsey retained-prefix size-stratified module-local sample

Review: 自审.

{
  "selected": 20,
  "returned": 20,
  "accepted": 20,
  "failed": 0,
  "cpu_s": 815.679164,
  "complete": true,
  "eligible": 190,
  "full_population": 444,
  "full_closure": false,
  "median_cpu_ratio": 0.40617944709342846,
  "min_cpu_ratio": 0.2602624037873538,
  "max_cpu_ratio": 0.5809953576327802,
  "pooled_cpu_ratio": 0.35911538856470154
}

Seed20261103: four uniformly without-replacement targets from each source-byte quintile of190 completed targets. This dependency-ordered prefix is not a random sample of444: it contains Construction prerequisites and some finite certificates before downstream CycleClique certificates/patterns/Main. The254 missing targets are unobserved. Size is not a proof-cost model. K10 is supplemental, excluded from random-sample summaries.

Each separate original4.34.1 module-local checker trusts imports as the existing reference does; startup/import are inside CPU clocks. Source emits olean/ilean/C. These are **not full-closure streaming ratios** and cannot share the Falconer6.31% or matched Mathlib8.95% denominator. Nonzero rc, timeout and OOM remain visible. No further Ramsey source is built.
