prelude
import Init.Data.Iterators.Lemmas.Monadic.Basic
example : (1 : Nat) = 1 := rfl
