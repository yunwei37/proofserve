# Research plan: two verification-cost regimes

Current frontier2026-11-03UTC, root0276. [Status](research-status.md) ·
[Evidence](evaluation.md) · [Results](../research/README.md) ·
[User words](user-instruction.md) · [Novelty](novelty-20261101.md).
[Exact previous plan](tmp/build-and-evaluate/step-0267-20261102T092013+0000/experiment-001/before-docs-research-plan.md.gz).

Current owner snapshot at root0275: Ramsey full production is stopped at190/444, not a running closure to restore;20-file sample complete. M original PMUmatrix is13/16 at entry, P2 pending; raw inherited worker READ metadata defects prevent treating all counters as qualified. W source38 now completes Tracked; Allocated preparation belongs to its existing master. Owner's SubexponentialSAT plan is preparation, not a root dispatch/result. Refresh actual terminals before any next integration.

## Fixed questions and ownership

The user-selected characterization title/four RQ meanings/section hierarchy remain:
1. Where does checking work fall, and what are population-weighted costs?
2. Which preparation/import/production boundaries obstruct cheap checking?
3. Which original-kernel parallelism survives complete costs and trust boundaries?
4. What does verified establish about build, outcome and axiom/declaration closure?

User novelty and narrowed-B decisions authorize evidence-based claim strength,
not generic mechanism firstness. Missing results stay explicit. A/B/C are measured
cases/limits, not a replacement framing or venue acceptance.

W owns workloads/ and fixed-frame population costs; M owns chunked-kernel-check/,
parallel-stream-check/ and reproducible-verdict/; O owns decoupled-check/,
cost-prediction/ and engine/service paths. Root owns docs/paper and root records,
reads foreign implementation only, and starts no additional agent or queue.
Same gpu-smt-dev/phobos-vt/128GiB PVC; W16/M16/O4/root4GiB within40,
at most8cores/line, root E22–23 small work. Native P0–7/existing pcore.lock;
no Lean -M option. Data/toolchains/builds remain outside Git. Charged caps,
sampled RSS and wait4HWM are distinct. Historical O share deviations stay explicit.
Preserve live identities and real lock waiters; never infer a resume from old status.

## Completed branches: integrate, do not repeat

| Branch | Current completion boundary | Record |
|---|---|---|
| Fixed source census |163097OAI files and8529Mathlib files already scanned with common masking; default-root lexical gap retained. No repeat download/census. | [0231](tmp/build-and-evaluate/step-0231-20261101T001556+0000/step-report.md) |
| W source continuations |48job suffix complete; later19job attempt adds only LowBlock original. Source38/42/19strata,4missing. Dependencies/censors never receive original-draw weights. | [0263](tmp/build-and-evaluate/step-0263-20261102T040256+0000/step-report.md) |
| W target replay |31/31accepted,14paired strata; trusted imports. Keep its source denominator separate from source36coverage. | [0260](tmp/build-and-evaluate/step-0260-20261102T020415+0000/step-report.md) |
| Original O closures |Four complete overlapping closures/5085source union/161module-local reference blocks. | [0235](tmp/build-and-evaluate/step-0235-20261101T041713+0000/step-report.md) |
| Falconer recovery |13205source/27successfulsegments, complete graph and reference union. Same-protocol Mathlib3segments also complete. Two full-check timeouts remain failures. No old checkpoint/reference queue restart. | [0264](tmp/build-and-evaluate/step-0264-20261102T061224+0000/step-report.md) |
| M parallel cases |Small-helper negatives, Barrier fragments, repairedMathlib18cells, full Barrier/Grid pairs and incremental targets completed with version-specific boundaries. | [0241](tmp/build-and-evaluate/step-0241-20261101T080929+0000/step-report.md), [0244](tmp/build-and-evaluate/step-0244-20261101T101651+0000/step-report.md) |
| B stage/cache/budget panels |v12census2524local helpers/30288checks complete; earlier24target/math-source/observer/cache/budget panels stay separate. Counts are not kernel polls/global candidate work. | [0262](tmp/build-and-evaluate/step-0262-20261102T030442+0000/step-report.md), [0261](tmp/build-and-evaluate/step-0261-20261102T023802+0000/step-report.md) |
| A limited policies |Native forecast/policy studies and grouped prediction errors complete; limited negative/tradeoff evidence, no bounded general predictor or route benefit. | [0254](tmp/build-and-evaluate/step-0254-20261101T195608+0000/step-report.md), [0256](tmp/build-and-evaluate/step-0256-20261101T205729+0000/step-report.md) |

## Evidence still needed within the four questions

| RQ | Unresolved evidence | Existing owner/integration boundary |
|---|---|---|
| RQ1 |5original source costs,11paired source/replay draws,13dynamic draws; native phase weights and uncertainty. | W/M; no -M/purposeful/dependency/zero-imputed substitute |
| RQ2 |Repeated/broader mathematics and released-software cases; causal preparation/production decomposition; arbitrary context and axiom qualification. | O/W; Falconer fills its selected closure only, not these global gaps |
| RQ3 |Matched native module-task comparison; complete selected-config Envelope baseline/pairs/repeats; general failure/budget/object-transfer and cluster evidence. | M; follow actual new plans/terminals, no root heavy native run |
| RQ4 |Whole declaration/axiom closure, observer/settings and cross-machine replication, released model-output software native evidence. | Existing W/M/O; no new generated candidates |

Current source37data preserve conditional marked CPU24.484% over18complete strata,
not a semantic phase/global fraction. Whole-frame242.2–315.2source/
16.5–28.0modeledstream CPUh retain missing-cost/mixed-protocol transfer
assumptions. The new point exceeded the old marked support maximum; scenarios
are neither CI nor guaranteed bounds. No-assumption upper remains unbounded.
Forecast/classification historical31-input panels do not become37-input experiments.

Kernel-helper allocation stability does not imply zero runtime overhead or a
sufficient maxHB margin. Math stored proofs are also stable in limited panels;
math kernel cells with only one eligible theorem do not establish8way concurrent
math checking. Source-count variation does not identify changed search paths.
The actual boundary is the measured stage/treatment, not universal regime law.

A checked-prefix chain starts empty and continues from its own certified deltas,
but stock loading trusts those deltas and private metadata. Whole acceptance
parity does not prove arbitrary snapshot safety, context transparency or axiom policy.
Do not merge segmented/uninterrupted ratios or treat unchanged mathematical kernel
rules as unchanged implementation TCB. Repaired M coordination has separate trust.

Bundled LeanChecker launches module-local tasks without a checked-import barrier.
A strict dependency-DAG span is a diagnostic, not its upper bound.
[Source audit](tmp/build-and-evaluate/step-0247-20261101T131749+0000/step-report.md).
Incremental and complete-configuration ratios have different clocks; never multiply
them, pool protocol versions or impute a full Envelope pair from a timeout.

## Next root action and review routing

Integrate real new owner terminals, or choose independent in-scope analysis only
when it can change a paper decision. Protect healthy work and genuine waiters.
No minute polling, duplicate controls, CPU-oracle extension, oldqueue restoration,
new runtime budget, agent or schedule. Completed Falconer/source19/v12points
are not pending despite stale owner README text.
The paper remains an unfinished characterization with explicit missing evidence;
self-review is not independent audit or submission acceptance.

Paper root0276:25pages/229052B,20oldtables/title/fullabstract/4RQ/sections/fourimplications unchanged;fullcompile/all-page self-review completed,0newrootnative/agent.

Historical finalized-number update [0265](tmp/build-and-evaluate/step-0265-20261102T065555+0000/step-report.md): RQ2 now places9.26%/10.56%/14.67% side by side with distinct closure/protocol boundaries and26exports/26restores included. RQ4 foregrounds2,524/2,524 zero-range targets, P95=max=0%, observed no-extra-count allowance only; module-source envelope0.0367–0.1385% and separate candidate maximum2.3339% remain different units. No guaranteed maxHB margin/future/zero-runtime claim.


New RQ3 boundary [0266](tmp/build-and-evaluate/step-0266-20261102T083616+0000/step-report.md): four complete later-version Barrier curves8/12/16/24workers add E cores and get slower. Do not repeat completed curves or call this homogeneous strong scaling. Resident-leaf determinism remains a separate actual owner capture; no result imputed. Whole-library O and Wremaining original draws are ongoing owner paths, not new root queues.

Streaming leaf count/byte capture now independently qualified by [0267](tmp/build-and-evaluate/step-0267-20261102T092013+0000/step-report.md):100targets overlap oldBarriercensus;12full-leaftrials/1200acceptedobservations/12exactoleanoutputs complete. Do not wait/restart17c4989; no globalmaxHB/TCB/property upgrade or poolingwith2524census. Existing ownerroutes handle further work.


CPU and coverage update [0268](tmp/build-and-evaluate/step-0268-20261102T190628+0000/step-report.md): Falconer native check/source CPU2038.443942/32292.603807s=6.3124%; matching checkpoint Mathlib91.145172/1018.219383s=8.9514%. Separate native elapsed ratios9.26%/historical10.56%/checkpoint14.67% remain. Source/protocol/CPU units are not pooled. Whole-source bounded attempt accepts2488/163097source+10744dependencies;160609source missing,9124source-compilation rc1 unclassified, not mathematical rejection or measured full-library cost.

Historical0268scope audited rc1count only. Root0271now independently classifies the retained9124diagnostics and qualifies finitecontrols, without asserting uniform phase/singlefacet/all-source repair.


[Root0269](tmp/build-and-evaluate/step-0269-20261102T191745+0000/step-report.md) independently qualifies W28d21e0 Hodge176 terminal:176rc0=175dependencies+1original IndexedInverseMultiplier (3.929919wall/4.131784CPU-s). Source33/42,16/21complete strata/144565modules;9ordinary original costs missing/18532module domain incomplete. Conditional source217.424460CPUh, marked57.546404h=26.4673%; summed-elapsed marked21.1985%. KnownHTsubtotal217.945744h is not population estimate/CI; each missing+1CPU-s adds5.134167h. Source support scenarios224.1–427.4CPUh; separate mixed-protocol transfer15.3–38.0CPUh uses current checkpoint ordinary6.31–8.95% with historical unsegmented computation8.4421–8.4671%. Neither is actual full checking/CI/guarantee. Wpaired31/42/14strata/dynamic13missing unchanged.


[Root0270](tmp/build-and-evaluate/step-0270-20261102T233639+0000/step-report.md) qualifies the actual84/84rc0terminal (19:44:26UTC), advancing the earlier Wsource34/77prefix:82dependencies+Intrinsic9.734671CPU/9.698324wall andDihedral20.154170CPU/8.784143wall. Original35/42,17/21complete strata/144663modules;7ordinary original costs missing/18434module domain incomplete. Conditional source218.220065CPUh, marked57.546404h=26.3708%; nativeelapsed marked21.1685%. KnownHTsubtotal227.988537h only; each missing+1CPU-s adds4.117083h. Source support scenarios232.9–396.0CPUh; separate mixed-protocol check transfer15.9–35.2CPUh, not actual full checking/CI/guarantees. Wpaired31/42/14strata/dynamic13missing unchanged.


[Root0271](tmp/build-and-evaluate/step-0271-20261103T004041+0000/step-report.md) reads all9124retained rc1source records/stdout/stderr:4697unknowninterpreterdecl+4421missingnativeexternal=9118unavailabledecldiagnostics,4missingmoduledata,1compilerIRmissingcode,1LakeinterpreterIR.139of9118are not atsource line1, so no uniform import/phase claim.4successful qualification controls=3pinned sourcefiles+1Init import control, plus preserved failedmetadata-copy retry. Current3source bytes11197match fixed full archive; old duplicate failure-input source copies are absent, so no direct historical-byte recheck. Old600s/11.5GiB/olean-only versuscontrols300s/11.75GiB/3facets and unlogged per-open env trace prevent isolatedfacet/cost causal claims.9124do not become proofrejection or repairedpasses. Historical2488/163097source+10744dependencies remains partial; currentRamsey is a separate unfinished closure, not its denominator.


[Root0272](tmp/build-and-evaluate/step-0272-20261103T025723+0000/step-report.md) independently qualifies the actual NativeCodeAssembly original terminal01:09:45UTC:4.981634wall/7.020013CPU-s, not E-core prerequisite timing. Exact42frame gains only that ID, prior35costs unchanged. Current36/42,18/21complete strata/151888modules;6ordinary original costs missing/11209module domain incomplete. Conditional source235.032925CPUh, marked57.546404h=24.4844%; nativeelapsed203.778943h/marked19.6382%. KnownHTsubtotal235.032925h equals complete-stratum subtotal here because incompletecells have0observations, not whole-frame point/CI. Missing+1CPU-s each adds3.113611h. Source support scenarios238.7–362.1CPUh; mixed-protocol checking transfer16.2–32.2CPUh, not actual full checking/CI/guarantees. Source35scenarios retained ashistory. Paired31/42/14strata/11missing and dynamic13missing remain distinct.


[Root0273](tmp/build-and-evaluate/step-0273-20261103T031343+0000/step-report.md) independently qualifies corrected-v2 twelve full Barrier cells+one compound leaf process and3finite controls. Every fullclosure has4449unique accepts/identicalimports/counts/referenceIDset,425463entries/3595unsafe-partialexclusions/0contextfallback.8observedcohorts preserve237863ordinarychecks/3283925639allocationunitsandper-modulesums. P4→P8nativeCPU+74.986s,observer-bracketCPU+71.953s=95.9549%; brackets includeheartbeat/timingreads,notpurecycles. NaturalP8→mixed24wall+19.230s/CPU+458.725s,phasewindows4.629serial+7.410occupancy+3.386batchoutside+3.805other;notinstructioncausality. Naturalwall+6.36%on/+5.53%off; P-first+3.25%on/-0.37%off,1orderedobservation/cell,notCI/isolatedcausalA-B.50overlappinghelpers×9=450accepted/zeroobservedcountranges;9actual9160440Boleansidenticaltooriginal,extensionmetadata trusted. Mixedchecks/same-targetsolo-typemedianCPUratiosP2.301/E2.834,notcontrolledphysicalcore/frequencyorRC/cachecause. Old2524census/100helperpaneldenominatorsunchanged.


[Root0274](tmp/build-and-evaluate/step-0274-20261103T040607+0000/step-report.md) independently qualifies PhysicalFieldPopulationLimit actual03:32:26UTC original return3.805640wall/3.900684CPU-s. Fixed42frame adds onlythisID;prior36costs match.37/42originals,18/21complete strata/151888coveredmodules unchanged becauseTrackedTestBoundsstillmissing in9146cell.5ordinary costs missing/11209module domain incomplete. Conditional235.032925CPUh/marked24.4844%/elapsed19.6382% unchanged;KnownHTsubtotal239.987877hincludesoneincomplete-celloriginal,notfullestimate/CI. Eachmissing+1CPU-sadds1.843333h. Sourceobservedsupportscenarios242.2–315.2CPUh; separate mixed-protocolchecktransfer16.5–28.0CPUh,notmeasuredfullchecking/CI/guarantees. Stressmissingcheck3xnow242.0hdoesnotexceedsource315.2;explicit4x317.1hdoes. Paired31/42/14strata/11missing,dynamic13missingnotfilledbysource37.

[Root0275](tmp/build-and-evaluate/step-0275-20261103T061615+0000/step-report.md) independently qualifies the completed20-file Ramsey sample and the190-source stopped prefix. Source CPU22146.098430s is separate from815.679164sample checkerCPU-s; sampled source2271.356756s gives35.9115% pooled, individual P10/median/P90=35.5103/40.6179/48.8260%. Five38-file size strata,4uniform without-replacement samples each, seed20261103 exactly reproduced. Independent module-local prefix estimate7748.952058CPU-s/22146.098430=34.9901%;10000within-stratum percentile resamples29.4130–40.4104%, not an interval for dependency-order bias,254missing targets or whole streaming.190Construction files median4457B versus81652.5B in254unbuilt;24/180marked built. K10supplement excluded:356.442522/1725.133882CPU-s=20.6617%, no+kernel marker but finite ordinary-decide certificates. Imports trusted; process/import floor not kernel dominance. Historical whole-source2488/163097 and completeFalconer/Mathlib fractions unchanged. No newrootnative/Agent/queue or foreign edit.


[Root0276](tmp/build-and-evaluate/step-0276-20261103T062502+0000/step-report.md) independently qualifies TrackedTestBounds actual06:22:07UTC original return5.198824wall/5.412330CPU-s. Fixed42frame adds onlythisID;prior37rawcosts match W38publishedrows.38/42originals,19/21complete strata/161034coveredmodules;4ordinarycostsmissing/2063module domain(1.26489%)in2cells. Conditional246.863040CPUh/marked57.546404h=23.311065%, summednativeelapsed215.217114h/marked40.018606h=18.594528%. Differentcovered domain than18-cell24.4844%,notpopulationtimetrend/semanticphaseweight. KnownHTsubtotal246.863040h equalsthecomplete-stratumsubtotalonlybecausemissing2cellshave0observations;notfullpoint/CI. Missing+1CPU-s eachadds0.573056h. Sourceobservedsupportscenarios247.5–270.3CPUh; separatemixed-protocolchecktransfer16.8–24.0CPUh,notmeasuredfullchecking/CI/guarantees.10xordinarymaxsource480.621868h;missingcheck1x40.184493/2x63.560375/4x110.312141/12x297.319203h. Fourtimesno longer exceedsactualmaxsource270.238923;explicit12xstressdoes,notmeasurement. Paired31/42/14strata/11missing,dynamic13missingunchanged.
