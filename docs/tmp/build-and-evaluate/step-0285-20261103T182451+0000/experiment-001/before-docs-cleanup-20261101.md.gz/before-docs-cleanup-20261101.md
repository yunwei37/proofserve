# Root cleanup, 2026-11-01
At 2026-11-01T18:35:17.093236+00:00, the same PVC has 36.679 GiB available before this action, rather than the earlier approximately7.9GiB snapshot. W/O cleanup is separately owned and not attributed to root.

Root removes 344 obsolete page/contact PNG/JPG renderings (210,688,408 logical bytes, 200.928 MiB) only inside prior root step0200–0247 paper-output directories outside Git. Each directory retains its PDF, source/build logs and receipts; these images can be rendered again from the retained PDF. No matching open descriptor was found immediately before unlinking. No source, raw native output, failed/partial record, toolchain, active build, other-lane output or current paper PDF is removed.

Exact [deletion manifest](tmp/build-and-evaluate/step-0250-20261101T183517+0000/experiment-001/deleted-renderings.csv) and [receipt](tmp/build-and-evaluate/step-0250-20261101T183517+0000/experiment-001/cleanup.json). Available bytes after: 39,594,598,400; other lanes can change free space concurrently, so df delta is not our reclamation total. Future paper build uses existing Tectonic cache and retains small outputs; no toolchain/cache installation or native experiment is introduced.

## After current paper review, step0252
After static review of all16pages, remove 24 newly generated page/contact/preview images (15,569,952 bytes) from this root paper output directory. The current167901-byte PDF, initial/final build outputs/logs/receipts and original data remain. [Exact manifest](tmp/build-and-evaluate/step-0252-20261101T184145+0000/experiment-001/post-review-rendering-cleanup.csv). These transient images were created during this task: removing them bounds new build storage and is not an additional pre-existing201MiB reclamation claim.

## After current paper review, step0255
After all17pages/5contacts were statically reviewed, remove 27 current root disposable
page/contact/preview images (16439805bytes) from its own paper-output directory outside Git.
[Manifest](tmp/build-and-evaluate/step-0255-20261101T200059+0000/experiment-001/post-review-rendering-cleanup.csv).
All final/initial PDFs, build logs, frozen source/raw/failed/partial evidence remain.
This bounds this task's generated storage, not another claim of the earlier201MiB recovery.
Observed PVC free space is 37269622784bytes; other owners can change it concurrently.

## After current paper review, step0256
Remove only 28 newly generated disposable root page/contact/preview images
(17748440bytes) after all18pages/5contacts reviewed.
[Exact manifest](tmp/build-and-evaluate/step-0256-20261101T205729+0000/experiment-001/post-review-rendering-cleanup.csv).
Final184684-byte PDF, initial-layout PDF/log and all raw/partial/failed/native/source
remain. These are this step's generated images, not repeated pre-existing cleanup gains.
Observed PVC free36150841344bytes can change concurrently.

## After current paper review, step0257
Only 29 newly generated disposable root page/contact/preview images
(18234040bytes) removed after all19pages/5contacts reviewed.
[Manifest](tmp/build-and-evaluate/step-0257-20261101T215746+0000/experiment-001/post-review-rendering-cleanup.csv).
Current188474-byte PDF, build logs/source/raw/failures/partials and other-lane files retained.
This bounds this step's new renderings, not repeated pre-existing cleanup gains.
Observed PVC free25729204224bytes can change concurrently.

## After current paper review, step0258
Remove only 29 newly generated root page/contact/preview renderings
(18431726bytes) after19pages/5contacts static self-review.
[Manifest](tmp/build-and-evaluate/step-0258-20261101T225830+0000/experiment-001/post-review-rendering-cleanup.csv).
Final189874-byte PDF, build/source/raw/failed/partial artifacts and foreignfiles remain.
This is current generated storage, not another oldcleanup gain.
ObservedPVCfree24943349760bytes may change concurrently.

## After current paper review, step0259
Remove only 29 newly generated root page/contact/preview renderings
(19060165bytes) after19pages/5contacts static self-review.
[Manifest](tmp/build-and-evaluate/step-0259-20261102T000306+0000/experiment-001/post-review-rendering-cleanup.csv).
Final193486-byte PDF, build/source/raw/failed/partial artifacts and foreignfiles remain.
This is current generated storage, not another oldcleanup gain.
ObservedPVCfree24190865408bytes may change concurrently.

## After current paper review, step0260
Remove only 30 newly generated root page/contact/preview renderings
(19890766bytes) after20pages/5contacts static self-review.
[Manifest](tmp/build-and-evaluate/step-0260-20261102T020415+0000/experiment-001/post-review-rendering-cleanup.csv).
Final198939-byte PDF, build/source/raw/failed/partial artifacts and foreignfiles remain.
This is current generated storage, not another oldcleanup gain.
ObservedPVCfree23648858112bytes may change concurrently.

## After current paper review, step0261
Remove only 33 newly generated root page/contact/preview renderings
(20890381bytes) after21pages/6contacts static self-review.
[Manifest](tmp/build-and-evaluate/step-0261-20261102T023802+0000/experiment-001/post-review-rendering-cleanup.csv).
Final204566-byte PDF, build/source/raw/failed/partial artifacts and foreignfiles remain.
This is current generated storage, not another oldcleanup gain.
ObservedPVCfree23013990400bytes may change concurrently.

## After current paper review, step0262
Remove only 33 newly generated root page/contact/preview renderings
(21221442bytes) after21pages/6contacts static self-review.
[Manifest](tmp/build-and-evaluate/step-0262-20261102T030442+0000/experiment-001/post-review-rendering-cleanup.csv).
Final206438-byte PDF, build/source/raw/failed/partial artifacts and foreignfiles remain.
This is current generated storage, not another oldcleanup gain.
ObservedPVCfree22387892224bytes may change concurrently.

## After current paper review, step0263
Remove only 34 newly generated root page/contact/preview renderings
(21278715bytes) after22pages/6contacts static self-review.
[Manifest](tmp/build-and-evaluate/step-0263-20261102T040256+0000/experiment-001/post-review-rendering-cleanup.csv).
Final207423-byte PDF, build/source/raw/failed/partial artifacts and foreign files remain.
This is current generated storage, not another old cleanup gain.
Observed PVC free20677156864bytes may change concurrently.

## After current paper review, step0264
Remove only34new root page/contact/preview renderings (20931774bytes)
after22pages/6contacts static self-review. [Manifest](tmp/build-and-evaluate/step-0264-20261102T061224+0000/experiment-001/post-review-rendering-cleanup.csv).
Final209773-byte PDF, raw/source/logs/failed/partial/startup files and foreign
artifacts remain. Current generated storage only, not repeated old cleanup gains.
PVC free snapshot16607567872bytes can change concurrently.

## After current paper review, step0265
Remove only34new root page/contact/preview renderings (21179451bytes)
after22pages/6contacts static self-review. [Manifest](tmp/build-and-evaluate/step-0265-20261102T065555+0000/experiment-001/post-review-rendering-cleanup.csv).
Final211433-byte PDF, raw/source/logs/failed/partial/startup files and foreign
artifacts remain. Current generated storage only, not repeated old cleanup gains.
PVC free snapshot16178278400bytes can change concurrently.

## After current paper review, step0266
Remove only35current rootrenderings/21721574bytes after all23pages/6contacts
self-review. [Manifest](tmp/build-and-evaluate/step-0266-20261102T083616+0000/experiment-001/post-review-rendering-cleanup.csv).
AllPDF/log/source/raw/failed/partial and foreign artifacts retained. Exact
compiler logs gzip preserves originalbytes, not data deletion. PVCfree snapshot
9622892544B is concurrent state, not oldcleanup reclaimed storage.

## Step0267 current reviewed renderings
Only35currentrootrenderings/22131383B removed after23page/6contact self-review and FDcheck. [Manifest](tmp/build-and-evaluate/step-0267-20261102T092013+0000/experiment-001/post-review-rendering-cleanup.csv). AllPDF/log/raw/source/failed/partial/foreign data retained. PVCfree snapshot12086128640B; no old cleanup gains reused.


## 2026-11-02 UTC — root0268 audit of historical build caches, no cache deletion

User requested native427 recovery (~12.2GiB) and repository/artifacts (~22.3GiB) audit, never delete tracked files or unreferenced raw. Root audited both. Native427 has13untracked .lake/build directories (4,945,862,656 allocated B), stock SDKlib2,588,311,552B, and11untracked artifact ELF executables714,248,192B. The25candidates span102693unique inodes; nlink-adjusted reclaim estimate8,235,347,968B. This is a candidate estimate, **not released space**. Artifacts contains17429Git-tracked files, all protected. No cache/SDK/ELF/source/raw file was deleted.

References checked: native427 absolute paths appear in10970tracked build/analysis records; SDK at artifacts/linarith-oracle-2026-10-17/gpu-stage/corrected-wall-profile/build-attempt3-compiler.log:19 and large-lp-race/native-queue-control/build-final.log; mathlib at current-budget-gpu-20261023/admission-async-20261024/preflight-analysis.json. Artifact families have existing tracked analyses/reports: artifacts/lean-modern-native-compilation-2026-10-14/native-oracle-full-plan.md and plan-gc.md; docs/idea-story.md (lean-gpu-checking). Inventory records exact candidate paths/inodes/blocks under [docs/tmp/build-and-evaluate/step-0268-20261102T190628+0000/experiment-001/cleanup-candidate-inventory.json.gz](tmp/build-and-evaluate/step-0268-20261102T190628+0000/experiment-001/cleanup-candidate-inventory.json.gz). Reproducible build caches and ELF outputs could be rebuilt; original raw/source/report/CSV must remain. This is an audit, not a claim every historical artifact can be deleted.

Initial live used129011671040B of134951424000B (~95.6%). Other owners' concurrent cleanup brought used to111201239040B (82.40%), already below85%, before root considered candidate deletion. Fresh analysis snapshot used97466384384B (72.223%), available37468262400B. None of that concurrent release is attributed to root. Target met; root retains all candidate caches to avoid unnecessary deletion. Earlier root0267 only deleted its35fresh renderings22,131,383B after all-page review, already separately recorded and pushed61e6dfd. New root0268 rendering cleanup, if any, is recorded only after review.

Connection uses existing Cloudflare SSH jump ssh.yunwei37.com added only in the invoking PowerShell module process; no network/Tailscale/server configuration mutation. No native collection, Agent/session, CronJob, queue or owner implementation changed.

## Step0268 current reviewed renderings
Only35current root renderings/22334648B removed after23page/6contact self-review and FDcheck. [Manifest](tmp/build-and-evaluate/step-0268-20261102T190628+0000/experiment-001/post-review-rendering-cleanup.csv). AllPDF/log/source/raw/failed/partial/foreign files retained. Current disk72.232%/available37456236544B; target<85% met by concurrent other-line cleanup, not credited to root. No native427/artifacts cache or tracked file deleted.

## Step0269 reviewed renderings only
Removed36initial reviewed renderings/22516564B and36final reviewed renderings/22516308B after24page/6contact self-review and FDcheck. [Initial manifest](tmp/build-and-evaluate/step-0269-20261102T191745+0000/experiment-001/before-spacing-rendering-cleanup.csv), [final manifest](tmp/build-and-evaluate/step-0269-20261102T191745+0000/experiment-001/post-review-rendering-cleanup.csv). BothPDFs/source/logs/raw/failed/partial/foreign data retained. Exact compiler logs byte-verified gzip. No native427/artifacts historical cache or tracked data deleted; PVCfree37435543552B/72.248% snapshot not prior cleanup attribution.

## Step0270 reviewed renderings only
Removed36reviewed renderings/22555185B after24page/6contact self-review and FDcheck. [final manifest](tmp/build-and-evaluate/step-0270-20261102T233639+0000/experiment-001/post-review-rendering-cleanup.csv). AllPDF/source/logs/raw/failed/partial/foreign data retained. Exact compiler logs byte-verified gzip. No native427/artifacts historical cache or tracked data deleted; PVCfree36920692736B/72.629% snapshot not prior cleanup attribution.

## Step0271 reviewed renderings only
Removed36reviewed renderings/22726517B after24page/6contact self-review and FDcheck. [final manifest](tmp/build-and-evaluate/step-0271-20261103T004041+0000/experiment-001/post-review-rendering-cleanup.csv). AllPDF/source/logs/raw/failed/partial/foreign data retained. Exact compiler logs byte-verified gzip. No native427/artifacts historical cache or tracked data deleted; PVCfree35733745664B/73.509% snapshot not prior cleanup attribution.

## Step0272 reviewed renderings only
Removed36reviewed renderings/22672753B after24page/6contact self-review and FDcheck. [final manifest](tmp/build-and-evaluate/step-0272-20261103T025723+0000/experiment-001/post-review-rendering-cleanup.csv). AllPDF/source/logs/raw/failed/partial/foreign data retained. Exact compiler logs byte-verified gzip. No native427/artifacts historical cache or tracked data deleted; PVCfree31896170496B/76.352% snapshot not prior cleanup attribution.

## Step0273 reviewed renderings only
Removed36reviewed renderings/23438773B after24page/6contact self-review and FDcheck. [final manifest](tmp/build-and-evaluate/step-0273-20261103T031343+0000/experiment-001/post-review-rendering-cleanup.csv). AllPDF/source/logs/raw/failed/partial/foreign data retained. Exact compiler logs byte-verified gzip. No native427/artifacts historical cache or tracked data deleted; PVCfree33195950080B/75.389% snapshot not prior cleanup attribution.

## Step0274 reviewed renderings only
Removed36reviewed renderings/23457840B after24page/6contact self-review and FDcheck. [final manifest](tmp/build-and-evaluate/step-0274-20261103T040607+0000/experiment-001/post-review-rendering-cleanup.csv). AllPDF/source/logs/raw/failed/partial/foreign data retained. Exact compiler logs byte-verified gzip. No native427/artifacts historical cache or tracked data deleted; PVCfree32278593536B/76.069% snapshot not prior cleanup attribution.

## Step0275 reviewed renderings only
Removed39reviewed renderings/23916350B after25page/7contact self-review and FDcheck. [final manifest](tmp/build-and-evaluate/step-0275-20261103T061615+0000/experiment-001/post-review-rendering-cleanup.csv). AllPDF/source/logs/raw/failed/partial/foreign data retained. Exact compiler logs byte-verified gzip. No native427/artifacts historical cache or tracked data deleted; PVCfree30514302976B/77.376% snapshot not prior cleanup attribution.

## Step0276 reviewed renderings only
Removed39reviewed renderings/23914839B after25page/7contact self-review and FDcheck. [final manifest](tmp/build-and-evaluate/step-0276-20261103T062502+0000/experiment-001/post-review-rendering-cleanup.csv). AllPDF/source/logs/raw/failed/partial/foreign data retained. Exact compiler logs byte-verified gzip. No native427/artifacts historical cache or tracked data deleted; PVCfree30404800512B/77.457% snapshot not prior cleanup attribution.

## Step0277 reviewed renderings only
Removed39reviewed renderings/24428931B after25page/7contact self-review and FDcheck. [final manifest](tmp/build-and-evaluate/step-0277-20261103T071354+0000/experiment-001/post-review-rendering-cleanup.csv). AllPDF/source/logs/raw/failed/partial/foreign data retained. Exact compiler logs byte-verified gzip. No native427/artifacts historical cache or tracked data deleted; PVCfree29683142656B/77.992% snapshot not prior cleanup attribution.

## Step0278 reviewed renderings only
Removed40reviewed renderings/24752564B after26page/7contact self-review and FDcheck. [final manifest](tmp/build-and-evaluate/step-0278-20261103T081624+0000/experiment-001/post-review-rendering-cleanup.csv). AllPDF/source/logs/raw/failed/partial/foreign data retained. Exact compiler logs byte-verified gzip. No native427/artifacts historical cache or tracked data deleted; PVCfree28237279232B/79.064% snapshot not prior cleanup attribution.

## 2026-11-03 UTC — root0279 actual historical reclamation
Direct user request is recorded verbatim in [user-instruction.md](user-instruction.md).
This replaces no historical observation: root0268 audited candidates without deleting
them; root0279 now actually reclaims the two named historical roots and retired
generated bench outputs within repository.

**Attributed released allocation: 16,290,934,784 bytes (15.172115 GiB).**
This is the sum of last-link file blocks, removed empty-directory blocks and the
measured Git-object allocation reduction, never a repeated old cleanup claim or
a concurrent df delta. Current PVC used 94,716,596,224/134,951,424,000 bytes
(70.1857%), available 40,218,050,560 bytes.
Both requested targets (at least15GiB and below75%) are met.

- Retired generated Lean build caches/stock4.27 SDK libraries/native ELF/Rust outputs:
  8,891,338,752 B; [inventory](tmp/build-and-evaluate/step-0279-20261103T122418+0000/experiment-001/cleanup-generated-candidates.json.gz).
  Sources/version/build commands and original reports/raw remain.
- Exact whole-file byte comparisons consolidate historical duplicates, preserving
  every path and raw byte: large-files 2,435,493,888 B, small-files
  458,776,576 B. [Large manifest](tmp/build-and-evaluate/step-0279-20261103T122418+0000/experiment-001/cleanup-identical-hardlinks.json.gz)
  and [small manifest](tmp/build-and-evaluate/step-0279-20261103T122418+0000/experiment-001/small-identical-completed.jsonl.gz).
  Historical paths now share inodes; copy to a distinct inode before any future
  edit/append. Original per-path mtimes/modes are recorded for restoration.
- Expanded duplicates are removed only after comparison to existing retained
  ZIP/split-tar/tar member bytes: 3,197,284,352 B,
  including a directly inspected archive containing only7517regenerable private
  compiler outputs. [ZIP/split-tar manifest](tmp/build-and-evaluate/step-0279-20261103T122418+0000/experiment-001/cleanup-retained-archive-duplicates.json.gz),
  [tar manifest](tmp/build-and-evaluate/step-0279-20261103T122418+0000/experiment-001/cleanup-tar-duplicates.jsonl.gz),
  [small duplicate receipts](tmp/build-and-evaluate/step-0279-20261103T122418+0000/experiment-001/cleanup-small-archive-result.json).
  Existing raw/source archives remain; restore each recorded member to its
  recorded path/mode/mtime if an expanded view is needed.
- 149501empty retired intermediate directories: 615,575,552 B;
  [manifest](tmp/build-and-evaluate/step-0279-20261103T122418+0000/experiment-001/cleanup-empty-directories.json.gz).
- Two old bench .lake/build trees: 478,969,856 B from39untracked
  compiled outputs, including sourceTrace/looseBVarReference/persistentKernel.
  Their Main.lean/LooseBVar.lean/toolchain/lake configuration and source package
  remain. [Manifest](tmp/build-and-evaluate/step-0279-20261103T122418+0000/experiment-001/cleanup-bench-generated.json.gz).
- Git repack, no pruning/reflog expiration: 213,495,808 B.
  All41669oldobjects remain readable, no commit rewritten/deleted;
  [receipt](tmp/build-and-evaluate/step-0279-20261103T122418+0000/experiment-001/git-repack-result.json).

Protected: all38372initially enumerated tracked paths across the main and nested
source repositories still exist;17419tracked artifacts were protected at initial
scan. No tracked artifact/bench deletion. Dirty foreign files and root a.out
remain untouched. Current M/W/O runtime/captures/snapshots were outside cleanup.
Before mutations, commands/descriptors/mappings were checked for actual use.
No native collection, infrastructure, network, credentials or runtime policy changed.

Unique unreferenced raw data remain. In particular,156native427 JSONL files over
1MB had no exact absolute-filepath match in the scoped tracked-reference query;
this is not proof that no relative/report reference exists. They were not discarded
or converted into permission to delete. Existing partial/failure logs and the
historical invalid ZIP remain. Any future proposal to discard unique unreferenced
raw must be listed and put to the user under the current explicit instruction.
The user15GiBtarget is already met without doing so.

An inefficient root-only small-file archival traversal was interrupted using its
actual PID/birth; its completed exact comparisons/deletions were logged, then a
direct-path traversal completed. No M/W/O process was signaled. Evidence includes
[correction](tmp/build-and-evaluate/step-0279-20261103T122418+0000/experiment-001/small-archive-loop-correction.json).
All root scripts, exact per-path inventories and results are retained in
[step0279](tmp/build-and-evaluate/step-0279-20261103T122418+0000/step-report.md); review is self-review.

## Step0280 reviewed renderings only
Removed41reviewed renderings/26874431B after27page/7contact self-review and FDcheck. [final manifest](tmp/build-and-evaluate/step-0280-20261103T131855+0000/experiment-001/post-review-rendering-cleanup.csv). AllPDF/source/logs/raw/failed/partial/foreign data retained. Exact compiler logs byte-verified gzip. No native427/artifacts historical cache or tracked data deleted; PVCfree39722004480B/70.553% snapshot not prior cleanup attribution.

## Step0281 reviewed renderings only
Removed41reviewed renderings/26059728B after27page/7contact self-review and FDcheck. [final manifest](tmp/build-and-evaluate/step-0281-20261103T141838+0000/experiment-001/post-review-rendering-cleanup.csv). AllPDF/source/logs/raw/failed/partial/foreign data retained. Exact compiler logs byte-verified gzip. No native427/artifacts historical cache or tracked data deleted; PVCfree38423089152B/71.516% snapshot not prior cleanup attribution.

## Step0282 reviewed renderings only
Removed41reviewed renderings/26124553B after27page/7contact self-review and FDcheck. [final manifest](tmp/build-and-evaluate/step-0282-20261103T145836+0000/experiment-001/post-review-rendering-cleanup.csv). AllPDF/source/logs/raw/failed/partial/foreign data retained. Exact compiler logs byte-verified gzip. No native427/artifacts historical cache or tracked data deleted; PVCfree37728485376B/72.030% snapshot not prior cleanup attribution.

## Step0283 reviewed renderings only
Removed41reviewed renderings/26582576B after27page/7contact self-review and FDcheck. [final manifest](tmp/build-and-evaluate/step-0283-20261103T162836+0000/experiment-001/post-review-rendering-cleanup.csv). AllPDF/source/logs/raw/failed/partial/foreign data retained. Exact compiler logs byte-verified gzip. No native427/artifacts historical cache or tracked data deleted; PVCfree36187824128B/73.172% snapshot not prior cleanup attribution.

## Step0284 reviewed renderings only
Removed42final reviewed renderings/26972557B and42initial reviewed renderings/26972419B after each28page/7contact self-review and FDcheck. Initial PDF/source/logs and separate initial manifest retained. [final manifest](tmp/build-and-evaluate/step-0284-20261103T172738+0000/experiment-001/post-review-rendering-cleanup.csv). AllPDF/source/logs/raw/failed/partial/foreign data retained. Exact compiler logs byte-verified gzip. No native427/artifacts historical cache or tracked data deleted; PVCfree34479730688B/74.438% snapshot not prior cleanup attribution.
