# 新颖性审计与论文主张：2026-11-01

本轮是**新检索、原始来源核查和主张裁决**，不是上次相关工作整理的重命名。根线程自审；没有独立审核或 venue 接受结论。检索于2026-11-01 UTC完成下述有限覆盖，不声称穷尽文献。当前用户明确授权按查重降级 A/B/C，覆盖旧文档“摘要冻结”的约束；两成本区间标题、四RQ及刻画主线保留。

## 先给判断

**A、B的通用机制不成立为新意；C的通用并行/分解/可信组合也不成立为新意。** A、B在我们负载上的效用或强性质仍待证；C已有有限实例的正确性控制和性能数据，可以写成“将既有证明分解、原内核重验和组合方法用于这个负载”，不能写“首个并行检查器”“任意大计算自动分块”“可信实现不变”。

目前可保留的中心贡献是**固定发布AI数学库的成本与验证边界刻画**：相同词法口径、区分源构建与重放/组件/完整闭包、保留困难样本缺失和失败、展示局部强加速为何不等于完整收益。这是有证据的经验增量候选，不是“检查与搜索不同”这个常识本身，也尚非完成的全库运行时刻画。OSDI水准目标保留；当前证据不足以宣布达到该目标。

证据等级与新颖性是两个维度：
- **已测**：明确版本、输入、计时/信任边界的真实观察，附原始实验/根复算；不代表普遍性质或新意。
- **部分**：已有局部观察，但在主张旁明确缺少的总体、对照、重复或语义证据。
- **待证**：尚无对应合格结果；代码、计划、编译和排队不算结果。论文数值缺项继续使用 LaTeX \missing。

## A/B/C逐条裁决

| 候选主张 | 已有工作与同主张风险 | 允许写的确切增量 | 当前证据等级 / 必须缺什么 |
|---|---|---|---|
| A 运行前预测验证成本并用于准入 | SATzilla已用实例特征预测难度并选择算法；Coq辅助文件已用历史证明耗时预测任务长度并调度。预测再做资源决策的泛化新意风险**高**。这些不是同一份Lean新输入的静态准入保证，也不能据此断言任何可能的特定预测器都已做过。 | “评估既有成本预测/资源决策思想在发布AI形式化负载上的适用性”；只有真实held-out结果才可声称准确/有用。过去source-cost crossfit未胜FIFO，必须保留。 | **待证**：前置特征是否包含生成/检查后的信息、固定版本与依赖、按项目/家族分割、防止重复/共享闭包泄漏；尾部/超时校准、特征成本、假拒绝/覆盖率和实际准入收益。相关性不等于安全资源上界。 |
| B 把墙钟预算改成确定工作量以复现判定 | Lean已有thread-local allocation heartbeats；SMT-LIB已有reproducible-resource-limit并要求限定条件下结果对预算确定。通用机制风险**高**，不应称新发明。 | “在这个验证流程上界定并测试预算重放的适用边界”。若要贡献强协议，须给出计数范围、身份和并发合并语义；目前不能写已保证。资源耗尽是unknown/操作结果，不是False。 | **待证**：相同字节/依赖/二进制/options、线程/异步子工作、observer开销、跨机与跨版本边界、缓存/预算可观察元程序、预算梯度与中断分类。历史7/200错误标志变化仅为**已测历史诊断**，不是新noM复现实验。 |
| C 大内核计算自动分块、可信拼装并行检查 | Wenzel的proof futures/fulfilment、Coq异步任务/完整检查、Lean并行elaboration/kernel和leanchecker任务已有；反射、证书分解再组合也已有。通用机制风险**高**；这些不等于证明已有人实现我们的每一项有限索引变换。 | “对源码资格匹配的有限索引证书应用既有分解与原内核重验/组合；测量相对声明并行的收益及完整成本”。selector和coordinator/C adapter仍新增可信实现；原内核数学规则不变不等于TCB不变。 | 有限案例**已测**；通用自动化/端到端优势**部分**。Envelope目标chunk8对强decl8为1.319x、CPU+5.19%，单次有序；small Grid整路径阴性保留。缺完整chosen-config Envelope pair、重复/泛化、原生module-task对照、坏输入/失败/预算语义与cluster。 |

A旧阴性：[held-out source-cost study](../artifacts/candidate-scheduling-2026-10-25/source-cost-crossfit-20261026/README.md)。
C原始边界：[Envelope强基线](tmp/build-and-evaluate/step-0243-20261101T091434+0000/step-report.md)、
[Grid/Barrier完整单配置](tmp/build-and-evaluate/step-0244-20261101T101651+0000/step-report.md)、
[完整Envelope串行超时](tmp/build-and-evaluate/step-0245-20261101T111249+0000/step-report.md)、
[原生module-task源码](tmp/build-and-evaluate/step-0247-20261101T131749+0000/step-report.md)。
不同协议/clock的加速比不相乘、不合并。

## 根线程亲自核查的核心先例

每行同时给已有工作、与我们差别、缺证据。日期为本次access；不将2026年的工具HEAD行为倒写为早年论文原始性质。

| 原始来源与核查位置 | 已有工作 / 对本论文的裁决 | 差别及我们的缺口 |
|---|---|---|
| Makarius Wenzel, *Parallel Proof Checking in Isabelle/Isar*, PLMMS2009，§3–4；[作者PDF](https://files.sketis.net/papers/parallel-isabelle.pdf)、[原作者索引](https://www21.in.tum.de/~wenzelm/papers/) | proof promises/futures、kernel fulfilment检查命题、背景理论包含及良基依赖；并行嵌套证明并非新问题。原站抓取失败后从作者镜像实际取183722B PDF并抽取正文。 | Isabelle LCF promise架构与我们的Lean序列化/内存协调不同；不能从不同推出新意或更强信任。我们没有一般context/失败证明，也没有匹配该架构的性能结论。 |
| Barras, Tankink, Tassi, *Asynchronous processing of Coq documents*,2015，§2–3、§5；[原论文](https://arxiv.org/html/1506.05605)；[Coq8.17.1官方手册](https://rocq-prover.org/doc/V8.17.1/refman/addendum/parallel-proof-processing.html) | 文档DAG、opaque proof promises、worker进程与延迟检查；完整检查与quick compilation有区别。手册已有基于历史耗时的任务预测/调度，并提示某些独立vio检查不查全局宇宙一致性。 | 不是将Coq数字移植Lean；“并行通过”和完整全局资格仍有差别。我们的exactclosure/fullcost、全局axiom与一般context资格尚不齐。 |
| Lean[4.17 release](https://lean-lang.org/doc/reference/latest/releases/v4.17.0/)及[4.19 release](https://lean-lang.org/doc/reference/latest/releases/v4.19.0/) parallel elaboration；官方[FAQ](https://lean-lang.org/faq/) | 4.17已有kernel checking与elaboration重叠，4.19已有theorem bodies并行。将并行引入Lean不是新贡献。FAQ也将导出后独立检查作为常规边界。 | 我们测的是已编译产物的重放/有限within-goal变换，不是首个并行elaborator；缺与现有模块任务匹配资源/ID/完整clock的实测。 |
| [lean4checker官方README](https://raw.githubusercontent.com/leanprover/lean4checker/master/README.md)；[固定4.34.1 LeanChecker](https://github.com/leanprover/lean4/blob/v4.34.1/src/LeanChecker.lean) | 官方kernel replay与parallel module tasks早已有；fresh mode已存在。README称其不是独立kernel实现，且现已并入toolchain。 | shared checked prefix与module-local trusted imports不同。不能用额外import完成barrier的DAG给原生checker上界；缺同闭包实测对照。 |
| [nanoda官方README](https://raw.githubusercontent.com/ammkrn/nanoda_lib/master/README.md)，当前num_threads/axiom/extension配置；[Lean4Lean v3](https://arxiv.org/html/2403.14064v3)，§7 | nanoda是独立Rust检查器并已有检查workers。Lean4Lean是独立Lean实现，已有compiled Mathlib重验与性能评估，并讨论module并行的内存限制。独立检查/并行外部检查器本身不新。 | 我们额外区分sourcework、imports、局部与完整closure；这不是独立实现的soundness贡献。缺跨checker相同公理/extension/排除范围的测量，不能借它们的速度或正确性。 |
| [Kimina技术报告](https://arxiv.org/html/2504.21230v1)，§2及表1–2；[官方实现](https://github.com/project-numina/kimina-lean-server) | 预启动并发REPL、按header复用imports、LRU及RL反馈服务均已公开并评估。warm/cache/普通调度不是新意。 | 我们的compiled independent stream不是其frontend服务。未测服务吞吐，不能把stream/source或target ratio称为胜过Kimina或服务收益。 |
| [DeepSeek-Prover-V1.5官方verifier](https://github.com/deepseek-ai/DeepSeek-Prover-V1.5/blob/main/prover/lean/verifier.py)，verify_lean4_file、Lean4ServerProcess、scheduler | 已有REPL验证、进程worker、墙钟timeout和pass/complete/系统异常分类。验证服务和资源边界并非我们首创。 | source反馈与独立artifact replay不同；本源不足以证明所有DeepSeek版本都没有确定预算。我们无matched service数据，也不把异常当数学反证。 |
| [Mathlib benchmark suite](https://raw.githubusercontent.com/leanprover-community/mathlib4/master/scripts/bench/README.md)、[build metrics](https://raw.githubusercontent.com/leanprover-community/mathlib4/master/scripts/bench/build/README.md)、[run](https://raw.githubusercontent.com/leanprover-community/mathlib4/master/scripts/bench/build/run)；[Stoll2024第一人称报告](https://leanprover-community.github.io/archive/stream/287929-mathlib4/topic/Ways.20to.20speed.20up.20Mathlib.html) | 官方已有全局/逐module指令、task/wall、RSS、profile、lakeprof与CI性能回归流程；社区已有Mathlib全库build/阶段分布。不能称首次测量形式化库成本。 | 原始released-AI frame、默认root漏域、匹配source/replay/closure和困难draw缺失是本研究的经验边界；全库运行时权重/代表性phase仍缺。Radar网页本次无可读正文，未据此编造当前CI金额/耗时。 |

## 两个直接威胁和方法学先例

- **B最直接重叠**：[Lean Timing](https://lean-lang.org/doc/reference/latest/IO/Timing/)说明heartbeat为当前线程small allocations，目标是比墙钟更确定；不是跨所有observer/版本/并发的保证。[SMT-LIB2.7](https://smt-lib.org/papers/smt-lib-reference-v2.7-r2025-04-09.pdf)§4.1.7、p61已规定可复现资源限额与unknown，并限定相同机器、前序命令/随机种子等条件。B的口号不是新主张。
- **A直接相邻**：[SATzilla2008](https://arxiv.org/abs/1111.2249)，实质是运行前特征/难度模型支持逐实例决策；[SATzilla07作者PDF](https://www.cs.ubc.ca/~hutter/papers/cp07-satzilla.pdf)还讨论censored samples。它不提供我们的确定资源上界，但排除“首次先预测再决策”。
- **C分解组合也已有**：Strub/Swamy/Fournet/Chen，[Self-Certification, POPL2012](https://www.microsoft.com/en-us/research/wp-content/uploads/2016/02/popl2012-paper211.pdf)，§7将顶层binding的证书分割再组合并报告Coq检查成本。不是我们的有限索引算法，但“分块+可信组合”抽象层不新。
- **W方法不是新统计学**：[Statistics Canada概率抽样](https://www150.statcan.gc.ca/n1/edu/power-pouvoir/ch13/prob/5214899-eng.htm)和[非抽样误差](https://www150.statcan.gc.ca/n1/edu/power-pouvoir/ch6/nse-endae/5214806-eng.htm)已有分层、已知入样概率和nonresponse边界。标准stratified estimator、固定seed、保留缺失属于可靠方法应用，不是新估计器。重尾与超时不能靠只保留成功draw解决。

## 三线整合与实际可读资格

本轮读取 W065完整终态报告及W-status：48job已完成，只增加2原draw，仍31/42、14/21complete strata，条件17.1434%；新hard36是另一个活跃有限点，不能提前填其结果。W的全库CPU/份额仍**部分**，11draw缺失，grain另缺13。**未把W065发布为一份尚未完成的查重报告。**

M新目录已有[step001](../research/reproducible-verdict/step-001-report.md)及[自审](../research/reproducible-verdict/step-001-audit.md)：其本人也将通用确定工作量机制判为已有，跨机/observer/线程性质为假设；初始实现/编译及计划不是fresh native复现结果。此处B裁决不借尚未完成的实验。

O新cost-prediction查重报告、W本轮专门查重报告在本次初稿整合时尚未可读；根独立完成其主张的核心先例核查，**不冒称三线都完成**。后续只吸收实际报告，不从目录/进程推断科学结论，也不另起替代队列。A仍待证；若后续结果为阴性，照实写，而非为保留贡献挑样本。

## 论文应当怎样写

1. 摘要/引言以“固定AI库的成本与验证边界刻画”为主张，保留实测词法浓度、selected source/check对比和完整成本案例；删除泛指“自动分块”与不变TCB暗示。数据支持的是这个发布版本和相应输入边界。
2. A放RQ1/RQ2的待证设计含义，不写已可预测或已实现安全准入。B放RQ4的适用边界与待证协议，不把heartbeat包装成新机制。C放RQ3的既有思想应用案例，先报强decl8比较、再完整clock，不只选串行弱基线。
3. 每条主要主张就近标**已测/部分/待证**并链接实验或缺项；“已测且先例充分”仍可作经验结果，不当机制创新。
4. 保留缺全库weights、causal components、软件、公理闭包、native parallel baseline、完整Envelope pair/重复和cluster；不能用新增标签替代缺少的实验。
5. 可发表的新意仍须来自新经验结论或证实的更强性质，不能仅来自将成熟组件重新命名、接口拼接、启动/缓存/并行实现。当前没有证据支持同时以A/B/C三个通用机制作为论文贡献。

核查日志和root自审见[本步报告](tmp/build-and-evaluate/step-0251-20261101T183642+0000/step-report.md)；清理见[cleanup](cleanup-20261101.md)。论文落实作为下一独立提交，不能以本记录代替实际改稿。

## 补充整合：M/W查重报告已实际到达
本节取代初稿的“尚未收到M/W完整查重”状态，不把初稿时间倒改。W066/f29316a的[专门方法查重](../workloads/openai-math/cost-method-prior-art-20261101/README.md)实际确认：HT/分层估计、native CPU统计和全库benchmark早有；增量只能是特定AI库的明确estimand与经验分布，且31/42 source draw无法完成global结论。对shared-stream的非可加启动/共享依赖和独立verification CPU应另外测，不能拿compiler stack占比乘出verification总成本。根已阅读其完整README/step；与本次独立判断一致。

M/e28ccc1的[完整先例表](../research/reproducible-verdict/prior-work.md)确认B口号不新；其[step002](../research/reproducible-verdict/step-002-report.md)新增六条简单classification控制。根读取实际6条输入、native command/result/terminal和PID/cgroup退休记录：P0–7/noM/14GiBcharged，5.032693s/rc0，无stop/OOM，controller240795/birth761085500、native240889/birth761094370已消失。这是分类/计数资格，不是已完成的跨线程/observer/机器稳定性矩阵。后续活跃矩阵未提前收取。B的总体“待证”不变。

根进一步打开了M指出的[Lean共享thunk计数修复51c2c9e](https://github.com/leanprover/lean4/commit/51c2c9e116cecfffb3c8f9f3bf650857d1b55f44)：先抢到共享thunk的线程受调度影响，原计数可能改变maxHeartbeats结果；修复不再把共享/persistent thunk计入该线程预算。它直接重叠“修复并行确定预算”问题，不能包装为我们新机制；未核实其对4.34.1的backport，绝不称本SDK已修好。ACL2页面本次root访问403；ACL2细节仅按M的来源核查记录归属，不冒称root成功打开。

W指出的[Growing Mathlib2025 §5](https://arxiv.org/html/2508.21593v1#S5)已由根打开：已有持续全库/逐文件、components、instructions/wall/task指标和library优化研究，进一步排除“首次从wall走向CPU/阶段成本”的主张。本文仍不移用其百分比作为我们的新硬件数据。

O的research/cost-prediction专门报告仍未可读；其新context/Falconer记录不是该预测查重报告，不能替代。A裁决由根的SATzilla/Coq先例独立支撑，应用收益仍待证；不冒称三线全部完成。

## 新鲜noM诊断补充：v1矩阵完成，B仍不升级
[根逐原始复算](tmp/build-and-evaluate/step-0253-20261101T185439+0000/step-report.md)：16个选定历史source×配置共768rows，8matrix+8task native cells全部终态。budget3000的所有比较均0通过集合变化；off/trace为16/256操作分类变化，来自同一个source重复配置，不是16独立反例。同步off/trace计数128/128变化；v1 stock/sync的48/384分类变化来自两source的parser消息被适配器清除，不是Lean内核缺陷。父线程130与子线程合计40110的控制强调计数范围。故“有局部诊断数据”已测，但B的观察器无关精确计数、通用/跨机判定复现仍待证。v1有已知适配器缺陷，v2在另一路实际进行，不能合并。论文主张力度不变，PDF不重编译。

## O查重与实验已到达：A强主张不获支持
[根逐原始复算](tmp/build-and-evaluate/step-0254-20261101T195608+0000/step-report.md)收取[O完整报告](../research/cost-prediction/analysis.md)，三线查重现已实际汇总。31/42完成样本的project-heldout static/regime CPU绝对相对误差中位数分别34.95%/50.07%，P90为77.38%/93.02%；差值区间跨0，不说regime有确定负效应。28/31上界覆盖不是确定/全库保证。60CPU-s原生单次点FIFO/排序/上界准入完成15/15/13，预算打断1/1/0；准入少打断也少完成并剩余18.15CPU-s。不同预算/arrival的离线正结果保留，matched60s离线15/15/13与原生一致，不能制造仿真/原生矛盾。A改为**强主张不获支持；有限负结果/权衡已测**，不作为新预测或准入机制贡献。原生11.5GiB cap/最高6.76GiBRSS仍不追认为O4合规，child PID/birth未留不能补造。

更近的[同库公开技术报告](https://github.com/nealmcb/openai-math-lean-tooling/blob/c9570a82f79b78a1a969a6316ac0fdd69aabef55/REPORT.md)已由根实际打开并固定版本，报告commit元数据2026-10-23，非声称peer-reviewed。它已有构建/检查成本、源码特征预测、kernel计算离群、并行检查、build域/验证含义讨论。重叠不限A：**不再将“同库首次成本刻画”或“首次区分廉价见证与昂贵计算”当新意**。可争取的经验增量是受控匹配边界、明确非响应/计数/信任限制与新负结果；对方版本/资源/clock不同，不直接比较性能，也不把其概念先例贬为无关。

## 修正版B的终态和实际论文落实
[根0255逐原始复算](tmp/build-and-evaluate/step-0255-20261101T200059+0000/step-report.md)收取v2实际17rc0phase（矩阵1536row/16选定历史输入、10资格row、8task控制），35个PID/birth含controller247273/birth761159154及全部cgroup已退休，不新跑。
在budget1000，off/trace8/256通过标志变化都为同一个1041输入的sync路径；stock路径没有观察到通过丢失。stock/sync8/384在1000不同、3000全相同；各observer的线程数对比均无通过变化。3000另16/256仅操作分类变化不当通过丢失。故B可以写**有限同步适配器对observer不透明已测**，不能写stock内核通过集合不稳定、8独立反例或通用确定预算已解决。v1 parser消息缺陷历史不混入v2；全局/跨机器/完整kernel工作计数仍待证。
本次实际改稿将A从单纯“待证收益”改成有边界的阴性/权衡结果，同时声明同库先例对核心概念的重叠。当前PDF17页177246bytes完整编译/全页静态自审；原12数值表体保持、新增2张独立协议表。标题/四RQ/章节含义/4设计含义保留，摘要力度按直接用户新要求修正。自审与可编译不构成独立审查或OSDI接受。

## 新完成的分类/route/准入点：分开承认效用和未证保证
[根0256](tmp/build-and-evaluate/step-0256-20261101T205729+0000/step-report.md)独立从31份旧raw kernel-call日志重建总CPU/decision-helperCPU；29原draw上TP14/TN13/FP1/FN1，27/29条件准确率。参考类只是helperCPU≥50%，不是完整语义区间/producer dominance。两错同Catalan项目；13dynamic draw仍缺，不能把93.10%输出为全库准确率或新分类算法。错标工作0.482%是exposure，不是改路由的因果浪费。
O新的9batch/12call真正完成，120CPU-s/三已知闭包/三循环arrival，FIFO/type/upper平均完整root0.333/0.333/1，打断1/1.333/0。**已知panel上的保守准入确有可用性收益**，不能因旧source60s阴性一概否定；但它defers两个计算root，闲置54.049s≈45.04%。原NearPin172.726CPU-s超过ordinary upper71.744s，否定该类上界的一般转移。route更快wall没有更多完成，说明分类不等于CPU预算最优路由。两种实验population/operation/budget分开，不合并为服务gain。
根实际打开[SATzilla2012 §I–II](https://www.cs.ubc.ca/~kevinlb/papers/2012-SATzilla2012-Solver-Description.pdf)：明确已有不作runtime回归的cost-sensitive分类选算法。换“分类”口号不能绕开A的先例。我们承认的是固定规则与所选dynamic标签一致性、已知任务准入权衡，不是新的classifier/selector/bounded admission。
M v3同步off有限预算阶梯100个lower-pass/larger-budget比较无反例；8budget-aware control先遇adapter imported-constant错误，未执行预期逻辑。48input-JSON cache对比无判定差，只处理7页，不能声称冷SDK/Mathlib复现。通用B仍待证，真实private-cache waiter受保护，不重启。

## 新完成的private-input cache与RQ1敏感性：局部正证据不升级通用B
[根0257](tmp/build-and-evaluate/step-0257-20261101T215746+0000/step-report.md)直接读取M v8完整终态：9rc0native phases（6资格控制+8×64rows），512rows/256cold-warm配对，verdict/diagnostics/axiompolicy差异0；128sync commandcounter vectors一致。42stock parentcounter pairs变动（raw差最高24），不是完整async候选计数或已隔离cache因果。101743private输入files/8846348681bytes，根核所有size/inode区别于liveoriginal，未假装重做8.85GB逐字节比较；选定2238400pages冷0/暖全resident。支持同机限定输入cache treatment的稳定性，**不支持一般机器/observer/全工作预算保证或新确定性机制**。旧v6确实Probe IR编译失败、0candidate rows，不当否定判定或零差异矩阵，失败/修复都保留。
W同14complete strata的sourceproxy份额从CPU17.1434%变为串行native elapsed14.8102%，不是总体时间趋势/因果剖析。11missing draw每个多1CPU-s令最终完整HTpoint多10.842083h，是权重灵敏度，不是成本预测、补值或新统计法。Known165.187936h仅公式subtotal，不当全库估计/下置信界。原31/42/14strata和dynamic13缺失均不变。

## 实际coexecution部分终态：计数透明性仍不成立，完整两区间对照缺失
[根0258](tmp/build-and-evaluate/step-0258-20261101T225830+0000/step-report.md)收取M5真实partial终态：15实际native phases/14rc0+1rc1，31PIDbirth含controller301735/birth762181601均退休/cgroupsabsent。数学8cells256rows完整，实际TID1/2/4/8；worker1对2/4/8有192配置比较，0verdict/acceptflag差异、84commandcounter vectors差异。只支持该有限数学子矩阵的判定观察；不把分配计数当透明/总预算，不把跨配置变化全因果归给并发。
Grid仅首轮4cells32rows原内核接受；首Envelope import报缺objectfile，0.916035827s/rc1/0Envelope REGIONrows，不是原内核拒绝/数学反证，未执行后续计算repeat。正确module名字与旧合格v14相同；现configuredLEAN_PATH不含该target，现有qualifiedoverlay中有2268344-byte对象。根只读定位，不复制/改M路径/重启；后续由M实际新版本/完整终态处理。完整two-regime对照仍missing，不能用partialprefix提升机制B/C新意或性能主张。


## Original-module stage qualification: root0259
[Root0259](tmp/build-and-evaluate/step-0259-20261102T000306+0000/step-report.md) reconstructs Mv10 actual complete terminal:58rc0nativephases,
56stagecells/336rows/252workercomparisons;117PID/birth identities and all cgroups retired.
Stored proofs: computational192rows/144pairs, mathematical16rows/12pairs,
0allocation/verdict/diagnostic differences. Mathematical kernel has only one eligible
proof per module and one active thread regardless of requested pool: no matched
concurrent-kernel treatment. Two mathematical source programs, eight clones percell:
128rows/96pairs/49allocation-vector differences,0verdict/diagnostic changes.
Syncbudget2000000/recursion20000/asyncfalse, not stock-budget equivalence.
Stage boundary, not math-only determinism, nativepollcount or completecandidate budget.
Full target imports trusted; computational source arm absent. Bgeneric guarantee remains unproven.
Old Mv5 partial remains partial: same192comparisons have83theorem/26opening/0terminal
count differences (overlap) and3timeout-text differences,0outcome changes.
No newrootnative/agent; old v5/v9/inventory/link/eligibility failures preserved.


## Completed target panel and repeated stages: root0260
[Root0260](tmp/build-and-evaluate/step-0260-20261102T020415+0000/step-report.md) independently reconstructs W31target-only replays:
31accepted/exact target-part matches; sourceCPU632.590445/replay272.695065s
(ratio0.431077), nativeelapsed393.895780/274.208513s(0.696145).
Queue-inclusive14768.395s is separate. Same14strata conditional source140.851561/
target-replay54.905548CPUh, ratio0.389811/nominal95%[0,0.940135],2draws/cell,
fragile effectiveDF1.185. Trustedimports/fulltransitiveidentity not established;
not empty-environment closure checking, full-library cost or source/service gain.
Original source31/42,11missing source/paired and13dynamic missing remain.

M v11 separately complete86rc0phases/84cells/504rows/378comparisons:
storedproof312rows/234pairs0allocation/verdict/diagnostic differences;
mathsource192rows/144pairs78allocationchanges/0verdict/diagnostic changes.
Only2actualprograms; kernelmath1activeproof/module, computational8selectedhelpers.
Pooled observed source count ranges0.036739%/0.138453%, not certified budget padding.
All205M/W recorded PIDbirth identities/controllers/cgroups retired; no rootnative/agent.
Prepared/queued Mv12full2524helper census is not this sampled result.

Falconer source summary reports13205constructed, but original fullcheck rc124/
1500.210998s,8942completeaccepts/8943headers plus75bytecutfragment.
CollectorJSONerror is operational, not math rejection or finalacceptsetmismatch.
Nativecgroup absent/noOOM; nativePIDbirth absent in receipt, not invented.
11.75GiBcharged cap deviates from listedO4; no retroactive authorization.
Recovery checks are separate actual owner paths; fullparity/ratio remainmissing.


## Direct B boundary and missing-cost scenario revision: root0261
[Root0261](tmp/build-and-evaluate/step-0261-20261102T023802+0000/step-report.md) implements the user's narrowed empirical argument in the
Bcontribution/RQ4 and adds Wwhole-frame scenario ranges inRQ1.
Prepared24computationtargets:0%observed allocation spread across12checks each;
two mathsource spans0.036739%/0.138453%; concurrentminiF2F theoremcommand
83/192changes (fullvector84/192), max2.333868%,0acceptancechanges.
Cache256verdict/diagnostic and128syncvectors stable;100ladderpairs no counterexample.
No newbudgetmechanism or inference that onlymath/tacticsearch needs margins.
Percentages are observed count allowances, not required/sufficient maxHBpadding:
Corebudgetscope differs and threshold/causal-search evidence is absent.
M12census has an actualcomplete receipt now, not stillrunning; this revision
does not silently adopt its unreviewed2524-target outcomes or generalize v11.

Wsource178.225696–627.348203CPUh (outward-rounded178.2–627.4),
modeledstream8.322086–41.555143h (8.3–41.6) under explicit missing-cost
support and Oclosure CPU-ratio transfer. Not confidence/guaranteed bounds
or measured wholelibrary costs; no-assumptionupper unbounded.
Missingchecks2xsource reverses gap935.534vs627.348h; no tautological generalgain.
MeasuredW31targetreplay medianCPUratio0.451(range0.087–0.885) remains
target-only/trustedimports, separate from modeledemptyenvstream.
14stratum140.852/54.906CPUh are retained as conditionalmeasured-estimator
quantities, not relabeled wholelibrary or replaced by a differentestimand.
Original31/42source/11missing,13dynamicmissing remain.0newrootnative/agent.


## Qualified computation-helper census: root0262
[Root0262](tmp/build-and-evaluate/step-0262-20261102T030442+0000/step-report.md) now independently qualifies actual Mv12 terminal/raw/source:
36rc0processes/30288accepted checks of2524unique local helpers
(UMoments91164/BarrierData411320/Envelope40),each12observations at1/2/4/8workers
and3fixed-order repeats.22716j1-versus-higher pairs0allocation/verdict/diagnostic
differences; all2524per-target observedranges0%. ActualTID counts match requested.
73PIDbirth identities/controller366671 and36cgroups retired;noOOM/RSSstop,
noM/P0–7/14GiBcharged.3target.olean byte-match retained originalWproducers.
OriginalnoinlineIOkernel-check/timing code matches prior qualifiedprobe;
selection expands8→all eligiblelocal of_decide_eq_true-headed theorems,
freshnames/proofbodies preserved, importtargetcontext stilltrusted.
This is all eligiblehelpers in3modules, not allcomputationalproofs/globalcandidate
work/nativekernelpoll counts or threshold/crossmachine budget guarantee.
UnitCPUvaries despite fixedallocations;UMj1→j8median73.957600→95.415988s,
notzero-overhead or isolatedconcurrencycausality.
wait4RSS12727196KiB/sample13028470784B/charged6533206016B distinct.
Wholecontroller1283.999848s includesall36cells,not singleconfiggain.
ActualBintro/RQ4 nowuses qualifiedcensus, keeps v11math/24target panel separate;
prior0261receipt-only caution was accurate then, this step supplies missingaudit.
Wsource31/42/scenarioassumptions and13dynamicmissing unchanged;O/Whealthy
partial/reference/checkpoint requests protected.0newrootnative/agent/foreignedit.


## New source draw and terminal source19: root0263
[Root0263](tmp/build-and-evaluate/step-0263-20261102T040256+0000/step-report.md) independently qualifies source19 actual complete terminal:
13nativecalls/12rc0compiles/1SIGALRMwallcensor/6dependency-uninvoked.
Successes are11dependencies+1original LowBlock15_1; DihedralIntervals original
notinvoked. All14recordednative/controllerPIDbirth identities and13cgroups retired.
noM/P0–7/j8/authoreddefaultHB/olean-ilean-C/15GiBcharged+separateRSS/noOOM.
13sourcefiles byte-match pinned4eaee875. NewLowBlock184.589081CPU-s/
124.512017648nativewall, outputs7246016/985771/47699B,notnewkernel/replay evidence.
IntegralPairings dependencyrc-14/600.197701524s/633.525530CPU-s:
resourcecensor,notmathematicalreject/targetfalse.6uninvoked areunknown,not6failures.
Native1456.905625wall/1560.934089CPU separate from8019.708321queue-inclusive.
No oldqueue resume/retry/budgetextension.

Rootoriginal42frame +1verifiedcost now32/42source,10missing/allordinary,
15complete strata/104632modules.9marked strata coverall5848marked files;
sourceCPUestimate57.546404h marked/116.704826ordinary, conditionalshare33.024963%;
summednativeelapsedshare27.020391%. Old14stratum17.1434/14.8102% remains
historicalcoverage,notfixed-populationtime trend. Full-libraryCPU/globalshare
unknown; proxy!=semanticphase. KnownHTsubtotal195.029837h/notconfidencebound;
uniform+1CPU-s/missingdraw sensitivity10.680417h.32observedCPU817.179526/
nativeelapsed518.407798s. Target-onlypaired replay remains31/42/14strata,
dynamicgrain29random+2purposeful/13missing unchanged.

NewLowBlockcost exceeds previousmarkedclassmax163.845944,showing oldsupport
was anassumption.Updated32cost/10ordinarymissing supportminmax scenarios:
source207.894666–630.701677h→outward207.8–630.8;modeledstream10.826785–
41.839086h→10.8–41.9 with OclosureCPUtransfer. NotCI/guaranteedbounds/
measuredfullstream. Old178.2–627.4/8.3–41.6retainedasdated31snapshot;
unknownchecks2xsource reversesgap885.083vs630.702h. No-assumptionupperunbounded.
ActualpaperMethods/RQ1 and pairedscope updated,notonlylogs. Bcensus/otherRQ
evidence unchanged;0rootnewnative/agent/foreignedit.

## Root0264 — selected large-project recovery completed, not a new general mechanism

[Root report](tmp/build-and-evaluate/step-0264-20261102T061224+0000/step-report.md).27successful Falconer segments accept13205unique modules
with complete native import graph;16new original module-local reference chunks
plus5077exact previously qualified common artifacts cover the same set.
Source13205records/8128new+5077reused:22077.770248wall/
32292.603807CPU-s. Falconer2043.585476wall/2038.443942CPU-s, ratio9.2563%.
Same checkpoint protocol/quota500 Mathlib3segments91.279127/622.379412sourcewall
=14.6662%, one ordered capture each; older unsegmented10.5551% is another adapter.
Two full-check timeouts remain3000.415754failedwall, excluded from successful
protocol cost, not hidden or mathematical rejections. Queue/control/qualification
and collector cleanup are separate from timed native intervals.
Base starts empty; later stock imports trust this run's own certified deltas and
unsafe-cast private metadata. Not arbitrary-snapshot safety, general context/
axiomclosure, service performance or a first checkpoint mechanism.
Oshare deviation remains:sourcecaps11.875/11.75GiB/check11.75,wait4checkRSS10.368GiB.
IndependentRSS sampling/native-child PIDbirth not emitted;4recorded controller
identities retire,63PID-only submission records are not birth-audited.
Source32/paired31/dynamic13missing and B2524scope remain unchanged.

## Root0265 — direct finalized-number wording and index update
[Step](tmp/build-and-evaluate/step-0265-20261102T065555+0000/step-report.md). Owner commitsa0a2916/395a8b3
restate already raw-qualified results. Root rechecks all2524published count ranges,
12observations each, nearest-rankP95=max=0%,30288checks/22716pairs.
RQ4 says no extra allocation-count allowance for these observed prepared kernel
runs; it does not guarantee future execution or a sufficient native maxHB margin.
Math source modules0.036739/0.138453% (coarse0.03–0.14% envelope) and a separate
16-source panel maximum2.333868% are not pooled or causal tactic-path evidence.
RQ2adds a three-row9.26%/10.56%/14.67% comparison, differentclosures/protocols,
not multiplied/averaged;26exports/26restores already inside2043.59s.
Index directly links both final owner reports. No new native experiment, generic
determinism/checkpoint mechanism or globalcost guarantee.

## Root0266 — heterogeneous expansion is a measured limit
[0266](tmp/build-and-evaluate/step-0266-20261102T083616+0000/step-report.md). Same4449-module Barrier closure in frozenv16,8/12/16/24workers with
8P/8P+4E/8P+8E/8P+16E allowed masks:284.720/299.807/310.591/319.705s.
24vs8 wall+12.29%,wait4nativeCPU+75.31%; graph and retained serial accept set
match at all four settings. One fixed-order capture, no P/E-specific CPU or
external-load/frequency control; no isolated contention/scheduling explanation.
No homogeneous scaling/cluster/general limit or cross-version v14ratio.
Added coordinator/Cadapter trust and native module-task baseline gap remain.
This bounds the existing RQ3 case, not a new parallel-checking mechanism.

## Root0267 — streaming count and mathematical-output stability
[0267](tmp/build-and-evaluate/step-0267-20261102T092013+0000/step-report.md). A newly checked4448-moduleprefix and12complete3425-declaration leaf
trials yield100overlapping targets×12=1200acceptedobservations with0range,
P95/max0%,and12serialized9,160,440Boleanfiles byte-equal to each other/original.
Original-kernel checked constants substitute into retainedmetadata; extension
entries are not revalidated. Only1actualartifactpart,not alloutputs/bootstrap.
Call-windowCPU3.575→9.941s while counts stayfixed; no free runtime/observer,
nativekernelpoll/globalcandidate/near-threshold/future guarantee.100targets
are selected from oldBarrier1320,not100newindependentcomputationalworkloads.
Prepared-stage evidence strengthens within the existing characterization,
without newdeterministicbudget/parallelchecking mechanism firstness.


## 2026-11-02 — CPU versus elapsed and partial source coverage

CPU and coverage update [0268](tmp/build-and-evaluate/step-0268-20261102T190628+0000/step-report.md): Falconer native check/source CPU2038.443942/32292.603807s=6.3124%; matching checkpoint Mathlib91.145172/1018.219383s=8.9514%. Separate native elapsed ratios9.26%/historical10.56%/checkpoint14.67% remain. Source/protocol/CPU units are not pooled. Whole-source bounded attempt accepts2488/163097source+10744dependencies;160609source missing,9124source-compilation rc1 unclassified, not mathematical rejection or measured full-library cost.
No new novelty search or stronger A/B/C mechanism claim. The new CPU reconciliation does not establish a full-library saving, AI-authorship causality, general context safety or venue acceptance.
