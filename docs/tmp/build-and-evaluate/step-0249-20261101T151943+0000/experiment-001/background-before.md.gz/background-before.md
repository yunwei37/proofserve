# Background And Related Work

Last updated: 2026-10-16, root direct primary-source review.
Source: [native CPU / adjacent GPU update](tmp/bootstrap/step-0010-20261014T133154+0000/literature-20261015T1300/report.md); [serving/source node](tmp/bootstrap/step-0010-20261014T133154+0000/literature-20261015T0556/report.md).
Completeness: scoped source coverage; no novelty, final baseline winner or RQ is proved.
The complete earlier map, queries, source pins and dated observations remain in
[the historical record](tmp/bootstrap/step-0010-20261014T133154+0000/literature-20261015T0556/related-work-history-through-20261015.md).
Current experiment versions/results belong in [implementation](implementation.md)
and [evaluation](evaluation.md); the scientific narrative remains in [idea-story](idea-story.md).

## Search Log

| Source/query | Purpose | Current decision |
|---|---|---|
| AXLE arXiv2606.26442v1, pinned public client e213b344; current local-backend query | Same problem, serving mechanism and measurement boundary | Existing isolated preloaded serving; public client does not establish a matched local backend |
| Spice official OSDI26 page/PDF; process-snapshot query | Same mechanism and accepted systems evidence | Disk restoration is established systems work; resident branching alone is insufficient differentiation |
| Lean manual/thesis; official4.35 release and mergedPR15015; pinned ix GPU protocol | CPU same-mechanism and adjacent GPU metric threats | Native compilation is prior art;4.35 offers finer selection; cryptographic proving is a distinct boundary |
| [Earlier finite coverage](tmp/bootstrap/step-0010-20261014T133154+0000/literature-20261014T1457/report.md) and historical record | Native snapshots, services, CPU/GPU arithmetic, workload/checker threats | Retain verified sources and scoped negatives; do not repeat builds or tiny tests to manufacture progress |

## PDF Corpus

| Work | Retained reference | Role |
|---|---|---|
| Lean4 | [PDF](reference/lean4-cade21.pdf) | Frontend/runtime/kernel architecture |
| Kimina | [PDF](reference/kimina-2504.21230.pdf) | Competent warm-service comparison |
| Keep the Proof State Live | [PDF](reference/lean-snapshot-2605.25556.pdf) | Direct native prepared-state branching overlap |
| AXLE | [PDF](reference/2026-xin-axle.pdf) | Existing isolated preloaded Lean service |
| Verus / VeruSAGE | [Verus](reference/verus-oopsla2023.pdf), [VeruSAGE](reference/verusage-2512.18436.pdf) | Systems-verification architecture/task provenance |
| Fine-grained verification caching | [PDF](reference/boogie-cache-krml245.pdf) | Existing result/dependency reuse |
| SOCK / SEUSS | [SOCK](reference/sock-atc18-oakes.pdf), [SEUSS](reference/seuss-eurosys20.pdf) | Prepared execution and memory sharing |
| Spice | [PDF](reference/2026-holmes-spice.pdf) | Accepted process-snapshot restoration mechanisms |

Reference annotations and their historical verification dates remain in docs/paper/references.bib.
Retained files are sources, not reproduced numerical baseline results.

## Claim-Oriented Novelty Map

| Plain claim | Closest prior work | Same-claim risk | Evidence/differentiation still required |
|---|---|---|---|
| Real candidate streams share expensive preparation beyond exact duplicates | Kimina, LeanDojo, Boogie caching, existing snapshots | Medium | Actual ordered attempts, available context and measured preparation costs across contexts/projects; task bytes or published final proofs alone do not answer RQ1 |
| Independent native candidate histories improve the equal-resource service frontier beyond competent reuse | Snapshot-DSP, stock Lean/REPL roots, AXLE, SOCK/SEUSS/Spice | High for the mechanism | Native responses/artifacts, cancellation, state mutation, resource accounting and complete service benefit in Lean and SMT; generic fork/COW/pooling is not novelty |
| Devices improve complete verification after the strongest measured CPU route | Arena CPU checkers, Farkas/Fast/lp, HiGHS, certified GPU SAT | High for generic representation or numeric search | Expensive supported dynamic work, actual parallel ready work, strongest compatible CPU path and complete setup/transfers/fallback/checking costs |

All four RQ meanings, Lean-first/SMT scope, RTX5090 and the full research objective remain unchanged.
Novelty cannot be repaired by renaming a primitive or shrinking the requested contribution.

## Closest Work

| Work | Relevant established capability | Comparison boundary |
|---|---|---|
| [AXLE](https://arxiv.org/abs/2606.26442v1) | Preloaded Mathlib with per-request processes | Published normalized-sample computation accounting differs from our unchanged-source whole-service clocks; no cross-system ratio is imported |
| [Snapshot-DSP](https://arxiv.org/abs/2605.25556) | Reuses elaborated proof state for parallel tactic branches | Tactic-state reuse is already established; complete source/service and resource claims need their own measurements |
| [Stock Lean snapshots](https://lean-lang.org/doc/reference/latest/releases/v4.32.0/), [REPL](https://github.com/leanprover-community/repl) | Incremental state, environment/proof roots and serialization | Choose a corpus-compatible native path; published current-version primitives are not automatically measured old-version competitors |
| [Kimina](https://github.com/project-numina/kimina-lean-server) | Warm header pools, GC pruning and lifecycle controls | Actual source defaults and GC engagement must be checked; an ever-growing mutable worker is a weak comparator |
| [Pantograph](https://github.com/leanprover/Pantograph), [LeanTree](https://github.com/Kripner/leantree) | Native state interaction and lifecycle tooling | Saved goal state differs from full environment/source verification; generic lifecycle is prior art |
| SOCK, SEUSS, [Spice](https://www.usenix.org/conference/osdi26/presentation/holmes) | Prepared process reuse and efficient disk restoration | Generic snapshotting is established; Spice co-designs disk layout and kernel restore, not verification history |
| [Z3](https://z3prover.github.io/papers/programmingz3.html), [SMT-LIB](https://smt-lib.org/papers/smt-lib-reference-v2.7-r2025-07-07.pdf) | Ordered commands, incremental state, native resource/artifact interfaces | Logical assertion equivalence does not guarantee identical resource-bounded responses or chosen artifact bytes |
| [Farkas/Fast](https://github.com/lucifer1004/farkas/tree/5a38a7e8502213cb644faa2e11a15429f0cf0f9a), [lp](https://github.com/leanprover/lp-tactic), [HiGHS](https://github.com/ERGO-Code/HiGHS) | Numeric support search, exact repair/native proof construction and CPU caching | Solver-only times/proof counts cannot replace whole Lean comparisons; first complete CPU trios are in evaluation |
| [Official native compilation](https://lean-lang.org/doc/reference/latest/Elaboration-and-Compilation/), [Lean4.35](https://lean-lang.org/doc/reference/latest/releases/v4.35.0/) | Native tactic shared libraries; finer import/library precompilation | Existing CPU mechanism; new options do not justify migrating pinned producer captures |
| [ix](https://github.com/argumentcomputer/ix/tree/91348190f091d53ab0838440eaeaf0cb36f2737f) | Lean-derived checking plus CUDA cryptographic proving | Charge compilation/proving/aggregation before certificate checking; not a matched native source-verification speedup |
| [Arena](https://arena.lean-lang.org/round/2026-09/), [gpu4bmc](https://github.com/muhos/gpu4bmc) | Alternative CPU kernels and certified GPU reasoning | Post-export checking differs from source verification; instruction-derived virtual time is not parallel wall time |
| [BendRT/BendTT](https://github.com/bendlang/bend/tree/d2aeefc1902d617340e26f7fab5c1ef50fe28efa/paper) | Affine functional CPU/GPU runtime and a different type theory | Pinned runtime suite uses M4Max/Metal; no unchanged Lean/Mathlib/Meta-unification reproduction or transferable speedup. [Scoped primary-source review](tmp/bootstrap/step-0010-20261014T133154+0000/literature-20261016T0100/report.md) |

## Mandatory Baselines

At most three competing scientific families; runnable admission remains experiment design.

| Family | Official artifact/version and status | Information/tuning/protocol | Consequence |
|---|---|---|---|
| Competent warm/cache serving | Kimina fb2393de and exact corpus-compatible REPL; actual full-source captures running | Same unchanged source/options, available cache/preparation, lifecycle and resources; full source/transport/replacement costs | If it wins, no beyond-warm benefit in that regime; no cold-only acceleration claim |
| Native logical/serialized reuse | Stock Lean, REPL/Pantograph and compatible native roots; exact corpus pins in receipts | Same available prefix, imports, validation and candidate order; charge state load/serialization/cancellation | If it matches branching, generic process cloning supplies no demonstrated incremental frontier |
| Strongest compatible complete CPU execution | Official native compiler/oracle and qualified arithmetic routes; closure-based CPU checkers for a post-export route | Equal boundary/resources; keep proof checking, failures, fallback and whole-run repetitions | No GPU superiority against an obsolete algorithm or solver-only denominator |

AXLE and Spice are citation-only precedents in the current matrix, not extra numerical main baselines.
No local AXLE backend equivalence is established here; its public SDK cannot reproduce its reported executor accounting.
[Current baseline handoff](tmp/bootstrap/step-0010-20261014T133154+0000/literature-20261015T0556/baseline-handoff.md)
records reproduction/fairness limits. Missing runnable evidence is not treated as a win.

## Experimental Precedents And External Assets

| RQ | Accepted precedent / official asset | Reusable design and required qualification |
|---|---|---|
| RQ1 | LeanDojo NeurIPS23; Boogie CAV15; public original-attempt cohorts | Real contexts/attempt ordering and dependency reuse; final-proof releases do not supply all failed model attempts or arrival traces |
| RQ2 | Verus SOSP24 [artifact](https://verus-lang.github.io/paper-sosp24-artifact/); native verifier/protocol tests | Original feedback/failure controls plus candidate cancellation/history/artifact tests; native behavior and logical soundness remain distinct |
| RQ3 | SOCK ATC18, SEUSS EuroSys20, Spice OSDI26 | Matched host/context working set, full latency/throughput, memory/CPU and whole-run repetition; add real verification work and distinguish offered load from closed-loop replay |
| RQ4 | ParaFROST CAV21 integration; official Arena/CPU checker recipes | Algorithm controls and end-to-end certification costs; SAT/BMC is precedent, not a substitute for Lean/Verus verification |

Original ProofNet/miniF2F attempt pools remain in scope.
[The original miniF2F paper](https://arxiv.org/abs/2109.00110v2) is the verified
ICLR2022 benchmark-origin reference. Our retained producer-version source and
submission protocol remain separate experimental facts; the citation does not
establish model quality or equivalence to the paper's original toolchains.
 The newer migrated Goedel
release is an additional arithmetic-heavy workload, not a complete model-rollout trace.
Producer versions, all published outcomes and exact input bytes stay in experiment receipts.
A complete reanalysis now associates all13760retained ProofNet/mini samples
with four actual serialSGLang output-availability segments. Official Goedel step1 uses a
batched vLLM call, so these clocks do not supply its arrival distribution or
many-producer/feedback traffic. Official step2 submits all completed codes as
a batch; the recovered clocks do not record verifier-request arrivals. Native
preparation costs and real online integration still need their own evidence. [Protocol/source result](tmp/bootstrap/step-0010-20261014T133154+0000/experiment-031/result-review.md).
[Official LP benchmark](https://github.com/leanprover/lp-benchmark) uses a newer small linear tactic-time workload;
it cannot establish a matched whole-source nlinarith speedup on the pinned producer corpus.
A direct follow-up retrievesPR40110 metadata/patch: closed/unmerged, used by
the benchmark through its fork pin; its syntactic atom-lookup cache differs from
resolved product-application reuse. Both are routine CPU optimizations, not this
project's systems novelty. [Pinned source comparison](tmp/bootstrap/step-0010-20261014T133154+0000/mathlib-atom-cache-source-20261015T0750/report.md).
Default cuOpt races CPU and GPU algorithms; real GPU work needs actual method/device evidence.
[The current source handoff](tmp/bootstrap/step-0010-20261014T133154+0000/literature-20261015T1300/baseline-handoff.md)
keeps producer-compatible CPU native compilation mandatory and separates its
one-time build cost from repeated verification. Official4.35 finer precompilation
is current context, not an upgrade to active4.9/4.27 captures. Adjacent ix CUDA
proving supplies representation/accounting ideas, not a replacement task or a
new numerical baseline.


## Baseline Candidates And Controls

| Candidate | Role and qualification |
|---|---|
| Fresh native execution | Behavior/cold-start control; not the strongest warm competitor |
| Exact-result cache / preparation disabled | Ablations with the same valid information and all outcomes |
| Generic COW, preparation depth, shared-process placement | Mechanism controls within the three families; complete closed negatives stay closed |
| Mallob/Bitwuzla | Optional only when solver fragment/deployment matches; not another default quantified-Verus family |
| Native GC/batch, Fast, product reuse, native compilation | Source-grounded implementations; code loading or reduced proof counts alone is dependency/engagement evidence |

## Absorbable Ideas And Adjacent Communities

| Source/community | Useful idea | Required evidence |
|---|---|---|
| Lean/CAV/PLDI | Retain native prefix/config/history rather than reconstructed formulas | Complete native feedback, resource behavior and cost opportunity |
| OSDI/SOSP/EuroSys/ATC | Jointly measure preparation density, mutation and candidate lifetime | Causal multi-context/load/replacement/cancellation experiments beyond ordinary snapshots |
| CPU kernels and certified GPU reasoning | Target costly dynamic work after competent CPU optimization | Full source/checking boundary and useful parallel work, not metadata throughput |

## Venue Evaluation Patterns

Use accepted experimental designs, not imported speedups: real workloads before
mechanism claims; competent alternatives; complete resources and accounting;
whole-run uncertainty and failures; causal explanation of service scaling.
The exact original-stream, multi-context, behavior/resource and useful-device
evidence remains incomplete. No source establishes universal wall-time identity.

## Must-Read List And Novelty Verdict

Read the closest-work sources above together with the preserved detailed source nodes.
Overall same-mechanism risk remains high. The ambitious joint behavior/resource/service
claim remains a hypothesis; current small CPU gains and negative GPU constructors do
not establish it. Citation pressure does not authorize scope reduction, a new name,
or another redundant benchmark. Complete the active admitted matrices, then choose
the decisive next implementation/experiment from their actual strongest-CPU and
native-trace evidence. All RQs, complete paper and independent audit remain open.

## Current expensive-work admission — 2026-10-16 local / 2026-10-17 UTC

The [source/coverage/decision node](tmp/bootstrap/step-0010-20261014T133154+0000/literature-20261017T0212/report.md)
checks candidate proof-computation reuse after the user-directed E038closure.
No new mechanism, native replay, model or full matrix is admitted.

| Primary work | Verified mechanism or asset | Effect on our next decision |
|---|---|---|
| [SHRED a6616e9](https://github.com/memo-ozdincer/shred/tree/a6616e99534ce777dcebfd56566eaaffb63997a8) | Exact tactic prefixes and elaborated-context closing-proof reuse; pinned4.9rc1source and upstream representative CPU aggregates | Plain prefix/certificate reuse is already implemented prior art; upstream4096-pair3.24%CPU reduction and small diagnostic prefix opportunity are not our replay or wall speed |
| [Learned Lean feedback](https://arxiv.org/abs/2610.21881) | GPU verdict/message prediction and approximate hybrid rewards; current repo announces executable code later | Its4.2xH100pipeline comparison does not establish exact native or5090acceleration; do not silently change verification into prediction |
| [Public evaluation corpus](https://huggingface.co/datasets/EPFL-LARA/lean-evaluation-benchmark/tree/0bbf31331bd1c726f539b311cce8b058a821f15c) |68932deduplicated4.15programs/labels, with operational and precheck exclusions | Useful future source asset, not a complete arrival/cost/failure trace or an admitted new full benchmark |
| [NanoProof](https://arxiv.org/abs/2610.11605) / LeanTree | Factorized search/interface and extracted Mathlib/DeepSeek proof trees | Strengthens existing same-mechanism comparison; extracted proofs do not supply complete failed search traffic |

Root recomputes upstream published aggregates, not original private per-pair data or native runs.
Selected per-hit maxima and enriched subsets are not whole-system results.
A future distinct cache mechanism belongs within the existing competent warm/cache baseline family;
citation alone settles generic novelty, so no redundant numerical rerun is needed now.
No source establishes a surviving new high-value implementation here. Preserve allfourRQs/Initial Narrative,
existing negatives and the full Lean/SMT/service/5090goal. Complete-evidence/contribution assessment continues
without reviving E038/E040/scalarGPU or importing another repository's budgets, gates or hash checks.


## 2026-10-18: arithmetic certificate and GPU batching overlap

Exact dual/Farkas certificates for infeasibility are established prior art:
[Schaeffeler and Abdulaziz, AAAI 2025](https://ojs.aaai.org/index.php/AAAI/article/view/34868)
and its [verified LP checker](https://github.com/schaeffm/fmdp_isabelle).
Generic external arithmetic search plus Lean proof reconstruction already
exists in Mathlib and [Farkas](https://github.com/lucifer1004/farkas).
[ICPE 2019](https://doi.org/10.1145/3297663.3310308) already maps one CUDA
block to each LP in a batch. These primitives cannot establish our novelty.

The surviving RQ4 hypothesis concerns complete verification at equal resources:
actual request supply, exact positive/negative termination, independent
cancellation and full setup/fallback costs must beat the strongest CPU path.
A matched 32-candidate-queue capacity preflight tests that uncertainty.
This does not replace the original native-state/service RQs or claim their
completion. [Primary-source review and baseline handoff](tmp/bootstrap/step-0010-20261014T133154+0000/literature-20261018T1036/report.md).


## 2026-10-19: exact arithmetic source comparison

The [source-level follow-up](tmp/bootstrap/step-0010-20261014T133154+0000/literature-20261020T061754Z/report.md) verifies the unchanged Farkas
upstream pin, the actual local reconstruction path, type/fast-path coverage
and the official LP tactic's direct-certificate precedent. Generic external
search and delayed native proof construction remain high-overlap prior
mechanisms. The measured4.27adaptation is not an unchanged upstream4.31
replication. Keep the current full-population experiment and original systems
goal; do not promote a local CPU composition into the missing systems novelty.
No additional numerical main baseline or new acquisition is admitted.


## 2026-10-24: arithmetic counterexample screening

[Bounded primary-source review and own-experiment handoff](tmp/bootstrap/step-0011-20261023T195335-0700/literature-20261024T0630/report.md)
covers sampling, hypothesis satisfaction, subgoal backtracking and current Lean
refutation. Generic counterexample filtering is not our new contribution:
[the Isabelle overview](https://isabelle.in.tum.de/~nipkow/pubs/frocos11.pdf)
and [ACL2 testing integration](https://arxiv.org/html/1105.4394v2) establish
the principle. [Official Lean Plausible source](https://github.com/leanprover-community/plausible/blob/fb13df72ecefd8ddbf9291021d7f33a8673eb57b/Plausible/Tactic.lean)
already tests local goals; [formal counterexample generation](https://arxiv.org/abs/2603.19514)
already requires Lean proofs of refutation. Our CPU rational witness checker
does not itself produce such a Lean proof.

The unresolved claim is useful complete verification savings on real expensive
failed candidates, including all host/device/fallback/cleanup cost at equal
resources. Current cheap witnesses do not establish that claim, and a finite
search finding no direct GPU counterpart does not prove novelty or impossibility.
No additional external reproduction or numerical baseline is admitted. Preserve
the original7808observation; actual completion precedes own native24qualification
and the complete same-candidate native/GPU pair. The source-access and incomplete
coverage limits remain in the detailed report. AllfourRQ/Lean+SMT/OSDI goals remain.


## 2026-10-29: workload and certificate-checking scope

[Completed scoped three-claim review](tmp/build-and-evaluate/step-0123-20261029T063534+0000/literature-20261029T063534+0000/report.md) reads the current paper and verifies primary overlap/protocol boundaries.
Resumable/streamed LRAT-to-Lean import is established in [LRAT-Catcher v2](https://arxiv.org/abs/2607.00815v2);our conversion fusion remains a qualified control,not a novelty claim.
Resource reuse and ordinary first-success scheduling remain prior techniques.
Useful native-preserving failure/memory methods and complete equal-resource
workload evidence remain unproven. No additional competitor reproduction is admitted.


## Resource-failure and exact first-success selection — 2026-10-30

[Primary-source review and applicability](tmp/build-and-evaluate/step-0163-20261030T032548+0000/literature/report.md)
covers [SATzilla](https://arxiv.org/pdf/1111.2249),
[Weitzman's search model](https://dspace.mit.edu/entities/publication/990c36ff-57d4-4d0e-916e-2db6a4e93969),
[Luby restarts](https://www.cs.utexas.edu/~diz/pubs/speedup.pdf),
[SOAP/Gittins](https://arxiv.org/html/1712.00790v2) and
[adaptive Best-of-N stopping](https://arxiv.org/abs/2510.01394).
Feature-based algorithm selection,p/c ordering and restart scheduling are prior
mechanisms. Their assumptions differ from correlated finite candidate groups,
RSS-watchdog failures and charged native kill/restart costs. Exact pass@k
requires exhaustive checking of every observed-unsolved task;generic reward
stopping cannot replace that obligation. A resource-failure record requires a
valid native transition/resource model,not just task,tactic text and an RSS cap.


### Closest Lean failure/cost-control precedents — 2026-10-30

[LeanGraphSearch](https://arxiv.org/html/2610.22339v1),appendixB.4,already skips
recompilation of unchanged deterministic failed candidates and excludes
infrastructure failures. [Cost-quality Lean control](https://arxiv.org/abs/2606.04883)
already uses failure history and predicted success/cost to control generation.
These are direct threats to generic failure-memory or cost-aware-selection
novelty. They do not establish native failed-transition fidelity or monotone
RSS-failure certificates. [Primary-source follow-up](tmp/build-and-evaluate/step-0165-20261030T035108+0000/literature/report.md)
retains the exact scope;no competitor implementation was reproduced.
