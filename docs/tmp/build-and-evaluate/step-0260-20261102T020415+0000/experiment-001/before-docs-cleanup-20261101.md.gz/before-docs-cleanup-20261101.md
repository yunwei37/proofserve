# Root cleanup, 2026-11-01
At 2026-11-01T18:35:17.093236+00:00, the same PVC has 36.679 GiB available before this action, rather than the earlier approximately7.9GiB snapshot. W/O cleanup is separately owned and not attributed to root.

Root removes 344 obsolete page/contact PNG/JPG renderings (210,688,408 logical bytes, 200.928 MiB) only inside prior root step0200–0247 paper-output directories outside Git. Each directory retains its PDF, source/build logs and receipts; these images can be rendered again from the retained PDF. No matching open descriptor was found immediately before unlinking. No source, raw native output, failed/partial record, toolchain, active build, other-lane output or current paper PDF is removed.

Exact [deletion manifest](tmp/build-and-evaluate/step-0250-20261101T183517+0000/experiment-001/deleted-renderings.csv) and [receipt](tmp/build-and-evaluate/step-0250-20261101T183517+0000/experiment-001/cleanup.json). Available bytes after: 39,594,598,400; other lanes can change free space concurrently, so df delta is not our reclamation total. Future paper build uses existing Tectonic cache and retains small outputs; no toolchain/cache installation or native experiment is introduced.

## After current paper review, step0252
After static review of all16pages, remove 24 newly generated page/contact/preview images (15,569,952 bytes) from this root paper output directory. The current167901-byte PDF, initial/final build outputs/logs/receipts and original data remain. [Exact manifest](tmp/build-and-evaluate/step-0252-20261101T184145+0000/experiment-001/post-review-rendering-cleanup.csv). These transient images were created during this task: removing them bounds new build storage and is not an additional pre-existing201MiB reclamation claim.

## After current paper review, step0255
After all17pages/5contacts were statically reviewed, remove 27 current root disposable
page/contact/preview images (16439805bytes) from its own paper-output directory outside Git.
[Manifest](tmp/build-and-evaluate/step-0255-20261101T200059+0000/experiment-001/post-review-rendering-cleanup.csv).
All final/initial PDFs, build logs, frozen source/raw/failed/partial evidence remain.
This bounds this task's generated storage, not another claim of the earlier201MiB recovery.
Observed PVC free space is 37269622784bytes; other owners can change it concurrently.

## After current paper review, step0256
Remove only 28 newly generated disposable root page/contact/preview images
(17748440bytes) after all18pages/5contacts reviewed.
[Exact manifest](tmp/build-and-evaluate/step-0256-20261101T205729+0000/experiment-001/post-review-rendering-cleanup.csv).
Final184684-byte PDF, initial-layout PDF/log and all raw/partial/failed/native/source
remain. These are this step's generated images, not repeated pre-existing cleanup gains.
Observed PVC free36150841344bytes can change concurrently.

## After current paper review, step0257
Only 29 newly generated disposable root page/contact/preview images
(18234040bytes) removed after all19pages/5contacts reviewed.
[Manifest](tmp/build-and-evaluate/step-0257-20261101T215746+0000/experiment-001/post-review-rendering-cleanup.csv).
Current188474-byte PDF, build logs/source/raw/failures/partials and other-lane files retained.
This bounds this step's new renderings, not repeated pre-existing cleanup gains.
Observed PVC free25729204224bytes can change concurrently.

## After current paper review, step0258
Remove only 29 newly generated root page/contact/preview renderings
(18431726bytes) after19pages/5contacts static self-review.
[Manifest](tmp/build-and-evaluate/step-0258-20261101T225830+0000/experiment-001/post-review-rendering-cleanup.csv).
Final189874-byte PDF, build/source/raw/failed/partial artifacts and foreignfiles remain.
This is current generated storage, not another oldcleanup gain.
ObservedPVCfree24943349760bytes may change concurrently.

## After current paper review, step0259
Remove only 29 newly generated root page/contact/preview renderings
(19060165bytes) after19pages/5contacts static self-review.
[Manifest](tmp/build-and-evaluate/step-0259-20261102T000306+0000/experiment-001/post-review-rendering-cleanup.csv).
Final193486-byte PDF, build/source/raw/failed/partial artifacts and foreignfiles remain.
This is current generated storage, not another oldcleanup gain.
ObservedPVCfree24190865408bytes may change concurrently.
